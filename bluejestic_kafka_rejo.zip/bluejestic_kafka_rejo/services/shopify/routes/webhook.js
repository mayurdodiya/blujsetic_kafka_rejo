
const app = require("express")();
const database = require("../../../database/models");
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY, {
    apiVersion: '2023-08-16'
});
const express = require("express");
//* withdrawal payment for seller (type - account)
app.post("/transfer", express.raw({ type: 'application/json' }), async (request, response) => {
    console.log("transfer webhook called", 111111);
    try {
        const sig = request.headers['stripe-signature'];
        console.log("here signature", sig);
        let event;
        let secret = process.env.APP_ENVIRONMENT === 'production' ? process.env.STRIPE_LIVE_TRANSFER_WEBHOOK_KEY : process.env.STRIPE_SIGNING_SECRET_KEY
        event = stripe.webhooks.constructEvent(request.body, sig, secret);

        //* events 
        switch (event.type) {
            case 'transfer.created':
                const transferCreated = event.data.object;
                const id = transferCreated.id;
                let transferPayload = {
                    seller_id: transferCreated.metadata.seller_id,
                    tansaction_id: id,
                    amount: transferCreated.amount,
                    balance_transaction: transferCreated.balance_transaction,
                    currency: transferCreated.currency,
                    destination_id: transferCreated.destination,
                    source_type: transferCreated.source_type,
                }
                await database.SellerTansactionHistory.create(transferPayload)
                break;
            case 'transfer.reversed':
                const transferReversed = event.data.object;
                break;
            case 'transfer.updated':
                const transferUpdated = event.data.object;
                break;
            case 'transter.cancelled':
                const transferCancelled = event.data.object;
                break;
            // case 'account.updated':
            //     const account = event.data.object;
            //     console.log("ACCCOOUNT UPDATED CALLED", account);
            //     await database.Seller.update({ isPaymentOnboardingCompleted: true }, { where: { stripeAccountId: account.id } })
            //     break;
            default:
                console.log(`Unhandled event type ${event.type}`);
        }

        response.send();
        // Return a 200 response to acknowledge receipt of the event
    } catch (err) {
        console.log("000000000000 - errrr", err.message);
        response.status(400).send(`Webhook Error: ${err.message}`);
        return;
    }

})


//* create seller account in stripe (type - connect)
app.post("/connect", express.raw({ type: 'application/json' }), async (request, response) => {
    console.log("transfer webhook called", 111111);
    try {
        const sig = request.headers['stripe-signature'];
        let event;
        let secret = process.env.APP_ENVIRONMENT === 'production' ? process.env.STRIPE_LIVE_CONNECT_WEBHOOK_KEY : process.env.STRIPE_CONNECT_WEBHOOK_KEY
        event = stripe.webhooks.constructEvent(request.body, sig, secret);

        switch (event.type) {

            //* after seller onboarding is completed then account updated called 
            case 'account.updated':
                const account = event.data.object;
                // console.log("ACCCOOUNT UPDATED CALLED", account);
                const seller = await database.Seller.findOne({ where: { stripeAccountId: account.id }, raw: true })
                //* updated status of detail submitted
                await database.Seller.update({ details_submitted: account.details_submitted }, { where: { stripeAccountId: account.id } })
                //* withdraw enabled when payout status is enabled
                if (seller && account.payouts_enabled) {

                    //* update status of account available to transfer money
                    await database.Seller.update({ isPaymentOnboardingCompleted: true }, { where: { stripeAccountId: account.id } })
                    //* add account details */
                    const accountDetails = await stripe.accounts.retrieve(account.id);
                    let acc_details = accountDetails.external_accounts.data[0]
                    let accountPayload = {
                        seller_id: seller.id,
                        type: acc_details.object,
                        brand: acc_details.brand,
                        country: acc_details.country,
                        currency: acc_details.currency,
                        exp_month: acc_details.exp_month,
                        exp_year: acc_details.exp_year,
                        last4: acc_details.last4,
                        account_holder_name: acc_details.account_holder_name,
                        bank_name: acc_details.bank_name,
                        routing_number: acc_details.routing_number,
                    }
                    const isExistsSellerBankAccount = await database.SellerBankAccounts.findOne({ where: { seller_id: seller.id }, raw: true })

                    /* all seller account will deactivated */
                    await database.SellerBankAccounts.update({ isActivated: false }, { where: { seller_id: seller.id } })

                    if (isExistsSellerBankAccount) {
                        await database.SellerBankAccounts.update({ ...accountPayload, isActivated: true }, { where: { seller_id: seller.id } })
                    } else {
                        await database.SellerBankAccounts.create(accountPayload)
                    }
                }
                else
                    await database.Seller.update({ isPaymentOnboardingCompleted: false }, { where: { stripeAccountId: account.id } })
                break;
            case 'account.external_account.updated':
                const external_account_update = event.data.object;
                break;
                //* update nbank or card detaik
            case 'account.external_account.created':
                const updateAccount = event.data.object;
                // console.log("ACCCOOUNT UPDATED CALLED", updateAccount);
                const sellerDetails = await database.Seller.findOne({ where: { stripeAccountId: event.account }, raw: true })
                if (sellerDetails) {
                    /* add updateAccount details */
                    let acc_details = updateAccount
                    let accountPayload = {
                        seller_id: sellerDetails.id,
                        type: acc_details.object,
                        brand: acc_details.brand,
                        country: acc_details.country,
                        currency: acc_details.currency,
                        exp_month: acc_details.exp_month,
                        exp_year: acc_details.exp_year,
                        last4: acc_details.last4,
                        account_holder_name: acc_details.account_holder_name,
                        bank_name: acc_details.bank_name,
                        routing_number: acc_details.routing_number,
                    }
                    const isExistsSellerBankAccount = await database.SellerBankAccounts.findOne({ where: { seller_id: sellerDetails.id }, raw: true })

                    /* all sellerDetails updateAccount will deactivated */
                    await database.SellerBankAccounts.update({ isActivated: false }, { where: { seller_id: sellerDetails.id } })

                    if (isExistsSellerBankAccount) {
                        await database.SellerBankAccounts.update({ ...accountPayload, isActivated: true }, { where: { seller_id: sellerDetails.id } })
                    } else {
                        await database.SellerBankAccounts.create(accountPayload)
                    }
                }
                else
                    await database.Seller.update({ isPaymentOnboardingCompleted: false }, { where: { stripeAccountId: updateAccount.id } })
                break;
                break;
            default:
                console.log(`Unhandled event type ${event.type}`);
        }

        response.send();
    } catch (err) {
        console.log("INTERNAL SERVER ERROR ", err.message);
        response.status(400).send(`Webhook Error: ${err.message}`);
        return;
    }

})

module.exports = app;