const app = require("express")();
const database = require("../../../database/models");
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-08-16",
});
const jwt = require("jsonwebtoken");
const axios = require("axios");
const crypto = require("crypto");

const ShopifyProductService = require("../../../database/services/shopifyProduct");
const elasticClient = require("../../elasticsearch");
const moment = require("moment");
const client = require("../../elasticsearch/config/config");

/* init stripe */
app.get("/", (req, res) => res.send("Welcome to Bluejesctic Payment!"));

//* seller onboarding for add bank details */

app.post("/getproduct", async (req, res) => {
  try {
    if (req.body) {
      console.log("input.id");
      let config = {
        method: "get",
        maxBodyLength: Infinity,
        url: `https://f3ad3d-3.myshopify.com/admin/api/2023-07/products/${req.body.id}.json`,
        headers: {
          "X-Shopify-Access-Token": "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",
          "Content-Type": "application/json",
        },
      };

      let response = await axios(config);
      let input = response.data.product;
      // let inputred = req.body;

      // console.log("input===========================================================================================", inputred);

      if (input.id) {
        let find_product = await database.Product.findOne({
          where: {
            shopify_product_id: input.id.toString(),
          },
        });
        let selectedVariant;
        // console.log("1 >>>>>>>>>>>>>> add", JSON.parse(JSON.stringify(find_product)));

        let product;
        let productInventoryDetail = null;
        if (!find_product) {
          // let selectedVariant;
          console.log("2 >>>>>>>>>>>>>> add");
          let productInput = {};
          let find_color = input?.options?.find((op) => op.name.toLowerCase() === "color");

          async function calculateRatio(height, width) {
            const gcd = (a, b) => {
              if (b === 0) return a;
              return gcd(b, a % b);
            };

            const commonDivisor = gcd(height, width);

            const simplifiedHeight = height / commonDivisor;
            const simplifiedWidth = width / commonDivisor;

            return `${simplifiedWidth} : ${simplifiedHeight}`;
          }

          let get_ratio = "1 : 1";

          if (input?.image) {
            get_ratio = await calculateRatio(input?.image?.height, input?.image?.width);
          }

          if (input?.variants?.length === 1 && input?.variants[0]?.title === "Default Title") {
            let product_detail = input?.variants[0];
            selectedVariant = input?.variants[0];
            productInput = {
              store_id: 1,
              title: input?.title,
              description: input?.body_html,
              isFeature: false,
              status: input?.active === "active" ? "Publish" : "Draft",
              isFreeShipping: false,
              condition: "New",
              metaTitle: "",
              metaDescription: "",
              keywords: "",
              ratio: get_ratio,
              colorVariant: find_color ? find_color?.data?.length : null,
              dis_price: product_detail?.price ? product_detail?.price : null,
              dis_listPrice: product_detail?.compare_at_price ? product_detail?.compare_at_price : null,
              shopify_product_id: input?.id,
            };

            productInventoryDetail = {
              price: product_detail?.price,
              listPrice: product_detail?.compare_at_price,
              quantity: product_detail?.inventory_quantity,
              sku: product_detail?.sku,
            };
          } else {
            const getSelectedVariant = async (variantArray) => {
              if (variantArray.length === 0) {
                // Handle the case where there are no variants.
                return null;
              }

              const isSamePrice = await variantArray.every((variant, index) => {
                return index === 0 || variant.price === variantArray[0].price;
              });

              if (isSamePrice) {
                // All variants have the same price, return the first one.
                return variantArray[0];
              } else {
                // Find the variant with the cheapest price.
                let cheapestVariant = variantArray[0];
                for await (const variant of variantArray) {
                  if (parseFloat(variant.price) < parseFloat(cheapestVariant.price)) {
                    cheapestVariant = variant;
                  }
                }
                return cheapestVariant;
              }
            };

            if (Boolean(input?.variants?.length)) {
              selectedVariant = await getSelectedVariant(input?.variants);
            }

            productInput = {
              store_id: 1,
              title: input?.title,
              description: input?.body_html,
              isFeature: false,
              status: input?.active === "active" ? "Publish" : "Draft",
              isFreeShipping: false,
              condition: "New",
              metaTitle: "",
              metaDescription: "",
              keywords: "",
              ratio: get_ratio,
              colorVariant: find_color ? find_color?.data?.length : null,
              dis_price: selectedVariant?.price ? selectedVariant?.price : null,
              dis_listPrice: selectedVariant?.compare_at_price ? selectedVariant?.compare_at_price : null,
              shopify_product_id: input?.id,
            };
          }

          product = await ShopifyProductService.add(productInput);
          product = JSON.parse(JSON.stringify(product));
          if (productInventoryDetail) {
            let product_inventory = await database.ProductInventory.create({ ...productInventoryDetail, product_id: product.id });
          }

          console.log("input?.images+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", JSON.parse(JSON.stringify(input)));

          //* elastic search - create product ==============
          let elasticsearchInput = productInput;
          elasticsearchInput["id"] = product.id;
          elasticsearchInput["product_id"] = product.id;
          let productImages = [];

          if (Boolean(input?.images?.length)) {
            for (const image_id of input?.images) {
              // console.log("find_images+++++++", find_images);\
              if (image_id?.src) {
                await productImages.push(image_id?.src);
              }
            }
            elasticsearchInput.images = productImages;
          }

          if (find_color) {
            elasticsearchInput.colorVariant = find_color?.data?.length;
          } else {
            elasticsearchInput.colorVariant = null;
          }

          console.log("selectedVariant++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", selectedVariant);

          elasticsearchInput.dis_price = selectedVariant?.price ? selectedVariant?.price : 0;
          elasticsearchInput.dis_listPrice = selectedVariant?.compare_at_price ? selectedVariant?.compare_at_price : 0;
          elasticsearchInput.createdAt = moment().toISOString();
          elasticsearchInput.updatedAt = moment().toISOString();
          let data = await elasticClient.product.addProduct({ ...elasticsearchInput, is_deleted: false });
          if (!data.success) return new Error("Elasticsearch - addProduct - " + data.message);
          //* elastic search - create product end =================

          await database.ProductImageSize.create({ height: input?.image?.height ? input?.image?.height : 1080, width: input?.image?.width ? input?.image?.width : 1080, product_id: product?.id });

          if (Boolean(input?.images?.length)) {
            console.log("4 >>>>>>>>>>>>>> add");
            for await (const img of input?.images) {
              let saved_image_response = await database.Media.create({ shopify_image_id: img.id, media_for: "PRODUCT", media: img?.src });
              if (saved_image_response) {
                await database.ProductMedia.create({
                  product_id: product.id,
                  media_id: saved_image_response.dataValues.id,
                  src: saved_image_response.dataValues.media,
                });
              }
            }
          }

          if (input?.options?.length === 1 && input?.otions && input?.options[0]?.values && input?.options[0]?.values[0] === "Default Title") {
          } else {
            if (input?.options && input?.options[0]?.values && input?.options[0]?.values[0] !== "Default Title") {
              console.log("5 >>>>>>>>>>>>>> add");
              for await (const attr of input?.options) {
                let variant_data = await database.Variation.create({ name: attr.name, product_id: product.id });
                for await (const val of attr?.values) {
                  let variation_option = await database.VariationOption.create({
                    variation_id: variant_data?.dataValues?.id,
                    value: val,
                    product_id: product.id,
                  });
                }
              }
            }
          }

          if (input?.variants?.length === 1 && input?.variants[0]?.title === "Default Title") {
          } else {
            console.log("input?.variants+++++++++++++++++++++++++++++++++++++++++++++++++++++++++", input?.variants);
            if (input?.variants?.length) {
              for await (const attr of input?.variants) {
                const totalVariant = [];
                let i = 1;
                let find_image = await database.Media.findOne({
                  where: {
                    shopify_image_id: attr?.image_id ? attr?.image_id.toString() : "",
                  },
                });
                console.log("6 >>>>>>>>>>>>>> add");

                let updatedObject = {
                  title: attr?.title,
                  inventory_quantity: attr?.inventory_quantity,
                  old_inventory_quantity: attr?.old_inventory_quantity,
                  ...(find_image && {
                    image_id: find_image.id,
                  }),
                  isTaxable: attr?.taxable,
                  grams: attr?.grams,
                  price: attr?.price,
                  listPrice: Number(attr?.compare_at_price),
                  sku: attr?.sku,
                  barcode: attr?.barcode,
                  weightValue: attr?.weight,
                  weightUnit: attr?.weight_unit,
                  length: 10,
                  width: 10,
                  height: 10,
                  product_id: product.id,
                  isRequiresShipping: attr?.requires_shipping,
                  fulfillment_service: attr?.fulfillment_service,
                  inventory_management: attr?.fulfillment_service,
                  position: attr?.position,
                };

                let product_item_id = await database.ProductItem.create(updatedObject);

                console.log("attr+++++++++++++++++++++++++++++++++++++++++++++++++++++++++if", attr);

                while (attr[`option${i}`] !== null) {
                  totalVariant.push(attr[`option${i}`]);
                  i++;
                }

                console.log("totalVarian++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++if", totalVariant);

                if (Boolean(totalVariant?.length)) {
                  for await (const variant of totalVariant) {
                    let find_variant_option = await database.VariationOption.findOne({
                      where: {
                        value: variant,
                      },
                    });
                    if (find_variant_option) {
                      await database.ProductConfiguration.create({
                        product_item_id: product_item_id.id,
                        variant_option_id: find_variant_option.id,
                        product_id: product.id,
                      });
                    }
                  }
                }
              }
            }
          }

          if (Boolean(input?.tags.split(","))) {
            console.log("7 >>>>>>>>>>>>>> add");

            for await (const tag of input?.tags.split(",")) {
              await database.ProductTag.create({ tag: tag, product_id: product.id });
            }
          }
          console.log("8 >>>>>>>>>>>>>> finally-added-successfully---------------------------------------------------------");
          // return res.send(`<h1>Success</h1>`);
        } else {
          product = find_product;
          // console.log("3 >>>>>>>>>>>>>> Already AddedAlready AddedAlready AddedAlready AddedAlready Added");
          // return res.send(`<h1>Already Added</h1>`);

          let remove_from_elastic = await client.deleteByQuery({
            index: "products",
            body: {
              query: {
                term: { product_id: product.id },
              },
            },
          });

          console.log("remove_from_elastic+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", remove_from_elastic);

          let productItems_destroy = await database.ProductItem.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("2 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

          let variation_destroy = await database.Variation.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("3 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

          let variationOptions_destroy = await database.VariationOption.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("4 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

          let product_inventory_destroy = await database.ProductInventory.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("4.5 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

          let productConfigurations_destroy = await database.ProductConfiguration.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("5 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

          let productMedia_destroy = await database.ProductMedia.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("6 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

          let media_destroy = await database.Media.destroy({
            where: {
              parent_id: product.id,
            },
          });
          console.log("7 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

          let size_destroy = await database.ProductImageSize.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("7.5 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

          let attributes_destroy = await database.ProductAttributes.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("7.6 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

          let tag_destroy = await database.ProductTag.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("7.7 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

          let category_destroy = await database.ProductCategories.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("7.99 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

          let productInput = {};

          async function calculateRatio(height, width) {
            const gcd = (a, b) => {
              if (b === 0) return a;
              return gcd(b, a % b);
            };

            const commonDivisor = gcd(height, width);

            const simplifiedHeight = height / commonDivisor;
            const simplifiedWidth = width / commonDivisor;

            return `${simplifiedWidth} : ${simplifiedHeight}`;
          }

          let get_ratio = "1 : 1";

          if (input?.image) {
            get_ratio = await calculateRatio(input?.image?.height, input?.image?.width);
          }

          let find_color = input?.options?.find((op) => op.name.toLowerCase() === "color");
          if (input?.variants?.length === 1 && input?.variants[0]?.title === "Default Title") {
            let product_detail = input?.variants[0];
            selectedVariant = input?.variants[0];
            productInput = {
              store_id: 1,
              title: input?.title,
              description: input?.body_html,
              isFeature: false,
              status: input?.active === "active" ? "Publish" : "Draft",
              isFreeShipping: false,
              condition: "New",
              metaTitle: "",
              metaDescription: "",
              keywords: "",
              ratio: get_ratio,
              colorVariant: find_color ? find_color?.data?.length : null,
              dis_price: product_detail?.price ? product_detail?.price : 0,
              dis_listPrice: product_detail?.compare_at_price ? product_detail?.compare_at_price : 0,
              shopify_product_id: input?.id,
            };

            productInventoryDetail = {
              price: product_detail?.price,
              listPrice: product_detail?.compare_at_price,
              quantity: product_detail?.inventory_quantity,
              sku: product_detail?.sku,
              product_id: product.id,
            };
            let product_inventory = await database.ProductInventory.create({ ...productInventoryDetail, product_id: product.id });
          } else {
            const getSelectedVariant = async (variantArray) => {
              if (variantArray.length === 0) {
                // Handle the case where there are no variants.
                return null;
              }

              const isSamePrice = await variantArray.every((variant, index) => {
                return index === 0 || variant.price === variantArray[0].price;
              });

              if (isSamePrice) {
                // All variants have the same price, return the first one.
                return variantArray[0];
              } else {
                // Find the variant with the cheapest price.
                let cheapestVariant = variantArray[0];
                for await (const variant of variantArray) {
                  if (parseFloat(variant.price) < parseFloat(cheapestVariant.price)) {
                    cheapestVariant = variant;
                  }
                }
                return cheapestVariant;
              }
            };

            if (Boolean(input?.variants?.length)) {
              selectedVariant = await getSelectedVariant(input?.variants);
            }

            productInput = {
              store_id: 1,
              title: input?.title,
              description: input?.body_html,
              isFeature: false,
              status: input?.active === "active" ? "Publish" : "Draft",
              isFreeShipping: false,
              condition: "New",
              metaTitle: "",
              metaDescription: "",
              keywords: "",
              ratio: get_ratio,
              colorVariant: find_color ? find_color?.data?.length : null,
              dis_price: selectedVariant?.price ? selectedVariant?.price : 0,
              dis_listPrice: selectedVariant?.compare_at_price ? selectedVariant?.compare_at_price : 0,
              shopify_product_id: input?.id,
            };
          }

          console.log("8 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

          let response = await database.Product.update(productInput, {
            where: {
              id: product.id,
            },
          });
          console.log("9 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

          //* elastic search - create product ==============
          let elasticsearchInput = productInput;
          elasticsearchInput["id"] = product.id;
          elasticsearchInput["product_id"] = product.id;
          let productImages = [];

          if (Boolean(input?.images?.length)) {
            for (const image_id of input?.images) {
              if (image_id?.src) {
                await productImages.push(image_id?.src);
              }
            }
            elasticsearchInput.images = productImages;
          }

          if (find_color) {
            elasticsearchInput.colorVariant = find_color?.data?.length;
          } else {
            elasticsearchInput.colorVariant = null;
          }

          console.log("---------------------------------------------------------------------------------------dasdasdasdasdasdasdasdasdasdasdasd", selectedVariant);

          elasticsearchInput.dis_price = selectedVariant?.price ? selectedVariant?.price : "0";
          elasticsearchInput.dis_listPrice = selectedVariant?.compare_at_price ? selectedVariant?.compare_at_price : "0";
          elasticsearchInput.createdAt = moment().toISOString();
          elasticsearchInput.updatedAt = moment().toISOString();

          // elasticsearchInput.like_count = 0;
          // elasticsearchInput.comment_count = 0;
          // elasticsearchInput.sharepost_count = 0;

          let data = await elasticClient.product.addProduct({ ...elasticsearchInput, is_deleted: false });
          if (!data.success) return new Error("Elasticsearch - addProduct - " + data.message);
          //* elastic search - create product end =================

          await database.ProductImageSize.create({ height: input?.image?.height ? input?.image?.height : 1080, width: input?.image?.width ? input?.image?.width : 1080, product_id: product?.id });

          if (Boolean(input?.images?.length)) {
            console.log("10 >>>>>>>>>>>>>> add-webhook-in-else-for-update", input?.images);
            for await (const img of input?.images) {
              let saved_image_response = await database.Media.create({
                shopify_image_id: img.id,
                media_for: "PRODUCT",
                media: img?.src,
                parent_id: product.id,
              });
              console.log("saved_image_response", saved_image_response);
              if (saved_image_response) {
                await database.ProductMedia.create({
                  product_id: product.id,
                  media_id: saved_image_response.dataValues.id,
                  src: saved_image_response.dataValues.media,
                });
              }
            }
          }
          if (input?.options?.length === 1 && input?.otions && input?.options[0]?.values && input?.options[0]?.values[0] === "Default Title") {
          } else {
            if (input?.options && input?.options[0]?.values && input?.options[0]?.values[0] !== "Default Title") {
              console.log("11 >>>>>>>>>>>>>> add-webhook-in-else-for-update");
              for await (const attr of input?.options) {
                let variant_data = await database.Variation.create({ name: attr.name, product_id: product.id });
                for await (const val of attr?.values) {
                  let variation_option = await database.VariationOption.create({
                    variation_id: variant_data?.dataValues?.id,
                    value: val,
                    product_id: product.id,
                  });
                }
              }
            }
          }

          if (input?.variants?.length === 1 && input?.variants[0]?.title === "Default Title") {
          } else {
            if (Boolean(input?.variants?.length)) {
              for await (const attr of input?.variants) {
                const totalVariant = [];
                let i = 1;
                let find_image = await database.Media.findOne({
                  where: {
                    shopify_image_id: attr?.image_id ? attr?.image_id.toString() : "",
                  },
                });

                let updatedObject = {
                  title: attr?.title,
                  inventory_quantity: attr?.inventory_quantity,
                  old_inventory_quantity: attr?.old_inventory_quantity,
                  ...(find_image && {
                    image_id: find_image.id,
                  }),
                  isTaxable: attr?.taxable,
                  grams: attr?.grams,
                  price: attr?.price,
                  listPrice: Number(attr?.compare_at_price),
                  sku: attr?.sku,
                  barcode: attr?.barcode,
                  weightValue: attr?.weight,
                  weightUnit: attr?.weight_unit,
                  length: 10,
                  width: 10,
                  height: 10,
                  product_id: product.id,
                  isRequiresShipping: attr?.requires_shipping,
                  fulfillment_service: attr?.fulfillment_service,
                  inventory_management: attr?.fulfillment_service,
                  position: attr?.position,
                };
                let product_item_id = await database.ProductItem.create(updatedObject);
                while (attr[`option${i}`] !== null) {
                  totalVariant.push(attr[`option${i}`]);
                  i++;
                }
                console.log("attr+++++++++++++++++++++++++++++++++++++++++++++++++++++++++else", attr);
                console.log("totalVarian++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++else", totalVariant);
                console.log("totalVarian++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++else", totalVariant);
                for await (const variant of totalVariant) {
                  let find_variant_option = await database.VariationOption.findOne({
                    where: {
                      value: variant,
                    },
                  });
                  if (find_variant_option) {
                    await database.ProductConfiguration.create({
                      product_item_id: product_item_id.id,
                      variant_option_id: find_variant_option.id,
                      product_id: product.id,
                    });
                  }
                }
              }
            }
          }

          if (Boolean(input?.tags.split(","))) {
            console.log("12 >>>>>>>>>>>>>> add-webhook-in-else-for-update");
            for await (const tag of input?.tags.split(",")) {
              await database.ProductTag.create({ tag: tag, product_id: product.id });
            }
          }
        }
      }
    }
  } catch (error) {
    console.log("error9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+", error);
  }
});

app.post("/updated-product", async (req, res) => {
  try {
    if (req.body.id) {
      console.log("input.id");
      let config = {
        method: "get",
        maxBodyLength: Infinity,
        url: `https://f3ad3d-3.myshopify.com/admin/api/2023-07/products/${req.body.id}.json`,
        headers: {
          "X-Shopify-Access-Token": "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",
          "Content-Type": "application/json",
        },
      };

      let response = await axios(config);
      let input = response.data.product;

      console.log("input+++++++", JSON.parse(JSON.stringify(input)));

      if (input.id) {
        console.log("1 >>>>>>>>>>>>>> update");
        let product = await database.Product.findOne({
          where: {
            shopify_product_id: input.id.toString(),
          },
        });

        if (product) {
          let productItems_destroy = await database.ProductItem.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("2 >>>>>>>>>>>>>> update");

          let variation_destroy = await database.Variation.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("3 >>>>>>>>>>>>>> update");

          let variationOptions_destroy = await database.VariationOption.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("4 >>>>>>>>>>>>>> update");

          let productConfigurations_destroy = await database.ProductConfiguration.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("5 >>>>>>>>>>>>>> update");

          let productMedia_destroy = await database.ProductMedia.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("6 >>>>>>>>>>>>>> update");

          let media_destroy = await database.Media.destroy({
            where: {
              parent_id: product.id,
            },
          });
          console.log("7 >>>>>>>>>>>>>> update");

          let productInput = {
            title: input?.title,
            description: input?.body_html,
            isFeature: false,
            isActive: input?.status === "draft" ? false : true,
            isVisible: input?.status === "draft" ? false : true,
            isFreeShipping: false,
            condition: "New",
            shopify_product_id: input?.id,
            store_id: 1,
          };
          console.log("8 >>>>>>>>>>>>>> update");

          let response = await database.Product.update(productInput, {
            where: {
              id: product.id,
            },
          });
          console.log("9 >>>>>>>>>>>>>> update");

          let size_destroy = await database.ProductImageSize.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("9.5 >>>>>>>>>>>>>> update");

          let attributes_destroy = await database.ProductAttributes.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("9.6 >>>>>>>>>>>>>> update");

          let tag_destroy = await database.ProductTag.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("9.7 >>>>>>>>>>>>>> update");

          let category_destroy = await database.ProductCategories.destroy({
            where: {
              product_id: product.id,
            },
          });
          console.log("9.99 >>>>>>>>>>>>>> update");

          if (Boolean(input?.images?.length)) {
            console.log("10 >>>>>>>>>>>>>> update", input?.images);
            for await (const img of input?.images) {
              let saved_image_response = await database.Media.create({
                shopify_image_id: img.id,
                media_for: "PRODUCT",
                media: img?.src,
                parent_id: product.id,
              });
              console.log("saved_image_response", saved_image_response);
              if (saved_image_response) {
                await database.ProductMedia.create({
                  product_id: product.id,
                  media_id: saved_image_response.dataValues.id,
                  src: saved_image_response.dataValues.media,
                });
              }
            }
          }

          if (Boolean(input?.options?.length)) {
            console.log("11 >>>>>>>>>>>>>> update");
            for await (const attr of input?.options) {
              let variant_data = await database.Variation.create({ name: attr.name, product_id: product.id });
              for await (const val of attr?.values) {
                let variation_option = await database.VariationOption.create({
                  variation_id: variant_data?.dataValues?.id,
                  value: val,
                  product_id: product.id,
                });
              }
            }
          }

          for await (const attr of input?.variants) {
            const totalVariant = [];
            let i = 1;
            let find_image = await database.Media.findOne({
              where: {
                shopify_image_id: attr?.image_id ? attr?.image_id.toString() : "",
              },
            });

            console.log("find_image++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", find_image);
            let updatedObject = {
              title: attr?.title,
              inventory_quantity: attr?.inventory_quantity,
              old_inventory_quantity: attr?.old_inventory_quantity,
              ...(find_image && {
                image_id: find_image.id,
              }),
              isTaxable: attr?.taxable,
              grams: attr?.grams,
              price: attr?.price,
              sku: attr?.sku,
              barcode: attr?.barcode,
              weightValue: attr?.weight,
              weightUnit: attr?.weight_unit,
              length: 10,
              width: 10,
              height: 10,
              product_id: product.id,
              isRequiresShipping: attr?.requires_shipping,
              fulfillment_service: attr?.fulfillment_service,
              inventory_management: attr?.fulfillment_service,
              position: attr?.position,
            };
            let product_item_id = await database.ProductItem.create(updatedObject);
            while (attr[`option${i}`] !== null) {
              totalVariant.push(attr[`option${i}`]);
              i++;
            }
            console.log("totalVarian++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++t", totalVariant);
            for await (const variant of totalVariant) {
              let find_variant_option = await database.VariationOption.findOne({
                where: {
                  value: variant,
                },
              });
              if (find_variant_option) {
                await database.ProductConfiguration.create({
                  product_item_id: product_item_id.id,
                  variant_option_id: find_variant_option.id,
                  product_id: product.id,
                });
              }
            }
          }

          if (Boolean(input?.tags.split(","))) {
            console.log("12 >>>>>>>>>>>>>> update");
            for await (const tag of input?.tags.split(",")) {
              await database.ProductTag.create({ tag: tag, product_id: product.id });
            }
          }
          console.log("12 >>>>>>>>>>>>>> finally-update-successfully---------------------------------------------------------");

          return res.send(`
        <h1>Success</h1>
        `);
        } else {
          console.log("3 >>>>>>>>>>>>>> Product not found | Product not found | Product not found | Product not found | Added");
          return res.send(`
          <h1>Product not found</h1>
          `);
        }
      }
    }
  } catch (error) {
    // console.log(
    //   "bodddddddddddddddddddddddddddddddddyerror9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+",
    //   error
    // );
    // res.status(500).send({
    //   error: err.message,
    // });
  }
});

app.post("/order-creation", async (req, res) => {
  console.log("order-creation++++++++++++++++++++++++++++++++", JSON.parse(JSON.stringify(req.body)));

  const add_webhook = await database.WebhookData.create({
    type: 'order-creation',
    json: req.body
  })

  if (req?.body?.id) {
    const order_detail = req?.body;

    const find_shopify_order = await database.OrderMaster.findOne({
      where: {
        shopify_order_id: String(order_detail?.id),
      },
      raw: true,
    });

    console.log("find_shopify_order", find_shopify_order);

    if (find_shopify_order) {
      const update = await database.OrderMaster.update(
        {
          order_status: order_detail.fulfillment_status ? order_detail.fulfillment_status : "pending",
          shopify_order_status_url: order_detail.order_status_url,
        },
        {
          where: {
            shopify_order_id: String(req?.body?.id),
          },
        }
      );

      for (let i = 0; i < order_detail.line_items; i++) {
        let order_item = order_detail.line_items[i];

        const update_order_item = await database.OrderItems.update(
          {
            order_status: "pending",
            // order_status: order_item?.fulfillment_status ? order_item?.fulfillment_status : "pending",
          },
          {
            where: {
              shopify_order_item_id: order_item?.id ? String(order_item?.id) : null,
              shopify_product_id: String(order_item?.product_id)
            },
          }
        );
      }

      for (let i = 0; i < order_detail.fulfillments?.length; i++) {
        let fulfilled = order_detail.fulfillments[i];
        for (let i = 0; i < fulfilled?.line_items?.length; i++) {
          let line_item = fulfilled?.line_items[i];
          const update = await database.OrderItems.update(
            {
              order_status: fulfilled.shipment_status,
              tracking_number: fulfilled.tracking_number,
              fulfillment_status: fulfilled?.fulfillment_status,
              trackingUrl: fulfilled.tracking_url,
              shopify_fulfillment_id: String(fulfilled?.id),
            },
            {
              where: {
                order_master_id: find_shopify_order?.id,
                shopify_product_id: String(line_item?.product_id),
                shopify_order_item_id: String(line_item?.id),
              },
            }
          );
          console.log('updatesadasdasdqweqw', update);

        }
      }
    }
  } else {
    console.log("<<<<<<<<<<<<<<<<< order-creation Log Not Found >>>>>>>>>>>>>>>>");
  }
});

app.post("/order-update", async (req, res) => {
  console.log("order-update++++++++++++++++++++++++++++++++", JSON.parse(JSON.stringify(req.body)));
  const add_webhook = await database.WebhookData.create({
    type: 'order-update',
    json: req.body
  })

  try {
    // const req = {
    //  body: { "id": 6187326144811, "admin_graphql_api_id": "gid://shopify/Order/6187326144811", "app_id": 65349779457, "browser_ip": null, "buyer_accepts_marketing": false, "cancel_reason": null, "cancelled_at": null, "cart_token": null, "checkout_id": null, "checkout_token": null, "client_details": null, "closed_at": "2024-11-26T12:51:24-05:00", "confirmation_number": "TMKM7UDGT", "confirmed": true, "contact_email": "jplaisir@bluejestic.com", "created_at": "2024-11-26T01:08:07-05:00", "currency": "USD", "current_subtotal_price": "30.00", "current_subtotal_price_set": { "shop_money": { "amount": "30.00", "currency_code": "USD" }, "presentment_money": { "amount": "30.00", "currency_code": "USD" } }, "current_total_additional_fees_set": null, "current_total_discounts": "0.00", "current_total_discounts_set": { "shop_money": { "amount": "0.00", "currency_code": "USD" }, "presentment_money": { "amount": "0.00", "currency_code": "USD" } }, "current_total_duties_set": null, "current_total_price": "30.00", "current_total_price_set": { "shop_money": { "amount": "30.00", "currency_code": "USD" }, "presentment_money": { "amount": "30.00", "currency_code": "USD" } }, "current_total_tax": "0.00", "current_total_tax_set": { "shop_money": { "amount": "0.00", "currency_code": "USD" }, "presentment_money": { "amount": "0.00", "currency_code": "USD" } }, "customer_locale": null, "device_id": null, "discount_codes": [], "email": "jplaisir@bluejestic.com", "estimated_taxes": false, "financial_status": "paid", "fulfillment_status": "fulfilled", "landing_site": null, "landing_site_ref": null, "location_id": null, "merchant_of_record_app_id": null, "name": "#1074", "note": null, "note_attributes": [{ "name": "Supplier 1 Name", "value": "B.Tiff New York" }, { "name": "Supplier 1 Order", "value": "btiff.com#12919" }, { "name": "Supplier 1 Order Date", "value": "11/26/2024 1:09 AM" }], "number": 74, "order_number": 1074, "order_status_url": "https://glamcozynest.myshopify.com/84207042859/orders/14cf3ce444db3736a84c8d250d01486e/authenticate?key=1d0184c6c950cc4f4e00e18a480ab5e4", "original_total_additional_fees_set": null, "original_total_duties_set": null, "payment_gateway_names": [], "phone": null, "po_number": null, "presentment_currency": "USD", "processed_at": "2024-11-26T01:08:07-05:00", "reference": null, "referring_site": null, "source_identifier": null, "source_name": "65349779457", "source_url": null, "subtotal_price": "30.00", "subtotal_price_set": { "shop_money": { "amount": "30.00", "currency_code": "USD" }, "presentment_money": { "amount": "30.00", "currency_code": "USD" } }, "tags": "Carro Supplier - B.Tiff New York", "tax_exempt": false, "tax_lines": [], "taxes_included": false, "test": false, "token": "14cf3ce444db3736a84c8d250d01486e", "total_discounts": "0.00", "total_discounts_set": { "shop_money": { "amount": "0.00", "currency_code": "USD" }, "presentment_money": { "amount": "0.00", "currency_code": "USD" } }, "total_line_items_price": "30.00", "total_line_items_price_set": { "shop_money": { "amount": "30.00", "currency_code": "USD" }, "presentment_money": { "amount": "30.00", "currency_code": "USD" } }, "total_outstanding": "30.00", "total_price": "30.00", "total_price_set": { "shop_money": { "amount": "30.00", "currency_code": "USD" }, "presentment_money": { "amount": "30.00", "currency_code": "USD" } }, "total_shipping_price_set": { "shop_money": { "amount": "0.00", "currency_code": "USD" }, "presentment_money": { "amount": "0.00", "currency_code": "USD" } }, "total_tax": "0.00", "total_tax_set": { "shop_money": { "amount": "0.00", "currency_code": "USD" }, "presentment_money": { "amount": "0.00", "currency_code": "USD" } }, "total_tip_received": "0.00", "total_weight": 0, "updated_at": "2024-11-27T01:44:34-05:00", "user_id": null, "billing_address": null, "customer": { "id": 8259001844011, "email": "jplaisir@bluejestic.com", "created_at": "2024-10-19T09:09:57-04:00", "updated_at": "2024-11-26T08:04:47-05:00", "first_name": "Jude", "last_name": "Plaisir", "state": "disabled", "note": null, "verified_email": true, "multipass_identifier": null, "tax_exempt": false, "phone": null, "email_marketing_consent": { "state": "not_subscribed", "opt_in_level": "single_opt_in", "consent_updated_at": null }, "sms_marketing_consent": null, "tags": "", "currency": "USD", "tax_exemptions": [], "admin_graphql_api_id": "gid://shopify/Customer/8259001844011", "default_address": { "id": 10282523885867, "customer_id": 8259001844011, "first_name": "Jude", "last_name": "Plaisir", "company": null, "address1": "8700 Maitland Summit Bvld Apt 204", "address2": null, "city": "Orlando", "province": "Florida", "country": "United States", "zip": "32810", "phone": "3216620185", "name": "Jude Plaisir", "province_code": "FL", "country_code": "US", "country_name": "United States", "default": true } }, "discount_applications": [], "fulfillments": [{ "id": 5478866092331, "admin_graphql_api_id": "gid://shopify/Fulfillment/5478866092331", "created_at": "2024-11-26T12:51:24-05:00", "location_id": 93675454763, "name": "#1074.1", "order_id": 6187326144811, "origin_address": {}, "receipt": {}, "service": "carro-partnerships", "shipment_status": "confirmed", "status": "success", "tracking_company": "USPS", "tracking_number": "420328109300110597203766567344", "tracking_numbers": ["420328109300110597203766567344"], "tracking_url": "https://tools.usps.com/go/TrackConfirmAction_input?qtc_tLabels1=420328109300110597203766567344", "tracking_urls": ["https://tools.usps.com/go/TrackConfirmAction_input?qtc_tLabels1=420328109300110597203766567344"], "updated_at": "2024-11-27T01:44:34-05:00", "line_items": [{ "id": 15726594228523, "admin_graphql_api_id": "gid://shopify/LineItem/15726594228523", "attributed_staffs": [], "current_quantity": 1, "fulfillable_quantity": 0, "fulfillment_service": "carro-partnerships", "fulfillment_status": "fulfilled", "gift_card": false, "grams": 0, "name": "ER300RG B.Tiff Rose Gold Hoop Earrings by B.Tiff New York - Gold", "price": "30.00", "price_set": { "shop_money": { "amount": "30.00", "currency_code": "USD" }, "presentment_money": { "amount": "30.00", "currency_code": "USD" } }, "product_exists": true, "product_id": 8894083727659, "properties": [], "quantity": 1, "requires_shipping": true, "sku": "carro-10899704", "taxable": true, "title": "ER300RG B.Tiff Rose Gold Hoop Earrings by B.Tiff New York", "total_discount": "0.00", "total_discount_set": { "shop_money": { "amount": "0.00", "currency_code": "USD" }, "presentment_money": { "amount": "0.00", "currency_code": "USD" } }, "variant_id": 47486284398891, "variant_inventory_management": "carro-partnerships", "variant_title": "Gold", "vendor": "B.Tiff New York", "tax_lines": [], "duties": [], "discount_allocations": [] }] }], "line_items": [{ "id": 15726594228523, "admin_graphql_api_id": "gid://shopify/LineItem/15726594228523", "attributed_staffs": [], "current_quantity": 1, "fulfillable_quantity": 0, "fulfillment_service": "carro-partnerships", "fulfillment_status": "fulfilled", "gift_card": false, "grams": 0, "name": "ER300RG B.Tiff Rose Gold Hoop Earrings by B.Tiff New York - Gold", "price": "30.00", "price_set": { "shop_money": { "amount": "30.00", "currency_code": "USD" }, "presentment_money": { "amount": "30.00", "currency_code": "USD" } }, "product_exists": true, "product_id": 8894083727659, "properties": [], "quantity": 1, "requires_shipping": true, "sku": "carro-10899704", "taxable": true, "title": "ER300RG B.Tiff Rose Gold Hoop Earrings by B.Tiff New York", "total_discount": "0.00", "total_discount_set": { "shop_money": { "amount": "0.00", "currency_code": "USD" }, "presentment_money": { "amount": "0.00", "currency_code": "USD" } }, "variant_id": 47486284398891, "variant_inventory_management": "carro-partnerships", "variant_title": "Gold", "vendor": "B.Tiff New York", "tax_lines": [], "duties": [], "discount_allocations": [] }], "payment_terms": null, "refunds": [], "shipping_address": { "first_name": "Jude", "address1": "8700 Maitland Summit Blvd Apt 204", "phone": "3216620185", "city": "Orlando", "zip": "32810", "province": "Florida", "country": "United States", "last_name": "Plaisir", "address2": "", "company": "", "latitude": 28.6372947, "longitude": -81.399755, "name": "Jude Plaisir", "country_code": "US", "province_code": "FL" }, "shipping_lines": [] }
    // }
    console.log('req?.body?.id', req?.body?.id);

    if (req?.body?.id) {
      const order_detail = req?.body;

      const find_shopify_order = await database.OrderMaster.findOne({
        where: {
          shopify_order_id: String(order_detail?.id),
        },
        raw: true,
      });


      if (find_shopify_order) {
        const update = await database.OrderMaster.update(
          {
            fulfillment_status: order_detail.fulfillment_status ? order_detail.fulfillment_status : "pending",
            shopify_order_status_url: order_detail.order_status_url,
          },
          {
            where: {
              shopify_order_id: String(req?.body?.id),
            },
          }
        );
        console.log("find_shopify_orderdasdas", order_detail.line_items, order_detail.fulfillments);

        for (let i = 0; i < order_detail.line_items; i++) {
          let order_item = order_detail.line_items[i];

          const update_order_item = await database.OrderItems.update(
            {
              fulfillment_status: order_item?.fulfillment_status ? order_item?.fulfillment_status : "pending",
            },
            {
              where: {
                shopify_order_item_id: order_item?.id ? String(order_item?.id) : null,
              },
            }
          );
        }

        for (let i = 0; i < order_detail.fulfillments?.length; i++) {
          let fulfilled = order_detail.fulfillments[i];
          for (let i = 0; i < fulfilled?.line_items?.length; i++) {
            let line_item = fulfilled?.line_items[i];
            const update = await database.OrderItems.update(
              {
                order_status: fulfilled.shipment_status,
                tracking_number: fulfilled.tracking_number,
                fulfillment_status: fulfilled?.fulfillment_status,
                trackingUrl: fulfilled.tracking_url,
                shopify_fulfillment_id: String(fulfilled?.id),
              },
              {
                where: {
                  order_master_id: find_shopify_order?.id,
                  shopify_product_id: String(line_item?.product_id),
                  shopify_order_item_id: String(line_item?.id),
                },
              }
            );
            console.log('updatesadasdasdqweqw', update);

          }
        }
      }
    } else {
      console.log("<<<<<<<<<<<<<<<<< order-creation Log Not Found >>>>>>>>>>>>>>>>");
    }
  } catch (error) {
    console.log('error', error);

  }

});

app.post("/order-fulfillment", async (req, res) => {
  console.log("order-fulfillment++++++++++++++++++++++++++++++++", JSON.parse(JSON.stringify(req.body)));
  const add_webhook = await database.WebhookData.create({
    type: 'order-fulfillment',
    json: req.body
  })
  if (req?.body?.id) {
    const order_detail = req?.body;

    const find_shopify_order = await database.OrderMaster.findOne({
      where: {
        shopify_order_id: String(order_detail?.id),
      },
      raw: true,
    });

    console.log("find_shopify_order", find_shopify_order);

    if (find_shopify_order) {
      const update = await database.OrderMaster.update(
        {
          order_status: order_detail.fulfillment_status ? order_detail.fulfillment_status : "pending",
          shopify_order_status_url: order_detail.order_status_url,
        },
        {
          where: {
            shopify_order_id: String(req?.body?.id),
          },
        }
      );

      for (let i = 0; i < order_detail.line_items; i++) {
        let order_item = order_detail.line_items[i];

        const update_order_item = await database.OrderItems.update(
          {
            order_status: order_item?.fulfillment_status ? order_item?.fulfillment_status : "pending",
          },
          {
            where: {
              shopify_order_item_id: order_item?.id ? String(order_item?.id) : null,
            },
          }
        );
      }
    }
  } else {
    console.log("<<<<<<<<<<<<<<<<< order-creation Log Not Found >>>>>>>>>>>>>>>>");
  }
});

app.post("/fulfillment-creation", async (req, res) => {
  console.log("fulfillment-creation++++++++++++++++++++++++++++++++", JSON.parse(JSON.stringify(req.body)));
  const add_webhook = await database.WebhookData.create({
    type: 'fulfillment-creation',
    json: req.body
  })
  if (req?.body?.id) {
    const order_detail = req?.body;

    const find_shopify_order = await database.OrderMaster.findOne({
      where: {
        shopify_order_id: String(order_detail?.order_id),
      },
      raw: true,
    });

    console.log("find_shopify_order", find_shopify_order);

    if (find_shopify_order && order_detail?.line_items?.length > 0) {
      let item_data = order_detail?.line_items[0]
      const update = await database.OrderItems.update(
        {
          shopify_fulfillment_id: String(order_detail.id),
          order_status: order_detail.shipment_status,
          tracking_number: order_detail.tracking_number,
          fulfillment_status: item_data?.fulfillment_status,
          trackingUrl: order_detail.tracking_url,
        },
        {
          where: {
            order_master_id: find_shopify_order?.id,
            shopify_product_id: String(item_data?.product_id),
            shopify_order_id: String(order_detail?.order_id),
          },
        }
      );
    }
  } else {
    console.log("<<<<<<<<<<<<<<<<< order-creation Log Not Found >>>>>>>>>>>>>>>>");
  }
});

app.post("/fulfillment-update", async (req, res) => {
  // console.log("fulfillment-update++++++++++++++++++++++++++++++++", JSON.parse(JSON.stringify(req.body)));
  // const add_webhook = await database.WebhookData.create({
  //   type: 'fulfillment-update',
  //   json: req.body
  // })

  // const req = {
  //   body: { "id": 5478866092331, "order_id": 6187326144811, "status": "success", "created_at": "2024-11-26T12:51:24-05:00", "service": "carro-partnerships", "updated_at": "2024-11-27T01:44:34-05:00", "tracking_company": "USPS", "shipment_status": "confirmed", "location_id": 93675454763, "origin_address": null, "email": "jplaisir@bluejestic.com", "destination": { "first_name": "Jude", "address1": "8700 Maitland Summit Blvd Apt 204", "phone": "3216620185", "city": "Orlando", "zip": "32810", "province": "Florida", "country": "United States", "last_name": "Plaisir", "address2": "", "company": "", "latitude": 28.6372947, "longitude": -81.399755, "name": "Jude Plaisir", "country_code": "US", "province_code": "FL" }, "line_items": [{ "id": 15726594228523, "variant_id": 47486284398891, "title": "ER300RG B.Tiff Rose Gold Hoop Earrings by B.Tiff New York", "quantity": 1, "sku": "carro-10899704", "variant_title": "Gold", "vendor": "B.Tiff New York", "fulfillment_service": "carro-partnerships", "product_id": 8894083727659, "requires_shipping": true, "taxable": true, "gift_card": false, "name": "ER300RG B.Tiff Rose Gold Hoop Earrings by B.Tiff New York - Gold", "variant_inventory_management": "carro-partnerships", "properties": [], "product_exists": true, "fulfillable_quantity": 0, "grams": 0, "price": "30.00", "total_discount": "0.00", "fulfillment_status": "fulfilled", "price_set": { "shop_money": { "amount": "30.00", "currency_code": "USD" }, "presentment_money": { "amount": "30.00", "currency_code": "USD" } }, "total_discount_set": { "shop_money": { "amount": "0.00", "currency_code": "USD" }, "presentment_money": { "amount": "0.00", "currency_code": "USD" } }, "discount_allocations": [], "duties": [], "admin_graphql_api_id": "gid://shopify/LineItem/15726594228523", "tax_lines": [] }], "tracking_number": "420328109300110597203766567344", "tracking_numbers": ["420328109300110597203766567344"], "tracking_url": "https://tools.usps.com/go/TrackConfirmAction_input?qtc_tLabels1=420328109300110597203766567344", "tracking_urls": ["https://tools.usps.com/go/TrackConfirmAction_input?qtc_tLabels1=420328109300110597203766567344"], "receipt": {}, "name": "#1074.1", "admin_graphql_api_id": "gid://shopify/Fulfillment/5478866092331" }
  // }

  if (req?.body?.id) {
    const order_detail = req?.body;

    const find_shopify_order = await database.OrderMaster.findOne({
      where: {
        shopify_order_id: String(order_detail?.order_id),
      },
      raw: true,
    });

    console.log("find_shopify_order", order_detail?.line_items, order_detail.shipment_status);

    if (find_shopify_order) {
      for (let i = 0; i < order_detail?.line_items?.length; i++) {
        let line_item = order_detail?.line_items[i];
        const update = await database.OrderItems.update(
          {
            order_status: order_detail.shipment_status,
            tracking_number: order_detail.tracking_number,
            fulfillment_status: order_detail?.fulfillment_status,
            trackingUrl: order_detail.tracking_url,
            shopify_fulfillment_id: String(order_detail?.id),
          },
          {
            where: {
              order_master_id: find_shopify_order?.id,
              shopify_product_id: String(line_item?.product_id),
              shopify_order_item_id: String(line_item?.id),
            },
          }
        );
        console.log('updatesadasdasdqweqw', update);

      }


      // const update = await database.OrderItems.update(
      //   {
      //     order_status: order_detail.shipment_status,
      //     tracking_number: order_detail.tracking_number,
      //     fulfillment_status: order_detail?.fulfillment_status,
      //     trackingUrl: order_detail.tracking_url,
      //     shopify_fulfillment_id: String(order_detail?.id),
      //   },
      //   {
      //     where: {
      //       order_master_id: find_shopify_order?.id,
      //       shopify_product_id: String(item_data?.product_id),
      //       shopify_order_item_id: String(item_data?.id),
      //     },
      //   }
      // );
      // console.log('dasdsadasdasda', update);

    }
  } else {
    console.log("<<<<<<<<<<<<<<<<< order-creation Log Not Found >>>>>>>>>>>>>>>>");
  }
});

app.post("/fulfillment-fulfilled", async (req, res) => {
  console.log("fulfillment-fulfilled++++++++++++++++++++++++++++++++", JSON.parse(JSON.stringify(req.body)));
  const add_webhook = await database.WebhookData.create({
    type: 'fulfillment-fulfilled',
    json: req.body
  })
  if (req?.body?.id) {
    const order_detail = req?.body;

    const find_shopify_order = await database.OrderMaster.findOne({
      where: {
        shopify_order_id: String(order_detail?.order_id),
      },
      raw: true,
    });

    console.log("find_shopify_order", find_shopify_order);
    if (find_shopify_order && order_detail?.line_items?.length > 0) {
      let item_data = order_detail?.line_items[0]
      const update = await database.OrderItems.update(
        {
          order_status: order_detail.shipment_status,
          tracking_number: order_detail.tracking_number,
          fulfillment_status: item_data?.fulfillment_status,
          trackingUrl: order_detail.tracking_url,
        },
        {
          where: {
            shopify_fulfillment_id: String(order_detail?.id),
            order_master_id: find_shopify_order?.id,
            shopify_product_id: String(item_data?.product_id),
            shopify_order_id: String(order_detail?.order_id),
          },
        }
      );
    }

  } else {
    console.log("<<<<<<<<<<<<<<<<< order-creation Log Not Found >>>>>>>>>>>>>>>>");
  }
});

app.post("/fulfillment-request-accepted", async (req, res) => {
  console.log("fulfillment-request-accepted++++++++++++++++++++++++++++++++", JSON.parse(JSON.stringify(req.body)));
  const add_webhook = await database.WebhookData.create({
    type: 'fulfillment-request-accepted',
    json: req.body
  })
  if (req?.body?.id) {
    const order_detail = req?.body;

    const find_shopify_order = await database.OrderMaster.findOne({
      where: {
        shopify_order_id: String(order_detail?.order_id),
      },
      raw: true,
    });

    console.log("find_shopify_order", find_shopify_order);

    if (find_shopify_order) {
      const update = await database.OrderMaster.update(
        {
          order_status: order_detail.status,
          shopify_order_status_url: order_detail.tracking_url,
        },
        {
          where: {
            shopify_order_id: String(order_detail?.order_id),
          },
        }
      );

      for (let i = 0; i < order_detail.line_items; i++) {
        let order_item = order_detail.line_items[i];

        const update_order_item = await database.OrderItems.update(
          {
            order_status: order_item?.fulfillment_status ? order_item?.fulfillment_status : 'pending',
            trackingUrl: order_detail.tracking_url,
            tracking_number: order_detail.tracking_number
          },
          {
            where: {
              shopify_order_item_id: order_item?.id ? String(order_item?.id) : null,
            },
          }
        );
      }
    }
  } else {
    console.log("<<<<<<<<<<<<<<<<< order-creation Log Not Found >>>>>>>>>>>>>>>>");
  }
});

app.post("/order-update", async (req, res) => {
  const order_detail = req?.body;
  const add_webhook = await database.WebhookData.create({
    type: 'order-update',
    json: req.body
  })
  console.log("order Update is calling +++++++++++++++++", order_detail);
  try {
  } catch (error) {
    console.log("error", error);
  }
});


module.exports = app;
