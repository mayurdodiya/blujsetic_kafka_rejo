
const app = require("express")();
const database = require("../../../database/models");
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY, {
    apiVersion: '2023-08-16'
});
const express = require("express");
const utils = require("../../../utils/utils");

//* transfer payment for seller (type - connect account)
app.post("/transfer", express.json({ type: 'application/json' }), async (request, response) => {
    console.log("transfer webhook called", 111111);
    try {
        const plainObject = request.body;

        const sripe_webhook = await database.StripeWebhook.create({
            type: plainObject?.type,
            json: plainObject?.data?.object
        })

        //* events 
        switch (plainObject.type) {
            case 'transfer.created':
                const transferCreated = plainObject.data.object;
                let transferPayload = {
                    seller_id: transferCreated?.metadata?.seller_id,
                    transfer_id: transferCreated?.id,
                    amount: transferCreated?.amount / 100,
                    balance_transaction: transferCreated?.balance_transaction,
                    currency: transferCreated?.currency,
                    destination_id: transferCreated?.destination,
                    source_type: transferCreated?.source_type,
                    type: transferCreated?.object,
                    amount_reversed: transferCreated?.amount_reversed,
                    description: transferCreated?.description,
                    payment_destination: transferCreated?.destination_payment,
                    liveMode: transferCreated?.livemode,
                    reversed: transferCreated?.reversed,
                    created_date_by_stripe: String(transferCreated?.created)
                }
                const checkifExists = await database.SellerTansactionHistory.findOne({ where: { transfer_id: transferCreated?.id }, raw: true })
                if (checkifExists) {
                    await database.SellerTansactionHistory.update(transferPayload, {
                        where: {
                            transfer_id: transferCreated?.id
                        }
                    })
                } else {
                    await database.SellerTansactionHistory.create(transferPayload)
                }
                break;
            case 'transfer.reversed':
                const transferReversed = plainObject.data.object;
                break;
            case 'transfer.updated':
                const transferUpdated = plainObject.data.object;
                break;
            case 'transter.cancelled':
                const transferCancelled = plainObject.data.object;
                break;
            default:
                console.log(`Unhandled event type ${plainObject.type}`);
        }

        response.json({ received: true });
        // Return a 200 response to acknowledge receipt of the event
    } catch (error) {
        console.log("An error occured while transfer webhook calling: ", error.message);
        return response.status(500).json({
            success: false,
            message: error?.message
        })
    }

})

//* payout payment for seller (type - bank account)
app.post("/payout", express.json({ type: 'application/json' }), async (request, response) => {
    console.log("payout webhook called", 111111);
    try {

        const plainObject = request.body;

        const sripe_webhook = await database.StripeWebhook.create({
            type: plainObject?.type,
            json: plainObject?.data.object
        })

        //* events 
        switch (plainObject?.type) {
            case 'payout.created':
                const payoutCreated = plainObject.data.object;
                let payoutCreationPayload = {
                    seller_id: payoutCreated.metadata.seller_id,
                    payout_id: payoutCreated?.id,
                    amount: payoutCreated?.amount / 100,
                    balance_transaction_id: payoutCreated?.balance_transaction,
                    currency: payoutCreated?.currency,
                    destination_id: payoutCreated?.destination,
                    source_type: payoutCreated?.source_type,
                    type: payoutCreated?.object,
                    description: payoutCreated?.description,
                    liveMode: payoutCreated?.livemode,
                    reversed: payoutCreated?.reversed,
                    status: payoutCreated?.status,
                    method: payoutCreated?.method,
                    failure_balance_transaction: payoutCreated?.failure_balance_transaction,
                    failure_code: payoutCreated?.failure_code,
                    failure_message: payoutCreated?.failure_message,
                    statement_descriptor: payoutCreated?.statement_descriptor,
                    application_fee: payoutCreated?.application_fee,
                    application_fee_amount: payoutCreated?.application_fee_amount,
                    automatic: payoutCreated?.automatic,
                    created_date_by_stripe: String(payoutCreated?.created)
                }

                const ifExistsPayoutCreated = await database.SellerPayoutHistory.findOne({ where: { payout_id: payoutCreated?.id }, raw: true })

                if (ifExistsPayoutCreated) {
                    await database.SellerPayoutHistory.update({ ...payoutCreationPayload, custom_txn_id: ifExistsPayoutCreated?.custom_txn_id }, {
                        where: {
                            id: ifExistsPayoutCreated?.id,
                        }
                    })
                } else {
                    await database.SellerPayoutHistory.create({ ...payoutCreationPayload, custom_txn_id: await utils?.getNextTXRCustomIdForPayout() })
                }
                break;
            case 'payout.updated':
                const payoutUpdated = plainObject.data.object;

                let payoutUpdationPayload = {
                    payout_id: payoutUpdated?.id,
                    seller_id: payoutUpdated.metadata.seller_id,
                    amount: payoutUpdated?.amount / 100,
                    balance_transaction_id: payoutUpdated?.balance_transaction,
                    currency: payoutUpdated?.currency,
                    destination_id: payoutUpdated?.destination,
                    source_type: payoutUpdated?.source_type,
                    type: payoutUpdated?.object,
                    description: payoutUpdated?.description,
                    liveMode: payoutUpdated?.livemode,
                    reversed: payoutUpdated?.reversed,
                    status: payoutUpdated?.status,
                    method: payoutUpdated?.method,
                    failure_balance_transaction: payoutUpdated?.failure_balance_transaction,
                    failure_code: payoutUpdated?.failure_code,
                    failure_message: payoutUpdated?.failure_message,
                    statement_descriptor: payoutUpdated?.statement_descriptor,
                    application_fee: payoutUpdated?.application_fee,
                    application_fee_amount: payoutUpdated?.application_fee_amount,
                    automatic: payoutUpdated?.automatic,
                    created_date_by_stripe: String(payoutUpdated?.created)
                }

                const ifExistsPayoutUpdated = await database.SellerPayoutHistory.findOne({ where: { payout_id: payoutUpdated?.id }, raw: true })

                if (ifExistsPayoutUpdated) {
                    await database.SellerPayoutHistory.update({ ...payoutUpdationPayload, custom_txn_id: ifExistsPayoutUpdated?.custom_txn_id }, {
                        where: {
                            id: ifExistsPayoutUpdated?.id,
                        }
                    })
                }
                break;
            case 'payout.paid':
                const payoutPaid = plainObject.data.object;
                console.log("🚀 ~ app.post ~ payoutPaid:", payoutPaid)
                let payoutPaidPayload = {
                    payout_id: payoutPaid?.id,
                    seller_id: payoutPaid.metadata.seller_id,
                    amount: payoutPaid?.amount / 100,
                    balance_transaction_id: payoutPaid?.balance_transaction,
                    currency: payoutPaid?.currency,
                    destination_id: payoutPaid?.destination,
                    source_type: payoutPaid?.source_type,
                    type: payoutPaid?.object,
                    description: payoutPaid?.description,
                    liveMode: payoutPaid?.livemode,
                    reversed: payoutPaid?.reversed,
                    status: payoutPaid?.status,
                    method: payoutPaid?.method,
                    failure_balance_transaction: payoutPaid?.failure_balance_transaction,
                    failure_code: payoutPaid?.failure_code,
                    failure_message: payoutPaid?.failure_message,
                    statement_descriptor: payoutPaid?.statement_descriptor,
                    application_fee: payoutPaid?.application_fee,
                    application_fee_amount: payoutPaid?.application_fee_amount,
                    automatic: payoutPaid?.automatic,
                    created_date_by_stripe: String(payoutPaid?.created)
                }

                const ifExistsPayoutPaid = await database.SellerPayoutHistory.findOne({ where: { payout_id: payoutPaid?.id }, raw: true })

                if (ifExistsPayoutPaid) {
                    await database.SellerPayoutHistory.update({ ...payoutPaidPayload, custom_txn_id: ifExistsPayoutPaid?.custom_txn_id }, {
                        where: {
                            id: ifExistsPayoutPaid?.id,
                        }
                    })
                }
                break;
            case 'payout.failed':
                const payoutCancelled = plainObject.data.object;
                break;
            default:
                console.log(`Unhandled event type ${plainObject.type}`);
        }

        // Return a 200 response to acknowledge receipt of the event
        response.json({ received: true });
    } catch (err) {
        console.log("An error occured while transfer webhook calling: ", err.message);
        return response.status(500).json({
            success: false,
            message: err?.message
        })
    }

})


//* create seller account in stripe (type - connect)
app.post("/connect", express.json({ type: 'application/json' }), async (request, response) => {
    console.log("connect webhook called", 111111);
    try {

        const plainObject = request.body;

        const sripe_webhook = await database.StripeWebhook.create({
            type: plainObject?.type,
            json: plainObject?.data?.object
        })

        switch (plainObject?.type) {

            //* after seller onboarding is completed then account updated called 
            case 'account.updated':
                const account = plainObject?.data?.object;
                const sellerConnectedAccount = await database.SellerConnectedAccount.findOne({ where: { stripeAccountId: account?.id }, raw: true })
                //* updated status of detail submitted
                const businessType = account?.businessType === 'individual' ? 'individual' : 'company';
                await database.SellerConnectedAccount.update({
                    details_submitted: account?.details_submitted,
                    type: account?.type,
                    business_type: account?.business_type,
                    businessName: account?.business_profile?.name,
                    businessUrl: account?.business_profile?.url,
                    tax_id_provided: account?.company?.tax_id_provided,
                    ssn_last_4_provided: account?.individual?.ssn_last_4_provided,
                    dobDay: account?.individual?.dob?.day,
                    dobMonth: account?.individual?.dob?.month,
                    dobYear: account?.individual?.dob?.year,
                    first_name: account?.individual?.first_name,
                    last_name: account?.individual?.last_name,
                    line1: account[businessType]?.address?.line1,
                    line2: account[businessType]?.address?.line2,
                    city: account[businessType]?.address?.city,
                    state: account[businessType]?.address?.state,
                    country: account[businessType]?.address?.country,
                    postal_code: account[businessType]?.address?.postal_code
                }, { where: { stripeAccountId: account?.id } });
                //* withdraw enabled when payout status is enabled
                if (sellerConnectedAccount && account?.payouts_enabled) {

                    //* add account details */
                    const accountDetails = await stripe.accounts.retrieve(account?.id);

                    //* update status of account available to transfer money
                    await database.SellerConnectedAccount.update({ isPaymentOnboardingCompleted: true, sellerAcceptedTOSFromIPAddress: accountDetails?.tos_acceptance?.ip, sellerAcceptedTOSFromUserAgent: accountDetails?.tos_acceptance?.user_agent }, { where: { stripeAccountId: account?.id } })

                    const capabilities = Object.keys(accountDetails?.capabilities);

                    if (capabilities.length) {
                        for await (const capability of capabilities) {
                            const findSimiliar = await database.SellerConnectedAccountCapability.findOne({ where: { stripeAccountId: account?.id, name: capability }, raw: true })
                            if (findSimiliar) {
                                await database.SellerConnectedAccountCapability.update({ status: accountDetails?.capabilities[capability] === "active" ? true : false }, { where: { stripeAccountId: account?.id, name: capability } })
                            } else {
                                await database.SellerConnectedAccountCapability.create({
                                    seller_id: sellerConnectedAccount?.seller_id,
                                    stripeAccountId: account?.id,
                                    name: capability,
                                    status: accountDetails?.capabilities[capability] === "active" ? true : false
                                })
                            }
                        }
                    }

                    let externalAccountIds = accountDetails?.external_accounts?.data.map(item => item?.id);

                    for await (const externalAccountId of externalAccountIds) {
                        const findBankAccountFromResponse = accountDetails?.external_accounts?.data.find(item => item?.id === externalAccountId);

                        let accountPayload = {
                            bank_or_card_id: findBankAccountFromResponse?.id,
                            seller_id: sellerConnectedAccount?.seller_id,
                            type: findBankAccountFromResponse?.object,
                            brand: findBankAccountFromResponse?.brand,
                            country: findBankAccountFromResponse?.country,
                            currency: findBankAccountFromResponse?.currency,
                            exp_month: findBankAccountFromResponse?.exp_month,
                            exp_year: findBankAccountFromResponse?.exp_year,
                            last4: findBankAccountFromResponse?.last4,
                            account_holder_name: findBankAccountFromResponse?.account_holder_name,
                            bank_name: findBankAccountFromResponse?.bank_name,
                            routing_number: findBankAccountFromResponse?.routing_number,
                            stripeAccountId: account?.id,
                            sellerConnectedAccountId: sellerConnectedAccount?.id
                        }
                        const find_similiar = await database.SellerBankAccounts.findOne({ where: { bank_or_card_id: externalAccountId }, raw: true })
                        if (find_similiar) {
                            await database.SellerBankAccounts.update({
                                ...accountPayload
                            }, { where: { bank_or_card_id: externalAccountId } })
                        } else {

                            const findBankAccount = await database.SellerBankAccounts.findAll({ where: { stripeAccountId: plainObject?.account }, raw: true })
                            if (!findBankAccount.length) {
                                await database.SellerBankAccounts.create({ ...accountPayload, isDefault: true });
                            } else {
                                await database.SellerBankAccounts.create(accountPayload);
                            }

                        }
                    }
                }
                else {
                    await database.SellerConnectedAccount.update({ isPaymentOnboardingCompleted: false }, { where: { stripeAccountId: account?.id } })
                }
                break;
            case 'account.external_account.updated':
                const external_account_update = plainObject.data.object;
                break;
            //* update nbank or card detaik
            case 'account.external_account.created':

                const updateAccount = plainObject?.data?.object;
                const sellerconnectedAccountDetails = await database.SellerConnectedAccount.findOne({ where: { stripeAccountId: plainObject?.account }, raw: true })

                if (sellerconnectedAccountDetails) {
                    /* add updateAccount details */
                    let acc_details = updateAccount;
                    let accountPayload = {
                        bank_or_card_id: acc_details?.id,
                        seller_id: sellerconnectedAccountDetails?.seller_id,
                        type: acc_details?.object,
                        brand: acc_details?.brand,
                        country: acc_details?.country,
                        currency: acc_details?.currency,
                        exp_month: acc_details?.exp_month,
                        exp_year: acc_details?.exp_year,
                        last4: acc_details?.last4,
                        account_holder_name: acc_details?.account_holder_name,
                        bank_name: acc_details?.bank_name,
                        routing_number: acc_details?.routing_number,
                        stripeAccountId: plainObject?.account,
                        // account_number: acc_details?.metadata?.account_number,
                        sellerConnectedAccountId: sellerconnectedAccountDetails?.id
                    }
                    const isExistsSellerBankAccount = await database.SellerBankAccounts.findOne({ where: { bank_or_card_id: acc_details?.id }, raw: true })

                    if (isExistsSellerBankAccount) {
                        await database.SellerBankAccounts.update({ ...accountPayload, isActivated: true }, { where: { bank_or_card_id: acc_details?.id } })
                    }
                    else {
                        const findBankAccount = await database.SellerBankAccounts.findAll({ where: { stripeAccountId: plainObject?.account }, raw: true })
                        if (!findBankAccount.length) {
                            await database.SellerBankAccounts.create({ ...accountPayload, isDefault: true });
                        } else {
                            await database.SellerBankAccounts.create(accountPayload);
                        }
                    }
                }
                else {
                    await database.SellerConnectedAccount.update({ isPaymentOnboardingCompleted: false }, { where: { stripeAccountId: plainObject?.account } })
                }

                break;
            case 'account.application.deauthorized':

                const sellerConnectedAccDetails = await database.SellerConnectedAccount.findOne({ where: { stripeAccountId: plainObject?.account }, raw: true })
                if (sellerConnectedAccDetails) {
                    await database.SellerConnectedAccount.update({ isConnectAccountDeleted: true }, { where: { stripeAccountId: plainObject?.account } })
                    const isExistsSellerBankAccount = await database.SellerBankAccounts.findAll({ where: { sellerConnectedAccountId: sellerConnectedAccDetails?.id, stripeAccountId: plainObject?.account }, raw: true })

                    if (isExistsSellerBankAccount.length) {
                        await database.SellerBankAccounts.update({ isActivated: false }, { where: { sellerConnectedAccountId: sellerConnectedAccDetails?.id, stripeAccountId: plainObject?.account } })
                    }
                }

                break;
            default:
                console.log(`Unhandled event type ${plainObject?.type}`);
        }

        // Return a 200 response to acknowledge receipt of the event
        response.json({ received: true });
    } catch (error) {
        console.error("An error occured while seller connect webhook calling: ", error);
        return response.status(500).json({ success: false, message: error?.message });
    }

})

const endpointSecret = "whsec_IshTzPsph4xo4BUsOwwqqm9n7PjPYfM0";

app.post('/refund', express.json({ type: 'application/json' }), async (request, response) => {
    console.log('refund called ================');

    try {
        const plainObject = request.body;

        const sripe_webhook = await database.StripeWebhook.create({
            type: plainObject?.type,
            json: plainObject?.object
        })

        // Handle the event
        switch (plainObject?.type) {
            // case 'refund.created':
            //     const refundCreated = event.data.object;
            //     console.log('refundCreated', refundCreated);

            //     break;
            case 'refund.updated':
                const refundUpdated = plainObject?.data?.object;
                const add_refund_entry = await database.RefundPayment.update(
                    {
                        amount: refundUpdated?.amount,
                        refund_id: refundUpdated?.id,
                        balance_transaction: refundUpdated?.balance_transaction,
                        charge: refundUpdated?.charge,
                        currency: refundUpdated?.currency,
                        destination_details_type: refundUpdated?.destination_details?.type,
                        reference_status: refundUpdated?.destination_details?.card?.reference_status,
                        payment_intent: refundUpdated?.payment_intent,
                        reason: refundUpdated?.reason,
                    },
                    {
                        where: {
                            refund_id: refundUpdated?.id
                        }
                    })

                break;
            case 'refund.failed':
                const refundFailed = plainObject?.data?.object;

                // Then define and call a function to handle the event refund.failed
                break;
            default:
                console.log(`Unhandled event type ${plainObject?.type}`);
        }

        // Return a 200 response to acknowledge receipt of the event
        response.json({ received: true });
    } catch (error) {

    }
});


module.exports = app;