// const app = require("express")();
// const database = require("../../../database/models");
// const { auth } = require("../middleware/auth");
// const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY, {
//   apiVersion: "2023-08-16",
// });
// const jwt = require("jsonwebtoken");
// /* init stripe */
// app.get("/", (req, res) => res.send("Welcome to Bluejesctic Payment!"));


// //* This api is for seller express account
// // app.post("/onboard-seller", auth(), async (req, res) => {
// //   try {
// //     let { email, country, token_type } = req.user;
// //     console.log("email, country, token_type", email, country, token_type);
// //     let find_seller = await database.Seller.findOne({
// //       where: { email },
// //     });
// //     const seller = JSON.parse(JSON.stringify(find_seller));
// //     console.log("🚀 ~ file: index.js:18 ~ seller:", seller);
// //     if (!seller) return res.status(400).send({ message: "Seller not found!" });
// //     // if (seller.isPaymentOnboardingCompleted)
// //     // return res.status(400).send({ success: false, message: "Connect account onboarding already completed!" });
// //     // if (!token_type === "seller") return res.status(400).send({ message: "Unauthorized" });

// //     //* Stripe express account creation
// //     const account = await stripe.accounts.create({
// //       type: "express",
// //       country: country ?? "US",
// //       email: email,
// //       capabilities: {
// //         transfers: { requested: true },
// //       },
// //     });
// //     console.log("🚀 ~ file: index.js:24 ~ account:", account);

// //     // Store the ID of the new Standard connected account.
// //     // req.session.accountID = account.id;
// //     // const token = await jwt.sign({ accountID: account.id, email: email, id: req.user.id }, process.env.JWT_SECRET, { expiresIn: "10m" });
// //     // await database.Seller.update(
// //     //   { stripeAccountId: account?.id,
// //     //     // isConnectAccountDeleted: false
// //     //   },
// //     //   { where: { id: seller?.id } }
// //     // );
// //     console.log("00");
// //     const sellerConnectAccount = await database.SellerConnectedAccount.create(
// //       {
// //         seller_id: seller?.id,
// //         stripeAccountId: account?.id,
// //         isConnectAccountDeleted: false,
// //         isPaymentOnboardingCompleted: false,
// //         details_submitted: false
// //       },
// //     );
// //     console.log("11");
// //     console.log("🚀 ~ file: index.js:49 ~ sellerConnectAccount:", sellerConnectAccount)
// //     const capabilities = Object.keys(account?.capabilities);
// //     console.log("22");
// //     console.log("🚀 ~ file: index.js:59 ~ capabilities:", capabilities)

// //     console.log("33");
// //     const sanitizedSellerConnectAccount = JSON.parse(JSON.stringify(sellerConnectAccount));
// //     console.log("44");
// //     console.log("🚀 ~ file: index.js:62 ~ sanitizedSellerConnectAccount:", sanitizedSellerConnectAccount)
// //     console.log("55");


// //     if (sanitizedSellerConnectAccount && sanitizedSellerConnectAccount?.id) {
// //       for await (const capability of capabilities) {
// //         await database.SellerConnectedAccountCapability.create(
// //           {
// //             seller_id: seller?.id,
// //             stripeAccountId: account?.id,
// //             sellerConnectAccountId: sanitizedSellerConnectAccount?.id,
// //             name: capability,
// //             status: false
// //           }
// //         );
// //       }
// //     }


// //     //* create account url for seller onboarding
// //     const accountLink = await stripe.accountLinks.create({
// //       type: "account_onboarding",
// //       account: account?.id,
// //       // refresh_url: process.env.BASE_LOCAL_URL,
// //       // return_url: process.env.BASE_LOCAL_URL,
// //       refresh_url: process.env.BACK_TO_ROUTE_URL,
// //       return_url: process.env.SUCCESS_URL,
// //     });
// //     console.log("🚀 ~ file: index.js:42 ~ accountLink:", accountLink);

// //     res.status(200).send({
// //       status: true,
// //       message: "Account creation link generated successfully.",
// //       url: accountLink.url,
// //     });

// //     // res.redirect(303, accountLink.url);
// //   } catch (error) {
// //     console.error("An error occured while generating account creation link: ", error);
// //     res.status(500).send({
// //       success: false,
// //       message: error.message,
// //     });
// //   }
// // });

// app.post("/onboard-seller", auth(), async (req, res) => {
//   try {
//     let { email, country } = req.user;
//     let find_seller = await database.Seller.findOne({
//       where: { email },
//     });
//     const seller = JSON.parse(JSON.stringify(find_seller));
//     if (!seller) return res.status(400).send({ message: "Seller not found!" });



//     let firstName, lastName;
//     if (req.body.legalName) {
//       firstName = req.body.legalName.split(" ")[0];
//       lastName = req.body.legalName.split(" ")[1];
//     }

//     if (!req.body.acceptTOS) {
//       return res.status(400).json({
//         status: false,
//         message: "Seller must accept Terms of Service first!"
//       });
//     }

//     //* Stripe custom account creation
//     const account = await stripe.accounts.create({
//       type: "custom",
//       country: country ?? "US",
//       email: email,
//       business_type: req.body?.businessType,
//       capabilities: {
//         transfers: { requested: true },
//       },
//       tos_acceptance: {
//         date: Math.floor(Date.now() / 1000),
//         ip: req.body?.ipAddress,
//         user_agent: req.headers["user-agent"],
//       },
//       business_profile: {
//         name: req.body?.businessName,
//         url: req.body?.businessUrl,
//       },
//       ...(req.body?.businessType === "individual" && {
//         individual: {
//           first_name: firstName,
//           last_name: lastName,
//           dob: {
//             day: req.body?.dob?.day,
//             month: req.body?.dob?.month,
//             year: req.body?.dob?.year,
//           },
//           address: {
//             line1: req.body?.address?.line1,
//             line2: req.body?.address?.line2,
//             city: req.body?.address?.city,
//             state: req.body?.address?.state,
//             postal_code: req.body?.address?.postalCode,
//             country: req.body?.address?.businessCountry,
//           },
//           ssn_last_4: req.body?.ssnLast4,
//         },
//       }),
//       ...(req.body?.businessType === "company" && {
//         company: {
//           name: req.body?.businessName,
//           tax_id: req.body?.taxId,
//           address: {
//             line1: req.body?.address?.line1,
//             line2: req.body?.address?.line2,
//             city: req.body?.address?.city,
//             state: req.body?.address?.state,
//             postal_code: req.body?.address?.postalCode,
//             country: req.body?.address?.businessCountry,
//           },
//         },
//       })
//     });

//     const sellerConnectAccount = await database.SellerConnectedAccount.create(
//       {
//         seller_id: seller?.id,
//         stripeAccountId: account?.id,
//         isConnectAccountDeleted: false,
//         isPaymentOnboardingCompleted: false,
//         details_submitted: false,
//         isSellerAcceptsTOS: req.body?.acceptTOS,
//         sellerAcceptedTOSFromIPAddress: req.body?.ipAddress
//       },
//     );

//     if (account && account.id) {
//       await stripe.accounts.createExternalAccount(account?.id, {
//         external_account: {
//           object: 'bank_account',
//           country: req.body?.bankCountry ?? "US",
//           currency: req.body?.currency ?? 'usd',
//           routing_number: req.body?.routingNumber,
//           account_number: req.body?.accountNumber,
//           account_holder_name: req.body?.businessType === 'individual'
//             ? `${firstName} ${lastName}`
//             : req.body?.businessName,
//           account_holder_type: req.body?.businessType === 'individual' ? 'individual' : 'company',
//         },
//       });

//     }

//     const capabilities = Object.keys(account?.capabilities);

//     const sanitizedSellerConnectAccount = JSON.parse(JSON.stringify(sellerConnectAccount));

//     if (sanitizedSellerConnectAccount && sanitizedSellerConnectAccount?.id) {
//       for await (const capability of capabilities) {
//         await database.SellerConnectedAccountCapability.create(
//           {
//             seller_id: seller?.id,
//             stripeAccountId: account?.id,
//             sellerConnectAccountId: sanitizedSellerConnectAccount?.id,
//             name: capability,
//             status: false
//           }
//         );
//       }
//     }

//     res.status(200).send({
//       status: true,
//       message: "Payment onboarding successfully.",
//     });

//     // res.redirect(303, accountLink.url);
//   } catch (error) {
//     console.error("An error occured while creating connect account: ", error);
//     res.status(500).send({
//       success: false,
//       message: error.message,
//     });
//   }
// });


// app.post("/capabilities-active-link", auth(), async (req, res) => {
//   try {
//     const { email } = req.user;
//     const { stripeAccountId } = req.body;
    
//     let find_seller = await database.Seller.findOne({
//       where: { email },
//     });
//     const seller = JSON.parse(JSON.stringify(find_seller));
//     if (!seller) return res.status(400).send({ message: "Seller not found!" });

//     if (!stripeAccountId) {
//       return res.status(400).send({ 
//         status: false,
//         message: "stripeAccountId is required!"
//        });
//     }
    
//     const capablitiesActiveLink = await stripe.accounts.createLoginLink(stripeAccountId);
//     res.status(200).send({
//       status: true,
//       message: "Capabilities activation link successfully.",
//       url: capablitiesActiveLink?.url,
//     });

//     // res.redirect(303, accountLink.url);
//   } catch (error) {
//     console.error("An error occured while generating capabilities activation link: ", error);
//     res.status(500).send({
//       success: false,
//       message: error.message,
//     });
//   }
// });



// // * This api is for delete connect account of seller by admin
// app.delete("/connect-account/:accountId", auth(), async (req, res) => {
//   try {
//     let { role } = req.user;
//     if (role !== "admin")
//       return res.status(401).send({ success: false, message: "Unauthorized!" });
//     const { accountId } = req.params;
//     if (!accountId)
//       return res
//         .status(400)
//         .send({ success: false, message: "Please provide the account id!" });

//     const deletedAccount = await stripe.accounts.del(accountId);

//     res.status(200).send({
//       success: true,
//       message: "Connect account deleted successfully.",
//     });

//     // res.redirect(303, accountLink.url);
//   } catch (error) {
//     console.error("An error occured while delete connect account!", error);
//     res.status(500).json({
//       success: false,
//       message: error.message,
//     });
//   }
// });

// app.get("/transaction-history", auth(), async (req, res) => {
//   try {
//     let { email } = req.user;

//     let find_seller = await database.Seller.findOne({
//       where: { email },
//     });
//     const seller = JSON.parse(JSON.stringify(find_seller));
//     if (!seller) return res.status(400).send({ message: "Seller not found!" });

//     const transactionHistories = await database.SellerPayoutHistory.findAll({
//       where: {
//         seller_id: seller?.id
//       },
//       order: [["createdAt", "DESC"]]
//     });
//     res.status(200).send({
//       success: true,
//       message: "Transaction history fetched successfully.",
//       data: JSON.parse(JSON.stringify(transactionHistories))
//     });

//     // res.redirect(303, accountLink.url);
//   } catch (error) {
//     console.error("An error occured while fetching transaction history!", error);
//     res.status(500).json({
//       success: false,
//       message: error.message,
//     });
//   }
// });



// // app.post("/seller-payout", auth(), async (req, res) => {
// //     try {
// //         const { withdrawAmount } = req.body;
// //         let { email } = req.user;
// //         if (!withdrawAmount) return res.status(400).send({ message: "" });
// //         const find_seller = await database.Seller.findOne({
// //             where: {
// //                 email
// //             }
// //         });

// //         find_seller.withdrawableAmount = 200 * 100;

// //         if (!find_seller) return res.status(404).send({ message: "Seller not found!" });

// //         console.log("🚀 ~ file: index.js:134 ~ find_seller.withdrawableAmount:", find_seller.withdrawableAmount)
// //         const withdrawAmountInCents = withdrawAmount * 100;
// //         console.log("🚀 ~ file: index.js:139 ~ withdrawAmountInCents:", withdrawAmountInCents)
// //         if (withdrawAmountInCents > find_seller?.withdrawableAmount) {
// //             return res.status(400).send({ message: "Insufficient funds!" });
// //         }

// //         const sellerStripeAccount = await stripe.accounts.retrieve(find_seller?.stripeAccountId);

// //         if (!sellerStripeAccount.external_accounts ||
// //             !sellerStripeAccount.external_accounts.data ||
// //             !sellerStripeAccount.external_accounts.data.length
// //         ) {
// //             return res.status(404).json({message: "Seller doesn't have connect account on stripe"});
// //         }

// //         console.log("🚀 ~ file: index.js:140 ~ sellerStripeAccount:", sellerStripeAccount)
// //         console.log("🚀 ~ file: index.js:140 ~ sellerStripeAccount:", sellerStripeAccount?.external_accounts?.data)

// //         const transferFundsToSeller = await stripe.transfers.create({
// //             amount: withdrawAmountInCents,
// //             currency: "usd",
// //             destination: sellerStripeAccount?.external_accounts?.data[0]?.account, // Connected account's ID
// //             description: 'Transfer to seller for product sale',
// //         });
// //         console.log("🚀 ~ file: index.js:158 ~ transferFundsToSeller:", transferFundsToSeller);

// //         res.status(200).send({
// //             url: "Success",
// //         });

// //         // res.redirect(303, accountLink.url);
// //     } catch (err) {
// //         // console.log(err);
// //         res.status(500).send({
// //             error: err.message,
// //         });
// //     }
// // });

// // this api is for seller withdraw fund to own bank account(outside stripe)
// app.post("/seller-withdraw", auth(), async (req, res) => {
//   try {
//     let { email } = req.user;
//     const { withdrawAmount, currency, stripeAccountId, bankAccountId } = req.body;
//     if (!withdrawAmount) {
//       return res.status(400).send({ success: false, message: "Withdraw amount is required!" });
//     }

//     if (!stripeAccountId) {
//       return res
//         .status(400)
//         .json({ status: false, message: "Stripe account id is required!" });
//     }

//     if (!bankAccountId) {
//       return res
//         .status(400)
//         .json({ status: false, message: "Bank account id is required!" });
//     }
//     const find_seller = await database.Seller.findOne({
//       where: {
//         email,
//       },
//     });

//     const seller = JSON.parse(JSON.stringify(find_seller));

//     if (!seller)
//       return res.status(404).send({ success: false, message: "Seller not found!" });

//     // seller.withdrawableAmount = 200 * 100;

//     const withdrawableAmountInCents =
//       seller?.withdrawableAmount ?? 200 * 100;

//     const withdrawAmountInCents = withdrawAmount * 100;

//     if (withdrawAmountInCents > withdrawableAmountInCents) {
//       return res.status(400).send({ success: false, message: "Insufficient funds!" });
//     }

//     const transferFundsToSeller = await stripe.transfers.create({
//       amount: withdrawAmountInCents,
//       currency: currency ?? "usd",
//       destination: stripeAccountId,
//       description: "Transfer to seller's stripe connect account for product sale",
//       metadata: {
//         seller_id: seller?.id,
//       },
//     });

//     if (transferFundsToSeller && transferFundsToSeller.id) {

//       const payoutFundsToSeller = await stripe.payouts.create(
//         {
//           amount: withdrawAmountInCents,
//           currency: currency ?? "usd",
//           destination: bankAccountId,
//           method: "instant", // or 'standard' if available and enabled
//           description:
//             "Withdraw to seller's personal bank account for product sale",
//           metadata: {
//             seller_id: seller?.id,
//           },
//         },
//         {
//           stripeAccount: stripeAccountId,
//         }
//       );

//       if (payoutFundsToSeller && payoutFundsToSeller?.id) {
//         return res.status(200).json({
//           status: true,
//           message: "Withdraw funds to seller's bank account successfully.",
//         });
//       }
//     }


//     // res.redirect(303, accountLink.url);
//   } catch (err) {

//     console.error("An error occcured while seller withdrawing funds", err);
//     res.status(500).json({
//       success: false,
//       message: err.message,
//     });
//   }
// });

// /* seller onboarding - refresh //*not used*/
// app.get("/onboard-seller/refresh", async (req, res) => {
//   if (!req.session.accountID) {
//     res.redirect("/");
//     return;
//   }

//   try {
//     const { accountID } = req.session;

//     const token = await jwt.sign({ accountID }, process.env.JWT_SECRET, {
//       expiresIn: "10m",
//     });

//     const accountLink = await stripe.accountLinks.create({
//       type: "account_onboarding",
//       account: accountID,
//       refresh_url: process.env.BASE_LOCAL_URL,
//       return_url: process.env.BASE_LOCAL_URL,
//     });

//     res.redirect(303, accountLink.url);
//   } catch (err) {
//     res.status(500).send({
//       error: err.message,
//     });
//   }
// });
// /* seller onboarding - success - //*not used*/
// app.get("/onboard-seller/success", async (req, res) => {
//   const { token } = req.query;
//   if (!token) return res.status(400).send({ message: "Unauthorized" });
//   const { accountID, email, id } = await jwt.verify(
//     token,
//     process.env.JWT_SECRET
//   );
//   /* update seller */
//   await database.Seller.update(
//     { isPaymentOnboardingCompleted: true, stripeAccountId: accountID },
//     { where: { email, id } }
//   );
//   return res.send(`
// <h1>Success</h1>
// `);
// });

// module.exports = app;
