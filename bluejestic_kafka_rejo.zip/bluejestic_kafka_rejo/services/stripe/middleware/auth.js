const { User, Seller } = require("../../../database/models");
const jwt = require("jsonwebtoken");
const { AuthenticationError } = require("apollo-server-express");

module.exports = {
    auth: ({ isTokenRequired = true, usersAllowed = [] } = {}) => {
        return async (req, res, next) => {
            try {
                const token = req.header("x-auth-token");
                if (isTokenRequired && !token) return res.status(401).send({ message: "Access denied. No token provided." });
                if (!isTokenRequired && !token) return next();
                let decoded = jwt.verify(token, process.env.JWT_SECRET);
                console.log("🚀 ~ file: auth.js:13 ~ decoded:", decoded)
                let user
                // if(decoded.role == USER_TYPE.ADMIN) return next();
                if (decoded.type == "user") {
                    user = await User.findByPk(decoded.id);
                    user = JSON.parse(JSON.stringify(user));
                    user.token_type = "user";
                }
                if (decoded.type == "seller") {
                    user = await Seller.findByPk(decoded.id);
                    user = JSON.parse(JSON.stringify(user));
                    user.token_type = "seller";
                }
                if (decoded.type == "admin") {
                    user = await User.findByPk(decoded.id);
                    user = JSON.parse(JSON.stringify(user));
                    user.token_type = "admin";
                }

                if (!user) return res.status(401).send({ message: "Invalid token" });
                delete user.password;
                req.user = user;
                next();
            } catch (error) {
                console.log('error >>>>>', error);
                return res.status(401).send({ message: error.message });
            }
        };
    },
};
