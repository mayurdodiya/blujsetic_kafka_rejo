const { Client } = require('@elastic/elasticsearch');

// Create Elasticsearch client
// const client = new Client({ node: 'http://localhost:9200' });


// connect to elasticsearch - production 
const client = new Client({
    node: process.env.ELASTIC_URI,
    maxRetries: 5,
    requestTimeout: 60000,
    // ssl: {
    //   rejectUnauthorized: false,
    // },
    auth: {
        username: process.env.ELASTIC_USERNAME,
        password: process.env.ELASTIC_PASSWORD,
    },
    maxRetries: 5,
    requestTimeout: 60000,
    tls: { rejectUnauthorized: false },
    // ssl: {
    //   ca: "", // Set to empty string to skip certificate verification
    //   agent: httpsAgent, // Use the custom HTTPS agent
    // },
});
module.exports = client;