const client = require("../config/config");
let validationSchema = require("../validation/index");
const moment = require("moment");
const storeActivity = require("../storeActivity/storeActivity");
const database = require("../../../database/models");
const { getPreviousDate } = require("../../../utils/utils");
module.exports = self = {
  /* ************ Create index for orders ************ */
  createIndexForProducts: async (indexName) => {
    try {
      console.log("+++++++++++++++++++ ENTERS in index cretion +++++++++++++++++++");
      const indexExists = await client.indices.exists({ index: indexName });

      if (indexExists) {
        console.log(`Index "${indexName}" already exists.`);
        return { success: false, message: `Index "${indexName}" already exists.` };
      }

      let product_index = await client.indices.create({
        index: indexName,
        body: {
          mappings: {
            properties: {
              product_id: { type: "integer" },
              store_id: { type: "integer" },
              title: { type: "text" },
              description: { type: "text" },
              price: { type: "float" },
              isFeature: { type: "boolean" },
              isActive: { type: "boolean" },
              quantity: { type: "integer" },
              listPrice: { type: "float" },
              sku: { type: "keyword" },
              metaTitle: { type: "text" },
              metaDescription: { type: "text" },
              keywords: { type: "text" },
              isVisible: { type: "boolean" },
              isFreeShipping: { type: "boolean" },
              condition: { type: "keyword" },
              tags: { type: "keyword" },
              image: { type: "keyword" },
              video: { type: "keyword" },
              is_deleted: { type: "boolean" },
              customerId: { type: "keyword" },
              cropImages: {
                type: "nested",
                properties: {
                  id: { type: "keyword" },
                  oldFile: { type: "text" },
                  croppedFile: {
                    properties: {
                      baseURL: { type: "text" },
                      zoom: { type: "float" },
                      rotate: { type: "integer" },
                      crop: {
                        properties: {
                          x: { type: "long" },
                          y: { type: "long" },
                        },
                      },
                    },
                  },
                },
              },
              ratio: { type: "keyword" },
              size: {
                type: "object",
                properties: {
                  height: { type: "integer" },
                  width: { type: "integer" },
                },
              },
              id: { type: "integer" },
              isDeleted: {
                type: "boolean",
              },
              createdAt: {
                type: "date",
              },
            },
          },
        },
      });

      // let datasss = await client.indices.create({
      //   index: 'product_v4', // new index name
      //   body: {
      //     mappings: {
      //       properties: {
      //         "store_id": { type: 'integer' },
      //         "title": { type: 'text' },
      //         "description": { type: "text" },
      //         "isFeature": { type: "boolean" },
      //         "status": { type: "keyword" },
      //         "isFreeShipping": { type: "boolean" },
      //         "condition": { type: "keyword" },
      //         "metaTitle": { type: "keyword" },
      //         "metaDescription": { type: "keyword" },
      //         "keywords": { type: "keyword" },
      //         "ratio": { type: "keyword" },
      //         "dis_price": { type: 'float' },
      //         "dis_listPrice": { type: 'float' },
      //         "shopify_product_id": { type: 'long' },
      //         "id": { type: "integer" },
      //         "product_id": { type: "integer" },
      //         "images": { type: "keyword" },
      //         "is_deleted": { type: "boolean" }
      //       }
      //     }
      //   }
      // });

      return { success: true, message: "Index created successfully.", data: product_index };
    } catch (error) {
      return error;
    }
  },
  /* ************ Put mapping for orders ************ */
  putMappingForProducts: async (indexName) => {
    let order_mapping = await client.indices.putMapping({
      index: indexName,
      body: {
        properties: {
          productId: { type: "keyword" },
          orderDate: { type: "date" },
          customerId: { type: "keyword" },
          products: {
            type: "nested",
            properties: {
              productId: { type: "keyword" },
              productName: { type: "text" },
              price: { type: "float" },
              quantity: { type: "integer" },
            },
          },
          status: {
            type: "object",
            properties: {
              code: { type: "keyword" },
              name: { type: "keyword" },
            },
          },
        },
      },
    });
    return order_mapping;
  },

  /* ************ Add Bulk data for orders ************ */
  addBulkDataForProducts: async (index, data) => {
    // let productDatas = require("./orders.json");
    let productDatas = data;

    let body = [];
    for (const order of productDatas) {
      body.push({ index: { _index: index } });
      body.push(order);
    }
    console.log(JSON.parse(JSON.stringify(body)), "body");
    const bulkData = body;

    // // Perform bulk indexing
    const performBulkIndexing = async () => {
      const data = await client.bulk({ refresh: true, body: bulkData });
      if (data.errors) {
        console.log("Error indexing data:", data.items[0].index.error);
        console.log("Error indexing data:", data.errors);
      } else {
        console.log("Data indexed successfully.");
      }
    };

    performBulkIndexing()
      .then(() => {
        console.log("Bulk indexing completed successfully.");
      })
      .catch((error) => {
        console.error("An error occurred during bulk indexing:", error);
      });
  },

  /* ************ Add Single data for order ************ */
  addProduct: async (data, indexName = "products") => {
    try {
      // console.log(data, "data");
      // let error = validationSchema("createProductIndexSchema", data);
      // if (error) return { success: false, message: error };
      // index exists or not

      // console.log('fsafdfsdfasdfsdfadfasfasdfasdfadfsdfasdfadfasdfasdf+++++++++++++++++++++++++++++++++++', data);

      const indexExists = await client.indices.exists({
        index: indexName,
      });
      console.log(indexExists, "indexExists");
      if (!indexExists) {
        let check = await self.createIndexForProducts(indexName);
        console.log("checkcheckcheckcheckcheckcheck", check);
      }
      const product = await client.search({
        index: indexName,
        body: {
          query: {
            match: {
              product_id: data.product_id,
            },
          },
        },
      });

      // console.log('producasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdas+++++++++++++++++++++++++++++++++t',product);

      // if ((product.hits.hits.length)) {
      // return { success: false, message: "product already exists" };
      // }
      // console.log(indexName, "indexName+++++++++++++++++++++++++++++++");
      const productData = await client.index({
        index: indexName,
        body: data,
      });
      console.log(productData, "productData");
      return { success: true, message: "product added successfully", data: productData };
    } catch (error) {
      console.log(error, "error");
    }
  },

  /* ************ Add data for orders ************ */
  getAllProductsData: async (indexName) => {
    const data = await client.search({
      index: indexName,
    });
    const ordersData = data.hits.hits.map((hit) => {
      return { ...hit._source, _id: hit._id };
    });
    return ordersData;
  },
  /* ************ get Seller Dashboard Metrics  metrics ************ */
  getInventoryMetrics: async (indexName, { store_id, month = 1 }) => {
    let currentProductMetrics = await client.search({
      index: indexName,
      body: {
        // add query for match store id
        query: {
          bool: {
            must: [
              {
                match: {
                  store_id: store_id,
                },
              },
              {
                match: {
                  is_deleted: false,
                },
              },
            ],
          },
        },
        size: 0,
        aggs: {
          // filter with fields
          total_products: {
            value_count: {
              field: "id",
            },
          },
          total_active_products: {
            filter: {
              term: {
                isActive: true,
              },
            },
          },
          // out of stock products
          out_of_stock_products: {
            filter: {
              term: {
                quantity: 0,
              },
            },
          },

          // low stock products
          low_stock_products: {
            filter: {
              range: {
                quantity: {
                  gte: 1,
                  lte: 20,
                },
              },
            },
          },
          in_stock_products: {
            filter: {
              range: {
                quantity: {
                  gte: 21,
                },
              },
            },
          },
        },
      },
    });
    /* data with last month comparison */
    let pastProductMetrics = await client.search({
      index: indexName,
      body: {
        size: 0,
        query: {
          bool: {
            must: [
              {
                match: {
                  store_id: store_id,
                },
              },
              {
                range: {
                  createdAt: {
                    gte: moment()
                      .subtract(month + 1, "months")
                      .format("YYYY-MM-DD"),
                    lte: moment().subtract(month, "months").format("YYYY-MM-DD"),
                  },
                },
              },
            ],
          },
        },
        aggs: {
          // filter with fields
          past_total_products: {
            value_count: {
              field: "id",
            },
          },

          past_total_active_products: {
            filter: {
              term: {
                isActive: true,
              },
            },
          },
        },
      },
    });

    console.log("store_id++++++++++++++++++++++", store_id);
    let currentSellerOrdersMetrics = await client.search({
      index: "order_master",
      body: {
        query: {
          match: {
            store_id: store_id,
          },
        },
        size: 0,
        aggs: {
          total_sold_orders: {
            filter: {
              bool: {
                must: [{ term: { store_id } }, { term: { order_status: "delivered" } }],
              },
            },
          },
          total_shipped_orders: {
            filter: {
              bool: {
                must: [{ term: { store_id } }, { term: { order_status: "processing" } }],
              },
            },
          },
          total_pending_orders: {
            filter: {
              bool: {
                must: [{ term: { store_id: store_id } }, { term: { order_status: "pending" } }],
              },
            },
          },
          // customer count with unique user_id
          total_customers: {
            cardinality: {
              field: "user_id",
              precision_threshold: 100,
            },
          },
        },
      },
    });

    console.log("currentSellerOrdersMetrics+++++++++++++++++++++++++", currentSellerOrdersMetrics);

    /* past month data */
    let pastSellerOrdersMetrics = await client.search({
      index: "orders",
      body: {
        size: 0,
        query: {
          bool: {
            must: [
              {
                match: {
                  store_id: store_id,
                },
              },
              {
                range: {
                  createdAt: {
                    gte: moment()
                      .subtract(month + 1, "months")
                      .format("YYYY-MM-DD"),
                    lte: moment().subtract(month, "months").format("YYYY-MM-DD"),
                  },
                },
              },
            ],
          },
        },
        aggs: {
          // filter with fields
          past_total_sold_orders: {
            filter: {
              bool: {
                must: [{ term: { store_id } }, { term: { order_status: "delivered" } }],
              },
            },
          },
          past_total_shipped_orders: {
            filter: {
              bool: {
                must: [{ term: { store_id } }, { term: { order_status: "shipped" } }],
              },
            },
          },
          past_total_pending_orders: {
            filter: {
              bool: {
                must: [{ term: { store_id } }, { term: { order_status: "pending" } }],
              },
            },
          },
          // customer count with unique user_id
          past_total_customers: {
            cardinality: {
              field: "user_id",
              precision_threshold: 100,
            },
          },
        },
      },
    });

    /* store product metrics */
    const curr_product_metrics = currentProductMetrics.aggregations;
    const past_product_metrics = pastProductMetrics.aggregations;

    /* store order metrics */
    const curr_seller_orders_metrics = currentSellerOrdersMetrics.aggregations;
    const past_seller_orders_metrics = pastSellerOrdersMetrics.aggregations;

    if (!curr_product_metrics || !past_product_metrics || !curr_seller_orders_metrics || !past_seller_orders_metrics) return { status: false, message: "Something went wrong" };

    const { total_products, out_of_stock_products, low_stock_products, in_stock_products, total_active_products } = curr_product_metrics;
    const { past_total_products, past_total_active_products } = past_product_metrics;

    const { total_sold_orders, total_shipped_orders, total_pending_orders, total_customers } = curr_seller_orders_metrics;
    const { past_total_sold_orders, past_total_shipped_orders, past_total_pending_orders, past_total_customers } = past_seller_orders_metrics;

    /* get diffrence and  current store activity data */
    let store_activity = {
      new_orders: total_pending_orders.doc_count,
      pending_shipments: total_shipped_orders.doc_count,
      out_of_stock_products: out_of_stock_products.doc_count,
    };

    /* store overview data */
    let store_overview = {
      total_active_products: total_active_products.doc_count,
      total_active_products_diff: total_active_products.doc_count - past_total_active_products.doc_count,
      total_sold_products: total_sold_orders.doc_count,
      total_sold_products_diff: total_sold_orders.doc_count - past_total_sold_orders.doc_count,
      total_shipped_products: total_shipped_orders.doc_count,
      total_shipped_products_diff: total_shipped_orders.doc_count - past_total_shipped_orders.doc_count,
      total_customers: total_customers.value,
      total_customers_diff: total_customers.value - past_total_customers.value,
      total_sold_orders_diff_percentage: total_sold_orders.doc_count !== 0 ? (((total_sold_orders.doc_count - past_total_sold_orders.doc_count) / total_sold_orders.doc_count) * 100).toFixed(2) : 0,
      total_shipped_products_diff_percentage: total_shipped_orders.doc_count !== 0 ? (((total_shipped_orders.doc_count - past_total_shipped_orders.doc_count) / total_shipped_orders.doc_count) * 100).toFixed(2) : 0,
      total_customers_diff_percentage: total_customers.value !== 0 ? (((total_customers.value - past_total_customers.value) / total_customers.value) * 100).toFixed(2) : 0,
    };

    /* store inventory data */
    let store_inventory = {
      total_products: total_products.value,
      total_products_diff: total_products.value - past_total_products.value,
      out_of_stock_products: out_of_stock_products.doc_count,
      in_stock_products: in_stock_products.doc_count,
      low_stock_products: low_stock_products.doc_count,
      out_of_stock_products_percentage: total_products.value !== 0 ? ((out_of_stock_products.doc_count / total_products.value) * 100).toFixed(2) : 0,
      low_stock_products_percentage: total_products.value !== 0 ? ((low_stock_products.doc_count / total_products.value) * 100).toFixed(2) : 0,
      in_stock_products_percentage: total_products.value !== 0 ? ((in_stock_products.doc_count / total_products.value) * 100).toFixed(2) : 0,
    };
    // console.log(out_of_stock_products.doc_count / total_products.value, out_of_stock_products.doc_count, total_products.value);
    // console.log(store_inventory, "store_inventory");
    // console.log(store_overview, "store_overview");
    // console.log(store_activity, "store_activity");
    return { status: true, data: { store_activity, store_overview, store_inventory } };
  },

  getOrderSales: async (indexName, { store_id, month = 1 }) => {
    const startOfCurrentMonth = moment().startOf('month').toISOString();
    const startOfLastMonth = moment().subtract(1, 'months').startOf('month').toISOString();
    const endOfLastMonth = moment().subtract(1, 'months').endOf('month').toISOString();

    const currentMonthResult = await client.search({
      index: indexName,
      body: {
        size: 0,
        query: {
          bool: {
            must: [
              { term: { store_id } },
              // {
              //   range: {
              //     orderDate: {
              //       gte: startOfCurrentMonth,
              //     },
              //   },
              // },
            ],
          },
        },
        aggs: {
          total_sales: { sum: { field: 'totalAmount' } },
          order_count: { value_count: { field: 'id' } },
          total_customers: {
            cardinality: {
              field: "user_id",
              precision_threshold: 100,
            },
          },
        },
      },
    });

    // Perform the aggregation query for the previous month
    const lastMonthResult = await client.search({
      index: indexName,
      body: {
        size: 0,
        query: {
          bool: {
            must: [
              { term: { store_id } },
              // {
              //   range: {
              //     orderDate: {
              //       gte: startOfLastMonth,
              //       lte: endOfLastMonth,
              //     },
              //   },
              // },
              {
                range: {
                  createdAt: {
                    gte: moment()
                      .subtract(month + 1, "months")
                      .format("YYYY-MM-DD"),
                    lte: moment().subtract(month, "months").format("YYYY-MM-DD"),
                  },
                },
              },
            ],
          },
        },
        aggs: {
          total_sales: { sum: { field: 'totalAmount' } },
          order_count: { value_count: { field: 'id' } },
          total_customers: {
            cardinality: {
              field: "user_id",
              precision_threshold: 100,
            },
          },
        },
      },
    });

    // Extract results for current month
    const currentTotalSales = currentMonthResult.aggregations.total_sales.value || 0;
    const currentOrderCount = currentMonthResult.aggregations.order_count.value || 0;
    const currentNewCustomerCount = currentMonthResult.aggregations.total_customers.value || 0;
    const currentAvgOrderValue = currentOrderCount > 0 ? currentTotalSales / currentOrderCount : 0;

    // Extract results for last month
    const lastTotalSales = lastMonthResult.aggregations.total_sales.value || 0;
    const lastOrderCount = lastMonthResult.aggregations.order_count.value || 0;
    const lastNewCustomerCount = lastMonthResult.aggregations.total_customers.value || 0;
    const lastAvgOrderValue = lastOrderCount > 0 ? lastTotalSales / lastOrderCount : 0;

    // Calculate percentage changes
    const salesChange = lastTotalSales > 0 ? ((currentTotalSales - lastTotalSales) / lastTotalSales) * 100 : 0;
    const avgOrderValueChange = lastAvgOrderValue > 0 ? ((currentAvgOrderValue - lastAvgOrderValue) / lastAvgOrderValue) * 100 : 0;
    const total_customers_different = lastNewCustomerCount > 0 ? ((currentNewCustomerCount - lastNewCustomerCount) / lastNewCustomerCount) * 100 : 0
    const total_orders_different = lastOrderCount > 0 ? ((currentOrderCount - lastOrderCount) / lastOrderCount) * 100 : 0


    // Output the results
    // console.log(`Total Sales (Current Month): ${currentTotalSales}`);
    // console.log(`Average Order Value (Current Month): ${currentAvgOrderValue}`);
    // console.log(`Total Sales (Last Month): ${lastTotalSales}`);
    // console.log(`Average Order Value (Last Month): ${lastAvgOrderValue}`);
    // console.log(`Total Customers: ${currentNewCustomerCount}`);
    // console.log(`Total Customers (%): ${total_customers_different}`);
    // console.log(`Average Order Value (Last Month): ${lastAvgOrderValue}`);
    // console.log(`Sales Change (%): ${salesChange.toFixed(2)}%`);
    // console.log(`AvgOrder Value Change (%): ${avgOrderValueChange.toFixed(2)}%`);

    const orderSales = {
      total_sales: currentTotalSales,
      total_sales_diff_pct: salesChange,

      total_orders: currentOrderCount,
      total_orders_diff_pct: total_orders_different,

      total_customers: currentNewCustomerCount,
      total_customers_diff_pct: total_customers_different,

      avg_order: currentAvgOrderValue,
      avg_order_diff_pct: avgOrderValueChange,
    }

    return { success: true, data: orderSales }

    // const result = await client.search({
    //   index: indexName,
    //   body: {
    //     size: 0,
    //     query: {
    //       term: { // Filter by store_id
    //         store_id: store_id,
    //       },
    //     },
    //     aggs: {
    //       total_sales: {
    //         sum: {
    //           field: 'totalAmount',
    //         },
    //       },
    //       order_count: {
    //         value_count: {
    //           field: 'id',
    //         },
    //       },
    //     },
    //   },
    // });    

    // const totalSales = result.aggregations.total_sales.value;
    // const orderCount = result.aggregations.order_count.value;
    // const avgOrderValue = orderCount > 0 ? totalSales / orderCount : 0;

    // console.log(`Total Sales: ${totalSales}`);
    // console.log(`Number of Orders: ${orderCount}`);
    // console.log(`Average Order Value: ${avgOrderValue}`);
  },

  getProductSoldAndShippedMetrics: async (indexName, { store_id, start_date, end_date }) => {
    let currentSellerOrdersMetrics = await client.search({
      index: "orders",
      body: {
        query: {
          bool: {
            must: [
              {
                match: {
                  store_id: store_id,
                },
              },
              {
                match: {
                  is_deleted: false,
                },
              },
              {
                range: {
                  createdAt: {
                    gte: start_date,
                    lte: end_date,
                  },
                },
              },
            ],
          },
        },
        size: 0,
        aggs: {
          total_sold_orders: {
            filter: {
              bool: {
                must: [{ term: { store_id } }, { term: { order_status: "delivered" } }],
              },
            },
          },
          total_shipped_orders: {
            filter: {
              bool: {
                must: [{ term: { store_id } }, { term: { order_status: "shipped" } }],
              },
            },
          },
          total_pending_orders: {
            filter: {
              bool: {
                must: [{ term: { store_id } }, { term: { order_status: "pending" } }],
              },
            },
          },
          // customer count with unique user_id
          total_customers: {
            cardinality: {
              field: "user_id",
              precision_threshold: 100,
            },
          },
        },
      },
    });
    let { previous_start_date, previous_end_date } = await getPreviousDate(start_date, end_date);

    /* past month data */
    let pastSellerOrdersMetrics = await client.search({
      index: "orders",
      body: {
        size: 0,
        query: {
          bool: {
            must: [
              {
                match: {
                  store_id: store_id,
                },
              },
              {
                range: {
                  createdAt: {
                    gte: previous_start_date,
                    lte: previous_end_date,
                  },
                },
              },
            ],
          },
        },
        aggs: {
          // filter with fields
          past_total_sold_orders: {
            filter: {
              bool: {
                must: [{ term: { store_id } }, { term: { order_status: "delivered" } }],
              },
            },
          },
          past_total_shipped_orders: {
            filter: {
              bool: {
                must: [{ term: { store_id } }, { term: { order_status: "shipped" } }],
              },
            },
          },
          past_total_pending_orders: {
            filter: {
              bool: {
                must: [{ term: { store_id } }, { term: { order_status: "pending" } }],
              },
            },
          },
          // customer count with unique user_id
          past_total_customers: {
            cardinality: {
              field: "user_id",
              precision_threshold: 100,
            },
          },
        },
      },
    });

    /* store order metrics */
    const curr_seller_orders_metrics = currentSellerOrdersMetrics.aggregations;
    const past_seller_orders_metrics = pastSellerOrdersMetrics.aggregations;

    if (!curr_seller_orders_metrics || !past_seller_orders_metrics) return { status: false, message: "Something went wrong" };

    const { total_sold_orders, total_shipped_orders, total_pending_orders, total_customers } = curr_seller_orders_metrics;
    const { past_total_sold_orders, past_total_shipped_orders, past_total_pending_orders, past_total_customers } = past_seller_orders_metrics;

    /* store overview data */
    let store_overview = {
      total_sold_products: total_sold_orders.doc_count,
      total_sold_products_diff: total_sold_orders.doc_count - past_total_sold_orders.doc_count,
      total_shipped_products: total_shipped_orders.doc_count,
      total_shipped_products_diff: total_shipped_orders.doc_count - past_total_shipped_orders.doc_count,
    };

    return { status: true, data: { store_overview } };
  },

  /* ************ delete order by id ************ */
  deleteProduct: async (indexName, productId) => {
    try {
      // search product by id

      const existData = await client.search({
        index: indexName,
        body: {
          query: {
            match: {
              id: productId,
            },
          },
        },
      });

      if (existData.hits.hits.length == 0) {
        console.log("Product does not exists");
        return { success: false, message: "Product does not exists" };
      }

      let _id = existData.hits.hits[0]._id;
      const productData = await client.delete({
        index: indexName,
        id: _id,
      });
      // console.log(productData.result, "productData");
      return productData;
    } catch (error) {
      console.log(error, "error");
      return error;
    }
  },
  /* ************ get order by id ************ */
  getProductById: async (indexName, productId) => {
    // if exists
    const productExists = await client.exists({
      index: indexName,
      id: productId,
    });

    if (!productExists) {
      return { success: false, message: "Product does not exists" };
    }

    let productData = await client.get({
      index: indexName,
      id: productId,
    });
    productData = { ...productData._source, id: productData._id };
    return productData;
  },

  /* ************ update order by id ************ */
  updateProductById: async (indexName, id, data) => {
    try {
      // if exists
      const isExists = await client.search({
        index: indexName,
        body: {
          query: {
            match: {
              id: id,
            },
          },
        },
      });
      if (isExists.hits.hits.length === 0) {
        return { success: false, message: "Product does not exists" };
      }
      if (isExists.hits.hits.length > 0) {
        let orders = isExists.hits.hits;
        for (let i = 0; i < orders.length; i++) {
          const order = orders[i];
          // if exists
          const orderExists = await client.exists({
            index: indexName,
            id: order._id,
          });
          // console.log(orderExists, "orderExists");
          if (!orderExists) {
            console.log("Product does not exists");
            return { success: false, message: "Product does not exists" };
          }

          const orderData = await client.get({
            index: indexName,
            id: order._id,
          });

          const _source = orderData._source;

          const updatedDocument = {
            ..._source,
            ...data,
          };
          // const updatedDocument = data
          const updateResponse = await client.update({
            index: indexName,
            id: order._id,
            body: {
              doc: updatedDocument,
            },
          });
        }
      }
      return { success: true, message: "Product updated successfully" };
    } catch (error) {
      console.log(error, "error");
      return error;
    }
  },

  updateOrderMaster: async (indexName, id, data) => {
    try {
      // if exists
      const isExists = await client.search({
        index: indexName,
        body: {
          query: {
            match: {
              id: id,
            },
          },
        },
      });
      console.log("isExists", isExists);
      // if (isExists.hits.hits.length === 0) {
      //   return { success: false, message: "Product does not exists" };
      // }
      // if (isExists.hits.hits.length > 0) {
      //   let orders = isExists.hits.hits;
      //   for (let i = 0; i < orders.length; i++) {
      //     const order = orders[i];
      //     // if exists
      //     const orderExists = await client.exists({
      //       index: indexName,
      //       id: order._id,
      //     });
      //     // console.log(orderExists, "orderExists");
      //     if (!orderExists) {
      //       console.log("Product does not exists");
      //       return { success: false, message: "Product does not exists" };
      //     }

      //     const orderData = await client.get({
      //       index: indexName,
      //       id: order._id,
      //     });

      //     const _source = orderData._source;

      //     const updatedDocument = {
      //       ..._source,
      //       ...data,
      //     };
      //     // const updatedDocument = data
      //     const updateResponse = await client.update({
      //       index: indexName,
      //       id: order._id,
      //       body: {
      //         doc: updatedDocument,
      //       },
      //     });
      //   }
      // }
      return { success: true, message: "Product updated successfully" };
    } catch (error) {
      console.log(error, "error");
      return error;
    }
  },

  searchTopSellingProducts: async (index, { store_id, month = 1 }) => {
    console.log(store_id, "store_id");
    // Define the query
    const query = {
      query: {
        bool: {
          must: [
            {
              match: {
                store_id: store_id,
              },
            },
            {
              match: {
                is_deleted: false,
              },
            },
          ],
        },
      },

      size: 0,
      aggs: {
        top_products: {
          terms: {
            field: "product_id",
            size: 10,
            order: {
              revenue: "desc",
            },
          },
          aggs: {
            order_details: {
              top_hits: {
                size: 1,
                _source: {
                  includes: ["order_id", "product_id", "price", "quantity", "createdAt", "generate_id", "isPaymentDone", "product_info"],
                },
              },
            },
            total_orders: {
              sum: {
                field: "quantity",
              },
            },
            revenue: {
              sum: {
                script: {
                  source: "params['_source']['price'] * params['_source']['quantity']",
                },
              },
            },
            past_revenue: {
              filter: {
                range: {
                  createdAt: {
                    gte: moment()
                      .subtract(month + 1, "months")
                      .format("YYYY-MM-DD"),
                    lte: moment().subtract(month, "months").format("YYYY-MM-DD"),
                  },
                },
              },
              aggs: {
                revenue: {
                  sum: {
                    script: {
                      source: "params['_source']['price'] * params['_source']['quantity']",
                    },
                  },
                },
              },
            },
          },
        },
      },
    };

    try {
      const data = await client.search({
        index: "orders",
        body: query,
      });
      if (!data?.aggregations?.top_products?.buckets) return { status: false, message: "No data found" };
      let response = [];
      for (const final of data?.aggregations?.top_products?.buckets) {
        let response_object = {
          product_id: final?.key,
          total_orders: final?.total_orders?.value,
          revenue: final?.revenue?.value,
          past_revenue: final?.past_revenue?.revenue?.value,
          past_revenue_diff: final?.revenue?.value - final?.past_revenue?.revenue?.value,
          past_revenue_diff_percentage: final?.past_revenue?.revenue?.value !== 0 ? ((final?.revenue?.value - final?.past_revenue?.revenue?.value) / final?.past_revenue?.revenue?.value) * 100 : 0,
          order_details: final?.order_details?.hits?.hits[0]?._source,
        };
        response.push(response_object);
      }
      return { status: true, data: response };
    } catch (error) {
      console.error(error);
    }
  },

  productStockFilter: async (index, { store_id, stock_status }) => {
    let qty = { gt: 0 };
    let validStockStatus = ["in_stock", "low_stock", "out_of_stock"];
    if (stock_status && !validStockStatus.includes(stock_status)) return { success: false, message: "stock_status not valid" };
    if (stock_status === "in_stock") {
      qty = { gt: 20 };
    }
    if (stock_status === "low_stock") {
      qty = { lte: 20 };
    }
    if (stock_status === "out_of_stock") {
      qty = { lte: 0 };
    }
    const query = {
      // _source: ['id', 'title', 'cropImages', 'price', 'stock_status', 'quantity', 'sku'],
      _source: [],
      query: {
        bool: {
          must: [
            { match: { store_id: store_id } },
            { range: { quantity: qty } },
            {
              match: {
                is_deleted: false,
              },
            },
          ],
        },
      },
      // query: {
      //     match: {
      //         store_id: store_id,

      //     }
      // },
      script_fields: {
        current_stock_status: {
          script: {
            source: "if (doc['quantity'].value <= 0) { return 'Out of Stock' } else if (doc['quantity'].value <= 20) { return 'Low Stock' } else { return 'In Stock' }",
          },
        },
      },
    };
    try {
      const response = await client.search({
        index: "products",
        body: query,
      });
      if (!response?.hits?.hits) return { success: false, message: "Error - elasticsearch - Data not gound" };
      let result = [];
      for (let res of response.hits.hits) {
        let stock_status = { current_stock_status: res.fields.current_stock_status[0] };
        res = { ...stock_status, ...res._source };
        console.log(res.current_stock_status);
        result.push(res);
      }
      // console.log(result);
      return { success: true, message: "Data fetch successfully", data: result };
      // console.log("Data", data);
    } catch (error) {
      console.log(error);
    }
  },

  searchProductsWithElasticSearch: async (index, { search, page = 1, limit = 10, sort, order, user_id, minPrice, maxPrice }) => {
    // page = page > 0 ? page - 1 : 0;
    const response = await client.search({
      index: "store",
      _source: ["id"],
      body: {
        query: {
          match: {
            status: "Active",
          },
          // match_all: {},
        },
      },
      size: 10000,
    });
    const sellerIds = response.hits.hits.map((hit) => hit._source.id);
    const activeStoreIds = sellerIds;

    let products_mapped;
    let product_data;
    const stopWords = [
      "and",
      "or",
      "but",
      "if",
      "the",
      "a",
      "an",
      "to",
      "in",
      "with",
      "on",
      "for",
      "at",
      "by",
      "from",
      "up",
      "down",
      "out",
      "about",
      "as",
      "into",
      "like",
      "through",
      "after",
      "over",
      "between",
      "off",
      "since",
      "until",
      "while",
      "of",
    ];

    const keywords = cleanSearchTerm(search);

    function cleanSearchTerm(searchTerm) {
      let cleaned = searchTerm.replace(/[^\w\s]/gi, "");
      let words = cleaned.split(" ");
      words = words.filter((word) => !stopWords.includes(word.toLowerCase()));
      return words;
    }

    const shouldQueries = keywords.map((keyword) => ({
      match: {
        title: {
          query: keyword,
          operator: "and",
        },
      },
    }));

    let products = await client.search({
      index: "products",
      body: {
        from: (page - 1) * limit, // Calculate the offset based on page and limit
        size: limit,
        track_total_hits: true,
        query: {
          bool: {
            filter: [
              {
                terms: {
                  store_id: sellerIds,
                },
              },
              {
                match: {
                  status: "Publish",
                },
              },
              {
                range: {
                  dis_price: {
                    gte: minPrice,
                    lte: maxPrice,
                  },
                },
              },
            ],
          },
        },
        ...(search !== "" && {
          query: {
            bool: {
              should: shouldQueries,
              minimum_should_match: keywords?.length >= 2 ? 2 : 1,
              filter: [
                {
                  terms: {
                    store_id: sellerIds,
                  },
                },
                {
                  match: {
                    status: "Publish",
                  },
                },
                {
                  range: {
                    dis_price: {
                      gte: minPrice,
                      lte: maxPrice,
                    },
                  },
                },
              ],
            },
          },
        }),
        sort: [{ createdAt: { order: "asc" } }],
      },
    });
    const totalProductCount = products?.hits?.total?.value ? products?.hits?.total?.value : 0;
    products_mapped = products?.hits?.hits.map((product) => {
      return { ...product._source, type: "product" };
    });

    const getProductDetails = async (products, user_id) => {
      for await (let product of products) {
        const like = await database.Like.count({
          where: {
            product_id: product.id,
          },
        });
        const comment = await database.Comment.count({
          where: {
            product_id: product.id,
          },
        });
        product.like_count = like;
        product.comment_count = comment;
      }
      return products;
    };

    product_data = await getProductDetails(products_mapped, user_id);
    return { success: true, message: "Data fetch successfully", data: { products: product_data, total: totalProductCount } };
  },

  globalSearchWithElasticSearch: async (index, { search, page = 1, limit = 10, sort, order, user_id }) => {
    page = page > 0 ? page - 1 : 0;

    let products = await client.search({
      index: "products",
      body: {
        from: (page - 1) * limit, // Calculate the offset based on page and limit
        size: limit,
        query: {
          bool: {
            must: [
              search
                ? {
                  bool: {
                    should: [
                      {
                        regexp: {
                          title: `.*${search.toLowerCase()}.*`,
                        },
                      },
                      {
                        regexp: {
                          description: `.*${search.toLowerCase()}.*`,
                        },
                      },
                      {
                        regexp: {
                          meta_description: `.*${search.toLowerCase()}.*`,
                        },
                      },
                      {
                        regexp: {
                          meta_title: `.*${search.toLowerCase()}.*`,
                        },
                      },
                      {
                        regexp: {
                          metameta_keyword_description: `.*${search.toLowerCase()}.*`,
                        },
                      },
                    ],
                  },
                }
                : { match: { is_deleted: false } },
              // { match: { is_deleted: false } },
            ],
          },
        },
      },
    });
    products = products?.hits?.hits.map((product) => {
      return { ...product._source, type: "product" };
    });

    //* get product extra details */
    const getProductDetails = async (products, user_id) => {
      for await (let product of products) {
        /* get product like count */
        const like = await database.Like.count({
          where: {
            product_id: product.id,
          },
        });
        /* get product comment count */
        const comment = await database.Comment.count({
          where: {
            product_id: product.id,
          },
        });
        product.like_count = like;
        product.comment_count = comment;
      }
      return products;
    };
    products = await getProductDetails(products, user_id);
    /* store search with elasticsearch */

    //* ======================================== OLD_CODE_FOR_SEARCH_START =====================================================
    // let stores = await client.search({
    //     index: 'store',
    //     size: 10000,
    //     body: {
    //         from: page,
    //         size: limit,
    //         ...(search
    //             ? {
    //                 query: {
    //                     bool: {
    //                         must: [
    //                             {
    //                                 multi_match: {
    //                                     query: `.*${search}*.`,
    //                                     fields: ["name", "companyLegalName"],
    //                                     type: "phrase_prefix",
    //                                 },
    //                             },
    //                         ],
    //                     },
    //                 },
    //             }
    //             : { query: { match_all: {} } }),
    //     },
    // });

    //* ======================================== OLD_CODE_FOR_SEARCH_END =====================================================
    console.log("search+++++++++++++++++++", search);
    let stores;
    const stores_value = await client.search({
      index: "store",
      size: 10000,
      body: {
        from: page,
        size: limit,
        ...(search !== ""
          ? {
            query: {
              bool: {
                should: [
                  {
                    regexp: {
                      category: `.*${search.toLowerCase()}.*`,
                    },
                  },
                  {
                    regexp: {
                      subCategory: `.*${search.toLowerCase()}.*`,
                    },
                  },
                  {
                    regexp: {
                      name: `.*${search.toLowerCase()}.*`,
                    },
                  },
                  // {
                  //   regexp: {
                  //     companyLegalName: `.*${search.toLowerCase()}.*`,
                  //   },
                  // },
                ],
              },
            },
          }
          : // : { query: { match_all: {} } }),
          {
            query: { match_all: {} },
            //   query: {
            //     bool: {
            //       must: [{ term: { category: "Fashion & Accessories" } }, { term: { subCategory: "Boys" } }],
            //     },
            //   },
            //   query: {
            //     bool: {
            //       must: [{ match: { category: "Fashion & Accessories" } }, { match: { subCategory: "Boys" } }],
            //     },
            //   },
          }),
      },
    });

    console.log("stores_value+++++++++++++++++++++++++++++++++++++++++", stores_value);
    //   let stores;

    //* get stores extra details */
    store_data_mapped = stores_value?.hits?.hits.map((store) => {
      return { ...store._source, type: "store" };
    });
    let storesArray = [];
    const getStoreDetails = async (stores, store_id) => {
      for (let i = 0; i < stores.length; i++) {
        const store = stores[i];
        if (user_id) {
          let isFollow = await database.FollowStore.findOne({
            where: {
              store_id: store.id,
              user_id: Number(user_id),
            },
          });
          store.isFollow = isFollow ? true : false;
          let isLike = await database.StoreLike.findOne({
            where: {
              store_id: store.id,
              user_id: Number(user_id),
            },
          });
          store.isLike = isLike ? true : false;
        } else {
          store.isLike = false;
          store.isFollow = false;
        }

        // let products_count = await client.count({
        //   index: "products",
        //   body: {
        //     query: {
        //       match: {
        //         store_id: store.id,
        //       },
        //     },
        //   },
        // });
        // store.products_count = products_count?.count;
        // /* get store activity */
        // let start_date = moment().subtract(30, "days").toISOString();
        // let end_date = moment().toISOString();
        // let data = await storeActivity.getAllStoreActivityChartData({ store_id: store.id, start_date, end_date });
        // store.total_visitors = data?.current_total_user_reached_count;
        // store.past_visitors = data?.previous_total_user_reached_count_percentage;

        // /* user isFollow store or not */
        // let isFollow;
        // if (user_id) {
        //   isFollow = await client.search({
        //     index: "store-followers",
        //     body: { query: { bool: { must: [{ match: { store_id: store.id } }, { match: { user_id: user_id } }] } } },
        //   });
        // } else {
        //   isFollow = await client.search({
        //     index: "store-followers",
        //     body: { query: { bool: { must: [{ match: { store_id: store.id } }] } } },
        //   });
        // }
        // store.isFollow = user_id ? (isFollow?.hits?.hits?.length > 0 ? true : false) : false;

        if (store.product_count > 0) storesArray.push(store);
      }
      return storesArray;
    };
    stores = await getStoreDetails(store_data_mapped);

    //* get User details */
    let users = await client.search({
      index: "user",
      // size: 10000,
      body: {
        from: page,
        size: limit,
        ...(search
          ? {
            query: {
              bool: {
                must: [
                  {
                    multi_match: {
                      query: `.*${search}*.`,
                      fields: ["firstName", "lastName"],
                      type: "phrase_prefix",
                    },
                  },
                ],
              },
            },
          }
          : { query: { match_all: {} } }),
        sort: [
          {
            createdAt: {
              order: "asc",
            },
          },
        ],
      },
    });
    users = users?.hits?.hits.map((user) => {
      return { ...user._source, type: "user" };
    });

    const getUsersDetails = async (users) => {
      for (let i = 0; i < users.length; i++) {
        const user = users[i];
        /*get followers count */
        let users_followers_count = await database.Friend.count({
          where: {
            user_id: Number(user.id),
            isFriend: true,
          },
        });
        /* is follow user or not */

        let isFollow;

        if (user_id) {
          isFollow = await database.Friend.findOne({
            where: {
              user_id: Number(user_id),
              friend_id: Number(user.id),
              // isFriend: true,
            },
          });
        } else {
          isFollow = await database.Friend.findOne({
            where: {
              friend_id: Number(user.id),
              // isFriend: true,
            },
          });
        }
        user.isFollow = user_id ? (isFollow ? true : false) : false;
        user.followers_count = users_followers_count;
      }
      return users;
    };
    users = await getUsersDetails(users);
    //* get User details */
    let groups = await client.search({
      index: "group",
      // size: 10000,
      body: {
        from: page,
        size: limit,
        ...(search
          ? {
            query: {
              bool: {
                must: [
                  {
                    multi_match: {
                      query: `.*${search}*.`,
                      fields: ["name"],
                      type: "phrase_prefix",
                    },
                  },
                ],
              },
            },
          }
          : { query: { match_all: {} } }),
        // sort: [
        //     {
        //         [sort]: {
        //             order: order,
        //         },
        //     },
        // ],
      },
    });
    groups = groups?.hits?.hits.map((user) => {
      return { ...user._source, type: "user" };
    });

    const getGroupsDetails = async (groups) => {
      for (let i = 0; i < groups.length; i++) {
        const group = groups[i];
        /* isJoined */
        let isJoined;

        if (user_id) {
          isJoined = await client.search({
            index: "join-group",
            size: 10000,
            body: {
              query: {
                bool: {
                  must: [
                    {
                      match: { group_id: group.id },
                    },
                    {
                      match: { user_id: user_id },
                    },
                  ],
                },
              },
            },
          });
        } else {
          isJoined = await client.search({
            index: "join-group",
            body: {
              query: {
                bool: {
                  must: [
                    {
                      match: { group_id: group.id },
                    },
                  ],
                },
              },
            },
          });
        }
        group.isFollow = user_id ? (isJoined?.hits?.hits.length > 0 ? true : false) : false;

        /* get group members */
        const groupMembers = await client.search({
          index: "join-group",
          body: {
            query: {
              bool: {
                must: [
                  {
                    match: { group_id: group.id },
                  },
                ],
              },
            },
          },
        });
        let membersIds = groupMembers?.hits?.hits.map((member) => {
          return member._source?.user_id;
        });
        let members = await client.search({
          index: "user",
          body: {
            query: {
              bool: {
                must: [
                  {
                    terms: { id: membersIds },
                  },
                ],
              },
            },
          },
        });
        members = members?.hits?.hits.map((member) => {
          return { ...member._source, type: "user" };
        });
        group.members = members.slice(0, 3);
        group.total_members = members.length;
      }
      return groups;
    };
    groups = await getGroupsDetails(groups);
    let result = { products, stores, users, groups };
    return { success: true, message: "Data fetch successfully", data: result };
  },

  getProductTractionElasticSearch: async (index, { product_id, start_date, end_date, time_interval, time_zone }) => {
    try {
      const getRevenueData = async (product_id, min_date, max_date, time_interval, time_zone) => {
        // const searchParams = {
        //   index: "product-views",
        //   query: {
        //     bool: {
        //       must: [
        //         {
        //           match: {
        //             product_id: product_id,
        //           },
        //         },
        //         {
        //           range: {
        //             createdAt: {
        //               gte: min_date,
        //               lte: max_date,
        //             },
        //           },
        //         },
        //       ],
        //     },
        //   },
        //   size: 0,
        //   body: {
        //     aggs: {
        //       date_counts: {
        //         date_histogram: {
        //           field: "createdAt",
        //           calendar_interval: time_interval ? time_interval : "month",
        //           time_zone: time_zone ? time_zone : "Asia/Kolkata",
        //           extended_bounds: {
        //             min: min_date,
        //             max: max_date,
        //           },
        //         },
        //         // aggs: {
        //         //   store_revenue: {
        //         //     sum: {
        //         //       field: "totalAmount",
        //         //     },
        //         //   },
        //         // },
        //       },
        //       // total_store_revenue: {
        //       //   sum: {
        //       //     field: "totalAmount",
        //       //   },
        //       // },
        //       // total_orders: {
        //       //   value_count: {
        //       //     field: "id",
        //       //   },
        //       // },
        //     },
        //   },
        // };
        // const response = await client.search(searchParams);

        const response = await client.msearch({
          body: [
            { index: "product-comments" },
            {
              query: {
                bool: {
                  must: [
                    {
                      match: {
                        product_id: product_id,
                      },
                    },
                    {
                      range: {
                        createdAt: {
                          gte: min_date,
                          lte: max_date,
                        },
                      },
                    },
                  ],
                },
              },
              size: 0,
              aggs: {
                date_counts: {
                  date_histogram: {
                    field: "createdAt",
                    calendar_interval: time_interval ? time_interval : "month",
                    time_zone: time_zone ? time_zone : "Asia/Kolkata",
                    extended_bounds: {
                      min: min_date,
                      max: max_date,
                    },
                  },
                },
              },
            },
            { index: "product-views" },
            {
              query: {
                bool: {
                  must: [
                    {
                      match: {
                        product_id: product_id,
                      },
                    },
                    {
                      range: {
                        createdAt: {
                          gte: min_date,
                          lte: max_date,
                        },
                      },
                    },
                  ],
                },
              },
              size: 0,
              aggs: {
                date_counts: {
                  date_histogram: {
                    field: "createdAt",
                    calendar_interval: time_interval,
                    time_zone: time_zone,
                    extended_bounds: {
                      min: min_date,
                      max: max_date,
                    },
                  },
                },
              },
            },
            { index: "order_items" },
            {
              query: {
                bool: {
                  must: [
                    {
                      match: {
                        product_id: product_id,
                      },
                    },
                    {
                      range: {
                        createdAt: {
                          gte: min_date,
                          lte: max_date,
                        },
                      },
                    },
                  ],
                },
              },
              size: 0,
              aggs: {
                date_counts: {
                  date_histogram: {
                    field: "createdAt",
                    calendar_interval: time_interval,
                    time_zone: time_zone,
                    extended_bounds: {
                      min: min_date,
                      max: max_date,
                    },
                  },
                },
              },
            },
          ],
        });

        console.log(
          "response++++++++++++++++++++++++++++++++++",
          response?.responses?.map((data) => {
            let count = data?.hits;
            return count;
          })
        );

        return response?.responses?.map((data) => {
          let count = data?.aggregations.date_counts.buckets;
          return count?.map((sub) => {
            return sub?.doc_count;
          });
        });
        // const dateCounts = response.aggregations.date_counts.buckets;

        // // console.log("fsdafasdfadasfasfsafdsafafasdf+++++++++++++++++", response.aggregations.date_counts.buckets);
        // const formattedData = dateCounts.map((bucket) => [
        //   bucket.key, // Date in the desired format
        //   bucket.store_revenue.value || 0, // Revenue sum (if available) or 0 as default
        // ]);
        // // return formattedData
        // return {
        //   data: formattedData,
        //   revenue: response?.aggregations?.total_store_revenue?.value || 0,
        //   average_order_value: response?.aggregations?.total_store_revenue?.value / response?.aggregations?.total_orders?.value || 0,
        // };
      };
      let current_data_response = await getRevenueData(product_id, start_date, end_date, time_interval, time_zone);

      console.log("current_data_response++++++++++++++++++++", current_data_response);
      return current_data_response;
      // let current_data = current_data_response.data;
      // let current_revenue = current_data_response.revenue;

      // let { previous_start_date, previous_end_date } = await getPreviousDate(start_date, end_date, time_interval, time_zone);
      // let previous_revenue = (await getRevenueData(previous_start_date, previous_end_date)).revenue;
      // // current_revenue and previous_revenue in percentage
      // let current_revenue_percentage = previous_revenue !== 0 ? (((previous_revenue - current_revenue) / previous_revenue) * 100).toFixed(2) : 0;

      // return {
      //   current_revenue: current_revenue,
      //   previous_revenue_percentage: current_revenue_percentage,
      //   current_data: current_data,
      // };
    } catch (error) {
      console.error(error);
    }
  },
};
