const client = require("../config/config");
let validationSchema = require("../validation/index");
const moment = require("moment");
const storeActivity = require("../storeActivity/storeActivity");
const database = require("../../../database/models");

module.exports = self = {
  /* ************ Create index for orders ************ */
  createIndexForStore: async (indexName) => {
    try {
      console.log("+++++++++++++++++++ ENTERS in index cretion +++++++++++++++++++");
      const indexExists = await client.indices.exists({ index: indexName });

      if (indexExists) {
        console.log(`Index "${indexName}" already exists.`);
        return { success: false, message: `Index "${indexName}" already exists.` };
      }

      let storeIndex = await client.indices.create({
        index: indexName,
        body: {
          mappings: {
            properties: {
              id: { type: "integer" },
              user_id: { type: "integer" },
              seller_id: { type: "integer" },
              name: { type: "text" },
              companyLegalName: { type: "text" },
              streetAddress: { type: "text" },
              city: { type: "text" },
              state: { type: "text" },
              postalCode: { type: "text" },
              websiteUrl: { type: "text" },
              isHaveTeam: { type: "boolean" },
              annualSale: { type: "text" },
              totalEmployees: { type: "text" },
              logo: { type: "text" },
              cover_image: { type: "text" },
              sellerType: { type: "text" },
              companyLegalName: { type: "text" },
              businessType: { type: "text" },
              shortDescription: { type: "text" },
              longDescription: { type: "text" },
              country: { type: "text" },
              employmentType: { type: "text" },
              profession: { type: "text" },
              title: { type: "text" },
              BusinessInformationFor: { type: "keyword" },
              isDeleted: { type: "boolean" },
              createdAt: { type: "date" },
            },
          },
        },
      });

      return { success: true, message: "Index created successfully.", data: storeIndex };
    } catch (error) {
      return error;
    }
  },
  /* ************ Put mapping for orders ************ */
  putMappingForStore: async (indexName) => {
    let storePutMapping = await client.indices.putMapping({
      index: indexName,
      body: {
        properties: {
          id: { type: "integer" },
          user_id: { type: "integer" },
          seller_id: { type: "integer" },
          name: { type: "text" },
          companyLegalName: { type: "text" },
          streetAddress: { type: "text" },
          city: { type: "text" },
          state: { type: "text" },
          postalCode: { type: "text" },
          websiteUrl: { type: "text" },
          isHaveTeam: { type: "boolean" },
          annualSale: { type: "text" },
          totalEmployees: { type: "text" },
          logo: { type: "text" },
          cover_image: { type: "text" },
          sellerType: { type: "text" },
          businessType: { type: "text" },
          shortDescription: { type: "text" },
          longDescription: { type: "text" },
          country: { type: "text" },
          employmentType: { type: "text" },
          profession: { type: "text" },
          title: { type: "text" },
          BusinessInformationFor: { type: "keyword" },
          isDeleted: { type: "boolean" },
          createdAt: { type: "date" },
        },
      },
    });
    return storePutMapping;
  },

  /* ************ Add Single data for store ************ */
  createStore: async (data, indexName = "store") => {
    try {
      // console.log(data, "data");
      // let error = validationSchema("createStoreIndexSchema", data);
      // if (error) return { success: false, message: error };
      // index exists or not
      const indexExists = await client.indices.exists({
        index: indexName,
      });
      if (!indexExists) {
        let check = await self.createIndexForStore(indexName);
      }
      const store = await client.search({
        index: indexName,
        body: {
          query: {
            match: {
              id: data.id,
            },
          },
        },
      });
      if (store.hits.hits.length > 0) {
        return { success: false, message: "You're already reply this comment" };
      }

      console.log(indexName, "indexName+++++++++++++++++++++++++++++++");
      const Store = await client.index({
        index: indexName,
        body: {
          ...data,
          createdAt: moment().toISOString(),
        },
      });
      console.log(Store, "Store");
      return { success: true, message: "store added successfully", data: Store };
    } catch (error) {
      console.log(error, "error");
    }
  },

  /* ************ Add data for orders ************ */
  getAllStore: async (indexName) => {
    const data = await client.search({
      index: indexName,
    });
    const ordersData = data.hits.hits.map((hit) => {
      return { ...hit._source, _id: hit._id };
    });
    return ordersData;
  },
  /* ************ delete store by id ************ */
  deleteStore: async ({ id }, indexName = "store") => {
    try {
      // search product by id

      const existData = await client.search({
        index: indexName,
        body: {
          query: {
            bool: {
              must: [{ match: { id } }],
            },
          },
        },
      });
      let _id = existData?.hits?.hits[0]?._id;
      if (!_id) {
        return { success: false, message: "Store does not exists" };
      }
      const commentData = await client.delete({
        index: indexName,
        id: _id,
      });
      // console.log(commentData.result, "commentData");
      return { success: true, message: "Store deleted successfully", data: commentData.result };
    } catch (error) {
      console.log(error, "error");
      return error;
    }
  },

  /* ************ delete store(s) by ids ************ */
  deleteStoresByAdmin: async (store_ids, indexName = "store") => {
    try {

    let response = [];

    for (const id of store_ids) {
      const existData = await client.search({
        index: indexName,
        body: {
          query: {
            term: {
              id: id
            }
          },
        },
      });
      response.push(existData);
    }

    const filteredResponses = response.filter((res) => res.hits.hits.length);

    for await (let filteredResponse of filteredResponses) {
      filteredResponse = filteredResponse.hits.hits[0];
      const _source = filteredResponse._source;
      const updatedDocument = {
        ..._source,
        is_deleted: true
      };
      const updateResponse = await client.update({
        index: indexName,
        id: filteredResponse._id,
        body: {
          doc: updatedDocument,
        },
      });
    }

    return { success: true, message: "Store(s) deleted successfully." };

    } catch (error) {
      console.error("An error occured during removing store(s) in elastic search: ", error);
      throw new Error("An error occured during removing store(s)!");
    }
  },

  /* ************ update store by id ************ */
  updateStoreById: async (indexName, id, data) => {
    try {
      // if exists
      const isExists = await client.search({
        index: indexName,
        body: {
          query: {
            match: {
              id: id,
            },
          },
        },
      });
      if (isExists.hits.hits.length === 0) {
        return { success: false, message: "Store does not exists" };
      }
      if (isExists.hits.hits.length > 0) {
        let orders = isExists.hits.hits;
        for (let i = 0; i < orders.length; i++) {
          const store = orders[i];
          // if exists
          const commentExists = await client.exists({
            index: indexName,
            id: store._id,
          });
          // console.log(commentExists, "commentExists");
          if (!commentExists) {
            console.log("Store does not exists");
            return { success: false, message: "Store does not exists" };
          }

          const commentData = await client.get({
            index: indexName,
            id: store._id,
          });

          const _source = commentData._source;

          const updatedDocument = {
            ..._source,
            ...data,
          };
          // const updatedDocument = data
          const updateResponse = await client.update({
            index: indexName,
            id: store._id,
            body: {
              doc: updatedDocument,
            },
          });
        }
      }
      return { success: true, message: "Store updated successfully" };
    } catch (error) {
      console.log(error, "error");
      return error;
    }
  },
  /* ************ get store chart data  ************ */

  getAllStoreChartData: async ({ store_id, comment_for, start_date, end_date, time_interval, time_zone }, indexName = "store") => {
    try {
      console.log("start_date, end_date", start_date, end_date);
      const getStoresData = async (min_date, max_date, time_interval, time_zone, comment_for) => {
        console.log("min_date, max_date", min_date, max_date);
        const searchParams = {
          index: indexName,
          // match with store_id
          query: {
            bool: {
              must: [
                {
                  match: { store_id: store_id },
                },
                {
                  match: { comment_for: comment_for || "STORE" },
                },
                {
                  range: {
                    createdAt: {
                      gte: min_date,
                      lte: max_date,
                    },
                  },
                },
              ],
            },
          },
          size: 0,
          body: {
            aggs: {
              date_counts: {
                date_histogram: {
                  field: "createdAt",
                  calendar_interval: time_interval ? time_interval : "day",
                  time_zone: time_zone ? time_zone : "Asia/Kolkata",
                  extended_bounds: {
                    min: min_date,
                    max: max_date,
                  },
                },
                aggs: {
                  store_count: {
                    cardinality: {
                      field: "createdAt",
                    },
                  },
                },
              },
              total_store_count: {
                cardinality: {
                  field: "createdAt",
                },
              },
            },
          },
        };
        console.log("searchParams", JSON.stringify(searchParams));
        const response = await client.search(searchParams);
        console.log("response", JSON.stringify(response));
        const dateCounts = response.aggregations.date_counts.buckets;
        // console.log("response.aggregations", dateCounts)
        const formattedData = dateCounts.map((bucket) => [
          bucket.key, // Date in the desired format
          bucket.store_count.value || 0, // Revenue sum (if available) or 0 as default
        ]);
        // console.log("response?.aggregations", response?.aggregations?.total_store_count);
        // return formattedData
        return { data: formattedData, total_store_count: response?.aggregations?.total_store_count?.value || 0 };
      };
      // console.log("start_date, end_date", start_date, end_date);
      let current_data_called = await getStoresData(start_date, end_date, time_interval, time_zone, comment_for);
      // console.log("current_data_called", 1111, current_data_called.total_store_count);
      let current_data = current_data_called.data;
      let current_total_store_count = current_data_called.total_store_count;

      const startDateCheck = moment(start_date);
      const endDateCheck = moment(end_date);
      const diff = endDateCheck.diff(startDateCheck); // Calculate the difference between dates in milliseconds
      // console.log(start_date);
      const previousStartDate = startDateCheck.subtract(diff).toISOString();
      let prev_min_date = previousStartDate;
      let prev_max_date = moment(start_date).toISOString();
      // let previous_data = (await getStoresData(prev_min_date, prev_max_date)).data;
      let previous_total_store_count = (await getStoresData(prev_min_date, prev_max_date, time_interval, time_zone, comment_for)).total_store_count;
      // current_total_store_count and previous_total_store_count in percentage
      let current_total_store_count_percentage = previous_total_store_count !== 0 ? (((previous_total_store_count - current_total_store_count) / previous_total_store_count) * 100).toFixed(2) : 0;
      return {
        current_total_store_count: current_total_store_count,
        // previous_total_store_count: current_total_store_count_percentage,
        previous_total_store_count_percentage: current_total_store_count_percentage,
        current_data: current_data,
        // previous_data: previous_data
      };
    } catch (error) {
      console.error(error);
    }
  },

  /* search store by id */
  searchStoressWithElasticSearch: async (index, { search, page = 1, limit = 10, sort, order, user_id, isCategoryFilter, category, subCategory }) => {
    page = page > 0 ? page - 1 : 0;

    /* store search with elasticsearch */

    //* ======================================== OLD_CODE_FOR_SEARCH_START =====================================================

    // let stores = await client.search({
    //   index: "store",
    //   size: 10000,
    //   body: {
    //     from: page,
    //     size: limit,
    //     ...(search
    //       ? {
    //           query: {
    //             bool: {
    //               must: [
    //                 {
    //                   multi_match: {
    //                     query: `.*${search}*.`,
    //                     fields: ["name", "companyLegalName"],
    //                     type: "phrase_prefix",
    //                   },
    //                 },
    //               ],
    //             },
    //           },
    //         }
    //       : { query: { match_all: {} } }),
    //   },
    // });

    //* ======================================== OLD_CODE_FOR_SEARCH_END =====================================================
    let store_data_mapped = [];
    const stores = await client.search({
      index: "store",
      body: {
        from: page,
        size: limit,
        ...(isCategoryFilter
          ? {
              query: {
                bool: {
                  must: [{ match: { category: category } }, { match: { status: "Active" } }, { range: { product_count: { gt: 0 } } }, { match: { subCategory: subCategory } }],
                },
              },
              sort: [{ createdAt: { order: "asc" } }],
            }
          : search !== ""
          ? {
              query: {
                bool: {
                  must: [
                    { match: { status: "Active" } },
                    { range: { product_count: { gt: 0 } } },
                    {
                      bool: {
                        should: [
                          {
                            regexp: {
                              category: `.*${search.toLowerCase()}.*`,
                            },
                          },
                          {
                            regexp: {
                              name: `.*${search.toLowerCase()}.*`,
                            },
                          },
                        ],
                      },
                    },
                  ],
                },
              },
              sort: [{ createdAt: { order: "asc" } }],
            }
          : {
              query: {
                bool: {
                  must: [{ match: { status: "Active" } }, { range: { product_count: { gt: 0 } } }],
                },
              },
              sort: [
                { createdAt: { order: "desc" } }, // Sort by createdAt field in ascending order
              ],
            }),
      },
    });

    let store_data;
    /* get stores extra details */
    store_data_mapped = stores?.hits?.hits.map((store) => {
      return { ...store._source, type: "store" };
    });

    let storesArray = [];
    const getStoreDetails = async (stores, store_id) => {
      for (let i = 0; i < stores.length; i++) {
        const store = stores[i];
        if (user_id) {
          let isFollow = await database.FollowStore.findOne({
            where: {
              store_id: store.id,
              user_id: Number(user_id),
            },
          });
          store.isFollow = isFollow ? true : false;
          let isLike = await database.StoreLike.findOne({
            where: {
              store_id: store.id,
              user_id: Number(user_id),
            },
          });
          store.isLike = isLike ? true : false;
        } else {
          store.isLike = false;
          store.isFollow = false;
        }

        // let products_count = await client.count({
        //   index: "products",
        //   body: {
        //     query: {
        //       match: {
        //         store_id: store.id,
        //       },
        //     },
        //   },
        // });
        // store.products_count = products_count?.count;
        // /* get store activity */
        // let start_date = moment().subtract(30, "days").toISOString();
        // let end_date = moment().toISOString();
        // let data = await storeActivity.getAllStoreActivityChartData({ store_id: store.id, start_date, end_date });
        // store.total_visitors = data?.current_total_user_reached_count;
        // store.past_visitors = data?.previous_total_user_reached_count_percentage;

        // /* user isFollow store or not */
        // let isFollow;
        // if (user_id) {
        //   isFollow = await client.search({
        //     index: "store-followers",
        //     body: { query: { bool: { must: [{ match: { store_id: store.id } }, { match: { user_id: user_id } }] } } },
        //   });
        // } else {
        //   isFollow = await client.search({
        //     index: "store-followers",
        //     body: { query: { bool: { must: [{ match: { store_id: store.id } }] } } },
        //   });
        // }
        // store.isFollow = user_id ? (isFollow?.hits?.hits?.length > 0 ? true : false) : false;

        if (store.product_count > 0) storesArray.push(store);
      }
      return storesArray;
    };
    store_data = await getStoreDetails(store_data_mapped);
    let result = { stores: store_data };
    return { success: true, message: "Data fetch successfully", data: result };
  },
  /* get all search data */
  getAllStoresWithElasticSearch: async (index, { isFollow, page = 1, limit = 10, sort, order, user_id, allData }) => {
    page = page > 0 ? page - 1 : 0;

    /* store search with elasticsearch */
    let stores = await client.search({
      index: "store",
      body: {
        from: page,
        size: limit,
        query: { match_all: {} },
      },
      // sort: [
      //     {
      //         [sort]: {
      //             order: order,
      //         },
      //     },
      // ],
    });

    /* get stores extra details */
    stores = stores?.hits?.hits.map((store) => {
      return { ...store._source, type: "store" };
    });
    let storesArray = [];
    const getStoreDetails = async (stores, store_id) => {
      for (let i = 0; i < stores.length; i++) {
        const store = stores[i];
        /*get followers count */
        let followers_count = await client.count({
          index: "store-followers",
          body: {
            query: {
              match: {
                store_id: store.id,
              },
            },
          },
        });
        store.followers_count = followers_count?.count;
        /* get roducts count */
        let products_count = await client.count({
          index: "products",
          body: {
            query: {
              match: {
                store_id: store.id,
              },
            },
          },
        });
        store.products_count = products_count?.count;
        /* get store activity */
        let start_date = moment().subtract(30, "days").toISOString();
        let end_date = moment().toISOString();
        let data = await storeActivity.getAllStoreActivityChartData({ store_id: store.id, start_date, end_date });
        store.total_visitors = data?.current_total_user_reached_count;
        store.past_visitors = data?.previous_total_user_reached_count_percentage;

        /* user isFollow store or not */
        // let isFollow = await client.search({
        //     index: 'store-followers',
        //     body: { query: { bool: { must: [{ match: { store_id: store.id }, }, { match: { user_id: user_id }, },], }, }, },
        // });
        // store.isFollow = isFollow?.hits?.hits?.length > 0 ? true : false
        if (user_id) {
          let isFollow = await client.search({
            index: "store-followers",
            body: { query: { bool: { must: [{ match: { store_id: store.id } }, { match: { user_id: user_id } }] } } },
          });
          store.isFollow = isFollow?.hits?.hits?.length > 0 ? true : false;
        } else {
          store.isFollow = false;
        }
        if (!allData && store.products_count) storesArray.push(store);
        else if (allData) storesArray.push(store);
      }
      return storesArray;
    };
    stores = await getStoreDetails(stores);
    let check = isFollow === true || isFollow === false;
    console.log("isFollow", isFollow, check);
    stores = check ? stores.filter((store) => store.isFollow === isFollow && store.products_count) : stores;
    // stores = check ? stores.filter(store => store.isFollow === isFollow) : stores
    let result = { stores };
    return { success: true, message: "Data fetch successfully", data: result };
  },
};
