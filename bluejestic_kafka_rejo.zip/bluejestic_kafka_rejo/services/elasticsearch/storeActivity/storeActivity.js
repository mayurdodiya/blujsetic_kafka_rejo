const { userDevicesHelper, getPreviousDate, visitorsGenderHelper, visitorsLocationHelper } = require("../../../utils/utils");
const client = require("../config/config");
let validationSchema = require("../validation/index");
const moment = require("moment");
module.exports = {
    /* ************ Create index for orders ************ */
    createIndexForStoreActivities: async (indexName) => {
        try {
            console.log("+++++++++++++++++++ ENTERS in index cretion +++++++++++++++++++");
            const indexExists = await client.indices.exists({ index: indexName });

            if (indexExists) {
                console.log(`Index "${indexName}" already exists.`);
                return { success: false, message: `Index "${indexName}" already exists.` };
            }

            let storeActivityIndex = await client.indices.create({
                index: indexName,
                body: {
                    mappings: {
                        properties: {
                            id: { type: "integer" },
                            user_id: { type: "integer" },
                            store_id: { type: "integer" },
                            userType: { type: "keyword" },
                            startDate: { type: "date" },
                            endDate: { type: "date" },
                            deviceName: { type: "keyword" },
                            isDeleted: { type: "boolean", },
                            createdAt: { type: "date", },
                        },
                    },
                },
            });

            return { success: true, message: "Index created successfully.", data: storeActivityIndex };
        } catch (error) {
            return error;
        }
    },
    /* ************ Put mapping for orders ************ */
    putMappingForStoreActivities: async (indexName) => {
        let storeActivityPutMapping = await client.indices.putMapping({
            index: indexName,
            body: {
                properties: {
                    id: { type: "integer" },
                    user_id: { type: "integer" },
                    store_id: { type: "integer" },
                    userType: { type: "keyword" },
                    startDate: { type: "date" },
                    endDate: { type: "date" },
                    isDeleted: { type: "boolean", },
                    createdAt: { type: "date", },
                },
            },
        });
        return storeActivityPutMapping;
    },

    /* ************ Add Single data for storeActivity ************ */
    addStoreActivities: async (data, indexName = "store-activities") => {
        try {
            let error = validationSchema("createStoreActivitiesIndexSchema", data);
            if (error) return { success: false, message: error };
            // index exists or not
            const indexExists = await client.indices.exists({
                index: indexName,
            });
            if (!indexExists) {
                let check = await module.exports.createIndexForStoreActivities(indexName);
            }
            const storeFollower = await client.search({
                index: indexName,
                body: {
                    query: {
                        match: {
                            id: data.id,
                        },
                    },
                },
            });
            if (storeFollower.hits.hits.length > 0) {
                return { success: false, message: "store follower already exists" };
            }
            const StoreActivities = await client.index({
                index: indexName,
                body: { ...data, createdAt: moment().toISOString() },
            });
            return { success: true, message: "storeFollower added successfully", data: StoreActivities };
        } catch (error) {
            console.log(error, "error");
        }
    },

    /* ************ Add data for orders ************ */
    getAllStoreActivitiesData: async (indexName) => {
        const data = await client.search({
            index: indexName,
        });
        const ordersData = data.hits.hits.map((hit) => {
            return { ...hit._source, _id: hit._id };
        });
        return ordersData;
    },
    /* ************ delete storeActivity by id ************ */
    deleteStoreActivity: async ({ store_id, user_id }, indexName = "store-activities") => {
        try {
            // search storeFollower by id

            const existData = await client.search({
                index: indexName,
                body: {
                    query: {
                        bool: {
                            must: [
                                {
                                    match: { store_id: store_id, },
                                },
                                {
                                    match: { user_id: user_id, }
                                }
                            ],
                        },
                    },
                },
            });
            let _id = existData?.hits?.hits[0]?._id;
            if (!_id) { return { success: false, message: "StoreActivities does not exists" }; }
            const storeFollowerData = await client.delete({
                index: indexName,
                id: _id,
            });
            return { success: true, message: "StoreActivities deleted successfully", data: storeFollowerData.result };
        } catch (error) {
            console.log(error, "error");
            return error;
        }
    },

    /* ************ update storeActivity by id ************ */
    updateStoreActivitiesById: async (indexName, id, data) => {
        try {
            // if exists
            const isExists = await client.search({
                index: indexName,
                body: {
                    query: {
                        match: {
                            id: id
                        },
                    },
                },
            });
            if (isExists.hits.hits.length === 0) {
                return { success: false, message: "StoreActivities does not exists" };
            }
            if (isExists.hits.hits.length > 0) {
                let orders = isExists.hits.hits;
                for (let i = 0; i < orders.length; i++) {
                    const storeActivity = orders[i];
                    // if exists
                    const orderExists = await client.exists({
                        index: indexName,
                        id: storeActivity._id,
                    });
                    // console.log(orderExists, "orderExists");
                    if (!orderExists) {
                        console.log("StoreActivities does not exists");
                        return { success: false, message: "StoreActivities does not exists" };
                    }

                    const orderData = await client.get({
                        index: indexName,
                        id: storeActivity._id,
                    });

                    const _source = orderData._source;

                    const updatedDocument = {
                        ..._source,
                        ...data,
                    };
                    // const updatedDocument = data
                    const updateResponse = await client.update({
                        index: indexName,
                        id: storeActivity._id,
                        body: {
                            doc: updatedDocument,
                        },
                    });
                }
            }
            return { success: true, message: "StoreActivities updated successfully" };
        } catch (error) {
            console.log(error, "error");
            return error;
        }
    },

    /* ************ get storeActivity chart data  ************ */
    getAllStoreActivityChartData: async (
        { store_id, start_date, end_date, time_interval, time_zone }, indexName = "store-activities"
    ) => {
        try {
            const getRevenueData = async (min_date, max_date, time_interval, time_zone) => {
                const searchParams = {
                    index: indexName,
                    // match with store_id
                    query: {
                        bool: {
                            must: [
                                {
                                    match: {
                                        store_id: store_id,
                                    },
                                },
                                {
                                    range: {
                                        createdAt: {
                                            gte: min_date,
                                            lte: max_date,
                                        },
                                    },
                                },
                            ],
                        },
                    },
                    size: 0,
                    body: {
                        aggs: {
                            date_counts: {
                                date_histogram: {
                                    field: 'createdAt',
                                    calendar_interval: time_interval ? time_interval : 'day',
                                    time_zone: time_zone ? time_zone : "Asia/Kolkata",
                                    extended_bounds: {
                                        min: min_date,
                                        max: max_date,
                                    },
                                },
                                aggs: {
                                    user_reached_count: {
                                        cardinality: {
                                            field: "id"
                                        }
                                    },

                                },
                            },
                            total_user_reached_count: {
                                cardinality: {
                                    field: 'id',
                                }
                            }
                        },
                    },
                }
                const response = await client.search(searchParams);
                const dateCounts = response.aggregations.date_counts.buckets;
                const formattedData = dateCounts.map(bucket => [
                    bucket.key, // Date in the desired format
                    bucket.user_reached_count.value || 0, // Revenue sum (if available) or 0 as default
                ]);
                // return formattedData
                return { data: formattedData, total_user_reached_count: response?.aggregations?.total_user_reached_count?.value || 0 };
            }
            let current_data_called = (await getRevenueData(start_date, end_date, time_interval, time_zone));
            let current_data = current_data_called.data;
            let current_total_user_reached_count = current_data_called.total_user_reached_count;

            const startDateCheck = moment(start_date);
            const endDateCheck = moment(end_date);
            const diff = endDateCheck.diff(startDateCheck); // Calculate the difference between dates in milliseconds
            const previousStartDate = startDateCheck.subtract(diff).toISOString()
            let prev_min_date = previousStartDate
            let prev_max_date = moment(start_date).toISOString()
            // let previous_data = (await getRevenueData(prev_min_date, prev_max_date)).data;
            let previous_total_user_reached_count = (await getRevenueData(prev_min_date, prev_max_date)).total_user_reached_count
            // current_total_user_reached_count and previous_total_user_reached_count in percentage
            let current_total_user_reached_count_percentage = previous_total_user_reached_count !== 0 ? ((previous_total_user_reached_count - current_total_user_reached_count) / previous_total_user_reached_count * 100).toFixed(2) : 0
            return {
                current_total_user_reached_count: current_total_user_reached_count,
                // previous_total_user_reached_count: current_total_user_reached_count_percentage,
                previous_total_user_reached_count_percentage: current_total_user_reached_count_percentage,
                current_data: current_data,
                // previous_data: previous_data
            };
        } catch (error) {
            console.error(error);
        }
    },
    getUserDevicesData: async ({ store_id, start_date, end_date, time_interval, time_zone }, indexName = "store-activities") => {
        try {
            let current = await userDevicesHelper(store_id, start_date, end_date, time_interval, time_zone)
            // previous date
            let { previous_start_date, previous_end_date } = await getPreviousDate(start_date, end_date)
            let previous = await userDevicesHelper(store_id, previous_start_date, previous_end_date, time_interval, time_zone)
            /* previous percentage */
            for (let i = 0; i < previous.length; i++) {
                /* get two different array */
                let current_count = current[i].count
                let previous_count = previous[i].count
                let diffrence = previous_count !== 0 ? ((current_count - previous_count) / previous_count * 100).toFixed(2) : 0
                current[i].diffrence = diffrence
            }
            let genderObject = Object.fromEntries(current.map(z => [z.deviceName, { count: z.count, percentage: z.percentage, diffrence: z.diffrence }]))
            return { success: true, message: "Device details fetched", data: genderObject };
        } catch (error) {
            console.error('Error:', error);
            return { success: false, message: error.message };
        }
    },
    storeVisitorsGender: async ({ store_id, start_date, end_date, time_interval, time_zone }, indexName = "store-activities") => {
        try {
            let current = await visitorsGenderHelper(store_id, start_date, end_date, time_interval, time_zone)
            // previous date
            let { previous_start_date, previous_end_date } = await getPreviousDate(start_date, end_date)
            let previous = await visitorsGenderHelper(store_id, previous_start_date, previous_end_date, time_interval, time_zone)
            /* previous percentage */
            for (let i = 0; i < previous.length; i++) {
                /* get two different array */
                let current_count = current[i].count
                let previous_count = previous[i].count
                let diffrence = previous_count !== 0 ? ((current_count - previous_count) / previous_count * 100).toFixed(2) : 0
                current[i].diffrence = parseFloat(diffrence)
            }
            let genderObject = Object.fromEntries(current.map(z => [z.gender, { count: z.count, percentage: z.percentage, diffrence: z.diffrence }]))

            return { success: true, message: "Device details fetched", data: genderObject };
        } catch (error) {
            console.error('Error:', error);
            return { success: false, message: error.message };
        }
    },
    visitorsLocation: async ({ store_id, filter }, indexName = "store-activities") => {
        try {
            let current = await visitorsLocationHelper(store_id, filter)
            let genderObject = Object.fromEntries(current.map(z => [filter ? z[filter] : z.country, { count: z.count, percentage: z.percentage }]))
            return { success: true, message: "Device details fetched", data: genderObject };
        } catch (error) {
            console.error('Error:', error);
            return { success: false, message: error.message };
        }
    },
};
