const client = require("../config/config");
let validationSchema = require("../validation/index");
const moment = require("moment");
const database = require("../../../database/models");

module.exports = selfFunction = {
  /* ************ Create index for groups ************ */
  createIndexForGroup: async (indexName) => {
    try {
      console.log("+++++++++++++++++++ ENTERS in index cretion +++++++++++++++++++");
      const indexExists = await client.indices.exists({ index: indexName });

      if (indexExists) {
        console.log(`Index "${indexName}" already exists.`);
        return { success: false, message: `Index "${indexName}" already exists.` };
      }

      let groupIndex = await client.indices.create({
        index: indexName,
        body: {
          mappings: {
            properties: {
              id: { type: "integer" },
              name: { type: "text" },
              description: { type: "text" },
              hashtags: { type: "keyword" },
              category_id: { type: "integer" },
              coverImage: { type: "text" },
              bannerImage: { type: "text" },
              category: { type: "text" },
              privacy: { type: "text" },
              user_id: { type: "integer" },
              subCategory_id: { type: "integer" },
              isDeleted: { type: "boolean" },
              createdAt: { type: "date" },
            },
          },
        },
      });

      return { success: true, message: "Index created successfully.", data: groupIndex };
    } catch (error) {
      return error;
    }
  },
  /* ************ Put mapping for groups ************ */
  putMappingForGroup: async (indexName) => {
    let groupIndex = await client.indices.putMapping({
      index: indexName,
      body: {
        properties: {
          id: { type: "integer" },
          name: { type: "text" },
          description: { type: "text" },
          hashtags: { type: "text" },
          category_id: { type: "integer" },
          media_id: { type: "integer" },
          coverImage: { type: "text" },
          bannerImage: { type: "text" },
          category: { type: "text" },
          privacy: { type: "text" },
          user_id: { type: "integer" },
          subCategory_id: { type: "integer" },
          isDeleted: { type: "boolean" },
          createdAt: { type: "date" },
        },
      },
    });
    return groupIndex;
  },

  /* ************ Add Single data for groups ************ */
  addGroup: async (data, indexName = "group") => {
    try {
      // console.log(data, "data");
      // let error = validationSchema("createGroupIndexSchema", data);
      // if (error) return { success: false, message: error };
      // index exists or not
      const indexExists = await client.indices.exists({
        index: indexName,
      });
      console.log(indexExists, "indexExists");
      if (!indexExists) {
        let check = await module.exports.createIndexForGroup(indexName);
        console.log("checkcheckcheckcheckcheckcheck", check);
      }
      const group = await client.search({
        index: indexName,
        body: {
          query: {
            match: {
              id: data.id,
            },
          },
        },
      });
      if (group.hits.hits.length > 0) {
        return { success: false, message: "group already exists" };
      }
      console.log(indexName, "indexName+++++++++++++++++++++++++++++++");
      const Group = await client.index({
        index: indexName,
        body: { ...data, createdAt: moment().toISOString() },
      });
      console.log(Group, "Group");
      return { success: true, message: "group added successfully", data: Group };
    } catch (error) {
      console.log(error, "error");
      return { success: false, message: error };
    }
  },

  /* ************ Add data for groups ************ */
  getAllGroupData: async (indexName) => {
    const data = await client.search({
      index: indexName,
    });
    const groupsData = data.hits.hits.map((hit) => {
      return { ...hit._source, _id: hit._id };
    });
    return groupsData;
  },
  /* ************ delete groups by id ************ */
  deleteGroup: async ({ id, user_id }, indexName = "group") => {
    try {
      // search group by id
      if (!id) {
        return { success: false, message: "id requeired" };
      }
      const existData = await client.search({
        index: indexName,
        body: {
          query: {
            bool: {
              ...(user_id
                ? {
                    must: [
                      {
                        match: { id: id },
                      },
                      {
                        match: { user_id: user_id },
                      },
                    ],
                  }
                : {
                    must: [
                      {
                        match: { id: id },
                      },
                    ],
                  }),
            },
          },
        },
      });
      let _id = existData?.hits?.hits[0]?._id;
      if (!_id) {
        return { success: false, message: "Group does not exists" };
      }
      const groupData = await client.delete({
        index: indexName,
        id: _id,
      });
      return { success: true, message: "Group deleted successfully", data: groupData.result };
    } catch (error) {
      console.log(error, "error");
      return error;
    }
  },

  /* ************ update groups by id ************ */
  updateGroupById: async (id, data, indexName = "group") => {
    try {
      // if exists
      const isExists = await client.search({
        index: indexName,
        body: {
          query: {
            match: {
              id: id,
            },
          },
        },
      });
      if (isExists.hits.hits.length === 0) {
        return { success: false, message: "Group does not exists" };
      }
      if (isExists.hits.hits.length > 0) {
        let groups = isExists.hits.hits;
        for (let i = 0; i < groups.length; i++) {
          const group = groups[i];
          // if exists
          const groupExists = await client.exists({
            index: indexName,
            id: group._id,
          });
          // console.log(groupExists, "groupExists");
          if (!groupExists) {
            console.log("Group does not exists");
            return { success: false, message: "Group does not exists" };
          }

          const groupData = await client.get({
            index: indexName,
            id: group._id,
          });

          const _source = groupData._source;

          const updatedDocument = {
            ..._source,
            ...data,
          };
          // const updatedDocument = data
          const updateResponse = await client.update({
            index: indexName,
            id: group._id,
            body: {
              doc: updatedDocument,
            },
          });
        }
      }
      return { success: true, message: "Group updated successfully" };
    } catch (error) {
      console.log(error, "error");
      return error;
    }
  },
  searchGroupsWithElasticSearch: async (index, { search, page = 1, limit = 10, sort, order, user_id }) => {
    page = page > 0 ? page - 1 : 0;

    let find_groups = [];
    let mapped_goups = [];
    let final_group = [];

    find_groups = await client.search({
      index: "group",
      body: {
        from: page,
        size: limit,
        ...(search
          ? {
              query: {
                bool: {
                  must: [
                    {
                      multi_match: {
                        query: `.*${search}*.`,
                        fields: ["name"],
                        type: "phrase_prefix",
                      },
                    },
                  ],
                },
              },
            }
          : { query: { match_all: {} } }),
        // sort: [
        //     {
        //         [sort]: {
        //             order: order,
        //         },
        //     },
        // ],
      },
    });
    mapped_goups = find_groups?.hits?.hits.map((user) => {
      return { ...user._source, type: "user" };
    });

    const getGroupsDetails = async (groups) => {
      for (let i = 0; i < groups.length; i++) {
        let group = groups[i];

        const total_members = await database.JoinGroup.count({
          where: {
            group_id: group.id,
          },
        });
        group.total_members = total_members;

        let groupUser;
        if (user_id) {
          groupUser = await database.JoinGroup.findOne({
            where: {
              user_id: user_id,
              group_id: group.id,
            },
            attributes: ["id"],
          });
          group.isExist = groupUser ? true : false;
        } else {
          group.isExist = false;
        }

        let group_data = await database.JoinGroup.findAll({
          order: [["createdAt", "desc"]],
          where: {
            group_id: group.id,
          },
          limit: 3,
          raw: true,
        });
        let group_member_array = [];
        for (const group_member of group_data) {
          const limitedMembers = await database.User.findOne({
            where: {
              id: group_member?.user_id,
            },
            attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "userName"],
            raw: true,
          });
          group_member_array.push({ ...limitedMembers });
        }
        group.members = group_member_array;

        // if (database_type === "redis") {
        //   let add_data = await redisClient.lpush(redis_list_name, JSON.stringify(group));
        //   console.log("adding data in Redis >>>>>>>>>>>>>>>>>>>>", add_data);
        // } else {
        // storesArray.push(group);
        console.log("not adding into DB pushing for response >>>>>>>>>>>>>>>>>>>>");
        // }
      }
      return groups;
    };
    final_group = await getGroupsDetails(mapped_goups);
    return { success: true, message: "Data fetch successfully", data: final_group };
  },
};

module.exports.deleteGroup({ user_id: 100000 });
