const client = require("../config/config");
let validationSchema = require("../validation/index");
const moment = require("moment");
const database = require("../../../database/models");
module.exports = self = {
  /* ************ Create index for users ************ */
  createIndexForUser: async (indexName) => {
    try {
      console.log("+++++++++++++++++++ ENTERS in index cretion +++++++++++++++++++");
      const indexExists = await client.indices.exists({ index: indexName });

      if (indexExists) {
        console.log(`Index "${indexName}" already exists.`);
        return { success: false, message: `Index "${indexName}" already exists.` };
      }

      let userIndex = await client.indices.create({
        index: indexName,
        body: {
          mappings: {
            properties: {
              id: { type: "integer" },
              firstName: { type: "text" },
              lastName: { type: "text" },
              email: { type: "text" },
              password: { type: "text" },
              mobileNumber: { type: "text" },
              phoneNumber: { type: "text" },
              ext: { type: "integer" },
              gender: { type: "keyword" },
              jobTitle: { type: "text" },
              address: { type: "keyword" },
              subAddress: { type: "keyword" },
              city: { type: "keyword" },
              state: { type: "keyword" },
              country: { type: "keyword" },
              zipCode: { type: "text" },
              userFor: { type: "text" },
              is_deleted: { type: "boolean" },
              created_by: { type: "text" },
              updated_by: { type: "text" },
              createdAt: { type: "date" },
              updatedAt: { type: "date" },
              becomeSellerStatus: { type: "keyword" },
              isOnboardCompleted: { type: "boolean" },
              bday: { type: "date" },
              forgotPasswordOTP: { type: "keyword" },
              forgotPasswordOTPExpiry: { type: "date" },
              isRegisterVerified: { type: "boolean" },
              isUserOnboardCompleted: { type: "boolean" },
              userName: { type: "text" },
              role: { type: "keyword" },
              logo_image: { type: "text" },
              banner_image: { type: "text" },
              social_type: { type: "text" },
              social_id: { type: "text" },
              isSocial: { type: "boolean" },
              isSeller: { type: "boolean" },
              isUser: { type: "boolean" },
              status: { type: "keyword" },
              becomeSellerApprovalNote: { type: "text" },
              isDetails5OnboardingCompletedNew: { type: "boolean" },
              details5OnboardingCompletedAtNew: { type: "date" },
              currentStepForSellerOnboarding: { type: "keyword" },
              currentQueryForVerification: { type: "keyword" },
              onboardCompletedAt: { type: "date" },
            },
          },
        },
      });

      return { success: true, message: `Index "${indexName}" created successfully.`, data: userIndex };
    } catch (error) {
      return error;
    }
  },
  /* ************ Put mapping for users ************ */
  putMappingForUser: async (indexName) => {
    let userPutMapping = await client.indices.putMapping({
      index: indexName,
      body: {
        properties: {
          id: { type: "integer" },
          firstName: { type: "text" },
          lastName: { type: "text" },
          email: { type: "text" },
          password: { type: "text" },
          mobileNumber: { type: "text" },
          phoneNumber: { type: "text" },
          ext: { type: "integer" },
          gender: { type: "text" },
          bday: { type: "text" },
          jobTitle: { type: "text" },
          profileAvtar: { type: "text" },
          profileCoverImage: { type: "text" },
          address: { type: "text" },
          subAddress: { type: "text" },
          city: { type: "text" },
          state: { type: "text" },
          country: { type: "text" },
          zipCode: { type: "text" },
          becomeSellerStatus: { type: "text" },
          isOnboardCompleted: { type: "boolean" },
          is_deleted: { type: "boolean" },
          createdAt: { type: "date" },
        },
      },
    });
    return userPutMapping;
  },

  /* ************ Add Single data for user ************ */
  createUser: async (data, indexName = "user") => {
    try {
      // console.log(data, "data");
      // let error = validationSchema("createUserIndexSchema", data);
      // if (error) return { success: false, message: error };
      // index exists or not
      const indexExists = await client.indices.exists({
        index: indexName,
      });
      if (!indexExists) {
        let check = await self.createIndexForUser(indexName);
      }
      const user = await client.search({
        index: indexName,
        body: {
          query: {
            match: {
              id: data.id,
            },
          },
        },
      });
      if (user.hits.hits.length > 0) {
        return { success: false, message: "User already exists" };
      }

      console.log(indexName, "indexName+++++++++++++++++++++++++++++++");
      const User = await client.index({
        index: indexName,
        body: { ...data },
      });
      console.log(User, "User");
      return { success: true, message: "user added successfully", data: User };
    } catch (error) {
      console.log(error, "error");
    }
  },

  /* ************ Add data for users ************ */
  getAllUser: async (indexName) => {
    const data = await client.search({
      index: indexName,
    });
    const usersData = data.hits.hits.map((hit) => {
      return { ...hit._source, _id: hit._id };
    });
    return usersData;
  },
  /* ************ delete users by ids ************ */
  deleteUser: async (indexName = "user", ids) => {
    try {
      let response = [];

      for (const id of ids) {
        const existData = await client.seach({
          index: indexName,
          body: {
            query: {
              term: {
                id: id
              }
            },
          },
        });
        response.push(existData);
      }

      const filteredResponse = response.filter((res) => res.hits.hits.length);

      const _ids = filteredResponse.map(res => res.hits.hits[0]._id);

      for (const _id of _ids) {
        await client.delete({
          index: indexName,
          id: _id,
        });
      }

      return { success: true, message: "User(s) deleted successfully" };
    } catch (error) {
      console.error("An error occured during removing user: ", error);
      throw new Error("An error occured during removing user!");
    }
  },

  /* ************ update user status by id ************ */
  updateUserById: async (indexName = "user", id, data) => {
     try {
      const isExists = await client.search({
        index: indexName,
        body: {
          query: {
            match: {
              id: id,
            },
          },
        },
      });
      if (isExists.hits.hits.length === 0) {
        return { success: false, message: "User not found" };
      }
      let existUser = isExists.hits.hits[0];

      const _source = existUser._source;

      const updatedDocument = {
        ..._source,
        ...data,
      };

      const updateResponse = await client.update({
        index: indexName,
        id: existUser._id,
        body: {
          doc: updatedDocument,
        },
      });
      return { success: true, message: "User status updated successfully" };
    } catch (error) {
      console.error("An error occured during updating user status: ", error);
      throw new Error("An error occured during updating user status!");
    }
  },
  /* ************ get user chart data  ************ */

  getAllUserChartData: async ({ user_id, comment_for, start_date, end_date, time_interval, time_zone }, indexName = "user") => {
    try {
      console.log("start_date, end_date", start_date, end_date);
      const getUsersData = async (min_date, max_date, time_interval, time_zone, comment_for) => {
        console.log("min_date, max_date", min_date, max_date);
        const searchParams = {
          index: indexName,
          // match with user_id
          query: {
            bool: {
              must: [
                {
                  match: { user_id: user_id },
                },
                {
                  match: { comment_for: comment_for || "STORE" },
                },
                {
                  range: {
                    createdAt: {
                      gte: min_date,
                      lte: max_date,
                    },
                  },
                },
              ],
            },
          },
          size: 0,
          body: {
            aggs: {
              date_counts: {
                date_histogram: {
                  field: "createdAt",
                  calendar_interval: time_interval ? time_interval : "day",
                  time_zone: time_zone ? time_zone : "Asia/Kolkata",
                  extended_bounds: {
                    min: min_date,
                    max: max_date,
                  },
                },
                aggs: {
                  user_count: {
                    cardinality: {
                      field: "createdAt",
                    },
                  },
                },
              },
              total_user_count: {
                cardinality: {
                  field: "createdAt",
                },
              },
            },
          },
        };
        console.log("searchParams", JSON.stringify(searchParams));
        const response = await client.search(searchParams);
        console.log("response", JSON.stringify(response));
        const dateCounts = response.aggregations.date_counts.buckets;
        // console.log("response.aggregations", dateCounts)
        const formattedData = dateCounts.map((bucket) => [
          bucket.key, // Date in the desired format
          bucket.user_count.value || 0, // Revenue sum (if available) or 0 as default
        ]);
        // console.log("response?.aggregations", response?.aggregations?.total_user_count);
        // return formattedData
        return { data: formattedData, total_user_count: response?.aggregations?.total_user_count?.value || 0 };
      };
      // console.log("start_date, end_date", start_date, end_date);
      let current_data_called = await getUsersData(start_date, end_date, time_interval, time_zone, comment_for);
      // console.log("current_data_called", 1111, current_data_called.total_user_count);
      let current_data = current_data_called.data;
      let current_total_user_count = current_data_called.total_user_count;

      const startDateCheck = moment(start_date);
      const endDateCheck = moment(end_date);
      const diff = endDateCheck.diff(startDateCheck); // Calculate the difference between dates in milliseconds
      // console.log(start_date);
      const previousStartDate = startDateCheck.subtract(diff).toISOString();
      let prev_min_date = previousStartDate;
      let prev_max_date = moment(start_date).toISOString();
      // let previous_data = (await getUsersData(prev_min_date, prev_max_date)).data;
      let previous_total_user_count = (await getUsersData(prev_min_date, prev_max_date, time_interval, time_zone, comment_for)).total_user_count;
      // current_total_user_count and previous_total_user_count in percentage
      let current_total_user_count_percentage = previous_total_user_count !== 0 ? (((previous_total_user_count - current_total_user_count) / previous_total_user_count) * 100).toFixed(2) : 0;
      return {
        current_total_user_count: current_total_user_count,
        // previous_total_user_count: current_total_user_count_percentage,
        previous_total_user_count_percentage: current_total_user_count_percentage,
        current_data: current_data,
        // previous_data: previous_data
      };
    } catch (error) {
      console.error(error);
    }
  },

  searchUsersWithElasticSearch: async (index, { search, isFollow, page = 1, limit = 10, sort, order, user_id }) => {
    page = page > 0 ? page - 1 : 0;
    let user_data_mapped = [];
    let users_final_data = [];
    let users = await client.search({
      index: "user",
      body: {
        from: page,
        size: limit,
        ...(search
          ? {
              query: {
                bool: {
                  must: [
                    {
                      multi_match: {
                        query: `.*${search}*.`,
                        fields: ["firstName", "lastName"],
                        type: "phrase_prefix",
                      },
                    },
                  ],
                  // must_not: [
                  //   { term: { user_id: user_id } }, // Exclude documents with user_id 6
                  // ],
                },
              },
            }
          : // : { query: { match_all: {} } }),
            {
              query: {
                bool: {
                  ...(user_id
                    ? {
                        must_not: [
                          { term: user_id ? { id: user_id } : {} }, // Exclude documents with user_id 6
                        ],
                      }
                    : {}),
                },
              },
            }),
        sort: [
          {
            createdAt: {
              order: "asc",
            },
          },
        ],
      },
    });
    user_data_mapped = users?.hits?.hits.map((user) => {
      return { ...user._source, type: "user" };
    });
    const getUsersDetails = async (users) => {
      for (let i = 0; i < users.length; i++) {
        const user = users[i];
        let users_followers_count = await database.Friend.count({
          where: {
            user_id: Number(user.id),
            isFriend: true,
          },
        });
        user.followers_count = users_followers_count;

        if (user_id) {
          let get_isFollow = await database.Friend.findOne({
            where: {
              user_id: Number(user_id),
              friend_id: Number(user.id),
            },
          });
          user.isFollow = get_isFollow ? true : false;
        } else {
          let get_isFollow = await database.Friend.findOne({
            where: {
              friend_id: Number(user.id),
            },
          });
          user.isFollow = get_isFollow ? true : false;
        }
      }
      return users;
    };
    users_final_data = await getUsersDetails(user_data_mapped);
    return { success: true, message: "Data fetch successfully", data: { users: users_final_data } };
  },
};
