let elasticClient = {
  product: require("./product/products"),
  order: require("./order/order"),
  storeFollowers: require("./storeFollowers/storeFollowers"),
  storeActivities: require("./storeActivity/storeActivity"),
  storeLikes: require("./storeLikes/storeLikes"),
  storeComments: require("./storeComments/storeComments"),
  store: require("./store/store"),
  sellers: require("./sellers/sellers"),
  user: require("./users/users"),
  userFriends: require("./userFriends/userFriends"),
  group: require("./group/group"),
  joinGroup: require("./joinGroup/joinGroup"),
  productViews: require("./productViews/productViews"),
  sharePosts: require("./sharePosts/sharePosts"),
  post: require("./post/post"),
  comment: require("./comment/comment"),
  like: require("./like/like"),
};

module.exports = elasticClient;
const database = require("../../database/models");
const Op = require("sequelize").Op;
// // const client = require("./config/config");
// const { findMediaUrlFromIds, findCropImages } = require("../../utils/utils");

// setTimeout(async () => {
//   let stores = await database.User.findAll({ raw: true });
//   for (let i = 0; i < stores.length; i++) {
//     const s = stores[i];
//     const getMediaUrl = async (mediaId) => {
//       let check = Array.isArray(mediaId);
//       let query = { where: { id: mediaId } };
//       if (check) query = { where: { id: { [Op.in]: mediaId } } };
//       let media = await database.Media.findOne(query);
//       console.log("media", media, mediaId);
//       return media ? media.media : "";
//     }
//     // find logo & cover_image, documents
//     s.profileAvtar = await getMediaUrl(s.profileAvtar);
//     s.profileCoverImage = await getMediaUrl(s.profileCoverImage);
//     console.log("s", s);
//     let create = await elasticClient.user.createUser(s);
//     console.log("--------- CREATE ---------");
//   }
// }, 5000);

// setTimeout(async () => {
//   let stores = await database.StoreActivity.findAll({ raw: true });
//   for (let i = 0; i < stores.length; i++) {
//     const s = stores[i];
//     let create = await elasticClient.storeActivities.addStoreActivities(s);
// console.log("create", create);
//   }
// }, 5000);

// product.productStockFilter(null, { store_id: 1 });
// order.getDateWiseOrderRevenue(null, { store_id: 1, start_date: "2021-01-01", end_date: "2021-01-31" });
// client.ping({ requestTimeout: 30000 }, function (error) {
//     if (error) {
//         console.error("Elasticsearch cluster is down!");
//     } else {
//         console.log("Everything is ok");
//     }
// });
// console.log("elasticClient",client);
/*
 *************************** Add Bulk Orders  ****************************
 */

// setTimeout(async () => {
//   let orders = await database.ConfirmedOrder.findAll({});
//   console.log(JSON.parse(JSON.stringify(orders)));
//   let orderStatuss = ["pending", "shipped", "delivered"];
//   let allOrders = [];
//   orders = JSON.parse(JSON.stringify(orders));
//   for await (const order of orders) {
//     let orderStatus = orderStatuss[Math.floor(Math.random() * orderStatuss.length)];
//     let products = await database.Product.findAll({ where: { id: order.productId } });
//     for (let i = 0; i < products.length; i++) {
//       const product = products[i];
//       const qty = order.quantity[i];
//       const store_id = product.store_id;
//       let elasticPayload = {
//         id: order.id,
//         order_id: order.id,
//         product_id: product.id,
//         store_id: store_id,
//         quantity: qty,
//         order_status: orderStatus,
//         generate_id: Math.floor(Math.random() * 1000000000),
//         price: product.price,
//         total: product.price * qty,
//         user_id: order.userId,
//       };
//       allOrders.push(elasticPayload);
//     }
//   }
//   console.log(allOrders.length);
//   order
//     .addBulkDataForOrders("orders", allOrders)
//     .then((res) => {
//       console.log(res);
//     })
//     .catch((err) => {
//       console.log(err);
//     });
// }, 1000);

/*
 *************************** Add Bulk products  ****************************
 */

// setTimeout(async () => {
//   let products = await database.Product.findAll({});
//   // console.log(JSON.parse(JSON.stringify(products)));
//   products = JSON.parse(JSON.stringify(products));
//   for await (const product of products) {
//     product.product_id = product.id;
//     /* crop images  */
//     product["id"] = product.id;
//     product.image ? (product.image = await findMediaUrlFromIds(product.image)) : [];
//     product.cropImages = await findCropImages(product.cropImages);
//     product.createdAt = new Date(product.createdAt).toISOString();
//     product.updatedAt = new Date(product.updatedAt).toISOString();
//   }
//   console.log(products.length);
//   product
//     .addBulkDataForProducts("products", products)
//     .then((res) => {
//       console.log(res);
//     })
//     .catch((err) => {
//       console.log(err);
//     });
// }, 1000);

// product
//   .createIndexForProducts("products")
//   .then((res) => {
//     console.log(res);
//   })
//   .catch((err) => {
//     console.log(err);
//   });
