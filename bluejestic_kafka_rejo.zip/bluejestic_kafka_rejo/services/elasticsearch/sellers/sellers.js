const client = require("../config/config");
let validationSchema = require("../validation/index");
const moment = require("moment");
const database = require("../../../database/models");
module.exports = {
  /* ************ Create index for sellers ************ */
  createIndexForSeller: async (indexName) => {
    try {
      console.log("+++++++++++++++++++ ENTERS in index cretion +++++++++++++++++++");
      const indexExists = await client.indices.exists({ index: indexName });

      if (indexExists) {
        console.log(`Index "${indexName}" already exists.`);
        return { success: false, message: `Index "${indexName}" already exists.` };
      }

      let userIndex = await client.indices.create({
        index: indexName,
        body: {
          mappings: {
            properties: {
              id: { type: "integer" },
              firstName: { type: "text" },
              lastName: { type: "text" },
              email: { type: "text" },
              password: { type: "text" },
              ext: { type: "integer" },
              mobileNumber: { type: "text" },
              phoneNumber: { type: "text" },
              jobTitle: { type: "text" },
              isDeleted: { type: "boolean" },
              created_by: { type: "text" },
              updated_by: { type: "text" },
              aboutUs: { type: "text" },
              language: { type: "text" },
              dateFormat: { type: "text" },
              timeZone: { type: "text" },
              accountType: { type: "keyword" },
              isVerify: { type: "boolean" },
              sellerApprovedStatus: { type: "keyword" },
              createdAt: { type: "date" },
              updatedAt: { type: "date" },
              isPaymentOnboardingCompleted: { type: "boolean" },
              stripeAccountId: { type: "text" },
              details_submitted: { type: "boolean" },
              isPopup: { type: "boolean" },
              otpForWithdrawal: { type: "text" },
              otpForWithdrawalExpiry: { type: "date" },
              currentQueryForVerification: { type: "keyword" },
              isSellerInfoVerified: { type: "boolean" },
              otpForVerification: { type: "text" },
              otpVerificationExpiry: { type: "date" },
              user_id: { type: "integer" },
              isSellerVerify: { type: "boolean" },
              social_type: { type: "text" },
              userName: { type: "text" },
              isSocial: { type: "boolean" },
              status_updated_by_new: { type: "integer" },
              status_updated_at_new: { type: "date" },
              isDetails5OnboardingCompletedNew: { type: "boolean" },
              details5OnboardingCompletedAtNew: { type: "date" },
              is_user: { type: "boolean" },
              sellerApprovalNote: { type: "text" },
              isOnboardCompleted: { type: "boolean" },
              onboardCompletedAt: { type: "date" },
              currentStepForSellerOnboarding: { type: "keyword" },
              sellerApprovedStatusNew: { type: "keyword" },
            },
          },
        },
      });

      return { success: true, message: `Index "${indexName}" created successfully.`, data: userIndex };
    } catch (error) {
      return error;
    }
  },

  /* ************ Add Single data for seller ************ */
  createSeller: async (data, indexName = "sellers") => {
    try {
      // console.log(data, "data");
      // let error = validationSchema("createUserIndexSchema", data);
      // if (error) return { success: false, message: error };

      // index exists or not
      const indexExists = await client.indices.exists({
        index: indexName,
      });
      if (!indexExists) {
        let check = await module.exports.createIndexForSeller(indexName);
        console.log("🚀 ~ createSeller: ~ check:", check);
      }
      const seller = await client.search({
        index: indexName,
        body: {
          query: {
            match: {
              id: data.id,
            },
          },
        },
      });
      if (seller.hits.hits.length > 0) {
        return { success: false, message: "Seller already exists" };
      }

      console.log(indexName, "indexName+++++++++++++++++++++++++++++++");
      const Seller = await client.index({
        index: indexName,
        body: { ...data },
      });
      console.log(Seller, "Seller");
      return { success: true, message: "Seller added successfully", data: Seller };
    } catch (error) {
      console.log(error, "error");
    }
  },

  /* ************ update seller by id ************ */
  updateSellerById: async (id, data, indexName = "sellers") => {
    console.log("indexName, id, data", indexName, id, data);

    try {
      const isExists = await client.search({
        index: indexName,
        body: {
          query: {
            match: {
              id: id,
            },
          },
        },
      });
      // console.log(isExists.hits.hits, "isExists");
      if (isExists.hits.hits.length === 0) {
        return { success: false, message: "Seller not found" };
      }
      let existSeller = isExists.hits.hits[0];

      const _source = existSeller._source;

      const updatedDocument = {
        ..._source,
        ...data,
      };
      console.log("existSeller._id", existSeller._id.toString(), indexName);
      const updateResponse = await client.update({
        index: indexName,
        id: existSeller._id,
        body: {
          doc: updatedDocument,
        },
      });
      return { success: true, message: "Seller updated successfully" };
    } catch (error) {
      console.log(error, "error");
      // return error;
    }
  },

};
