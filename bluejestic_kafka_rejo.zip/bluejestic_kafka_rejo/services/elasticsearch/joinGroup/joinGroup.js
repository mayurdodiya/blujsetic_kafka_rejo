const client = require("../config/config");
let validationSchema = require("../validation/index");
const moment = require("moment");
module.exports = recall = {
    /* ************ Create index for joinGroups ************ */
    createIndexForJoinGroup: async (indexName) => {
        try {
            console.log("+++++++++++++++++++ ENTERS in index cretion +++++++++++++++++++");
            const indexExists = await client.indices.exists({ index: indexName });

            if (indexExists) {
                console.log(`Index "${indexName}" already exists.`);
                return { success: false, message: `Index "${indexName}" already exists.` };
            }

            let groupIndex = await client.indices.create({
                index: indexName,
                body: {
                    mappings: {
                        properties: {
                            id: { type: "integer" },
                            user_id: { type: "integer" },
                            group_id: { type: "integer" },
                            groupType: { type: "text" },
                            isAdmin: { type: "boolean" },
                            isOwner: { type: "boolean" },
                            isDeleted: { type: "boolean", },
                            createdAt: { type: "date", },
                        },
                    },
                },
            });

            return { success: true, message: "Index created successfully.", data: groupIndex };
        } catch (error) {
            return error;
        }
    },
    /* ************ Put mapping for joinGroups ************ */
    putMappingForJoinGroup: async (indexName) => {
        let groupIndex = await client.indices.putMapping({
            index: indexName,
            body: {
                properties: {
                    id: { type: "integer" },
                    user_id: { type: "integer" },
                    group_id: { type: "integer" },
                    groupType: { type: "text" },
                    isAdmin: { type: "boolean" },
                    isOwner: { type: "boolean" },
                    isDeleted: { type: "boolean", },
                    createdAt: { type: "date", },
                },
            },
        });
        return groupIndex;
    },

    /* ************ Add Single data for joinGroups ************ */
    addJoinGroup: async (data, indexName = "join-group") => {
        try {
            // console.log(data, "data");
            // let error = validationSchema("createJoinGroupIndexSchema", data);
            // if (error) return { success: false, message: error };
            // index exists or not
            const indexExists = await client.indices.exists({
                index: indexName,
            });
            console.log(indexExists, "indexExists");
            if (!indexExists) {
                let check = await recall.createIndexForJoinGroup(indexName);
                console.log("checkcheckcheckcheckcheckcheck", check);
            }
            const group = await client.search({
                index: indexName,
                body: {
                    query: {
                        match: {
                            id: data.id,
                        },
                    },
                },
            });
            if (group.hits.hits.length > 0) {
                return { success: false, message: "group already exists" };
            }
            console.log(indexName, "indexName+++++++++++++++++++++++++++++++");
            const JoinGroup = await client.index({
                index: indexName,
                body: { ...data, createdAt: moment().toISOString() },
            });
            console.log(JoinGroup, "JoinGroup");
            return { success: true, message: "group added successfully", data: JoinGroup };
        } catch (error) {
            console.log(error, "error");
            return { success: false, message: error };
        }
    },

    /* ************ Add data for joinGroups ************ */
    getAllJoinGroupData: async (indexName) => {
        const data = await client.search({
            index: indexName,
        });
        const joinGroupsData = data.hits.hits.map((hit) => {
            return { ...hit._source, _id: hit._id };
        });
        return joinGroupsData;
    },
    /* ************ delete joinGroups by id ************ */
    deleteJoinGroup: async ({ group_id, user_id }, indexName = "join-group") => {
        try {
            // search group by id
console.log("group_id, user_id", group_id, user_id);
            const existData = await client.search({
                index: indexName,
                body: {
                    query: {
                        bool: {
                            must: [
                                {
                                    match: { group_id: group_id, },
                                },
                                {
                                    match: { user_id: user_id, }
                                }
                            ],
                        },
                    },
                },
            });
            let _id = existData?.hits?.hits[0]?._id;
            console.log("_IDDDDDDDDDDDDDDDDDDD", _id);
            if (!_id) { return { success: false, message: "JoinGroup does not exists" }; }
            const groupData = await client.delete({
                index: indexName,
                id: _id,
            });
            return { success: true, message: "JoinGroup deleted successfully", data: groupData.result };
        } catch (error) {
            console.log(error, "error");
            return error;
        }
    },

    /* ************ update joinGroups by id ************ */
    updateJoinGroupById: async (id, data, indexName = "join-group") => {
        try {
            // if exists
            const isExists = await client.search({
                index: indexName,
                body: {
                    query: {
                        match: {
                            id: id
                        },
                    },
                },
            });
            if (isExists.hits.hits.length === 0) {
                return { success: false, message: "JoinGroup does not exists" };
            }
            if (isExists.hits.hits.length > 0) {
                let joinGroups = isExists.hits.hits;
                for (let i = 0; i < joinGroups.length; i++) {
                    const group = joinGroups[i];
                    // if exists
                    const groupExists = await client.exists({
                        index: indexName,
                        id: group._id,
                    });
                    // console.log(groupExists, "groupExists");
                    if (!groupExists) {
                        console.log("JoinGroup does not exists");
                        return { success: false, message: "JoinGroup does not exists" };
                    }

                    const groupData = await client.get({
                        index: indexName,
                        id: group._id,
                    });

                    const _source = groupData._source;

                    const updatedDocument = {
                        ..._source,
                        ...data,
                    };
                    // const updatedDocument = data
                    const updateResponse = await client.update({
                        index: indexName,
                        id: group._id,
                        body: {
                            doc: updatedDocument,
                        },
                    });
                }
            }
            return { success: true, message: "JoinGroup updated successfully" };
        } catch (error) {
            console.log(error, "error");
            return error;
        }
    },
    searchJoinGroupsWithElasticSearch: async (index, { search, page = 1, limit = 10, sort, order, user_id }) => {
        page = page > 0 ? page - 1 : 0;

        let joinGroups = await client.search({
            index: 'group',
            body: {
                from: page,
                size: limit,
                ...(search
                    ? {
                        query: {
                            bool: {
                                must: [
                                    {
                                        multi_match: {
                                            query: `.*${search}*.`,
                                            fields: ["name"],
                                            type: "phrase_prefix",
                                        },
                                    },
                                ],
                            },
                        },
                    }
                    : { query: { match_all: {} } }),
                // sort: [
                //     {
                //         [sort]: {
                //             order: order,
                //         },
                //     },
                // ],
            },
        });
        joinGroups = joinGroups?.hits?.hits.map((user) => { return { ...user._source, type: "user" } })

        const getUsersDetails = async (joinGroups) => {
            return joinGroups
        }
        joinGroups = await getUsersDetails(joinGroups)
        return { success: true, message: "Data fetch successfully", data: joinGroups }
    }
}