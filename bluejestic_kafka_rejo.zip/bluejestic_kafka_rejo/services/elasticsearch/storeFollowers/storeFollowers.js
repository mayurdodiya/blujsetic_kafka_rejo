const client = require("../config/config");
let validationSchema = require("../validation/index");
const moment = require("moment");
module.exports = selfFunction = {
    /* ************ Create index for orders ************ */
    createIndexForStoreFollowers: async (indexName) => {
        try {
            console.log("+++++++++++++++++++ ENTERS in index cretion +++++++++++++++++++");
            const indexExists = await client.indices.exists({ index: indexName });

            if (indexExists) {
                console.log(`Index "${indexName}" already exists.`);
                return { success: false, message: `Index "${indexName}" already exists.` };
            }

            let storeFollowersIndex = await client.indices.create({
                index: indexName,
                body: {
                    mappings: {
                        properties: {
                            id: { type: "integer" },
                            user_id: { type: "integer" },
                            store_id: { type: "integer" },
                            userType: { type: "keyword" },
                            isDeleted: { type: "boolean", },
                            createdAt: { type: "date", },
                        },
                    },
                },
            });

            return { success: true, message: "Index created successfully.", data: storeFollowersIndex };
        } catch (error) {
            return error;
        }
    },
    /* ************ Put mapping for orders ************ */
    putMappingForStoreFollowers: async (indexName) => {
        let storeFollowersPutMapping = await client.indices.putMapping({
            index: indexName,
            body: {
                properties: {
                    id: { type: "integer" },
                    user_id: { type: "integer" },
                    store_id: { type: "integer" },
                    userType: { type: "keyword" },
                    isDeleted: { type: "boolean", },
                    createdAt: { type: "date", },
                },
            },
        });
        return storeFollowersPutMapping;
    },

    /* ************ Add Single data for storeFollowers ************ */
    addStoreFollowers: async (data, indexName = "store-followers") => {
        try {
            // console.log(data, "data");
            let error = validationSchema("createStoreFollowersIndexSchema", data);
            if (error) return { success: false, message: error };
            // index exists or not
            const indexExists = await client.indices.exists({
                index: indexName,
            });
            console.log(indexExists, "indexExists");
            if (!indexExists) {
                let check = await selfFunction.createIndexForStoreFollowers(indexName);
                console.log("checkcheckcheckcheckcheckcheck", check);
            }
            const storeFollower = await client.search({
                index: indexName,
                body: {
                    query: {
                        match: {
                            id: data.id,
                        },
                    },
                },
            });
            if (storeFollower.hits.hits.length > 0) {
                return { success: false, message: "store follower already exists" };
            }
            console.log(indexName, "indexName+++++++++++++++++++++++++++++++");
            const StoreFollowers = await client.index({
                index: indexName,
                body: { ...data, createdAt: moment().toISOString() },
            });
            console.log(StoreFollowers, "StoreFollowers");
            return { success: true, message: "storeFollower added successfully", data: StoreFollowers };
        } catch (error) {
            console.log(error, "error");
            return { success: false, message: error };
        }
    },

    /* ************ Add data for orders ************ */
    getAllStoreFollowersData: async (indexName) => {
        const data = await client.search({
            index: indexName,
        });
        const ordersData = data.hits.hits.map((hit) => {
            return { ...hit._source, _id: hit._id };
        });
        return ordersData;
    },
    /* ************ delete storeFollowers by id ************ */
    deleteStoreFollower: async ({ store_id, user_id }, indexName = "store-followers") => {
        try {
            // search storeFollower by id

            const existData = await client.search({
                index: indexName,
                body: {
                    query: {
                        bool: {
                            must: [
                                {
                                    match: { store_id: store_id, },
                                },
                                {
                                    match: { user_id: user_id, }
                                }
                            ],
                        },
                    },
                },
            });
            let _id = existData?.hits?.hits[0]?._id;
            if (!_id) { return { success: false, message: "StoreFollowers does not exists" }; }
            const storeFollowerData = await client.delete({
                index: indexName,
                id: _id,
            });
            return { success: true, message: "StoreFollowers deleted successfully", data: storeFollowerData.result };
        } catch (error) {
            console.log(error, "error");
            return error;
        }
    },

    /* ************ update storeFollowers by id ************ */
    updateStoreFollowersById: async (indexName, id, data) => {
        try {
            // if exists
            const isExists = await client.search({
                index: indexName,
                body: {
                    query: {
                        match: {
                            id: id
                        },
                    },
                },
            });
            if (isExists.hits.hits.length === 0) {
                return { success: false, message: "StoreFollowers does not exists" };
            }
            if (isExists.hits.hits.length > 0) {
                let orders = isExists.hits.hits;
                for (let i = 0; i < orders.length; i++) {
                    const storeFollowers = orders[i];
                    // if exists
                    const orderExists = await client.exists({
                        index: indexName,
                        id: storeFollowers._id,
                    });
                    // console.log(orderExists, "orderExists");
                    if (!orderExists) {
                        console.log("StoreFollowers does not exists");
                        return { success: false, message: "StoreFollowers does not exists" };
                    }

                    const orderData = await client.get({
                        index: indexName,
                        id: storeFollowers._id,
                    });

                    const _source = orderData._source;

                    const updatedDocument = {
                        ..._source,
                        ...data,
                    };
                    // const updatedDocument = data
                    const updateResponse = await client.update({
                        index: indexName,
                        id: storeFollowers._id,
                        body: {
                            doc: updatedDocument,
                        },
                    });
                }
            }
            return { success: true, message: "StoreFollowers updated successfully" };
        } catch (error) {
            console.log(error, "error");
            return error;
        }
    },

    /* ************ get storeFollowers chart data  ************ */

    getAllStoreFollowChartData: async (
        { store_id, start_date, end_date, time_interval, time_zone }, indexName = "store-followers"
    ) => {
        try {
            const getRevenueData = async (min_date, max_date, time_interval, time_zone) => {
                const searchParams = {
                    index: indexName,
                    // match with store_id
                    query: {
                        bool: {
                            must: [
                                {
                                    match: {
                                        store_id: store_id,
                                    },
                                },
                                {
                                    range: {
                                        createdAt: {
                                            gte: min_date,
                                            lte: max_date,
                                        },
                                    },
                                },
                            ],
                        },
                    },
                    size: 0,
                    body: {
                        aggs: {
                            date_counts: {
                                date_histogram: {
                                    field: 'createdAt',
                                    calendar_interval: time_interval ? time_interval : 'day',
                                    time_zone: time_zone ? time_zone : "Asia/Kolkata",
                                    extended_bounds: {
                                        min: min_date,
                                        max: max_date,
                                    },
                                },
                                aggs: {
                                    follower_count: {
                                        cardinality: {
                                            field: "id"
                                        }
                                    },

                                },
                            },
                            total_followers: {
                                cardinality: {
                                    field: 'id',
                                }
                            }
                        },
                    },
                }
                const response = await client.search(searchParams);
                const dateCounts = response.aggregations.date_counts.buckets;
                // console.log("response.aggregations", dateCounts)
                const formattedData = dateCounts.map(bucket => [
                    bucket.key, // Date in the desired format
                    bucket.follower_count.value || 0, // Revenue sum (if available) or 0 as default
                ]);
                // return formattedData
                return { data: formattedData, total_followers: response?.aggregations?.total_followers?.value || 0 };
            }
            let current_data_called = (await getRevenueData(start_date, end_date, time_interval, time_zone));
            let current_data = current_data_called.data;
            let current_total_followers = current_data_called.total_followers;

            const startDateCheck = moment(start_date);
            const endDateCheck = moment(end_date);
            const diff = endDateCheck.diff(startDateCheck); // Calculate the difference between dates in milliseconds
            console.log(start_date);
            const previousStartDate = startDateCheck.subtract(diff).toISOString()
            let prev_min_date = previousStartDate
            let prev_max_date = moment(start_date).toISOString()
            // let previous_data = (await getRevenueData(prev_min_date, prev_max_date)).data;
            let previous_total_followers = (await getRevenueData(prev_min_date, prev_max_date)).total_followers
            // current_total_followers and previous_total_followers in percentage
            let current_total_followers_percentage = previous_total_followers !== 0 ? ((previous_total_followers - current_total_followers) / previous_total_followers * 100).toFixed(2) : 0
            return {
                current_total_followers: current_total_followers,
                // previous_total_followers: current_total_followers_percentage,
                previous_total_followers_percentage: current_total_followers_percentage,
                current_data: current_data,
                // previous_data: previous_data
            };
        } catch (error) {
            console.error(error);
        }
    }
};
