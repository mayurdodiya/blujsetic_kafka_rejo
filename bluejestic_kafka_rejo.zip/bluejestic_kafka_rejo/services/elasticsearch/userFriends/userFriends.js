const client = require("../config/config");
let validationSchema = require("../validation/index");
const moment = require("moment");
module.exports = selfFunction = {
    /* ************ Create index for orders ************ */
    createIndexForUserFriends: async (indexName) => {
        try {
            console.log("+++++++++++++++++++ ENTERS in index cretion +++++++++++++++++++");
            const indexExists = await client.indices.exists({ index: indexName });

            if (indexExists) {
                console.log(`Index "${indexName}" already exists.`);
                return { success: false, message: `Index "${indexName}" already exists.` };
            }

            let userFriendssIndex = await client.indices.create({
                index: indexName,
                body: {
                    mappings: {
                        properties: {
                            id: { type: "integer" },
                            user_id: { type: "integer" },
                            friend_id: { type: "integer" },
                            request_id: { type: "integer" },
                            isActive: { type: "boolean", },
                            isFriend: { type: "boolean", },
                            isDeleted: { type: "boolean", },
                            createdAt: { type: "date", },
                        },
                    },
                },
            });

            return { success: true, message: "Index created successfully.", data: userFriendssIndex };
        } catch (error) {
            return error;
        }
    },
    /* ************ Put mapping for orders ************ */
    putMappingForUserFriends: async (indexName) => {
        let userFriendssPutMapping = await client.indices.putMapping({
            index: indexName,
            body: {
                properties: {
                    id: { type: "integer" },
                    user_id: { type: "integer" },
                    friend_id: { type: "integer" },
                    request_id: { type: "integer" },
                    isActive: { type: "boolean", },
                    isFriend: { type: "boolean", },
                    isDeleted: { type: "boolean", },
                    createdAt: { type: "date", },
                },
            },
        });
        return userFriendssPutMapping;
    },

    /* ************ Add Single data for userFriendss ************ */
    addUserFriends: async (data, indexName = "user-followers") => {
        try {
            // console.log(data, "data");
            let error = validationSchema("createUserFriendsIndexSchema", data);
            if (error) return { success: false, message: error };
            // index exists or not
            const indexExists = await client.indices.exists({
                index: indexName,
            });
            console.log(indexExists, "indexExists");
            if (!indexExists) {
                let check = await selfFunction.createIndexForUserFriends(indexName);
                console.log("checkcheckcheckcheinckcheckcheck", check);
            }
            const userFriends = await client.search({
                index: indexName,
                body: {
                    query: {
                        match: {
                            id: data.id,
                        },
                    },
                },
            });
            if (userFriends.hits.hits.length > 0) {
                return { success: false, message: "store follower already exists" };
            }
            console.log(indexName, "indexName+++++++++++++++++++++++++++++++");
            const UserFriends = await client.index({
                index: indexName,
                body: { ...data, createdAt: moment().toISOString() },
            });
            console.log(UserFriends, "UserFriends");
            return { success: true, message: "userFriends added successfully", data: UserFriends };
        } catch (error) {
            console.log(error, "error");
            return { success: false, message: error };
        }
    },

    /* ************ Add data for orders ************ */
    getAllUserFriendsData: async (indexName) => {
        const data = await client.search({
            index: indexName,
        });
        const ordersData = data.hits.hits.map((hit) => {
            return { ...hit._source, _id: hit._id };
        });
        return ordersData;
    },
    /* ************ delete userFriendss by id ************ */
    deleteUserFriend: async ({ friend_id, user_id }, indexName = "user-followers") => {
        try {
            // search userFriends by id

            const existData = await client.search({
                index: indexName,
                body: {
                    query: {
                        bool: {
                            must: [
                                {
                                    match: { friend_id: friend_id, },
                                },
                                {
                                    match: { user_id: user_id, }
                                }
                            ],
                        },
                    },
                },
            });
            let _id = existData?.hits?.hits[0]?._id;
            if (!_id) { return { success: false, message: "UserFriends does not exists" }; }
            const userFriendsData = await client.delete({
                index: indexName,
                id: _id,
            });
            return { success: true, message: "UserFriends deleted successfully", data: userFriendsData.result };
        } catch (error) {
            console.log(error, "error");
            return error;
        }
    },

    /* ************ update userFriendss by id ************ */
    updateUserFriendsById: async (id, data, indexName = "user-followers") => {
        try {
            // if exists
            const isExists = await client.search({
                index: indexName,
                body: {
                    query: {
                        match: {
                            id: id
                        },
                    },
                },
            });
            if (isExists.hits.hits.length === 0) {
                return { success: false, message: "UserFriends does not exists" };
            }
            if (isExists.hits.hits.length > 0) {
                let orders = isExists.hits.hits;
                for (let i = 0; i < orders.length; i++) {
                    const userFriendss = orders[i];
                    // if exists
                    const orderExists = await client.exists({
                        index: indexName,
                        id: userFriendss._id,
                    });
                    // console.log(orderExists, "orderExists");
                    if (!orderExists) {
                        console.log("UserFriends does not exists");
                        return { success: false, message: "UserFriends does not exists" };
                    }

                    const orderData = await client.get({
                        index: indexName,
                        id: userFriendss._id,
                    });

                    const _source = orderData._source;

                    const updatedDocument = {
                        ..._source,
                        ...data,
                    };
                    // const updatedDocument = data
                    const updateResponse = await client.update({
                        index: indexName,
                        id: userFriendss._id,
                        body: {
                            doc: updatedDocument,
                        },
                    });
                }
            }
            return { success: true, message: "UserFriends updated successfully" };
        } catch (error) {
            console.log(error, "error");
            return error;
        }
    },

    /* ************ get userFriendss chart data  ************ */

    getAllStoreFollowChartData: async (
        { friend, start_date, end_date, time_interval, time_zone }, indexName = "user-followers"
    ) => {
        try {
            const getRevenueData = async (min_date, max_date, time_interval, time_zone) => {
                const searchParams = {
                    index: indexName,
                    // match with friend
                    query: {
                        bool: {
                            must: [
                                {
                                    match: {
                                        friend: friend,
                                    },
                                },
                                {
                                    range: {
                                        createdAt: {
                                            gte: min_date,
                                            lte: max_date,
                                        },
                                    },
                                },
                            ],
                        },
                    },
                    size: 0,
                    body: {
                        aggs: {
                            date_counts: {
                                date_histogram: {
                                    field: 'createdAt',
                                    calendar_interval: time_interval ? time_interval : 'day',
                                    time_zone: time_zone ? time_zone : "Asia/Kolkata",
                                    extended_bounds: {
                                        min: min_date,
                                        max: max_date,
                                    },
                                },
                                aggs: {
                                    follower_count: {
                                        cardinality: {
                                            field: "id"
                                        }
                                    },

                                },
                            },
                            total_followers: {
                                cardinality: {
                                    field: 'id',
                                }
                            }
                        },
                    },
                }
                const response = await client.search(searchParams);
                const dateCounts = response.aggregations.date_counts.buckets;
                // console.log("response.aggregations", dateCounts)
                const formattedData = dateCounts.map(bucket => [
                    bucket.key, // Date in the desired format
                    bucket.follower_count.value || 0, // Revenue sum (if available) or 0 as default
                ]);
                // return formattedData
                return { data: formattedData, total_followers: response?.aggregations?.total_followers?.value || 0 };
            }
            let current_data_called = (await getRevenueData(start_date, end_date, time_interval, time_zone));
            let current_data = current_data_called.data;
            let current_total_followers = current_data_called.total_followers;

            const startDateCheck = moment(start_date);
            const endDateCheck = moment(end_date);
            const diff = endDateCheck.diff(startDateCheck); // Calculate the difference between dates in milliseconds
            console.log(start_date);
            const previousStartDate = startDateCheck.subtract(diff).toISOString()
            let prev_min_date = previousStartDate
            let prev_max_date = moment(start_date).toISOString()
            // let previous_data = (await getRevenueData(prev_min_date, prev_max_date)).data;
            let previous_total_followers = (await getRevenueData(prev_min_date, prev_max_date)).total_followers
            // current_total_followers and previous_total_followers in percentage
            let current_total_followers_percentage = previous_total_followers !== 0 ? ((previous_total_followers - current_total_followers) / previous_total_followers * 100).toFixed(2) : 0
            return {
                current_total_followers: current_total_followers,
                // previous_total_followers: current_total_followers_percentage,
                previous_total_followers_percentage: current_total_followers_percentage,
                current_data: current_data,
                // previous_data: previous_data
            };
        } catch (error) {
            console.error(error);
        }
    }
};
