const client = require("../config/config");
let validationSchema = require("../validation/index");
const moment = require("moment");
module.exports = self = {
    /* ************ Create index for orders ************ */
    createIndexForStoreLikes: async (indexName) => {
        try {
            console.log("+++++++++++++++++++ ENTERS in index cretion +++++++++++++++++++");
            const indexExists = await client.indices.exists({ index: indexName });

            if (indexExists) {
                console.log(`Index "${indexName}" already exists.`);
                return { success: false, message: `Index "${indexName}" already exists.` };
            }

            let storeFollowersIndex = await client.indices.create({
                index: indexName,
                body: {
                    mappings: {
                        properties: {
                            id: { type: "integer" },
                            user_id: { type: "integer" },
                            store_id: { type: "integer" },
                            post_id: { type: "integer" },
                            like_for: { type: "keyword" },
                            userType: { type: "keyword" },
                            isDeleted: { type: "boolean", },
                            createdAt: { type: "date", },
                        },
                    },
                },
            });

            return { success: true, message: "Index created successfully.", data: storeFollowersIndex };
        } catch (error) {
            return error;
        }
    },
    /* ************ Put mapping for orders ************ */
    putMappingForStoreLikes: async (indexName) => {
        let storeLikesPutMapping = await client.indices.putMapping({
            index: indexName,
            body: {
                properties: {
                    id: { type: "integer" },
                    user_id: { type: "integer" },
                    store_id: { type: "integer" },
                    post_id: { type: "integer" },
                    postType: { type: "keyword" },
                    userType: { type: "keyword" },
                    isDeleted: { type: "boolean", },
                    createdAt: { type: "date", },
                },
            },
        });
        return storeLikesPutMapping;
    },

    /* ************ Add Single data for storeFollowers ************ */
    addStoreLikes: async (data, indexName = "store-likes") => {
        try {
            // console.log(data, "data");
            let error = validationSchema("createStoreLikesIndexSchema", data);
            if (error) return { success: false, message: error };
            // index exists or not
            const indexExists = await client.indices.exists({
                index: indexName,
            });
            if (!indexExists) {
                let check = await module.exports.createIndexForStoreLikes(indexName);
            }
            const like = await client.search({
                index: indexName,
                body: {
                    query: {
                        match: {
                            id: data.id,
                        },
                    },
                },
            });
            if (like.hits.hits.length > 0) {
                return { success: false, message: "You're already like this posts" }
            };

            console.log(indexName, "indexName+++++++++++++++++++++++++++++++");
            const StoreLikes = await client.index({
                index: indexName,
                body: { ...data, createdAt: moment().toISOString() },
            });
            console.log(StoreLikes, "StoreLikes");
            return { success: true, message: "like added successfully", data: StoreLikes };
        } catch (error) {
            console.log(error, "error");
        }
    },

    /* ************ Add data for orders ************ */
    getAllStoreFollLikesData: async (indexName) => {
        const data = await client.search({
            index: indexName,
        });
        const ordersData = data.hits.hits.map((hit) => {
            return { ...hit._source, _id: hit._id };
        });
        return ordersData;
    },
    /* ************ delete storeFollowers by id ************ */
    deleteStoreLike: async ({ id }, indexName = "store-likes") => {
        try {
            // search product by id

            const existData = await client.search({
                index: indexName,
                body: {
                    query: {
                        bool: {
                            must: [
                                { match: { id }, },
                            ],
                        },
                    },
                },
            });
            let _id = existData?.hits?.hits[0]?._id;
            if (!_id) { return { success: false, message: "StoreLikes does not exists" }; }
            const productData = await client.delete({
                index: indexName,
                id: _id,
            });
            // console.log(productData.result, "productData");
            return { success: true, message: "StoreLikes deleted successfully", data: productData.result };
        } catch (error) {
            console.log(error, "error");
            return error;
        }
    },

    /* ************ update storeFollowers by id ************ */
    updateStoreFollLikesById: async (indexName, id, data) => {
        try {
            // if exists
            const isExists = await client.search({
                index: indexName,
                body: {
                    query: {
                        match: {
                            id: id
                        },
                    },
                },
            });
            if (isExists.hits.hits.length === 0) {
                return { success: false, message: "StoreLikes does not exists" };
            }
            if (isExists.hits.hits.length > 0) {
                let orders = isExists.hits.hits;
                for (let i = 0; i < orders.length; i++) {
                    const storeFollowers = orders[i];
                    // if exists
                    const orderExists = await client.exists({
                        index: indexName,
                        id: storeFollowers._id,
                    });
                    // console.log(orderExists, "orderExists");
                    if (!orderExists) {
                        console.log("StoreLikes does not exists");
                        return { success: false, message: "StoreLikes does not exists" };
                    }

                    const orderData = await client.get({
                        index: indexName,
                        id: storeFollowers._id,
                    });

                    const _source = orderData._source;

                    const updatedDocument = {
                        ..._source,
                        ...data,
                    };
                    // const updatedDocument = data
                    const updateResponse = await client.update({
                        index: indexName,
                        id: storeFollowers._id,
                        body: {
                            doc: updatedDocument,
                        },
                    });
                }
            }
            return { success: true, message: "StoreLikes updated successfully" };
        } catch (error) {
            console.log(error, "error");
            return error;
        }
    },
    /* ************ get storeFollowers chart data  ************ */

    getAllStoreLikesChartData: async (
        { store_id, like_for, start_date, end_date, time_interval, time_zone }, indexName = "store-likes"
    ) => {
        console.log("like_for", like_for);
        try {
            const getLikesData = async (min_date, max_date, time_interval, time_zone, like_for) => {
                const searchParams = {
                    index: indexName,
                    // match with store_id
                    query: {
                        bool: {
                            must: [
                                {
                                    match: { store_id: store_id, },
                                },
                                {
                                    match: { like_for: like_for || "SELLERPOST", },

                                },
                                {
                                    range: {
                                        createdAt: {
                                            gte: min_date,
                                            lte: max_date,
                                        },
                                    },
                                },
                            ],
                        },
                    },
                    size: 0,
                    body: {
                        aggs: {
                            date_counts: {
                                date_histogram: {
                                    field: 'createdAt',
                                    calendar_interval: time_interval ? time_interval : 'day',
                                    time_zone: time_zone ? time_zone : "Asia/Kolkata",
                                    extended_bounds: {
                                        min: min_date,
                                        max: max_date,
                                    },
                                },
                                aggs: {
                                    likes_count: {
                                        cardinality: {
                                            field: "id"
                                        }
                                    },

                                },
                            },
                            total_likes_count: {
                                cardinality: {
                                    field: 'id',
                                }
                            }
                        },
                    },
                }
                const response = await client.search(searchParams);
                const dateCounts = response.aggregations.date_counts.buckets;
                // console.log("response.aggregations", dateCounts)
                const formattedData = dateCounts.map(bucket => [
                    bucket.key, // Date in the desired format
                    bucket.likes_count.value || 0, // Revenue sum (if available) or 0 as default
                ]);
                // return formattedData
                return { data: formattedData, total_likes_count: response?.aggregations?.total_likes_count?.value || 0 };
            }
            let current_data_called = (await getLikesData(start_date, end_date, time_interval, time_zone, like_for));
            let current_data = current_data_called.data;
            let current_total_likes_count = current_data_called.total_likes_count;

            const startDateCheck = moment(start_date);
            const endDateCheck = moment(end_date);
            const diff = endDateCheck.diff(startDateCheck); // Calculate the difference between dates in milliseconds
            console.log(start_date);
            const previousStartDate = startDateCheck.subtract(diff).toISOString()
            let prev_min_date = previousStartDate
            let prev_max_date = moment(start_date).toISOString()
            // let previous_data = (await getLikesData(prev_min_date, prev_max_date)).data;
            let previous_total_likes_count = (await getLikesData(prev_min_date, prev_max_date, time_interval, time_zone, like_for)).total_likes_count
            // current_total_likes_count and previous_total_likes_count in percentage
            let current_total_likes_count_percentage = previous_total_likes_count !== 0 ? ((previous_total_likes_count - current_total_likes_count) / previous_total_likes_count * 100).toFixed(2) : 0
            return {
                current_total_likes_count: current_total_likes_count,
                // previous_total_likes_count: current_total_likes_count_percentage,
                previous_total_likes_count_percentage: current_total_likes_count_percentage,
                current_data: current_data,
                // previous_data: previous_data
            };
        } catch (error) {
            console.error(error);
        }
    }

};