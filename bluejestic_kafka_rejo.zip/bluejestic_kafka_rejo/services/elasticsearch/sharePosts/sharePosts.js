const { getPreviousDate } = require("../../../utils/utils");
const client = require("../config/config");
const moment = require("moment");
module.exports = selfFunction = {
    /* ************ Create index for sharePosts ************ */
    createIndexForSharePost: async (indexName) => {
        try {
            console.log("+++++++++++++++++++ ENTERS in index cretion +++++++++++++++++++");
            const indexExists = await client.indices.exists({ index: indexName });

            if (indexExists) {
                console.log(`Index "${indexName}" already exists.`);
                return { success: false, message: `Index "${indexName}" already exists.` };
            }

            let sharePostIndex = await client.indices.create({
                index: indexName,
                body: {
                    mappings: {
                        properties: {
                            id: { type: "integer" },
                            content: { type: "text" },
                            image: { type: "nested" },
                            store_id: { type: "integer" },
                            group_id: { type: "integer" },
                            store_name: { type: "keyword" },
                            user_id: { type: "integer" },
                            post_id: { type: "integer" },
                            product_id: { type: "integer" },
                            isBookmarked: { type: "boolean" },
                            share_post_for: { type: "keyword" },
                            isActive: { type: "boolean" },
                            isShare: { type: "boolean" },
                            isDraft: { type: "boolean" },
                            isDeleted: { type: "boolean", },
                            createdAt: { type: "date", },
                        },
                    },
                },
            });

            return { success: true, message: "Index created successfully.", data: sharePostIndex };
        } catch (error) {
            return error;
        }
    },
    /* ************ Put mapping for sharePosts ************ */
    putMappingForSharePost: async (indexName) => {
        let sharePostIndex = await client.indices.putMapping({
            index: indexName,
            body: {
                properties: {
                    id: { type: "integer" },
                    content: { type: "text" },
                    image: { type: "nested" },
                    store_id: { type: "integer" },
                    group_id: { type: "integer" },
                    store_name: { type: "keyword" },
                    user_id: { type: "integer" },
                    post_id: { type: "integer" },
                    product_id: { type: "integer" },
                    isBookmarked: { type: "boolean" },
                    share_post_for: { type: "keyword" },
                    isActive: { type: "boolean" },
                    isShare: { type: "boolean" },
                    isDraft: { type: "boolean" },
                    isDeleted: { type: "boolean", },
                    createdAt: { type: "date", },
                },
            },
        });
        return sharePostIndex;
    },

    /* ************ Add Single data for sharePosts ************ */
    addSharePost: async (data, indexName = "share_post") => {
        try {
            if (!data.isBookmarked) data.isBookmarked = false;
            // index exists or not
            const indexExists = await client.indices.exists({
                index: indexName,
            });
            if (!indexExists) {
                let check = await module.exports.createIndexForSharePost(indexName);
            }
            const sharePost = await client.search({
                index: indexName,
                body: {
                    query: {
                        match: {
                            id: data.id,
                        },
                    },
                },
            });
            if (sharePost.hits.hits.length > 0) {
                return { success: false, message: "sharePost already exists" };
            }
            console.log(indexName, "indexName+++++++++++++++++++++++++++++++");
            const SharePost = await client.index({
                index: indexName,
                body: { ...data, createdAt: moment().toISOString() },
            });
            console.log(SharePost, "SharePost");
            return { success: true, message: "sharePost added successfully", data: SharePost };
        } catch (error) {
            console.log(error, "error");
            return { success: false, message: error };
        }
    },

    /* ************ Add data for sharePosts ************ */
    getAllSharePostData: async (indexName) => {
        const data = await client.search({
            index: indexName,
        });
        const sharePostsData = data.hits.hits.map((hit) => {
            return { ...hit._source, _id: hit._id };
        });
        return sharePostsData;
    },
    /* ************ delete sharePosts by id ************ */
    deleteSharePost: async ({ id, user_id }, indexName = "share_post") => {
        try {
            // search sharePost by id

            const existData = await client.search({
                index: indexName,
                body: {
                    query: {
                        bool: {
                            must: [
                                {
                                    match: { id: id, },
                                },
                                {
                                    match: { user_id: user_id, }
                                }
                            ],
                        },
                    },
                },
            });
            let _id = existData?.hits?.hits[0]?._id;
            if (!_id) { return { success: false, message: "SharePost does not exists" }; }
            const sharePostData = await client.delete({
                index: indexName,
                id: _id,
            });
            return { success: true, message: "SharePost deleted successfully", data: sharePostData.result };
        } catch (error) {
            console.log(error, "error");
            return error;
        }
    },

    /* ************ update sharePosts by id ************ */
    updateSharePostById: async (id, data, indexName = "share_post") => {
        try {
            // if exists
            const isExists = await client.search({
                index: indexName,
                body: {
                    query: {
                        match: {
                            id: id
                        },
                    },
                },
            });
            if (isExists.hits.hits.length === 0) {
                return { success: false, message: "SharePost does not exists" };
            }
            if (isExists.hits.hits.length > 0) {
                let sharePosts = isExists.hits.hits;
                for (let i = 0; i < sharePosts.length; i++) {
                    const sharePost = sharePosts[i];
                    // if exists
                    const sharePostExists = await client.exists({
                        index: indexName,
                        id: sharePost._id,
                    });
                    // console.log(sharePostExists, "sharePostExists");
                    if (!sharePostExists) {
                        console.log("SharePost does not exists");
                        return { success: false, message: "SharePost does not exists" };
                    }

                    const sharePostData = await client.get({
                        index: indexName,
                        id: sharePost._id,
                    });

                    const _source = sharePostData._source;

                    const updatedDocument = {
                        ..._source,
                        ...data,
                    };
                    // const updatedDocument = data
                    const updateResponse = await client.update({
                        index: indexName,
                        id: sharePost._id,
                        body: {
                            doc: updatedDocument,
                        },
                    });
                }
            }
            return { success: true, message: "SharePost updated successfully" };
        } catch (error) {
            console.log(error, "error");
            return error;
        }
    },
    getAllSaveProductMetrics: async (
        { store_id, start_date, end_date, time_interval, time_zone }, indexName = "share_post"
    ) => {
        try {
            const getLikesData = async (min_date, max_date, time_interval, time_zone,) => {
                const searchParams = {
                    index: indexName,
                    // match with store_id
                    query: {
                        bool: {
                            must: [
                                {
                                    match: { store_id: store_id, },
                                },
                                {
                                    exists: {
                                        field: "product_id"
                                    }
                                },
                                {
                                    match: { share_post_for: "POST", },

                                },
                                {
                                    match: { isBookmarked: true, },
                                },
                                {
                                    range: {
                                        createdAt: {
                                            gte: min_date,
                                            lte: max_date,
                                        },
                                    },
                                },
                            ],
                        },
                    },
                    body: {
                        aggs: {
                            total_product_save_counts: {
                                cardinality: {
                                    field: 'id',
                                }
                            }
                        },
                    },
                }
                const response = await client.search(searchParams);
                // return formattedData
                return { total_product_save_counts: response?.aggregations?.total_product_save_counts?.value || 0 };
            }
            let current = (await getLikesData(start_date, end_date, time_interval, time_zone));
            let current_total_save_post_count = current.total_product_save_counts;


            let { previous_start_date, previous_end_date } = await getPreviousDate(start_date, end_date)
            let previous_total_likes_count = (await getLikesData(previous_start_date, previous_end_date, time_interval, time_zone)).total_product_save_counts
            // current_total_save_post_count and previous_total_likes_count in percentage
            let current_total_save_post_count_percentage = previous_total_likes_count !== 0 ? ((previous_total_likes_count - current_total_save_post_count) / previous_total_likes_count * 100).toFixed(2) : 0
            return {
                success: true, message: "", data: {
                    current_total_save_products: current_total_save_post_count,
                    previous_total_save_products: current_total_save_post_count_percentage,
                }
            };
        } catch (error) {
            console.error(error);
            return { success: false, message: error.message };
        }
    },
    getAllShareProductMetrics: async (
        { store_id, start_date, end_date, time_interval, time_zone }, indexName = "share_post"
    ) => {
        try {
            const getLikesData = async (min_date, max_date, time_interval, time_zone,) => {
                const searchParams = {
                    index: indexName,
                    // match with store_id
                    query: {
                        bool: {
                            must: [
                                {
                                    match: { store_id: store_id, },
                                },
                                {
                                    exists: {
                                        field: "product_id"
                                    }
                                },
                                {
                                    match: { share_post_for: "POST", },

                                },
                                {
                                    range: {
                                        createdAt: {
                                            gte: min_date,
                                            lte: max_date,
                                        },
                                    },
                                },
                            ],
                        },
                    },
                    body: {
                        aggs: {
                            total_share_products: {
                                cardinality: {
                                    field: 'id',
                                }
                            }
                        },
                    },
                }
                const response = await client.search(searchParams);
                // return formattedData
                return { total_share_products: response?.aggregations?.total_share_products?.value || 0 };
            }
            let current = (await getLikesData(start_date, end_date, time_interval, time_zone));
            let current_total_share_products = current.total_share_products;


            let { previous_start_date, previous_end_date } = await getPreviousDate(start_date, end_date)
            let previous_total_share_product = (await getLikesData(previous_start_date, previous_end_date, time_interval, time_zone)).total_share_products
            // current_total_share_products and previous_total_share_product in percentage
            let current_total_save_post_count_percentage = previous_total_share_product !== 0 ? ((previous_total_share_product - current_total_share_products) / previous_total_share_product * 100).toFixed(2) : 0
            return {
                success: true, message: "", data: {
                    current_total_share_products: current_total_share_products,
                    previous_total_share_products: current_total_save_post_count_percentage,
                }
            };
        } catch (error) {
            console.error(error);
            return { success: false, message: error.message };
        }
    }

}