const client = require("../config/config");
let validationSchema = require("../validation/index");
let moment = require("moment");
const database = require("../../../database/models");
const {
  getPreviousDate,
  storeCustomersMetrics,
  orderCustomersGenderHelper,
  customersLocationHelper,
  customersLocationBySalesHelper,
  customersCategoryBySalesHelper,
  customerAgeRatioMetrics,
  customerAgeBarChartResponse,
  repeatCustomersHelper,
} = require("../../../utils/utils");
module.exports = self = {
  /*  ================================
      ================================
      ======== ORDERS SECTION ========= */

  /* ************ CREATE INDEX FOR ORDER ************ */
  createIndexForOrders: async (indexName) => {
    try {
      let order_index = await client.indices.create({
        index: indexName,
        body: {
          mappings: {
            properties: {
              order_id: { type: "keyword" },
              userId: { type: "integer" },
              productId: {
                type: "integer",
              },
              quantity: {
                type: "integer",
              },
              generate_id: { type: "long" },
              total: { type: "float" },
              isPaymentDone: { type: "boolean" },
              createdAt: { type: "date" },
              orderDate: { type: "date" },
              order_status: { type: "keyword" },
              product_info: {
                type: "object",
                properties: {
                  product_id: { type: "integer" },
                  store_id: { type: "integer" },
                  title: { type: "text" },
                  description: { type: "text" },
                  price: { type: "float" },
                  isFeature: { type: "boolean" },
                  isActive: { type: "boolean" },
                  quantity: { type: "integer" },
                  listPrice: { type: "float" },
                  sku: { type: "keyword" },
                  metaTitle: { type: "text" },
                  metaDescription: { type: "text" },
                  keywords: { type: "text" },
                  isVisible: { type: "boolean" },
                  isFreeShipping: { type: "boolean" },
                  condition: { type: "keyword" },
                  tags: { type: "keyword" },
                  image: { type: "keyword" },
                  video: { type: "keyword" },
                  is_deleted: { type: "boolean" },
                  customerId: { type: "keyword" },
                  cropImages: {
                    type: "nested",
                    properties: {
                      id: { type: "keyword" },
                      oldFile: { type: "text" },
                      croppedFile: {
                        properties: {
                          baseURL: { type: "text" },
                          zoom: { type: "float" },
                          rotate: { type: "integer" },
                          crop: {
                            properties: {
                              x: { type: "long" },
                              y: { type: "long" },
                            },
                          },
                        },
                      },
                    },
                  },
                  ratio: { type: "keyword" },
                  size: {
                    type: "object",
                    properties: {
                      height: { type: "integer" },
                      width: { type: "integer" },
                    },
                  },
                  id: { type: "integer" },
                  isDeleted: {
                    type: "boolean",
                  },
                  createdAt: {
                    type: "date",
                  },
                },
              },
            },
          },
        },
      });
      return order_index;
    } catch (error) {
      return error;
    }
  },
  /* ************ PUT MAPPING FOR ORDER ************ */
  putMappingForOrders: async (indexName) => {
    let order_mapping = await client.indices.putMapping({
      index: indexName,
      body: {
        properties: {
          order_id: { type: "keyword" },
          orderDate: { type: "date" },
          customerId: { type: "keyword" },
          products: {
            type: "nested",
            properties: {
              productId: { type: "keyword" },
              productName: { type: "text" },
              price: { type: "float" },
              quantity: { type: "integer" },
            },
          },
          status: {
            type: "object",
            properties: {
              code: { type: "keyword" },
              name: { type: "keyword" },
            },
          },
        },
      },
    });
    return order_mapping;
  },

  /* ************ ADD BULK ORDERS  ************ */
  addBulkDataForOrders: async (index, data) => {
    let orderDatas = data;

    let body = [];
    for (const order of orderDatas) {
      body.push({ index: { _index: index } });
      body.push(order);
    }
    console.log(JSON.parse(JSON.stringify(body)), "body");
    const bulkData = body;

    // // Perform bulk indexing
    const performBulkIndexing = async () => {
      const data = await client.bulk({ refresh: true, body: bulkData });
      if (data.errors) {
        console.log("Error indexing data:", data.errors);
      } else {
        console.log("Data indexed successfully.");
      }
    };

    performBulkIndexing()
      .then(() => {
        console.log("Bulk indexing completed successfully.");
      })
      .catch((error) => {
        console.error("An error occurred during bulk indexing:", error);
      });
  },

  /* ************ ADD SINGLE ORDER ************ */
  addSingleDataForOrder: async (indexName, data) => {
    const indexExists = await client.indices.exists({
      index: indexName,
    });
    console.log(indexExists, "indexExists");
    if (!indexExists) {
      let check = await self.createIndexForOrders(indexName);
      console.log("checkcheckcheckcheckcheckcheck", check);
    }
    const orderExists = await client.search({
      index: indexName,
      body: {
        query: {
          match: {
            order_id: data.order_id,
          },
        },
      },
    });
    console.log(orderExists, "orderExists");
    if (orderExists.hits.hits.length > 0) {
      return { success: false, message: "Order already exists" };
    }
    const orderData = await client.index({
      index: indexName,
      body: data,
    });
    console.log(orderData, "orderData");
    return { success: true, message: "Order added successfully", data: orderData };
  },

  /*  ================================
      ================================
      ======== UPDATE ORDERS SECTION ========= */

  /*  ================================
      ================================
      ======== GET ORDERS SECTION ========= */
  /* ************ Add data for orders ************ */
  getAllOrdersData: async (indexName) => {
    const data = await client.search({
      index: indexName,
    });
    const ordersData = data.hits.hits.map((hit) => {
      return { ...hit._source, _id: hit._id };
    });
    return ordersData;
  },
  /* ************ get Orders metrics ************ */
  getOrdersMetrics: async (indexName, store_id) => {
    let metrics = await client.search({
      index: indexName,
      body: {
        // matching with store id
        ...(store_id ? { query: { match: { store_id: store_id } } } : { query: { match_all: {} } }),
        size: 0,
        aggs: {
          // filter with values
          pending_orders: {
            filter: { term: { order_status: "pending" } },
          },
          shipped_orders: {
            filter: { term: { order_status: "shipped" } },
          },

          dispatched_orders: {
            filter: { term: { order_status: "delivered" } },
          },
          // filter with fields
          total_orders: {
            value_count: {
              field: "id",
            },
          },
        },
      },
    });
    // console.log(metrics.aggregations, "metrics");
    return metrics;
  },

  /* ************ get Orders metrics with percentage ************ */
  getOrdersMetricsWithPercentage: async (indexName) => {
    const getOrderStatusCountsPercentage = async (indexName) => {
      let metricsWithPercentage = await client.search({
        index: indexName,
        body: {
          size: 0,
          aggs: {
            order_statuses: {
              terms: {
                field: "status.code",
              },
              aggs: {
                status_count: {
                  value_count: {
                    field: "order_id",
                  },
                },
                status_percentage: {
                  bucket_script: {
                    buckets_path: {
                      count: "status_count",
                    },
                    script: "params.count / params.total * 100",
                    gap_policy: "skip",
                  },
                },
              },
            },
          },
        },
      });
      console.log(metricsWithPercentage.aggregations, "metricsWithPercentage");
      return metricsWithPercentage;
    };
  },

  /*  ================================
      ================================
      ======== DELETE ORDERS SECTION ========= */

  /* ************ delete order by id ************ */
  deleteOrder: async (indexName, order_id) => {
    try {
      // if exists
      const orderExists = await client.exists({
        index: indexName,
        id: order_id,
      });
      // console.log(orderExists, "orderExists");
      if (!orderExists) {
        console.log("Order does not exists");
        return { success: false, message: "Order does not exists" };
      }

      const orderData = await client.delete({
        index: indexName,
        id: order_id,
      });
      console.log(orderData.result, "orderData");
      return orderData;
    } catch (error) {
      console.log(error, "error");
      return error;
    }
  },

  /* ************ get order by id ************ */
  getOrderById: async (indexName, order_id) => {
    // if exists
    const orderExists = await client.exists({
      index: indexName,
      id: order_id,
    });

    if (!orderExists) {
      return { success: false, message: "Order does not exists" };
    }

    let orderData = await client.get({
      index: indexName,
      id: order_id,
    });
    orderData = { ...orderData._source, id: orderData._id };
    return orderData;
  },

  /* ************ update order by id ************ */
  updateOrderById: async (indexName, id, data) => {
    try {
      const isExists = await client.search({
        index: indexName,
        body: {
          query: {
            match: {
              id: id,
            },
          },
        },
      });
      // console.log(isExists.hits.hits, "isExists");
      if (isExists.hits.hits.length === 0) {
        return { success: false, message: "Order does not exists" };
      }
      if (isExists.hits.hits.length > 0) {
        let orders = isExists.hits.hits;
        for (let i = 0; i < orders.length; i++) {
          const order = orders[i];
          // if exists
          const orderExists = await client.exists({
            index: indexName,
            id: order._id,
          });
          // console.log(orderExists, "orderExists");
          if (!orderExists) {
            console.log("Order does not exists");
            return { success: false, message: "Order does not exists" };
          }

          const orderData = await client.get({
            index: indexName,
            id: order._id,
          });

          const _source = orderData._source;

          const updatedDocument = {
            ..._source,
            ...data,
          };
          // const updatedDocument = data
          const updateResponse = await client.update({
            index: indexName,
            id: order._id,
            body: {
              doc: updatedDocument,
            },
          });
        }
      }

      return { success: true, message: "Order updated successfully" };
    } catch (error) {
      console.log(error, "error");
      return error;
    }
  },

  /* ************ get date wise order revenue ************ */
  getDateWiseOrderRevenue: async (indexName, { store_id, start_date, end_date, time_interval, time_zone }) => {
    try {
      const getRevenueData = async (min_date, max_date, time_interval, time_zone) => {
        const searchParams = {
          index: "order_items",
          // match with store_id
          query: {
            bool: {
              must: [
                {
                  match: {
                    store_id: store_id,
                  },
                },
                {
                  range: {
                    createdAt: {
                      gte: min_date,
                      lte: max_date,
                    },
                  },
                },
              ],
            },
          },
          size: 0,
          body: {
            aggs: {
              date_counts: {
                date_histogram: {
                  field: "createdAt",
                  calendar_interval: time_interval ? time_interval : "day",
                  time_zone: time_zone ? time_zone : "Asia/Kolkata",
                  extended_bounds: {
                    min: min_date,
                    max: max_date,
                  },
                },
                aggs: {
                  store_revenue: {
                    sum: {
                      field: "totalAmount",
                    },
                  },
                },
              },
              total_store_revenue: {
                sum: {
                  field: "totalAmount",
                },
              },
              total_orders: {
                value_count: {
                  field: "id",
                },
              },
            },
          },
        };
        const response = await client.search(searchParams);
        const dateCounts = response.aggregations.date_counts.buckets;
        // console.log("fsdafasdfadasfasfsafdsafafasdf+++++++++++++++++", response.aggregations.date_counts.buckets);
        const formattedData = dateCounts.map((bucket) => [
          bucket.key, // Date in the desired format
          bucket.store_revenue.value || 0, // Revenue sum (if available) or 0 as default
        ]);
        // return formattedData
        return {
          data: formattedData,
          revenue: response?.aggregations?.total_store_revenue?.value || 0,
          average_order_value: response?.aggregations?.total_store_revenue?.value / response?.aggregations?.total_orders?.value || 0,
        };
      };
      let current_data_response = await getRevenueData(start_date, end_date, time_interval, time_zone);
      let current_data = current_data_response.data;
      let current_revenue = current_data_response.revenue;

      let { previous_start_date, previous_end_date } = await getPreviousDate(start_date, end_date, time_interval, time_zone);
      let previous_revenue = (await getRevenueData(previous_start_date, previous_end_date)).revenue;
      // current_revenue and previous_revenue in percentage
      let current_revenue_percentage = previous_revenue !== 0 ? (((previous_revenue - current_revenue) / previous_revenue) * 100).toFixed(2) : 0;

      return {
        current_revenue: current_revenue,
        previous_revenue_percentage: current_revenue_percentage,
        current_data: current_data,
      };
    } catch (error) {
      console.error(error);
    }
  },

  getDatewiseUserActivityReport: async (start_date, end_date, time_interval, user_id, count = 1) => {
    try {
      console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", start_date, end_date, time_interval, count);
      // const getPOstCount = async (min_date, max_date, time_interval, time_zone) => {
      // const searchParams = {
      //   index: "comment",
      //   query: {
      //     bool: {
      //       must: [
      //         {
      //           range: {
      //             createdAt: {
      //               gte: min_date,
      //               lte: max_date,
      //             },
      //           },
      //         },
      //       ],
      //     },
      //   },
      //   size: 0,
      // };
      //   const response = await client.search(searchParams);
      //   return response?.hits?.total?.value;
      // };
      // let current_data_response = await getPOstCount(start_date, end_date, time_interval, time_zone);
      // let { previous_start_date, previous_end_date } = await getPreviousDate(start_date, end_date);
      // console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>", previous_start_date, previous_end_date);
      // let previous_data_response = await getPOstCount(previous_start_date, previous_end_date);
      // console.log("current_data_response, previous_data_response", current_data_response, previous_data_response);
      // async function calculateDifference(currentData, previousData) {
      //   return currentData - previousData;
      // }
      // const difference = await calculateDifference(current_data_response, previous_data_response);
      // console.log("difference++++++++++++++++++++++++++++", difference);
      // =================================================================================================================================================================
      // let currentPostCount = await client.search({
      //   index: "post",
      //   body: {
      //     query: {
      //       bool: {
      //         must: [
      //           {
      //             range: {
      //               createdAt: {
      //                 gte: start_date,
      //                 lte: end_date,
      //               },
      //             },
      //           },
      //         ],
      //       },
      //     },
      //     size: 0,
      //     // aggs: {
      //     //   total_products: {
      //     //     value_count: {
      //     //       field: "id",
      //     //     },
      //     //   },
      //     // },
      //   },
      // });
      // let PreviousPostCount = await client.search({
      //   index: "post",
      //   body: {
      //     query: {
      //       bool: {
      //         must: [
      //           {
      //             range: {
      //               createdAt: {
      //                 gte: moment()
      //                   .subtract(month + 1, "months")
      //                   .format("YYYY-MM-DD"),
      //                 lte: moment().subtract(month, "months").format("YYYY-MM-DD"),
      //               },
      //             },
      //           },
      //         ],
      //       },
      //     },
      //     size: 0,
      //   },
      // });
      // let product_count_diff = currentPostCount?.hits?.total?.value - PreviousPostCount?.hits?.total?.value;
      // console.log("currentProductMetrics++++++++++++++++++++++++", currentPostCount?.hits?.total?.value - PreviousPostCount?.hits?.total?.value);
      // ================================================================================================================================================================
      // let currentLikeCount = await client.search({
      //   index: "like",
      //   body: {
      //     query: {
      //       bool: {
      //         must: [
      //           {
      //             range: {
      //               createdAt: {
      //                 gte: start_date,
      //                 lte: end_date,
      //               },
      //             },
      //           },
      //         ],
      //       },
      //     },
      //     size: 0,
      //   },
      // });
      // let PreviousLikeCount = await client.search({
      //   index: "like",
      //   body: {
      //     query: {
      //       bool: {
      //         must: [
      //           {
      //             range: {
      //               createdAt: {
      //                 gte: moment()
      //                   .subtract(month + 1, "months")
      //                   .format("YYYY-MM-DD"),
      //                 lte: moment().subtract(month, "months").format("YYYY-MM-DD"),
      //               },
      //             },
      //           },
      //         ],
      //       },
      //     },
      //     size: 0,
      //   },
      // });
      // let like_count_diff = currentLikeCount?.hits?.total?.value !== 0 ? Number(((currentLikeCount?.hits?.total?.value - PreviousLikeCount?.hits?.total?.value) / currentLikeCount?.hits?.total?.value) * 100).toFixed(2) : 0;
      // ================================================================================================================================================================
      // let currentCommentCount = await client.search({
      //   index: "comment",
      //   body: {
      //     query: {
      //       bool: {
      //         must: [
      //           {
      //             range: {
      //               createdAt: {
      //                 gte: start_date,
      //                 lte: end_date,
      //               },
      //             },
      //           },
      //         ],
      //       },
      //     },
      //     size: 0,
      //   },
      // });
      // let PreviousCommentCount = await client.search({
      //   index: "comment",
      //   body: {
      //     query: {
      //       bool: {
      //         must: [
      //           {
      //             range: {
      //               createdAt: {
      //                 gte: moment()
      //                   .subtract(month + 1, "months")
      //                   .format("YYYY-MM-DD"),
      //                 lte: moment().subtract(month, "months").format("YYYY-MM-DD"),
      //               },
      //             },
      //           },
      //         ],
      //       },
      //     },
      //     size: 0,
      //   },
      // });
      // let comment_count_diff = currentCommentCount?.hits?.total?.value !== 0 ? Number(((currentCommentCount?.hits?.total?.value - PreviousCommentCount?.hits?.total?.value) / currentCommentCount?.hits?.total?.value) * 100).toFixed(2) : 0;
      // console.log("currentProductMetrics++++++++++++++++++++++++", PreviousCommentCount?.hits?.total?.value, currentCommentCount?.hits?.total?.value);
      // =====================================================================================================================================================================

      const getCalculation = async (indexName, start_date, end_date) => {
        const searchParams1 = {
          index: indexName,
          body: {
            query: {
              bool: {
                must: [
                  {
                    match: {
                      user_id: user_id,
                    },
                  },
                  {
                    range: {
                      createdAt: {
                        gte: start_date,
                        lte: end_date,
                      },
                    },
                  },
                ],
              },
            },
            size: 0,
          },
        };
        let data = await client.search(searchParams1);
        return data?.hits?.total?.value;
      };

      const [currentPostCount, PreviousPostCount, currentLikeCount, PreviousLikeCount, currentCommentCount, PreviousCommentCount] = await Promise.all([
        getCalculation("post", start_date, end_date),
        getCalculation(
          "post",
          moment(start_date)
            .subtract(count + 1, time_interval)
            .format("YYYY-MM-DD"),
          moment(end_date).subtract(count, time_interval).format("YYYY-MM-DD")
        ),
        getCalculation("like", start_date, end_date),
        getCalculation(
          "like",
          moment(start_date)
            .subtract(count + 1, time_interval)
            .format("YYYY-MM-DD"),
          moment(end_date).subtract(count, time_interval).format("YYYY-MM-DD")
        ),
        getCalculation("comment", start_date, end_date),
        getCalculation(
          "comment",
          moment(start_date)
            .subtract(count + 1, time_interval)
            .format("YYYY-MM-DD"),
          moment(end_date).subtract(count, time_interval).format("YYYY-MM-DD")
        ),
      ]);

      let current_post_count = currentPostCount;
      let current_post_count_diff = currentPostCount - PreviousPostCount;

      let current_like_count = currentLikeCount;
      let current_like_count_diff_pct = currentLikeCount !== 0 ? Number((((currentLikeCount - PreviousLikeCount) / currentLikeCount) * 100).toFixed(2)) : 0;

      let current_comment_count = currentCommentCount;
      let current_comment_count_diff_pct = currentCommentCount !== 0 ? Number((((currentCommentCount - PreviousCommentCount) / currentCommentCount) * 100).toFixed(2)) : 0;

      return { current_post_count, current_post_count_diff, current_like_count, current_like_count_diff_pct, current_comment_count, current_comment_count_diff_pct };
    } catch (error) {
      console.error(error);
    }
  },

  /* ************ get User Order Analysis ************ */
  getDateWiseUserOrderAnalysis: async (indexName, { user_id, start_date, end_date, time_interval, time_zone }) => {
    try {
      const getRevenueData = async (min_date, max_date, time_interval, time_zone) => {
        const searchParams = {
          index: "order_master",
          // match with store_id
          query: {
            bool: {
              must: [
                {
                  match: {
                    user_id: user_id,
                  },
                },
                {
                  range: {
                    createdAt: {
                      gte: min_date,
                      lte: max_date,
                    },
                  },
                },
              ],
            },
          },
          size: 0,
          body: {
            aggs: {
              date_counts: {
                date_histogram: {
                  field: "createdAt",
                  calendar_interval: time_interval ? time_interval : "day",
                  time_zone: time_zone ? time_zone : "Asia/Kolkata",
                  extended_bounds: {
                    min: min_date,
                    max: max_date,
                  },
                },
                aggs: {
                  store_revenue: {
                    sum: {
                      field: "totalAmount",
                    },
                  },
                },
              },
              total_store_revenue: {
                sum: {
                  field: "totalAmount",
                },
              },
              total_orders: {
                value_count: {
                  field: "id",
                },
              },
            },
          },
        };
        const response = await client.search(searchParams);
        const dateCounts = response.aggregations.date_counts.buckets;
        // console.log("fsdafasdfadasfasfsafdsafafasdf+++++++++++++++++", response.aggregations.date_counts.buckets);

        const formattedData = dateCounts.map((bucket) => [
          bucket.key, // Date in the desired format
          bucket.store_revenue.value || 0, // Revenue sum (if available) or 0 as default
        ]);
        // return formattedData

        return {
          data: formattedData,
          revenue: response?.aggregations?.total_store_revenue?.value || 0,
          average_order_value: response?.aggregations?.total_store_revenue?.value / response?.aggregations?.total_orders?.value || 0,
        };
      };
      let current_data_response = await getRevenueData(start_date, end_date, time_interval, time_zone);
      let current_data = current_data_response.data;
      let current_revenue = current_data_response.revenue;
      console.log("fsdfafsaf 111111111+++++++++++++++++++++++++++++++++++++++", current_data_response);
      console.log("fsdfafsaf 222222222+++++++++++++++++++++++++++++++++++++++", current_data);
      console.log("fsdfafsaf 333333333+++++++++++++++++++++++++++++++++++++++", current_revenue);

      let { previous_start_date, previous_end_date } = await getPreviousDate(start_date, end_date, time_interval, time_zone);
      let previous_revenue = (await getRevenueData(previous_start_date, previous_end_date)).revenue;
      console.log("fsdarewqrwerwer 9999 9999 999 ++++++++++++++++++++++++++++++++++++++++++", previous_revenue);
      // current_revenue and previous_revenue in percentage
      // return
      let current_revenue_percentage = previous_revenue !== 0 ? (((previous_revenue - current_revenue) / previous_revenue) * 100).toFixed(2) : 0;

      return {
        current_revenue: current_revenue,
        previous_revenue_percentage: current_revenue_percentage,
        current_data: current_data,
      };
    } catch (error) {
      console.error(error);
    }
  },

  /* ************ get order count stats************ */
  getUserOrderCountStatsElastic: async (indexName, { user_id }) => {
    try {



      const getRevenueData = async () => {
        const todayStart = moment().startOf("day").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]"); // Start of today
        const now = moment().format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]"); // Current time

        // Last month's date range
        const lastMonthStart = moment().subtract(1, "months").startOf("month").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
        const lastMonthEnd = moment().subtract(1, "months").endOf("month").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");

        // Calculate the same day last month
        const lastMonthSameDayStart = moment().subtract(1, "months").startOf("day").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
        const lastMonthSameDayEnd = moment().subtract(1, "months").endOf("day").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");


        const [
          todaysOrderCountResponse, 
          lastMonthSameDayOrderCountResponse, 
          totalOrderCountResponse, 
          lastMonthOrderCountResponse, 
          pendingOrderCountResponse, 
          lastMonthPendingOrderCountResponse, 
          completedOrderCountResponse, 
          lastMonthCompletedOrderCountResponse
        ] = await Promise.all([

        // Fetch today's order count
        client.count({
          index: indexName,
          body: {
            query: {
              bool: {
                must: [
                  { match: { user_id: user_id } },
                  {
                    range: {
                      createdAt: {
                        gte: todayStart,
                        lte: now,
                      },
                    },
                  },
                ],
              },
            },
          },
        }),
        

        // Fetch last month's same day order count for the same date range
        client.count({
          index: indexName,
          body: {
            query: {
              bool: {
                must: [
                  { match: { user_id: user_id } },
                  {
                    range: {
                      createdAt: {
                        gte: lastMonthSameDayStart,
                        lte: lastMonthSameDayEnd,
                      },
                    },
                  },
                ],
              },
            },
          },
        }),

        // Fetch total order count
        client.count({
          index: indexName,
          body: {
            query: {
              match: { user_id: user_id },
            },
          },
        }),

        // Fetch last month's order count for the same date range
        client.count({
          index: indexName,
          body: {
            query: {
              bool: {
                must: [
                  { match: { user_id: user_id } },
                  {
                    range: {
                      createdAt: {
                        gte: lastMonthStart,
                        lte: lastMonthEnd,
                      },
                    },
                  },
                ],
              },
            },
          },
        }),


        // Fetch pending orders count
        client.count({
          index: indexName,
          body: {
            query: {
              bool: {
                must: [
                  { match: { user_id: user_id } },
                  { match: { order_status: "pending" } },
                ],
              },
            },
          },
        }),

        // Fetch last month's pending order count
        client.count({
          index: indexName,
          body: {
            query: {
              bool: {
                must: [
                  { match: { user_id: user_id } },
                  { match: { order_status: 'pending' } },
                  {
                    range: {
                      createdAt: {
                        gte: lastMonthStart,
                        lte: lastMonthEnd,
                      },
                    },
                  },
                ],
              },
            },
          },
        }),


        // Fetch completed orders count
        client.count({
          index: indexName,
          body: {
            query: {
              bool: {
                must: [
                  { match: { user_id: user_id } },
                  { match: { order_status: "delivered" } },
                ],
              },
            },
          },
        }),


        // Fetch last month's completed order count
        client.count({
          index: indexName,
          body: {
            query: {
              bool: {
                must: [
                  { match: { user_id: user_id } },
                  { match: { order_status: 'delivered' } },
                  {
                    range: {
                      createdAt: {
                        gte: lastMonthStart,
                        lte: lastMonthEnd,
                      },
                    },
                  },
                ],
              },
            },
          },
        }),

      ]);

      const todaysOrderCount = todaysOrderCountResponse?.count || 0;
      const lastMonthSameDayOrderCount = lastMonthSameDayOrderCountResponse?.count || 0;
      const totalOrderCount = totalOrderCountResponse?.count || 0;
      const lastMonthOrderCount = lastMonthOrderCountResponse?.count || 0;
      const pendingOrderCount = pendingOrderCountResponse?.count || 0;
      const lastMonthPendingOrderCount = lastMonthPendingOrderCountResponse?.count || 0;
      const completedOrderCount = completedOrderCountResponse?.count || 0;
      const lastMonthCompletedOrderCount = lastMonthCompletedOrderCountResponse?.count || 0;

      // Percentage calculations
      const percentageChange = (current, previous) => {
        if (previous === 0) return 0;
        return ((current - previous) / previous) * 100;
      };

      const todaysOrderPercentageChange = percentageChange(todaysOrderCount, lastMonthSameDayOrderCount);
      const totalOrderPercentageChange = percentageChange(totalOrderCount, lastMonthOrderCount);
      const pendingOrderPercentageChange = percentageChange(pendingOrderCount, lastMonthPendingOrderCount);
      const completedOrderPercentageChange = percentageChange(completedOrderCount, lastMonthCompletedOrderCount);

      // Response
      return {
        todayOrders: todaysOrderCount,
        percentageChangeInTodayOrders: +todaysOrderPercentageChange.toFixed(2),
        totalOrders: totalOrderCount,
        percentageChangeInTotalOrders: +totalOrderPercentageChange.toFixed(2),
        pendingOrders: pendingOrderCount,
        percentageChangeInPendingOrders: +pendingOrderPercentageChange.toFixed(2),
        completedOrders: completedOrderCount,
        percentageChangeInCompletedOrders: +completedOrderPercentageChange.toFixed(2),
      };

      // let todays_order_count = await client.count({
      //   index: "order_master",
      //   body: {
      //     query: {
      //       bool: {
      //         must: [
      //           {
      //             match: {
      //               user_id: user_id,
      //             },
      //           },
      //           {
      //             range: {
      //               createdAt: {
      //                 gte: moment().startOf("day").format("YYYY-MM-DD[T]00:00:00.000"),
      //                 lte: moment().format("YYYY-MM-DD[T]HH:mm:ss.000"),
      //               },
      //             },
      //           },
      //         ],
      //       },
      //     },
      //   },
      // });

      // // const today = new Date(moment().startOf("day").format("YYYY-MM-DD[T]00:00:00.000"));
      // // const lastMonth = new Date(today.getFullYear(), today.getMonth() - 1, today.getDate());
      // // lastMonth.setUTCHours(0, 0, 0, 0);
      // // const lastDayOfMonth = new Date(lastMonth.getFullYear(), lastMonth.getMonth() + 1, 0);
      // // lastDayOfMonth.setUTCHours(23, 59, 59, 0);

      // let last_month_same_date_order_count = await client.count({
      //   index: "order_master",
      //   body: {
      //     query: {
      //       bool: {
      //         must: [
      //           {
      //             match: {
      //               user_id: user_id,
      //             },
      //           },
      //           {
      //             range: {
      //               createdAt: {
      //                 gte: lastMonth.toISOString(),
      //                 lte: lastDayOfMonth.toISOString(),
      //               },
      //             },
      //           },
      //         ],
      //       },
      //     },
      //   },
      // });

      // let todaysOrderCount = todays_order_count?.count || 0;
      // let todays_count_diff_vs_last_month = (todays_order_count?.count || 0) - (last_month_same_date_order_count?.count || 0);

      // let total_order_count = await client.count({
      //   index: "order_master",
      //   body: {
      //     query: {
      //       match: { user_id: user_id },
      //     },
      //   },
      // });

      // let totalOrderCount = total_order_count?.count || 0;

      // const total_pending_order = await client.count({
      //   index: "order_master",
      //   body: {
      //     query: {
      //       bool: {
      //         must: [
      //           {
      //             match: {
      //               user_id: user_id,
      //             },
      //           },
      //           { match: {
      //               order_status: "pending"
      //              }
      //           },
      //         ],
      //       },
      //     },
      //   },
      // });

      // const total_completed_order = await client.count({
      //   index: "order_master",
      //   body: {
      //     query: {
      //       bool: {
      //         must: [
      //           {
      //             match: {
      //               user_id: user_id,
      //             },
      //           },
      //           { match: { order_status: "delivered" } },
      //         ],
      //       },
      //     },
      //   },
      // });

      // console.log("fdsafasdf", todays_order_count?.count, total_order_count?.count, total_pending_order?.count, total_cancle_order.count);
      // return {
      //   todays_count: todaysOrderCount || 0,
      //   todays_count_diff: todays_count_diff_vs_last_month || 0,
      //   total_order: totalOrderCount || 0,
      //   total_pending_order: total_pending_order?.count || 0,
      //   total_completed_order: total_completed_order?.count || 0,
      // };
    };
    let current_data_response = await getRevenueData();
    return current_data_response;
  } catch(error) {
    console.error("An error occured while fetching orders stats for summary from elastic search", error);
  }
},

  /* ************ get date wise order earnings ************ */
  getDateWiseOrderEarnings: async (indexName, { store_id, start_date, end_date, time_interval, time_zone }) => {
    try {
      const getRevenueData = async (min_date, max_date, time_interval, time_zone) => {
        const searchParams = {
          index: "order_items",
          // match with store_id
          query: {
            bool: {
              must: [
                {
                  match: {
                    store_id: store_id,
                  },
                },
                {
                  range: {
                    createdAt: {
                      gte: min_date,
                      lte: max_date,
                    },
                  },
                },
              ],
            },
          },
          size: 0,
          body: {
            aggs: {
              date_counts: {
                date_histogram: {
                  field: "createdAt",
                  calendar_interval: time_interval ? time_interval : "day",
                  time_zone: time_zone ? time_zone : "Asia/Kolkata",
                  extended_bounds: {
                    min: min_date,
                    max: max_date,
                  },
                },
                aggs: {
                  store_revenue: {
                    sum: {
                      field: "sellerFinalAmount",
                    },
                  },
                },
              },
              total_store_revenue: {
                sum: {
                  field: "sellerFinalAmount",
                },
              },
              total_orders: {
                value_count: {
                  field: "id",
                },
              },
            },
          },
        };
        const response = await client.search(searchParams);
        const dateCounts = response.aggregations.date_counts.buckets;
        const formattedData = dateCounts.map((bucket) => [
          bucket.key, // Date in the desired format
          bucket.store_revenue.value || 0, // Revenue sum (if available) or 0 as default
        ]);
        // return formattedData
        return {
          data: formattedData,
          revenue: response?.aggregations?.total_store_revenue?.value || 0,
          average_order_value: response?.aggregations?.total_store_revenue?.value / response?.aggregations?.total_orders?.value || 0,
        };
      };
      let current_data_response = await getRevenueData(start_date, end_date, time_interval, time_zone);
      let current_data = current_data_response.data;
      let current_revenue = current_data_response.revenue;

      let { previous_start_date, previous_end_date } = await getPreviousDate(start_date, end_date, time_interval, time_zone);
      let previous_revenue = (await getRevenueData(previous_start_date, previous_end_date)).revenue;
      // current_revenue and previous_revenue in percentage
      let current_revenue_percentage = previous_revenue !== 0 ? (((previous_revenue - current_revenue) / previous_revenue) * 100).toFixed(2) : 0;

      return {
        current_revenue: current_revenue,
        previous_revenue_percentage: current_revenue_percentage,
        current_data: current_data,
      };
    } catch (error) {
      console.error(error);
    }
  },

    /* ************ get AOV ************ */
    getAverageOrderValueAndOrdersMetrtics: async (indexName, { store_id, start_date, end_date, time_interval, time_zone }) => {
      // console.log(store_id, days, types, "store_id, days, types");
      // diffrence date
      // let min_date = moment().subtract(days, types).format('YYYY-MM-DD');
      // let max_date = moment().format('YYYY-MM-DD');
      // let min_date = moment(start_date)
      // let max_date = moment(end_date)
      // console.log(min_date, max_date, "min_date, max_date");
      try {
        const getRevenueData = async (min_date, max_date, time_interval, time_zone) => {
          const searchParams = {
            index: "orders",
            // match with store_id
            query: {
              bool: {
                must: [
                  {
                    match: {
                      store_id: store_id,
                    },
                  },
                  {
                    range: {
                      orderDate: {
                        gte: min_date,
                        lte: max_date,
                      },
                    },
                  },
                ],
              },
            },
            size: 0,
            body: {
              aggs: {
                tota_revenue: {
                  sum: {
                    field: "price",
                  },
                },
                total_orders: {
                  value_count: {
                    field: "order_id",
                  },
                },
              },
            },
          };
          const response = await client.search(searchParams);
          return {
            revenue: response?.aggregations?.tota_revenue?.value || 0,
            orders: response?.aggregations?.total_orders?.value || 0,
            average_order_value: response?.aggregations?.tota_revenue?.value / response?.aggregations?.total_orders?.value || 0,
          };
        };

        let current_data = await getRevenueData(start_date, end_date, time_interval, time_zone);
        current_data = {
          revenue: current_data.revenue,
          orders: current_data.orders,
          average_order_value: current_data.average_order_value,
        };

        const startDateCheck = moment(start_date);
        const endDateCheck = moment(end_date);
        const diff = endDateCheck.diff(startDateCheck); // Calculate the difference between dates in milliseconds
        const previousStartDate = startDateCheck.subtract(diff).toISOString();
        let prev_min_date = previousStartDate;
        let prev_max_date = moment(start_date).toISOString();
        let previous_data = await getRevenueData(prev_min_date, prev_max_date);

        previous_data = {
          revenue: previous_data.revenue,
          orders: previous_data.orders,
          average_order_value: previous_data.average_order_value,
        };
        // current_revenue and previous_revenue in percentage
        let previous_revenue_percentage = previous_data.revenue !== 0 ? (((previous_data.revenue - current_data.revenue) / previous_data.revenue) * 100).toFixed(2) : 0;

        // orders in percentage
        let previous_orders_percentage = previous_data.orders !== 0 ? (((previous_data.orders - current_data.orders) / previous_data.orders) * 100).toFixed(2) : 0;

        // average_order_value in percentage
        let previous_average_order_value_percentage = previous_data.average_order_value !== 0 ? (((previous_data.average_order_value - current_data.average_order_value) / previous_data.average_order_value) * 100).toFixed(2) : 0;

        return {
          current_data: current_data,
          previous_data: previous_data,
          previous_revenue_percentage: previous_revenue_percentage,
          previous_orders_percentage: previous_orders_percentage,
          previous_average_order_value_percentage: previous_average_order_value_percentage,
        };
      } catch (error) {
        console.error(error);
      }
    },
      /* ************ get orders data with custormer details ************ */
      getAllOrdersDataWithCustomerDetails: async ({ page = 1, limit = 10, store_id, user_id }, indexName = "order_items") => {
        page = page > 0 ? page - 1 : 0;
        try {
          // Elasticsearch query
          const query = {
            /*pagination*/
            // from: page * limit,
            // size: limit,
            size: 0,
            ...(store_id && user_id ? { query: { match: { user_id: user_id, store_id: store_id } } } : { query: { match: { store_id: store_id } } }),
            aggs: {
              user_orders: {
                terms: {
                  field: "user_id",
                },
                aggs: {
                  total_spent: {
                    sum: {
                      field: "total",
                    },
                  },
                  total_orders: {
                    sum: {
                      field: "quantity",
                    },
                  },
                },
              },
            },
          };

          // Execute the query
          const response = await client.search({
            index: indexName, // Replace with your actual index name
            body: query,
          });

          // Process the results
          const userOrders = response.aggregations.user_orders.buckets;
          // Log or use the results as needed
          let result = [];
          for (let i = 0; i < userOrders.length; i++) {
            const user = userOrders[i];
            // const customer = await client.search({
            //   index: "user",
            //   body: {
            //     query: {
            //       match: {
            //         id: user.key,
            //       },
            //     },
            //   },
            // });

            const customer = await database.User.findOne({
              where: {
                id: user.key,
              },
              raw: true,
            });

            /* shipping address */
            const shipping = await database.BillingAddresses.findOne({
              where: {
                user_id: user.key,
              },
              nest: true,
              raw: true,
            });

            let orderWithCustomerPayload = {
              customer: { ...customer, shipping_address: shipping },
              total_spent: user.total_spent.value,
              total_orders: user.total_orders.value,
            };
            result.push(orderWithCustomerPayload);
          }
          return { success: true, message: "Data successfully", data: result };
        } catch (error) {
          console.error("Error:", error);
        }
      },
        /* ************ get orders history  ************ */
        getAllOrdersHistory: async ({ page = 1, limit = 10, user_id, store_id, start_date, end_date, time_interval, time_zone }, indexName = "order_items") => {
          page = page > 0 ? page - 1 : 0;
          try {
            // Elasticsearch query
            const query = {
              /*pagination*/
              from: page * limit,
              size: limit,
              size: 1000,
              ...(store_id
                ? /* get data between dates */
                {
                  query: {
                    bool: {
                      must: [
                        {
                          match: {
                            store_id: store_id,
                          },
                        },
                        user_id && { match: { user_id: user_id } },
                        {
                          range: {
                            createdAt: {
                              gte: start_date,
                              lte: end_date,
                              time_zone: time_zone ? time_zone : "Asia/Kolkata",
                            },
                          },
                        },
                      ],
                    },
                  },
                }
                : { query: { match_all: [] } }),
            };

            // Execute the query
            let orders = await client.search({
              index: indexName, // Replace with your actual index name
              body: query,
            });
            orders = orders.hits.hits.map((hit) => hit._source);
            console.log(orders, "ordersordersord");
            // Log or use the results as needed
            let result = [];
            for (let i = 0; i < orders.length; i++) {
              const order = orders[i];
              let { id, order_id, product_id, store_id, quantity, order_status, generate_id, price, total, user_id, createdAt } = order;

              const customer = await database.User.findOne({
                where: {
                  id: user_id,
                },
                raw: true,
              });

              const product = await client.search({
                index: "products",
                body: {
                  query: {
                    match: {
                      id: product_id,
                    },
                  },
                },
              });
              /* shipping address */
              let orderWithCustomerPayload = {
                customer: { ...customer },
                product: { ...product.hits.hits[0]._source },
                id,
                order_id,
                product_id,
                store_id,
                quantity,
                order_status,
                generate_id,
                price,
                total,
                user_id,
                createdAt,
              };
              result.push(orderWithCustomerPayload);
            }
            return { success: true, message: "Data successfully", data: result };
          } catch (error) {
            console.error("Error:", error);
          }
        },
          /* ************ get orders details  ************ */
          getOrderDetails: async (args, indexName = "orders") => {
            try {
              // Elasticsearch query
              const query = {
                size: 1,
                query: {
                  bool: {
                    must: [
                      {
                        match: {
                          order_id: args.id,
                        },
                      },
                    ],
                  },
                },
              };

              // Execute the query
              let orders = await client.search({
                index: indexName, // Replace with your actual index name
                body: query,
              });
              if (orders.hits.hits.length === 0) return { success: false, message: "Data not found" };
              let order = orders.hits.hits[0]._source;
              console.log(orders, "ordersordersord");
              // Log or use the results as needed
              let result = [];
              let { id, order_id, product_id, store_id, quantity, order_status, generate_id, price, total, user_id, createdAt } = order;
              const customer = await client.search({
                index: "user",
                body: {
                  query: {
                    match: {
                      id: user_id,
                    },
                  },
                },
              });

              const product = await client.search({
                index: "products",
                body: {
                  query: {
                    match: {
                      id: product_id,
                    },
                  },
                },
              });
              /* shipping address */
              const shipping = await database.BillingAddresses.findOne({
                where: {
                  user_id: user_id,
                },
                nest: true,
                raw: true,
              });

              /* card details */
              const cardDetails = await database.CardAndBillingAddress.findOne({
                where: {
                  user_id: user_id,
                  isDefault: true,
                },
                nest: true,
                raw: true,
              });
              let orderWithCustomerPayload = {
                customer: { ...customer.hits.hits[0]._source },
                product: { ...product.hits.hits[0]._source },
                shipping_address: shipping,
                card_details: cardDetails,
                id,
                order_id,
                product_id,
                store_id,
                quantity,
                order_status,
                generate_id,
                price,
                total,
                user_id,
                createdAt,
              };
              result.push(orderWithCustomerPayload);
              return { success: true, message: "Data successfully", data: orderWithCustomerPayload };
            } catch (error) {
              console.error("Error:", error);
            }
          },
            getOrderCustomerActivity: async ({ store_id, start_date, end_date, time_interval, time_zone }, indexName = "orders") => {
              try {
                let current = (await storeCustomersMetrics({ store_id, start_date, end_date, time_interval, time_zone }, (indexName = "orders"))).data;
                /* previous */
                let previos_dates = await getPreviousDate(start_date, end_date);
                let previous = (await storeCustomersMetrics({ store_id, start_date: previos_dates.previous_start_date, end_date: previos_dates.previous_end_date, time_interval, time_zone }, (indexName = "orders"))).data;
                let new_customers_rate = previous.new_customers === 0 ? 0 : parseFloat(((current.new_customers / previous.new_customers) * 100).toFixed(2));
                let repeat_customers_rate = previous.repeat_customers === 0 ? 0 : parseFloat(((current.repeat_customers / previous.repeat_customers) * 100).toFixed(2));
                let response = {
                  current,
                  previous,
                  difference: {
                    new_customers_rate,
                    repeat_customers_rate,
                  },
                };
                return { success: true, message: "Data successfully", data: response };
              } catch (error) {
                console.log(error.stack);
                return { success: false, message: error.message, data: null };
              }
            },
              /* repeat customers */
              getRepeatCustomers: async ({ store_id, start_date, end_date, time_interval, time_zone }, indexName = "order_items") => {
                try {
                  let current = (await repeatCustomersHelper({ store_id, start_date, end_date, time_interval, time_zone }, (indexName = "order_items"))).data;
                  /* previous */
                  let previos_dates = await getPreviousDate(start_date, end_date);
                  let previous = (await repeatCustomersHelper({ store_id, start_date: previos_dates.previous_start_date, end_date: previos_dates.previous_end_date, time_interval, time_zone }, (indexName = "order_items"))).data;
                  let response = {
                    current,
                    previous,
                    difference: {
                      repeat_customers_percentage: current.repeat_customers_percentage - previous.repeat_customers_percentage,
                    },
                  };
                  return { success: true, message: "Data successfully", data: response };
                } catch (error) {
                  console.log(error.stack);
                  return { success: false, message: error.message, data: null };
                }
              },
                storeCustomersGender: async ({ store_id, start_date, end_date, time_interval, time_zone }, indexName = "store-activities") => {
                  try {
                    let current = await orderCustomersGenderHelper(store_id, start_date, end_date, time_interval, time_zone);
                    // previous date
                    let { previous_start_date, previous_end_date } = await getPreviousDate(start_date, end_date);
                    let previous = await orderCustomersGenderHelper(store_id, previous_start_date, previous_end_date, time_interval, time_zone);
                    /* previous percentage */
                    for (let i = 0; i < previous.length; i++) {
                      /* get two different array */
                      let current_count = current[i].count;
                      let previous_count = previous[i].count;
                      let diffrence = previous_count !== 0 ? (((current_count - previous_count) / previous_count) * 100).toFixed(2) : 0;
                      current[i].diffrence = parseFloat(diffrence);
                    }
                    let genderObject = Object.fromEntries(current.map((z) => [z.gender, { count: z.count, percentage: z.percentage, diffrence: z.diffrence }]));

                    return { success: true, message: "Device details fetched", data: genderObject };
                  } catch (error) {
                    console.error("Error:", error);
                    return { success: false, message: error.message };
                  }
                },
                  storeCustomersAgeRatio: async ({ store_id, start_date, end_date, time_interval, time_zone }, indexName = "store-activities") => {
                    try {
                      let current = await customerAgeRatioMetrics(store_id, start_date, end_date, time_interval, time_zone);
                      // previous date
                      let { previous_start_date, previous_end_date } = await getPreviousDate(start_date, end_date);
                      let previous = await customerAgeRatioMetrics(store_id, previous_start_date, previous_end_date, time_interval, time_zone);

                      /* previous percentage */
                      current = current.map((z, i) => {
                        let previous_count = previous[i] ? previous[i].age_count : 0;
                        z.difference_count = z.age_count - previous_count;
                        let diffrence_percentage = previous_count !== 0 ? parseFloat((((z.age_count - previous_count) / previous_count) * 100).toFixed(2)) : 0;
                        z.diffrence_percentage = diffrence_percentage;
                        return z;
                      });
                      return { success: true, message: "Device details fetched", data: current };
                    } catch (error) {
                      console.error("Error:", error);
                      return { success: false, message: error.message };
                    }
                  },
                    storeCustomersAgeBarChart: async ({ store_id, start_date, end_date, time_interval, time_zone }, indexName = "store-activities") => {
                      try {
                        let current = await customerAgeBarChartResponse(store_id, start_date, end_date, time_interval, time_zone);
                        return { success: true, message: "Device details fetched", data: current };
                      } catch (error) {
                        console.error("Error:", error);
                        return { success: false, message: error.message };
                      }
                    },
                      /* ************ get date wise customer chart  ************ */
                      getCustomerAnalyticsChart: async (indexName, { store_id, start_date, end_date, time_interval, time_zone }) => {
                        try {
                          const getRevenueData = async (min_date, max_date, time_interval, time_zone) => {
                            const searchParams = {
                              index: "orders",
                              // match with store_id
                              query: {
                                bool: {
                                  must: [
                                    {
                                      match: {
                                        store_id: store_id,
                                      },
                                    },
                                    {
                                      range: {
                                        orderDate: {
                                          gte: min_date,
                                          lte: max_date,
                                        },
                                      },
                                    },
                                  ],
                                },
                              },
                              size: 0,
                              body: {
                                aggs: {
                                  date_counts: {
                                    date_histogram: {
                                      field: "createdAt",
                                      calendar_interval: time_interval ? time_interval : "day",
                                      time_zone: time_zone ? time_zone : "Asia/Kolkata",
                                      extended_bounds: {
                                        min: min_date,
                                        max: max_date,
                                      },
                                    },
                                    aggs: {
                                      customers: {
                                        value_count: {
                                          field: "user_id",
                                        },
                                      },
                                    },
                                  },
                                  total_customers: {
                                    value_count: {
                                      field: "user_id",
                                    },
                                  },
                                },
                              },
                            };
                            const response = await client.search(searchParams);
                            const dateCounts = response.aggregations.date_counts.buckets;
                            // console.log("response.aggregations", dateCounts)
                            const formattedData = dateCounts.map((bucket) => [
                              bucket.key, // Date in the desired format
                              bucket.customers.value || 0, // Revenue sum (if available) or 0 as default
                            ]);
                            // return formattedData
                            return {
                              data: formattedData,
                              total_customers: response?.aggregations?.total_customers?.value || 0,
                            };
                          };
                          let current = await getRevenueData(start_date, end_date, time_interval, time_zone);
                          let current_data = current.data;
                          let total_customers = current.total_customers;
                          let { previous_start_date, previous_end_date } = await getPreviousDate(start_date, end_date);

                          let previous = await getRevenueData(previous_start_date, previous_end_date);
                          let previous_customers = previous.total_customers;
                          // current_revenue and previous_revenue in percentage
                          let previous_customers_percentage = previous_customers !== 0 ? (((previous_customers - total_customers) / previous_customers) * 100).toFixed(2) : 0;

                          return {
                            total_customers,
                            previous_customers_percentage,
                            current_data,
                          };
                        } catch (error) {
                          console.error(error);
                        }
                      },
                        customersLocation: async ({ store_id, filter }, indexName = "store-activities") => {
                          try {
                            let current = await customersLocationHelper(store_id, filter);
                            let genderObject = Object.fromEntries(current.map((z) => [filter ? z[filter] : z.country, { count: z.count, percentage: z.percentage }]));
                            return { success: true, message: "Device details fetched", data: genderObject };
                          } catch (error) {
                            console.error("Error:", error);
                            return { success: false, message: error.message };
                          }
                        },
                          customersLocationBySales: async ({ store_id, filter }) => {
                            try {
                              let current = await customersLocationBySalesHelper(store_id, filter);
                              let genderObject = Object.fromEntries(current.map((z) => [filter ? z[filter] : z.country, { count: z.count, percentage: z.percentage, revenue: z.total_revenue, revenue_percentage: z.revenue_percentage }]));
                              return { success: true, message: "Device details fetched", data: genderObject };
                            } catch (error) {
                              console.error("Error:", error);
                              return { success: false, message: error.message };
                            }
                          },
                            customersCategoryBySales: async ({ store_id, filter }) => {
                              try {
                                let current = await customersCategoryBySalesHelper(store_id, filter);
                                let genderObject = Object.fromEntries(current.map((z) => [filter ? z[filter] : z.country, { count: z.count, percentage: z.percentage, revenue: z.total_revenue }]));
                                return { success: true, message: "Device details fetched", data: genderObject };
                              } catch (error) {
                                console.error("Error:", error);
                                return { success: false, message: error.message };
                              }
                            },

                              /*  ================================
                                  ================================
                                  ======== ORDERS MASTER SECTION ========= */

                              /* ************ Create index for orders master ************ */
                              createIndexForOrderMaster: async (indexName) => {
                                try {
                                  let order_index = await client.indices.create({
                                    index: indexName,
                                    body: {
                                      mappings: {
                                        properties: {
                                          id: { type: "integer" },
                                          order_id: { type: "keyword" },
                                          userId: { type: "integer" },
                                          // shippingId: { type: "integer" },
                                          cardId: { type: "integer" },
                                          paymentId: { type: "keyword" },
                                          orderDate: { type: "date" },
                                          totalAmount: { type: "float" },
                                          totalTaxAmount: { type: "float" },
                                          totalBasicAmount: { type: "float" },
                                          pendingAmount: { type: "float" },
                                          orderStatus: { type: "keyword" },
                                          isActive: { type: "boolean" },
                                          isPaymentDone: { type: "boolean" },
                                          createdAt: { type: "date" },
                                        },
                                      },
                                    },
                                  });
                                  return order_index;
                                } catch (error) {
                                  return error;
                                }
                              },
                                /* ************ Add Single data for order master  ************ */
                                addSingleDataForOrderMaster: async (indexName, data) => {
                                  try {
                                    const indexExists = await client.indices.exists({
                                      index: indexName,
                                    });
                                    if (!indexExists) {
                                      console.log("------ create index ------");
                                      let check = await module.exports.createIndexForOrders(indexName);
                                    }
                                    const orderExists = await client.search({
                                      index: indexName,
                                      body: {
                                        query: {
                                          match: {
                                            id: data.id,
                                          },
                                        },
                                      },
                                    });
                                    if (orderExists.hits.hits.length > 0) {
                                      return { success: false, message: "Order already exists" };
                                    }
                                    const orderData = await client.index({
                                      index: indexName,
                                      body: data,
                                    });
                                    return { success: true, message: "Order added successfully", data: orderData };
                                  } catch (error) {
                                    return { success: false, message: error.message };
                                  }
                                },
                                  /* ************ update order by id ************ */
                                  updateOrderMasterById: async (indexName, id, data) => {
                                    try {
                                      const isExists = await client.search({
                                        index: indexName,
                                        body: {
                                          query: {
                                            match: {
                                              id: id,
                                            },
                                          },
                                        },
                                      });
                                      // console.log(isExists.hits.hits, "isExists");
                                      if (isExists.hits.hits.length === 0) {
                                        return { success: false, message: "Order does not exists" };
                                      }
                                      if (isExists.hits.hits.length > 0) {
                                        let orders = isExists.hits.hits;
                                        for (let i = 0; i < orders.length; i++) {
                                          const order = orders[i];
                                          // if exists
                                          const orderExists = await client.exists({
                                            index: indexName,
                                            id: order._id,
                                          });
                                          // console.log(orderExists, "orderExists");
                                          if (!orderExists) {
                                            console.log("Order does not exists");
                                            return { success: false, message: "Order does not exists" };
                                          }

                                          const orderData = await client.get({
                                            index: indexName,
                                            id: order._id,
                                          });

                                          const _source = orderData._source;

                                          const updatedDocument = {
                                            ..._source,
                                            ...data,
                                          };
                                          // const updatedDocument = data
                                          const updateResponse = await client.update({
                                            index: indexName,
                                            id: order._id,
                                            body: {
                                              doc: updatedDocument,
                                            },
                                          });
                                        }
                                      }

                                      return { success: true, message: "Order updated successfully" };
                                    } catch (error) {
                                      console.log(error, "error");
                                      return error;
                                    }
                                  },

                                    /*  ================================
                                      ================================
                                      ======== ORDERS ITEMS SECTION ========= */

                                    /* ************ Create index for orders items ************ */
                                    createIndexForOrderItems: async (indexName) => {
                                      try {
                                        let order_index = await client.indices.create({
                                          index: indexName,
                                          body: {
                                            mappings: {
                                              properties: {
                                                id: { type: "integer" },
                                                orderId: { type: "integer" },
                                                productId: { type: "integer" },
                                                sellerId: { type: "integer" },
                                                storeId: { type: "integer" },
                                                productId: { type: "integer" },
                                                quantity: { type: "integer" },
                                                product_price: { type: "float" },
                                                basicAmount: { type: "float" },
                                                taxAmount: { type: "float" },
                                                discountAmount: { type: "float" },
                                                totalAmount: { type: "float" },
                                                pendingAmount: { type: "float" },
                                                globalCharges: { type: "float" },
                                                sellerCharges: { type: "float" },
                                                sellerFinalAmount: { type: "float" },
                                                createdAt: { type: "date" },
                                              },
                                            },
                                          },
                                        });
                                        return order_index;
                                      } catch (error) {
                                        return error;
                                      }
                                    },
                                      /* ************ Add Single data for order items  ************ */
                                      addSingleDataForOrderItems: async (indexName, data) => {
                                        try {
                                          const indexExists = await client.indices.exists({
                                            index: indexName,
                                          });
                                          if (!indexExists) {
                                            console.log("------ create index ------");
                                            let check = await module.exports.createIndexForOrders(indexName);
                                          }
                                          const orderExists = await client.search({
                                            index: indexName,
                                            body: {
                                              query: {
                                                match: {
                                                  id: data.id,
                                                },
                                              },
                                            },
                                          });
                                          if (orderExists.hits.hits.length > 0) {
                                            return { success: false, message: "Order already exists" };
                                          }
                                          const orderData = await client.index({
                                            index: indexName,
                                            body: data,
                                          });
                                          return { success: true, message: "Order added successfully", data: orderData };
                                        } catch (error) {
                                          return { success: false, message: error.message };
                                        }
                                      },

                                        /* ************ update order by id ************ */
                                        updateOrderItemsById: async (indexName, id, data) => {
                                          try {
                                            const isExists = await client.search({
                                              index: indexName,
                                              body: {
                                                query: {
                                                  match: {
                                                    id: id,
                                                  },
                                                },
                                              },
                                            });
                                            // console.log(isExists.hits.hits, "isExists");
                                            if (isExists.hits.hits.length === 0) {
                                              return { success: false, message: "Order does not exists" };
                                            }
                                            if (isExists.hits.hits.length > 0) {
                                              let orders = isExists.hits.hits;
                                              for (let i = 0; i < orders.length; i++) {
                                                const order = orders[i];
                                                // if exists
                                                const orderExists = await client.exists({
                                                  index: indexName,
                                                  id: order._id,
                                                });
                                                // console.log(orderExists, "orderExists");
                                                if (!orderExists) {
                                                  console.log("Order does not exists");
                                                  return { success: false, message: "Order does not exists" };
                                                }

                                                const orderData = await client.get({
                                                  index: indexName,
                                                  id: order._id,
                                                });

                                                const _source = orderData._source;

                                                const updatedDocument = {
                                                  ..._source,
                                                  ...data,
                                                };
                                                // const updatedDocument = data
                                                const updateResponse = await client.update({
                                                  index: indexName,
                                                  id: order._id,
                                                  body: {
                                                    doc: updatedDocument,
                                                  },
                                                });
                                              }
                                            }

                                            return { success: true, message: "Order updated successfully" };
                                          } catch (error) {
                                            console.log(error, "error");
                                            return error;
                                          }
                                        },
};
