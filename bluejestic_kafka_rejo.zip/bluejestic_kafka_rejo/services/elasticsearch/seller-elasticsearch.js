const { Client } = require('@elastic/elasticsearch');

// Create Elasticsearch client
const client = new Client({ node: 'http://localhost:9200' });
// const client = new Client({ node: 'https://ad975058c72fc474fa4e0122ea10bca8-376840634.us-east-1.elb.amazonaws.com:9200' });
// const client = new Client({
//     node: 'ad975058c72fc474fa4e0122ea10bca8-376840634.us-east-1.elb.amazonaws.com',
//     auth: {
//         username: 'elastic',
//         password: 'jy1Wr7kk84sqV5YH'
//     }
// })


module.exports = {
    /* ************ Create index for orders ************ */
    createIndexForOrders: async (indexName) => {
        try {
            let order_index = await client.indices.create({
                index: indexName,
                body: {
                    mappings: {
                        properties: {
                            orderId: { type: 'keyword' },
                            orderDate: { type: 'date' },
                            customerId: { type: 'keyword' },
                            products: {
                                type: 'nested',
                                properties: {
                                    productId: { type: 'keyword' },
                                    productName: { type: 'text' },
                                    price: { type: 'float' },
                                    quantity: { type: 'integer' },
                                },
                            },
                            status: {
                                type: 'object',
                                properties: {
                                    code: { type: 'keyword' },
                                    name: { type: 'keyword' },
                                },
                            },
                        },
                    },
                },
            })
            return order_index

        } catch (error) {
            return error
        }
    },
    /* ************ Put mapping for orders ************ */
    putMappingForOrders: async (indexName) => {
        let order_mapping = await client.indices.putMapping({
            index: indexName,
            body: {
                properties: {
                    orderId: { type: 'keyword' },
                    orderDate: { type: 'date' },
                    customerId: { type: 'keyword' },
                    products: {
                        type: 'nested',
                        properties: {
                            productId: { type: 'keyword' },
                            productName: { type: 'text' },
                            price: { type: 'float' },
                            quantity: { type: 'integer' },
                        },
                    },
                    status: {
                        type: 'object',
                        properties: {
                            code: { type: 'keyword' },
                            name: { type: 'keyword' },
                        },
                    },
                },
            },
        });
        return order_mapping
    },

    /* ************ Add Bulk data for orders ************ */
    addBulkDataForOrders: async (index, data) => {

        let orderDatas = require("./orders.json");

        let body = [];
        for (const order of orderDatas) {
            body.push({ index: { _index: index } });
            body.push(order);
        }
        console.log(JSON.parse(JSON.stringify(body)), "body");
        const bulkData = body

        // // Perform bulk indexing
        const performBulkIndexing = async () => {
            const data = await client.bulk({ refresh: true, body: bulkData });
            if (data.errors) {
                console.log('Error indexing data:', data.errors);
            } else {
                console.log('Data indexed successfully.');
            }
        };

        performBulkIndexing()
            .then(() => {
                console.log('Bulk indexing completed successfully.');
            })
            .catch((error) => {
                console.error('An error occurred during bulk indexing:', error);
            });

    },

    /* ************ Add Single data for order ************ */
    addSingleDataForOrder: async (indexName, data) => {

        const orderExists = await client.search({
            index: indexName,
            body: {
                query: {
                    match: {
                        orderId: data.orderId,
                    },
                },
            },
        });
        console.log(orderExists, "orderExists");
        if (orderExists.hits.hits.length > 0) {
            return { success: false, message: "Order already exists" };
        }
        const orderData = await client.index({
            index: indexName,
            body: data,
        });
        console.log(orderData, "orderData");
        return { success: true, message: "Order added successfully", data: orderData };
    },

    /* ************ Add data for orders ************ */
    getAllOrdersData: async (indexName) => {
        const data = await client.search({
            index: indexName,
        });
        const ordersData = data.hits.hits.map((hit) => { return { ...hit._source, _id: hit._id } });
        return ordersData;
    },
    /* ************ get Orders metrics ************ */
    getOrdersMetrics: async (indexName) => {

        let metrics = await client.search({
            index: indexName,
            body: {
                size: 0,
                aggs: {
                    // filter with values 
                    processing_orders: {
                        filter: { term: { "status.code": "processing" } },
                    },
                    shipped_orders: {
                        filter: { term: { "status.code": "shipped" } },
                    },

                    dispatched_orders: {
                        filter: { term: { "status.code": "dispatched" } },
                    },
                    // filter with fields
                    total_orders: {
                        value_count: {
                            field: "orderId"
                        }
                    }
                },
            },
        });
        console.log(metrics.aggregations, "metrics");
        return metrics

    },

    /* ************ get Orders metrics with percentage ************ */
    getOrdersMetricsWithPercentage: async (indexName) => {

        const getOrderStatusCountsPercentage = async (indexName) => {
            let metricsWithPercentage = await client.search({
                index: indexName,
                body: {
                    size: 0,
                    aggs: {
                        order_statuses: {
                            terms: {
                                field: 'status.code',
                            },
                            aggs: {
                                status_count: {
                                    value_count: {
                                        field: 'orderId',
                                    },
                                },
                                status_percentage: {
                                    bucket_script: {
                                        buckets_path: {
                                            count: 'status_count',
                                        },
                                        script: 'params.count / params.total * 100',
                                        gap_policy: 'skip',
                                    },
                                },
                            },
                        },
                    },
                },
            });
            console.log(metricsWithPercentage.aggregations, "metricsWithPercentage");
            return metricsWithPercentage
        }
    },

    /* ************ delete order by id ************ */
    deleteOrder: async (indexName, orderId) => {
        try {

            // if exists 
            const orderExists = await client.exists({
                index: indexName,
                id: orderId,
            });
            // console.log(orderExists, "orderExists");
            if (!orderExists) {
                console.log('Order does not exists');
                return { success: false, message: "Order does not exists" };
            }

            const orderData = await client.delete({
                index: indexName,
                id: orderId,
            });
            console.log(orderData.result, "orderData");
            return orderData
        } catch (error) {
            console.log(error, "error");
            return error
        }
    },
    /* ************ get order by id ************ */
    getOrderById: async (indexName, orderId) => {
        // if exists
        const orderExists = await client.exists({
            index: indexName,
            id: orderId,
        });

        if (!orderExists) {
            return { success: false, message: "Order does not exists" };
        }

        let orderData = await client.get({
            index: indexName,
            id: orderId,
        });
        orderData = { ...orderData._source, id: orderData._id }
        return orderData
    },

    /* ************ update order by id ************ */
    updateOrderById: async (indexName, id, data) => {
        try {
            // if exists 
            const orderExists = await client.exists({
                index: indexName,
                id: id,
            });
            // console.log(orderExists, "orderExists");
            if (!orderExists) {
                console.log('Order does not exists');
                return { success: false, message: "Order does not exists" }
            }

            const orderData = await client.get({
                index: indexName,
                id: id,
            });
            const _source = orderData._source;

            const updatedDocument = {
                ..._source,
                ...data,
            };
            // const updatedDocument = data
            const updateResponse = await client.update({
                index: indexName,
                id: id,
                body: {
                    doc: updatedDocument,
                },
            });
            return updateResponse
        } catch (error) {
            console.log(error, "error");
            return error
        }
    },
}