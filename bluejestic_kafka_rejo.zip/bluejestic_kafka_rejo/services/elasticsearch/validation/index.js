let validate = require("./validate");

function validateIndexDocument(index, document) {
    if (!index) throw new Error("Index name is required");
    if (!document) throw new Error("Document is required");
    // console.log("validateIndexDocument", index);

    let validation = validate[index]()
    const { error } = validation.validate(document);
    if (error) {
        return error.details[0].message;
    }
}

module.exports = validateIndexDocument;