const Joi = require('joi');
module.exports = {
    createProductIndexSchema: () => {
        const validate = Joi.object({
            product_id: Joi.number().required(),
            title: Joi.string().required(),
            description: Joi.string().optional().allow(''),
            store_id: Joi.number().required(),
            price: Joi.number().required(),
            isFeature: Joi.boolean(),
            isActive: Joi.boolean(),
            quantity: Joi.number().required(),
            listPrice: Joi.number(),
            sku: Joi.string(),
            metaTitle: Joi.string(),
            metaDescription: Joi.string(),
            keywords: Joi.string(),
            isVisible: Joi.boolean(),
            isFreeShipping: Joi.boolean(),
            condition: Joi.string(),
            tags: Joi.array().items(Joi.string()),
            image: Joi.array().items(Joi.string()),
            video: Joi.array().items(Joi.string()),
            is_deleted: Joi.boolean(),
            cropImages: Joi.array().items(Joi.object({
                id: Joi.string().required(),
                oldFile: Joi.string().required(),
                croppedFile: Joi.object({
                    baseURL: Joi.string().required(),
                    zoom: Joi.number(),
                    rotate: Joi.number(),
                    crop: Joi.object({
                        x: Joi.number().required(),
                        y: Joi.number().required(),
                    }),
                })
            })),
            ratio: Joi.string(),
            size: Joi.object({
                height: Joi.number().required(),
                width: Joi.number().required(),
            }),
            isDeleted: Joi.boolean(),
            // Add more fields and their validation rules as per your requirements
        }).options({ allowUnknown: true });
        return validate;
    },
    createStoreFollowersIndexSchema: () => {
        const validate = Joi.object({
            user_id: Joi.number().required(),
            store_id: Joi.number().required(),
            userType: Joi.string(),
            id: Joi.number().required(),
            isDeleted: Joi.boolean(),
            // Add more fields and their validation rules as per your requirements
        }).options({ allowUnknown: true });
        return validate;
    },
    createStoreLikesIndexSchema: () => {
        const validate = Joi.object({
            user_id: Joi.number().required(),
            like_for: Joi.string().required(),
            id: Joi.number().required(),
            // Add more fields and their validation rules as per your requirements
        }).options({ allowUnknown: true });
        return validate;
    },
    createStoreCommentsIndexSchema: () => {
        const validate = Joi.object({
            id: Joi.number().required(),
            user_id: Joi.number().required(),
            store_id: Joi.number().required(),
            post_id: Joi.number().required(),
            comment_for: Joi.string().required(),
            comment: Joi.string().required(),
            image: Joi.array().items(Joi.string()),
            isReply: Joi.boolean(),
            reply_id: Joi.number(),
            userType: Joi.string(),
            isDeleted: Joi.boolean(),
            // Add more fields and their validation rules as per your requirements
        }).options({ allowUnknown: true });
        return validate;
    },
    createStoreActivitiesIndexSchema: () => {
        const validate = Joi.object({
            id: Joi.number().required(),
            user_id: Joi.number().required(),
            store_id: Joi.number().required(),
            userType: Joi.string(),
            startDate: Joi.date().required(),
            endDate: Joi.date().required(),
            isDeleted: Joi.boolean(),
            // Add more fields and their validation rules as per your requirements
        }).options({ allowUnknown: true });
        return validate;
    },
    createProductViewsIndexSchema: () => {
        const validate = Joi.object({
            id: Joi.number().required(),
            user_id: Joi.number().required(),
            store_id: Joi.number().required(),
            product_id: Joi.number().required(),
            userType: Joi.string(),
            startDate: Joi.date().required(),
            endDate: Joi.date().required(),
            isDeleted: Joi.boolean(),
            // Add more fields and their validation rules as per your requirements
        }).options({ allowUnknown: true });
        return validate;
    },
    createUserFriendsIndexSchema: () => {
        const validate = Joi.object({
            id: Joi.number().required(),
            user_id: Joi.number().required(),
            friend_id: Joi.number().required(),
            request_id: Joi.number(),
            isActive: Joi.boolean(),
            isFriend: Joi.boolean(),
            isDeleted: Joi.boolean(),
            // Add more fields and their validation rules as per your requirements
        }).options({ allowUnknown: true });
        return validate;
    }
}
