require("dotenv").config();
global.kafkaConfig = undefined;
require("./kafka-config");
// const { server } = require("./api/server");
const server = require("./api/server");
const Sentry = require("@sentry/node");
const moment = require("moment");
const http = require("https");
const database = require("./database/models/index");
const express = require("express");
const { connect } = require("http2");
const client = require("./redis/redisClient");
const app = express();
const httpServer = http.createServer(app);
// const io = require("socket.io")(httpServer);
const port = process.env.PORT || 3301;
const cron = require("node-cron");
const { Op } = require("sequelize");

//* Kafka - start
/* produce message to client */
// setTimeout(() => {
// for (let i = 0; i < 25; i++) {

// global.kafkaConfig.produce("revenue", [{ value: `hello Kafka user${i}` }]);
// }
// }, 1000);
// global.kafkaConfig.produce("my-topic", [{ key: "some-key", value: "hello world" }]);
/* receive message from client */
// global.kafkaConfig.consume("my-topic", (message) => {
//   /*console log message  with emojis*/
//   console.log("message +++++++++++++", message);
//   console.log("message", message);
// });
//* Kafka - end

// process.on("uncaughtException", (err) => {
//   console.error(`${new Date().toUTCString()} uncaughtException:`, err);
//   process.exit(0);
// });

// process.on("SIGINT", (err) => {
//   console.error(`${new Date().toUTCString()} SIGINT:`, err);
//   process.exit(0);
// });

// process.on("SIGTERM", (err) => {
//   console.error(`${new Date().toUTCString()} SIGTERM:`, err);
//   process.exit(0);
// });

// process.on("ELIFECYCLE", (err) => {
//   console.error(`${new Date().toUTCString()} ELIFECYCLE:`, err);
//   process.exit(0);
// });

// process.on("unhandledRejection", (err) => {
//   console.error(`${new Date().toUTCString()} unhandledRejection:`, err);
// });

// io.on("connection", (socket) => {
//   console.log("=============Connected==================");
//   // your code
// });

// cron.schedule("* 1 * * *", async () => {
//   await cartAbandonment();
// });

//=== cron jobs start ====

const cartAbandonment = async () => {
  try {
    console.log("Starting cart abandonment task at every 1:00 Am at midnight");
    const thresoldDate = moment().subtract(24, "hours").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]"); 
    
    await database.Cart.update(
      {
        status: "cart_abandoned",
      },
      {
        where: {
          status: {
            [Op.in]: ["cart_created", "cart_updated", "checkout_initiated"]
          },
          [Op.or]: [
            {
              createdAt: {
                [Op.lte]: thresoldDate
              }
            },
            {
              updatedAt: {
                [Op.lte]: thresoldDate
              }
            }
          ]
        },
      }
    );
    console.log("Ending cart abandonment task at every 1:00 Am at midnight");
    
  } catch (error) {
    console.error("An error occured while performing a task at every 1:00 Am at midnight", error);
  }
}


cron.schedule("* 1 * * *", cartAbandonment);

//=== cron jobs end ====

Sentry.init({
  // dsn: "https://b2cb85860b5e9c8550759d0da9db1651@sentry.internal.bluejestic.com/3",
  dsn: process.env.SENTRY_DSN,

  // Performance Monitoring
  tracesSampleRate: 1.0, // Capture 100% of the transactions, reduce in production!
});

const transaction = Sentry.startTransaction({
  op: "test",
  name: "My First Test Transaction",
});

setTimeout(() => {
  try {
    foo();
  } catch (e) {
    Sentry.captureException(e);
  } finally {
    transaction.finish();
  }
}, 99);

// async function init() {
//   const fieldsAdded = await client.hset("bike:1", {
//     model: "Deimos",
//     brand: "Ergonom",
//     type: "Enduro bikes",
//     price: 4972,
//   });
//   console.log(`Number of fields were added: ${fieldsAdded}`);
// }

// init();

function foo() {
  console.log("[Sentry] Successfully connected to Sentry server.");
}


server.listen({ port }, () => {
  console.log(`[Server] Server is running at http://localhost:${port}`);
});



