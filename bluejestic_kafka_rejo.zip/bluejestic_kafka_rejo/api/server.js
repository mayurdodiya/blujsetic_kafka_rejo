//* server setup
const express = require("express");
const { createServer } = require("http");
const { ApolloServer } = require("apollo-server-express");
const cors = require("cors");
const bodyParser = require("body-parser");
// const getRawBody = require("raw-body");
const database = require("../database/models");

//* graphql configuration

const typeDefs = require("../graphql/schemas");
const resolvers = require("../graphql/resolvers");
const context = require("../graphql/context");

//* rest functions
const auth = require("../middlewares/auth");
const controller = require("../controller/controller");

//* database init.
  let db = require("../database/models/index");
const fastify = require("fastify")({
  logger: false,
});
const session = require("express-session");
const { uploadHandler } = require("../middlewares/gcp-upload-services");
const ShopifyProductService = require("../database/services/shopifyProduct");
const secretKey = "55422178d5cdd7d1f910a58ee1e676f1";
try {
  //* To sync schema with latest definitions. --xx-- Uncomment line below to apply changes in schema.  */
    // db.sequelize.sync({ alter: true }).then(() => {
    //   console.log("Success+++++++++++++++++++++++++++", 111111111);
    // });
} catch (error) {
  console.log(error);
}
fastify.addContentTypeParser("multipart", (request, payload, done) => {
  request.isMultipart = true;
  done();
});

fastify.addHook("preValidation", async function (request, reply) {
  if (!request.isMultipart) {
    return;
  }

  request.body = await processRequest(request.raw, reply.raw);
});

// function logMemoryUsageInMB() {
//   const memoryUsage = process.memoryUsage();
//   const memoryInMB = {
//     rss: (memoryUsage.rss / (1024 * 1024)).toFixed(2), // Resident Set Size
//     heapTotal: (memoryUsage.heapTotal / (1024 * 1024)).toFixed(2), // Total heap size
//     heapUsed: (memoryUsage.heapUsed / (1024 * 1024)).toFixed(2), // Used heap size
//     external: (memoryUsage.external / (1024 * 1024)).toFixed(2), // External memory
//     arrayBuffers: (memoryUsage.arrayBuffers / (1024 * 1024)).toFixed(2), // ArrayBuffer memory
//   };

//   console.log("Memory usage in MB:", memoryInMB);
// }

// Place this function call at the specific points in your code where you want to measure memory usage.
// setInterval(() => {
//   logMemoryUsageInMB();
// }, 1000); // Log memory usage every second
//* Server Initialization

const app = express();

//* Server Middleware

//* webhook for stripe
app.use("/webhook", require("../services/stripe/routes/webhook"));

app.use(cors());
app.use(express.json({ limit: "500mb" }));
app.use(express.urlencoded({ extended: false, limit: "500mb" }));
app.use(bodyParser.json({ limit: "500mb" }));
app.use(bodyParser.urlencoded({ limit: "500mb", extended: true, parameterLimit: 50000 }));
app.use(
  session({
    secret: "######-*****!@#$%^&*()_+******-######",
    resave: false,
    saveUninitialized: true,
  })
);

//* Server methods

// Rest API for image upload
app.post("/upload", auth, uploadHandler.array("image"), controller.imageUpload);
app.post("/upload/seller-document", uploadHandler.array("image"), controller.imageUpload);


/* REST API For stipe payment */
// app.use("/stripe", require("../services/stripe/routes/index"));

//* SHOPIFY_CREATE_PRODUCT_WEBHOOK

app.use("/webhook", require("../services/shopify/routes/index"));

// app.post("/webhook/getproduct", async (req, res) => {
//   // console.log("🎉 We got an order!", req, res);

//   // We'll compare the hmac to our own hash

//   try {
//     // const hmac = req.get("X-Shopify-Hmac-Sha256");

//     // Use raw-body to get the body (buffer)
//     // const body = await getRawBody(req);

//     let input = req.body;

//     console.log("body+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", JSON.stringify(req.body));

//     let productInput = {
//       title: input?.title,
//       description: input?.body_html,
//       isFeature: false,
//       isActive: input?.status === "draft" ? false : true,
//       // image: input?.image,
//       // video: input?.video,
//       isVisible: input?.status === "draft" ? false : true,
//       isFreeShipping: false,
//       condition: "New",
//       // cropImages: input.cropImages,
//       // ratio: input?.ratio,
//     };
//     // console.log("input>>>>>>>>>>>>>>>>>", productInput);
//     let product = await ShopifyProductService.add(productInput);
//     product = JSON.parse(JSON.stringify(product));

//     for (const attr of input?.variants) {
//       const totalVariant = [];
//       let i = 1;
//       let updatedObject = {
//         title: attr?.title,
//         inventory_quantity: attr?.inventory_quantity,
//         old_inventory_quantity: attr?.old_inventory_quantity,
//         image_id: attr?.image_id,
//         isTaxable: attr?.taxable,
//         grams: attr?.grams,
//         price: attr?.price,
//         sku: attr?.sku,
//         barcode: attr?.barcode,
//         weightValue: attr?.weight,
//         weightUnit: attr?.weight_unit,
//         length: 10,
//         width: 10,
//         height: 10,
//         product_id: product.id,
//         isRequiresShipping: attr?.requires_shipping,
//         fulfillment_service: attr?.fulfillment_service,
//         inventory_management: attr?.fulfillment_service,
//       };

//       let product_item_id = await database.ProductItem.create(updatedObject);

//       while (attr[`option${i}`] !== null) {
//         totalVariant.push(attr[`option${i}`]);
//         i++;
//       }

//       console.log("totalVarian++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++t", totalVariant);

//       for (const variant of totalVariant) {
//         let find_variant_option = await database.VariationOption.findOne({
//           where: {
//             value: variant,
//           },
//         });
//         if (find_variant_option) {
//           await database.ProductConfiguration.create({
//             product_item_id: product_item_id.id,
//             variant_option_id: find_variant_option.id,
//             product_id: product.id,
//           });
//         }
//       }
//     }

//     if (Boolean(input?.images?.length)) {
//       for (const img_id of input?.images) {
//         let saved_image_response = await database.Media.create({ parent_id: img_id.id, media_for: "PRODUCT", media: img_id?.src });
//         let find_image = await database.Media.findOne({
//           where: {
//             id: saved_image_response?.id,
//           },
//         });
//         if (find_image) {
//           await database.ProductMedia.create({ product_id: product.id, media_id: img_id, src: find_image.media });
//         }
//       }
//     }

//     if (Boolean(input?.tags.split(","))) {
//       for (const tag of input?.tags.split(",")) {
//         await database.ProductTag.create({ tag: tag, product_id: product.id });
//       }
//     }

//     // Create a hash using the body and our key
//     // const hash = crypto.createHmac("sha256", secretKey).update(body, "utf8", "hex").digest("base64");
//     // console.log("body++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", hash);

//     // if (hash === hmac) {
//     //   // It's a match! All good
//     //   console.log("Phew, it came from Shopify!");
//     //   res.sendStatus(200);
//     // } else {
//     //   // No match! This request didn't originate from Shopify
//     //   console.log("Danger! Not from Shopify!");
//     //   res.sendStatus(403);
//     // }
//   } catch (error) {
//     console.log("error9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+9+", error);
//   }

//   // Compare our hash to Shopify's hash
// });

// app.listen(3000, () => console.log("Example app listening on port 3000!"));

//* App start from here  , (GRAPHQL)

const apolloServer = new ApolloServer({
  typeDefs, //* schema
  resolvers, //* oprational functions
  context, //* Authentication
  introspection: true,
  // debug: false,
  // uploads: false,
  playground: {
    settings: {
      "schema.polling.enable": false,
      "editor.fontSize": 18,
    },
  },
});

const server = createServer(app);

apolloServer.start().then((res) => {
  // console.log("RRRRRRRRRR", res);
  apolloServer.applyMiddleware({ app, path: "/graphql" });
  app.listen({ port: 4000 }, () => {
    console.log(`[Apollo Server] Gateway API running at port: 3301/${apolloServer.graphqlPath}`);
  });
});

//* kafka connection check
// (async function () {
//   try {
//     async function checkConnection() {
//       let client = {};
//       // if (process.env.ELASTIC_URI) {
//       const Client = require("@elastic/elasticsearch").Client;
//       client = new Client({
//         node: "http://a3fefc125d61041c884a2b43299220ce-1434812987.us-east-1.elb.amazonaws.com/",
//         maxRetries: 5,
//         requestTimeout: 60000,
//         auth: {
//           username: "elastic",
//           password: "Kp952TJ13B69OTalT8miR46v",
//         },
//       });
//       console.log("Connectoiomn .....");
//       client.ping({ requestTimeout: 30000 }, function (error) {
//         if (error) {
//           console.error("Elasticsearch cluster is down!");
//         } else {
//           console.log("Elasticsearch cluster is up!");
//         }
//       });
//       client.cluster.health({}, function (err, resp, status) {
//         console.log("-- Client Health --", resp);
//       });

//       // }
//     }
//     await checkConnection();

//     console.log('HELLLLLLLLLLLLLLLLLLLLLLLLLLLLL +++++++++++++++++++++++++++++++');
//   } catch (err) {
//     console.log("Error in connection", err);
//   }
// })();

module.exports = server;
