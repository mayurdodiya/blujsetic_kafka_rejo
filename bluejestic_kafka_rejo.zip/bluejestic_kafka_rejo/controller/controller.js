const { Media } = require("../database/models");

module.exports = {
  imageUpload: async (req, res) => {
    try {
      const { media_for, parent_id } = req.body;
      console.log(req.file);
      //* validation 
      if (!media_for) {
        return res.status(400).json({
          success: false,
          message: "all Fields are required",
        });
      }

      const medias = [
        "post",
        "profiles",
        "comment",
        "product",
        "store",
        "user",
        "groups",
        "banner",
        "category",
        "livestream"
      ];
      const isValidMedia = medias.includes(media_for);

      if (!isValidMedia) {
        return res.status(400).json({
          success: false,
          message: "Media_for is not valid",
        });
      }

      const { files } = req;
      if (files.length > 0) {
        let response = [];
        for (const file of files) {
          //* database opration - create 
          const media = await Media.create({
            parent_id: parent_id,
            media: file.path,
            media_type: file.mimetype,
            media_for: media_for.toUpperCase(),
          });

          response.push(media);
        }
        //* response send to client
        return res.status(200).json({
          success: true,
          image: response,
          message: "Image uploaded successfully",
        });
      } else if (!files || files === null || files === undefined) {
        return res.status(400).json({
          success: false,
          message: "No files were uploaded",
        });
      } else {
        return res.status(400).json({
          success: false,
          message: "Some Error in Files Upload",
        });
      }
    } catch (error) {
      console.error("An Error occured while uploading medias: ", error);
      res.status(500).json({ success: false, message: error.message || "An Error occured while uploading medias!" });
    }
  },
};
