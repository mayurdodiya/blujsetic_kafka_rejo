// const { Kafka } = require("kafkajs");

// class KafkaConfig {
//     constructor() {
//         this.kafka = new Kafka({
//             // brokers: ['localhost:9092'],
//             brokers: ['tolerant-piglet-13648-us1-kafka.upstash.io:9092'],
//             // sasl: {
//             //     mechanism: 'scram-sha-256',
//             //     username: 'dG9sZXJhbnQtcGlnbGV0LTEzNjQ4JKDklhQJlCk3tewb48ZYg_Zw0PBAJ6b2fUI',
//             //     password: '0e3eb322b74343468509ee5d49f17f92',
//             // },
//             sasl: {
//                 mechanism: 'scram-sha-256',
//                 username: 'dG9sZXJhbnQtcGlnbGV0LTEzNjQ4JKDklhQJlCk3tewb48ZYg_Zw0PBAJ6b2fUI',
//                 password: '0e3eb322b74343468509ee5d49f17f92',
//             },
//             ssl: true,
//             autoCreateTopic: true
//         })
//         this.producer = this.kafka.producer();
//         this.consumer = this.kafka.consumer({ groupId: "test-group" });
//         /* check connction */
//         // this.checkConnection();
//     }

//     async checkConnection() {
//         try {
//             await this.producer.connect();
//             await this.consumer.connect();
//             console.log("🚀 🚀 🚀 :-Kafka connected successfully");
//         } catch (error) {
//             console.error(error);
//         } finally {
//             await this.producer.disconnect();
//             await this.consumer.disconnect();
//         }
//     }
//     async produce(topic, messages) {
//         try {
//             console.log("Producre called...");
//             /* create topic if not exist */
//             await this.createOrCheckTopic(topic);
//             await this.producer.connect();
//             /* send message to kafka tinybird */
//             const formattedMessages = messages.map(message => ({
//                 key: "some-key",
//                 value: JSON.stringify({ __value: message.value }),
//             }));

//             await this.producer.send({
//                 topic: topic,
//                 messages: formattedMessages,
//             });
//             console.log("🚀 🚀 🚀 :-Kafka message sent successfully");
//         } catch (error) {
//             console.error(error);
//         } finally {
//             await this.producer.disconnect();
//         }
//     }

//     async consume(topic, callback) {
//         try {

//             /* create topic if not exist */
//             // await this.createOrCheckTopic(topic);
//             await this.consumer.connect();
//             await this.consumer.subscribe({ topic: topic, fromBeginning: true });
//             await this.consumer.run({
//                 eachMessage: async ({ topic, partition, message }) => {
//                     const value = message.value.toString();
//                     callback(value);
//                 },
//             });
//         } catch (error) {
//             console.error(error);
//         }
//     }

//     /* check topic is exist or not */

//     async createOrCheckTopic(topic, numPartitions = 1, replicationFactor = 1, topicConfig = { 'cleanup.policy': 'compact', 'retention.ms': '3600000' }) {
//         const admin = this.kafka.admin();
//         console.log("admin🚀 🚀 🚀🚀 🚀 🚀", await admin.listTopics());
//         try {
//             // Check if the topic already exists
//             const topics = await admin.listTopics()
//             if (topic in topics) {
//                 console.log(`Topic "${topic}" already exists.`);
//                 return;
//             }
//             // Create the topic
//             await admin.createTopics({ topics: [{ topic, partitions: numPartitions, replicationFactor }] })
//             console.log(`Topic "${topic}" created successfully.`);
//             await admin.disconnect();
//         } catch (error) {
//             console.error('Failed to create or check topic:', error);
//         } finally {
//             await admin.disconnect();
//             // admin.close(() => client.close());
//         }
//     }

// }

// /*global set kafkaConfig*/
// global.kafkaConfig = new KafkaConfig();
// // export default KafkaConfig;