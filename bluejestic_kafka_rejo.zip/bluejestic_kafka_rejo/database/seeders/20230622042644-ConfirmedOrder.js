'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    return queryInterface.bulkInsert('ConfirmedOrders', [
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 856321863,
        "productId": [
          25,
          25,
          18,
          8,
          17
        ],
        "quantity": [
          4,
          5,
          2,
          5,
          3
        ],
        "generate_id": 941872748,
        "total": 30801,
        "orderDate": "2023-06-21T06:27:58.365Z",
        "isPaymentDone": true,
        "createdAt": "2023-06-21T06:27:58.365Z",
        "updatedAt": "2023-06-20T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 65096094,
        "productId": [
          20,
          31,
          23,
          21
        ],
        "quantity": [
          3,
          4,
          5,
          3
        ],
        "generate_id": 258304146,
        "total": 12793,
        "orderDate": "2023-06-16T06:27:58.366Z",
        "isPaymentDone": false,
        "createdAt": "2023-06-17T06:27:58.366Z",
        "updatedAt": "2023-06-17T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 208423828,
        "productId": [
          28,
          8
        ],
        "quantity": [
          5,
          1
        ],
        "generate_id": 99914438,
        "total": 12385,
        "orderDate": "2023-06-19T06:27:58.366Z",
        "isPaymentDone": true,
        "createdAt": "2023-06-17T06:27:58.366Z",
        "updatedAt": "2023-06-21T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 372546131,
        "productId": [
          24
        ],
        "quantity": [
          3
        ],
        "generate_id": 696358608,
        "total": 1497,
        "orderDate": "2023-06-16T06:27:58.366Z",
        "isPaymentDone": true,
        "createdAt": "2023-06-20T06:27:58.366Z",
        "updatedAt": "2023-06-21T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 831988910,
        "productId": [
          17
        ],
        "quantity": [
          1
        ],
        "generate_id": 77530490,
        "total": 550,
        "orderDate": "2023-06-19T06:27:58.366Z",
        "isPaymentDone": false,
        "createdAt": "2023-06-17T06:27:58.366Z",
        "updatedAt": "2023-06-17T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 762553110,
        "productId": [
          24,
          8,
          17
        ],
        "quantity": [
          5,
          2,
          5
        ],
        "generate_id": 330219185,
        "total": 14025,
        "orderDate": "2023-06-16T06:27:58.366Z",
        "isPaymentDone": true,
        "createdAt": "2023-06-16T06:27:58.366Z",
        "updatedAt": "2023-06-15T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 820376046,
        "productId": [
          23
        ],
        "quantity": [
          2
        ],
        "generate_id": 196754540,
        "total": 1000,
        "orderDate": "2023-06-17T06:27:58.366Z",
        "isPaymentDone": true,
        "createdAt": "2023-06-19T06:27:58.366Z",
        "updatedAt": "2023-06-15T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 576661815,
        "productId": [
          31,
          22,
          21
        ],
        "quantity": [
          3,
          4,
          5
        ],
        "generate_id": 317538513,
        "total": 10293,
        "orderDate": "2023-06-21T06:27:58.366Z",
        "isPaymentDone": false,
        "createdAt": "2023-06-19T06:27:58.366Z",
        "updatedAt": "2023-06-15T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 698945900,
        "productId": [
          17,
          27,
          8,
          24,
          31
        ],
        "quantity": [
          1,
          4,
          5,
          2,
          4
        ],
        "generate_id": 485913401,
        "total": 29490,
        "orderDate": "2023-06-15T06:27:58.366Z",
        "isPaymentDone": true,
        "createdAt": "2023-06-18T06:27:58.366Z",
        "updatedAt": "2023-06-18T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 589567417,
        "productId": [
          19,
          6,
          22,
          18
        ],
        "quantity": [
          3,
          2,
          2,
          1
        ],
        "generate_id": 767426411,
        "total": 7433,
        "orderDate": "2023-06-15T06:27:58.366Z",
        "isPaymentDone": true,
        "createdAt": "2023-06-21T06:27:58.366Z",
        "updatedAt": "2023-06-20T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 480904994,
        "productId": [
          23
        ],
        "quantity": [
          3
        ],
        "generate_id": 914886955,
        "total": 1500,
        "orderDate": "2023-06-19T06:27:58.366Z",
        "isPaymentDone": false,
        "createdAt": "2023-06-18T06:27:58.366Z",
        "updatedAt": "2023-06-17T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 433826010,
        "productId": [
          23,
          21,
          19
        ],
        "quantity": [
          3,
          5,
          5
        ],
        "generate_id": 633535884,
        "total": 9000,
        "orderDate": "2023-06-21T06:27:58.366Z",
        "isPaymentDone": false,
        "createdAt": "2023-06-17T06:27:58.366Z",
        "updatedAt": "2023-06-21T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 313912795,
        "productId": [
          18,
          27
        ],
        "quantity": [
          4,
          3
        ],
        "generate_id": 889205234,
        "total": 3317,
        "orderDate": "2023-06-20T06:27:58.366Z",
        "isPaymentDone": true,
        "createdAt": "2023-06-18T06:27:58.366Z",
        "updatedAt": "2023-06-18T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 249113520,
        "productId": [
          19
        ],
        "quantity": [
          5
        ],
        "generate_id": 535178110,
        "total": 5000,
        "orderDate": "2023-06-16T06:27:58.366Z",
        "isPaymentDone": true,
        "createdAt": "2023-06-15T06:27:58.366Z",
        "updatedAt": "2023-06-18T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 155068110,
        "productId": [
          27,
          17,
          28,
          24,
          25
        ],
        "quantity": [
          1,
          3,
          4,
          2,
          5
        ],
        "generate_id": 690779496,
        "total": 13038,
        "orderDate": "2023-06-17T06:27:58.366Z",
        "isPaymentDone": false,
        "createdAt": "2023-06-20T06:27:58.366Z",
        "updatedAt": "2023-06-19T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 814153908,
        "productId": [
          8,
          17,
          28
        ],
        "quantity": [
          2,
          3,
          4
        ],
        "generate_id": 381058347,
        "total": 16826,
        "orderDate": "2023-06-16T06:27:58.366Z",
        "isPaymentDone": false,
        "createdAt": "2023-06-21T06:27:58.366Z",
        "updatedAt": "2023-06-19T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 970949476,
        "productId": [
          18,
          28,
          8,
          27,
          18
        ],
        "quantity": [
          5,
          3,
          5,
          2,
          2
        ],
        "generate_id": 350459805,
        "total": 30930,
        "orderDate": "2023-06-17T06:27:58.366Z",
        "isPaymentDone": false,
        "createdAt": "2023-06-20T06:27:58.366Z",
        "updatedAt": "2023-06-20T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 738053074,
        "productId": [
          27,
          31
        ],
        "quantity": [
          4,
          5
        ],
        "generate_id": 639874451,
        "total": 6991,
        "orderDate": "2023-06-18T06:27:58.366Z",
        "isPaymentDone": true,
        "createdAt": "2023-06-20T06:27:58.366Z",
        "updatedAt": "2023-06-20T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 633522379,
        "productId": [
          17,
          6
        ],
        "quantity": [
          3,
          4
        ],
        "generate_id": 880494297,
        "total": 4810,
        "orderDate": "2023-06-20T06:27:58.366Z",
        "isPaymentDone": false,
        "createdAt": "2023-06-20T06:27:58.366Z",
        "updatedAt": "2023-06-15T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 734103441,
        "productId": [
          19,
          22,
          23,
          18,
          8
        ],
        "quantity": [
          4,
          3,
          5,
          5,
          3
        ],
        "generate_id": 864833242,
        "total": 25542,
        "orderDate": "2023-06-16T06:27:58.366Z",
        "isPaymentDone": true,
        "createdAt": "2023-06-16T06:27:58.366Z",
        "updatedAt": "2023-06-19T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 541630353,
        "productId": [
          20
        ],
        "quantity": [
          2
        ],
        "generate_id": 491418083,
        "total": 3198,
        "orderDate": "2023-06-16T06:27:58.366Z",
        "isPaymentDone": false,
        "createdAt": "2023-06-17T06:27:58.366Z",
        "updatedAt": "2023-06-17T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 765782062,
        "productId": [
          17,
          24,
          27
        ],
        "quantity": [
          1,
          5,
          4
        ],
        "generate_id": 290465602,
        "total": 5041,
        "orderDate": "2023-06-20T06:27:58.366Z",
        "isPaymentDone": true,
        "createdAt": "2023-06-15T06:27:58.366Z",
        "updatedAt": "2023-06-21T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 562379764,
        "productId": [
          26,
          25,
          24
        ],
        "quantity": [
          1,
          4,
          1
        ],
        "generate_id": 590494536,
        "total": 4194,
        "orderDate": "2023-06-16T06:27:58.366Z",
        "isPaymentDone": false,
        "createdAt": "2023-06-15T06:27:58.366Z",
        "updatedAt": "2023-06-17T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 160475886,
        "productId": [
          19,
          18
        ],
        "quantity": [
          3,
          5
        ],
        "generate_id": 512816579,
        "total": 5275,
        "orderDate": "2023-06-21T06:27:58.366Z",
        "isPaymentDone": false,
        "createdAt": "2023-06-18T06:27:58.366Z",
        "updatedAt": "2023-06-17T06:27:58.366Z"
      },
      {
        "userId": 1,
        "shippingId": 1,
        "cardId": 1,
        "paymentId": 969532539,
        "productId": [
          21,
          21,
          20,
          17
        ],
        "quantity": [
          1,
          2,
          4,
          1
        ],
        "generate_id": 106241077,
        "total": 8446,
        "orderDate": "2023-06-19T06:27:58.366Z",
        "isPaymentDone": true,
        "createdAt": "2023-06-18T06:27:58.366Z",
        "updatedAt": "2023-06-17T06:27:58.366Z"
      }
    ]);
  },

  async down(queryInterface, Sequelize) {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
  }
};
