const database = require("../models");

class BookmarkService {
  static async add(data) {
    try {
      //   let ImageUpload = data.image;

      let response = await database.Bookmark.create(data);
      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getAll() {
    try {
      return await database.Bookmark.findAll({});
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.Bookmark.findOne({
        where: {
          id: Number(id),
        },
      });

      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.Bookmark.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      console.log("response++++++++++++++++++++++", response);
      if (response) {
        response = await database.Bookmark.findOne({
          where: {
            id: Number(data.id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.Bookmark.findOne({
        where: {
          id: Number(id),
        },
      });

      console.log("Response Data ===============", JSON.parse(JSON.stringify(response)));
      if (response) {
        await database.Store.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }
}

module.exports = BookmarkService;
