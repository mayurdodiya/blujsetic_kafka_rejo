const database = require("../models");
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
let { checkStatusesForFriend } = require("../../utils/utils");

class UserService {
  static async add(data) {
    try {
      let response = await database.User.create(data);
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAll(id) {
    try {
      let response = await database.User.findAll({});
      if (id) {
        let friendIdListIsActive = await database.Friend.findAll({
          where: {
            user_id: Number(id),
            isActive: true,
          },
          raw: true,
        });
        let friendIdListIsFriend = await database.Friend.findAll({
          where: {
            user_id: Number(id),
            isFriend: true,
          },
          raw: true,
        });
        friendIdListIsActive = friendIdListIsActive.map((item) => item.friend_id);
        friendIdListIsFriend = friendIdListIsFriend.map((item) => item.friend_id);
        response = JSON.parse(JSON.stringify(response));
        for await (const [index, item] of response.entries()) {
          item.isFriendForFriendStatus = friendIdListIsFriend.includes(item.id);
          item.isActiveForFriendStatus = friendIdListIsActive.includes(item.id);
        }
      }
      // for await (const item of response) {
      //   if (item.profileAvtar != null && item.profileAvtar.length != 0) {
      //     const media = await database.Media.findOne({
      //       where: {
      //         id: Number(item.profileAvtar[0]),
      //       },
      //     });
      //     item.profileUrl = media?.media;
      //     item.profileAvtar = [media?.media];
      //   } else {
      //     item.profileUrl = "";
      //     item.profileAvtar = [];
      //   }
      // }
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async skipUsers(id) {
    try {
      return await database.User.findAll({
        where: {
          id: { [Op.notIn]: id },
        },
      });
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
  static async getById(id) {
    try {
      const response = await database.User.findOne({
        where: {
          id: Number(id),
        },
        // attributes: {
        //   include: [[Sequelize.fn("COUNT", Sequelize.col("cartItems.user_id")), "cartCounts"]]
        // },

        include: [
          {
            model: database.SavePost,
            as: "save_posts",
            include: [
              {
                model: database.Post,
                as: "post",
                include: [
                  {
                    model: database.Like,
                    as: "likes",
                  },
                  {
                    model: database.Comment,
                    as: "comments",
                  },
                  // {
                  //   model: database.Media,
                  //   as: "medias",
                  // },
                ],
              },
            ],
          },
          {
            model: database.JoinGroup,
            as: "joingroups",
            include: [
              {
                model: database.Group,
                as: "groups",
              },
            ],
          },
          {
            model: database.BioDetail,
            as: "bio_detail",
          },
          {
            model: database.Cart,
            as: "cartItems",
          },
        ],
        // group: ["User.id"]
      });
      response.cartCount = response.cartItems.length;
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getUserbyName(id, userId) {
    try {
      let response;
      response = await database.User.findOne({
        where: {
          id: id,
        },
        include: [
          {
            model: database.BioDetail,
            as: "bio_detail",
          },
        ],
        raw: true,
      });
      response.status = response["bio_detail.marital_status"];
      response.education = response["bio_detail.education"];
      response.hobbies = response["bio_detail.hobbies"];
      response.occupation = response["bio_detail.occupation"];
      response.marital_status = response["bio_detail.marital_status"];
      response.occupation = response["bio_detail.occupation"];
      response.education = response["bio_detail.education"];
      response.interest = response["bio_detail.interest"];
      response.about = response["bio_detail.about"];
      response.experience = response["bio_detail.experience"];
      response.hobbies = response["bio_detail.hobbies"];
      response.gender = response["bio_detail.gender"];
      // Friend Status
      response.isActiveForFriendStatus = await (await checkStatusesForFriend(userId, id)).isActiveForFriendStatus;
      response.isFriendForFriendStatus = await (await checkStatusesForFriend(userId, id)).isFriendForFriendStatus;

      // images of user
      // response.profileCoverImageUrl = await database.Media.findOne({
      //   where: {
      //     id: response.profileCoverImage ? response.profileCoverImage[0] : 0,
      //   },
      // }).then((res) => res?.media);

      // response.profileUrl = await database.Media.findOne({
      //   where: { id: Number(response.profileAvtar[0]) },
      // }).then((res) => res.media);
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async update(data, id) {
    try {
      let [response] = await database.User.update(data, {
        where: {
          id: Number(id),
        },
      });
      if (response) {
        response = await database.User.findOne({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("An error occured while updating the user", error);
      throw new Error("An error occured while updating the user");
    }
  }

  static async updateBiodetail(data, id) {
    try {
      let changeOnboard;
      let user = await database.BioDetail.findOne({
        where: {
          user_id: Number(id),
        },
      });
      //UPDATE_ONBOARD_DETAIL
      let response;
      if (user) {
        response = await database.BioDetail.update(data, {
          where: {
            user_id: Number(id),
          },
        });
        response = await database.User.update(data, {
          where: {
            id: Number(id),
          },
        });
        // const [rowsAffected, [updatedData]] = await database.User.update(data, {
        //   where: {
        //     id: Number(id),
        //   },
        // });

        // console.log('updatedDat==========================================================a',updatedData);

        const userData = await database.User.findOne({ where: { id: id } });
        // if ((userData?.firstName.trim() === "") || (userData?.lastName.trim() === "") || (userData?.gender.trim() === "")) {
        // if (userData?.userName?.trim() === "" || userData?.gender?.trim() === "") {
        //   changeOnboard = await database.User.update(
        //     {
        //       isUserOnboardCompleted: false,
        //     },
        //     {
        //       where: {
        //         id: Number(id),
        //       },
        //     }
        //   );
        // } else if (userData?.firstName.trim() !== "" || userData?.lastName.trim() !== "" || userData?.gender.trim() !== "") {
        //   changeOnboard = await database.User.update(
        //     {
        //       isUserOnboardCompleted: true,
        //     },
        //     {
        //       where: {
        //         id: Number(id),
        //       },
        //     }
        //   );
        // }
      } else {
        response = await database.BioDetail.create(data);
      }

      if (response) {
        response = await database.BioDetail.findOne({
          where: {
            user_id: Number(id),
          },
        });
        return response;
      } else {
        return null;
      }
    } catch (error) {
      console.error("An error occured while updating the bio details", error);
      throw new Error("An error occured while updating the bio details");
    }
  }

  static async delete(id) {
    try {
      return await database.User.destroy({
        where: {
          id: Number(id),
        },
      });
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
}

module.exports = UserService;
