const database = require("../models");
const Sequelize = require("sequelize");
const user = require("../models/user");
const elasticClient = require("../../services/elasticsearch");
const Op = Sequelize.Op;

class JoinGroupService {
  static async add(data) {
    try {
      let response = await database.JoinGroup.create(data);
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAll() {
    try {
      return await database.JoinGroup.findAll({});
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async skipJoinGroups(id) {
    try {
      return await database.JoinGroup.findAll({
        where: {
          id: { [Op.notIn]: id },
        },
      });
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.JoinGroup.findOne({
        where: {
          id: Number(id),
        },
      });

      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.JoinGroup.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.JoinGroup.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.JoinGroup.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        await database.JoinGroup.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
  static async update(data) {
    try {
      let [response] = await database.JoinGroup.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.JoinGroup.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async leave(groupId, userId) {
    try {
      console.log(groupId, userId);
      const response = await database.JoinGroup.findOne({
        where: {
          user_id: userId,
          group_id: groupId,
        },
      });
      if (response) {
        await database.JoinGroup.destroy({
          where: {
            user_id: userId,
            group_id: groupId,
          },
        });
        /* delete group in elastic search */
        // let elkData = await elasticClient.joinGroup.deleteJoinGroup({ group_id: groupId, user_id: userId });
        // if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");

        return response;
      }
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
}

module.exports = JoinGroupService;
