const { Op } = require("sequelize");
const database = require("../models");

class ShopifyProductService {
  static async add(data) {
    try {
      let response = await database.Product.create(data);
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAll() {
    try {
      console.log("args", args);
      return await database.Product.findAll({
        where: {
          is_deleted: false,
        },
        limit: 10,
        order: [["id", "ASC"]],
        include: [
          {
            model: database.Shipping,
            as: "shipping",
          },
          {
            model: database.ProductSEO,
            as: "productSEO",
          },
        ],
      });
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAllById(id) {
    try {
      return await database.Product.findAll({
        where: {
          id: id,
          is_deleted: false,
        },
        order: [["id", "ASC"]],
      });
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.Product.findOne({
        where: {
          id: Number(id),
          is_deleted: false,
        },
        order: [
          [{ model: database.Comment, as: "productComments" }, "createdAt", "ASC"],
          [{ model: database.Like, as: "productLikes" }, "createdAt", "ASC"],
          [{ model: database.Comment, as: "productComments" }, { model: database.CommentReply, as: "commentReply" }, "createdAt", "ASC"],
          [
            { model: database.Comment, as: "productComments" },
            { model: database.CommentReply, as: "commentReply" },
            { model: database.Like, as: "commentReplyLike" },
            "createdAt",
            "ASC",
          ],
          [{ model: database.Comment, as: "productComments" }, { model: database.Like, as: "likes" }, "createdAt", "ASC"],
          ["createdAt", "ASC"],
        ],
        include: [
          // {
          //   model: database.Shipping,
          //   as: "shipping",
          // },
          {
            model: database.ProductSEO,
            as: "productSEO",
          },
          {
            model: database.BusinessInformation,
            as: "store",
          },
          {
            model: database.Comment,
            as: "productComments",
            include: [
              {
                model: database.User,
                as: "user",
              },
              {
                model: database.Like,
                as: "likes",
                include: [
                  {
                    model: database.User,
                    as: "user",
                  },
                ],
              },
              {
                model: database.CommentReply,
                as: "commentReply",
                include: [
                  {
                    model: database.User,
                    as: "user",
                  },
                  {
                    model: database.Like,
                    as: "commentReplyLike",
                    include: [
                      {
                        model: database.User,
                        as: "user",
                      },
                    ],
                  },
                ],
              },
            ],
          },
          {
            model: database.Like,
            as: "productLikes",
            include: [
              {
                model: database.User,
                as: "user",
              },
            ],
          },

          {
            model: database.ProductShippingDetails,
            as: "shipping",
          },
          // {
          //   model: database.ProductSEO,
          //   as: "productSEO",
          // },
          {
            model: database.ProductOtherInformations,
            as: "other",
          },
          {
            model: database.Color,
            as: "colors",
          },
          {
            model: database.Size,
            as: "sizes",
          },
          {
            model: database.ProductAttributes,
            as: "attributes",
          },
          {
            model: database.ProductCategories,
            as: "categories",
            include: [
              {
                model: database.Category,
                as: "category",
              },
              {
                model: database.Subcategory,
                as: "subCategory",
              },
              {
                model: database.Childsubcategory,
                as: "childSubCategory",
              },
            ],
          },
        ],
      });
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async update(data) {
    try {
      console.log("data", data);
      let [response] = await database.Product.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        console.log(">><<<<<>>><<<>>>");
        response = await database.Product.findOne({
          where: {
            id: Number(data.id),
            is_deleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.Product.findOne({
        where: {
          id: Number(id),
          is_deleted: false,
        },
      });
      if (response) {
        await database.Product.update(
          { is_deleted: true },
          {
            where: {
              id: Number(id),
            },
          }
        );
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
}

module.exports = ShopifyProductService;
