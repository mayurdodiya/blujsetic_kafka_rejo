const database = require("../models");
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const elasticClient = require("../../services/elasticsearch");
class GroupService {
  static async add(data) {
    try {
      let response = await database.Group.create(data);
      if (response) {
        let input = {
          group_id: response.id,
          user_id: data.user_id,
          isAdmin: true,
          isOwner: true,
        };
        let joinGroup = await database.JoinGroup.create(input);
        let elkData = await elasticClient.joinGroup.addJoinGroup({ ...input, id: joinGroup.id });
        if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");
      }
      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getAll(subCategory_id) {
    try {
      let where = {};
      if (subCategory_id) {
        let subCategoriesIds = [];
        const categories = await database.Category.findOne({
          where: {
            id: subCategory_id,
          },
          include: [
            {
              model: database.Subcategory,
              as: "subCategory",
            },
          ],
        });
        if (categories && categories.subCategory) subCategoriesIds = categories.subCategory.map((subCategory) => subCategory.id);
        const subCategories = await database.Subcategory.findOne({
          where: {
            id: subCategory_id,
          },
        });

        if (subCategories && subCategories.id) subCategoriesIds.push(subCategories.id);
        if (subCategory_id)
          where = {
            subCategory_id: {
              [Op.in]: subCategoriesIds,
            },
          };
      }
      return await database.Group.findAll({
        where: where,
      });
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getSuggestedGroups(user_id) {
    try {
      console.log("user_id", user_id);
      let groupJoinedIds = await database.JoinGroup.findAll({
        where: {
          user_id: { [Op.eq]: user_id },
        },
        raw: true,
      });
      groupJoinedIds = groupJoinedIds.map((group) => group.group_id);
      console.log("groupJoinedIds", groupJoinedIds);
      let criteria = {
        where: {
          privacy: { [Op.or]: ["Public", "Private", "public", "private"] },
          id: { [Op.notIn]: groupJoinedIds },
          user_id: { [Op.not]: user_id },
        },
        include: [
          {
            model: database.User,
            as: "user",
          },
        ],
        raw: true,
        nest: true,
      };
      console.log("criteria", criteria);
      let response = await database.Group.findAll(criteria);
      for await (let group of response) {
        const { user } = group;
        user.id = user.id || -1;
        user.firstName = user.firstName || "";
        user.lastName = user.lastName || "";
        user.email = user.email || "";
        user.userName = user.userName || "";
      }
      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }
  static async getJoinedGroups(user_id) {
    try {
      let groupJoinedIds = await database.JoinGroup.findAll({
        where: {
          user_id: user_id,
        },
        raw: true,
      });
      console.log("groupJoinedIds", groupJoinedIds);
      let criteria = {
        where: { id: { [Op.in]: groupJoinedIds.map((joined) => joined.group_id) } },
        include: [
          {
            model: database.User,
            as: "user",
          },
        ],
      };
      console.log("criteria", criteria);
      let response = await database.Group.findAll(criteria);
      for await (let group of response) {
        const { user } = group;
        user.id = user.id || -1;
        user.firstName = user.firstName || "";
        user.lastName = user.lastName || "";
        user.email = user.email || "";
        user.userName = user.userName || "";
      }
      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }
  static async getMyGroups(user_id) {
    try {
      let criteria = {};

      if (user_id) {
        criteria.where = {
          user_id: user_id,
          [Op.or]: [{ isAdmin: true }, { isOwner: true }],
        };
      } else {
        criteria.where = {};
      }
      let groupJoinedIds = await database.JoinGroup.findAll({ ...criteria, raw: true, nest: true });
      groupJoinedIds = groupJoinedIds.map((group) => group.group_id);

      criteria = {
        where: {
          id: { [Op.in]: groupJoinedIds },
        },
        include: [
          {
            model: database.User,
            as: "user",
          },
        ],
        raw: true,
        nest: true,
      };
      let response = await database.Group.findAll(criteria);
      for await (let group of response) {
        const { user } = group;
        user.id = user.id || -1;
        user.firstName = user.firstName || "";
        user.lastName = user.lastName || "";
        user.email = user.email || "";
        user.userName = user.userName || "";
      }
      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  // Follow Group

  static async followGroup(groupId, userId) {
    try {
      let response;
      if (userId) {
        response = await database.JoinGroup.findOne({
          where: {
            group_id: Number(groupId),
            user_id: Number(userId),
          },
          raw: true,
        });
      } else {
        response = await database.JoinGroup.findOne({
          where: {
            group_id: Number(groupId),
          },
          raw: true,
        });
      }

      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getAllGroupsRequested(id) {
    try {
      let invitedGroups = await database.InviteGroup.findAll({
        where: {
          user_id: id,
          isJoin: false,
        },
        raw: true,
      });
      let response = await database.Group.findAll({
        where: {
          privacy: "Private",
          id: { [Op.in]: invitedGroups.map((group) => group.group_id) },
        },
        raw: true,
      });
      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getById(slug) {
    try {
      let response_data = await database.Group.findOne({
        where: {
          slug: slug,
        },
        include: [
          // {
          //   model: database.User,
          //   as: "user",
          // },
          {
            model: database.Subcategory,
            as: "sub_Category",
            attributes: ["id", "name"],
          },
        ],
      });

      if (!response_data) {
        return null;
      }

      let response = JSON.parse(JSON.stringify(response_data)); // return;

      if (!response) new Error("Group Not found");
      // // profile image of group owner
      // response.user.profileAvtar = response.user.profileAvtar
      //   ? await database.Media.findOne({
      //       where: { id: Number(response.user.profileAvtar[0]) },
      //     }).then((res) => res?.media || "")
      //   : [];
      // // cover image of group owner
      // response.user.profileCoverImage = response.user.profileCoverImage
      //   ? await database.Media.findOne({
      //       where: {
      //         id: Number(response.user.profileCoverImage[0]),
      //       },
      //     }).then((res) => res?.media || "")
      //   : [];
      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.Group.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.Group.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async delete(id, userId) {
    try {
      const response = await database.Group.findOne({
        where: {
          id: Number(id),
          user_id: Number(userId),
        },
      });
      if (response) {
        await database.Group.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getGroupMedia(groupId) {
    const response = await database.Post.findAll({
      where: {
        group_id: Number(groupId),
        post_for: "GROUP",
      },
    });
    if (response) {
      let mediaIds = response.map((item) => item.media_id).flat(1);

      let images = await database.Media.findAll({
        where: {
          id: { [Op.in]: mediaIds },
        },
      });

      return images;
    }
    return null;
  }

    static async deleteBySlug(slug) {
      try {
        const response = await database.Group.findOne({
          where: {
            slug: slug,
            is_deleted : false
          },
        });
        if (response) {
          await database.Group.update(
            {is_deleted: true},
            {
            where: {
              slug: slug,
            },
          });
          return response;
        }
        return null;
      } catch (error) {
        console.error("An error occured while deleting group: ", error);
        throw new Error("An error occured while deleting group!");
      }
    }
}

module.exports = GroupService;
