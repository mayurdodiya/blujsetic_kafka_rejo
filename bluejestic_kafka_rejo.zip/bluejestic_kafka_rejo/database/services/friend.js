const { Op } = require("sequelize");
const { checkStatusesForFriend } = require("../../utils/utils");
const database = require("../models");

class FriendService {
  static async add(data) {
    try {
      /* if friend request already sent */
      console.log(data);

      let response = await database.Friend.create(data);

      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getAll() {
    try {
      return await database.Friend.findAll({});
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.Friend.findOne({
        where: {
          id: Number(id),
        },
      });

      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getByUserId(id) {
    try {
      const response = await database.Friend.findAll({
        where: {
          user_id: Number(id),
          isActive: true,
          isFriend: false,
        },
        include: [
          {
            model: database.User,
            as: "user",
          },
        ],
      });

      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getFriendByUserId(id) {
    try {
      let response = await database.Friend.findAll({
        where: {
          friend_id: Number(id),
          isActive: true,
          isFriend: false,
        },
        // include: [
        //   {
        //     model: database.User,
        //     as: "friend",
        //   },
        // ],
      });
      response = JSON.parse(JSON.stringify(response));
      for await (const item of response) {
        console.log("item.user_id+++++++++++++++++++++++++++++++++++++++++++++++++s", item.friend_id);
        const user = await database.User.findOne({
          where: {
            id: item.user_id,
          },
        });
        console.log("item.user_id+++++++++++++++++++++++++++++++++++++++++++++++++s", user);
        item.user = user;
      }

      for await (const item of response) {
        const media = await database.Media.findOne({
          where: {
            id: item.user.profileAvtar ? item.user.profileAvtar[0] : 0,
          },
        });
        console.log("media?.media+++++++++++++++++++++++++++", media?.media);
        item.user.profileUrl = media?.media ? media.media : null;
      }

      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getByUserByStatus(user_id, friend_id) {
    try {
      // console.log("Get By User By Status ", user_id, friend_id);
      const response = await database.Friend.findAll({
        where: {
          user_id: Number(user_id),
          friend_id: Number(friend_id),
        },
        include: [
          {
            model: database.User,
            as: "user",
          },
        ],
      });
      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }
  static async deleteFriendByUserAndFriendId(user_id, friend_id) {
    try {
      let isDeleteFriend = await database.Friend.destroy({
        where: { user_id: Number(user_id), friend_id: Number(friend_id) },
      });
      console.log("isDeleteFriend", isDeleteFriend);
      if (isDeleteFriend) {
        return {
          message: "Friend Deleted Successfully",
        };
      } else {
        return {
          message: "Friend Not Found",
        };
      }
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }
  static async getMyFriends(user_id, token) {
    try {
      let response;
      if (user_id) {
        response = await database.Friend.findAll({
          where: {
            user_id: Number(user_id),
            isFriend: true,
          },
          include: [
            {
              model: database.User,
              as: "user",
            },
          ],
        });
      } else {
        response = await database.Friend.findAll({
          where: {
            isFriend: true,
          },
          include: [
            {
              model: database.User,

              as: "user",
            },
          ],
        });
      }
      for await (const item of response) {
        if (item && item.user != null) {
          if (token) {
            let { isActiveForFriendStatus, isFriendForFriendStatus } = await checkStatusesForFriend(token, user_id);
            item.user.isActiveForFriendStatus = isActiveForFriendStatus;
            item.user.isFriendForFriendStatus = isFriendForFriendStatus;
          }
          // if (item.user.profileAvtar.length) {
          //   const media = await database.Media.findOne({
          //     where: {
          //       id: item.user.profileAvtar ? item.user.profileAvtar[0] : 0,
          //     },
          //     raw: true,
          //   });
          //   item.user.profileUrl = media?.media ? media.media : null;
          // }
        } else {
          new Error("User Not Found");
        }
      }
      return response;
      // let users = []
      // for (let i = 0; i < response.length; i++) {
      //   const user = JSON.parse(JSON.stringify(response[i].user));
      //   console.log("user", user.id);
      //   /* profile url */
      //   const media = await database.Media.findOne({
      //     where: {
      //       id: user.profileAvtar ? user.profileAvtar[0] : 0,
      //     },
      //     raw: true,
      //   });
      //   user.profileUrl = media?.media ? media.media : null;
      //   /*get followers count */
      //   let users_followers_count = await database.Friend.count({
      //     where: {
      //       user_id: Number(user.id),
      //       isFriend: true,
      //     },
      //   });
      //   /* is follow user or not */
      //   let isFollow = await database.Friend.findOne({
      //     where: {
      //       user_id: Number(user_id),
      //       friend_id: Number(user.id),
      //       // isFriend: true,
      //     },
      //   });
      //   user.isFollow = isFollow ? true : false
      //   user.followers_count = users_followers_count
      //   users.push({ user: user })
      //   // console.log("users_followers_count", user.isFollow,);
      // }
      // return users;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getMyFollowing(user_id, token) {
    try {
      let response;
      if (user_id) {
        response = await database.Friend.findAll({
          where: {
            friend_id: Number(user_id),
            isFriend: true,
          },
          include: [
            {
              model: database.User,
              as: "friend",
            },
          ],
        });
      } else {
        response = await database.Friend.findAll({
          where: {
            isFriend: true,
          },
          include: [
            {
              model: database.User,
              as: "friend",
            },
          ],
        });
      }

      for await (const item of response) {
        if (token) {
          let { isActiveForFriendStatus, isFriendForFriendStatus } = await checkStatusesForFriend(token, user_id);
          item.friend.isActiveForFriendStatus = isActiveForFriendStatus;
          item.friend.isFriendForFriendStatus = isFriendForFriendStatus;
        }
        // if (item.friend.profileAvtar.length) {
        //   const media = await database.Media.findOne({
        //     where: {
        //       id: item.friend.profileAvtar ? item.friend.profileAvtar[0] : 0,
        //     },
        //     raw: true,
        //   });
        //   item.friend.profileUrl = media?.media ? media.media : null;
        // }
      }
      return response;
      // let users = []
      // for (let i = 0; i < response.length; i++) {
      //   const user = JSON.parse(JSON.stringify(response[i].friend));
      //   if(!user) continue
      //   console.log("user", user.id);
      //   /* profile url */
      //   const media = await database.Media.findOne({
      //     where: {
      //       id: user.profileAvtar ? user.profileAvtar[0] : 0,
      //     },
      //     raw: true,
      //   });
      //   user.profileUrl = media?.media ? media.media : null;
      //   /*get followers count */
      //   let users_followers_count = await database.Friend.count({
      //     where: {
      //       user_id: Number(user.id),
      //       isFriend: true,
      //     },
      //   });
      //   /* is follow user or not */
      //   let isFollow = await database.Friend.findOne({
      //     where: {
      //       user_id: Number(user_id),
      //       friend_id: Number(user.id),
      //       // isFriend: true,
      //     },
      //   });
      //   user.isFollow = isFollow ? true : false
      //   user.followers_count = users_followers_count
      //   users.push({ user: user })
      //   // console.log("users_followers_count", user.isFollow,);
      // }
      // return users;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getUsesrsWithFollowings(user_id) {
    try {
      /*followers */
      const response = await database.Friend.findAll({
        where: {
          user_id: Number(user_id),
          isFriend: true,
        },
        include: [
          {
            model: database.User,
            as: "user",
          },
        ],
      });
      let users = [];
      for (let i = 0; i < response.length; i++) {
        const user = JSON.parse(JSON.stringify(response[i].user));
        if (!user) continue;
        console.log("user", user.id);
        /* profile url */
        const media = await database.Media.findOne({
          where: {
            id: user.profileAvtar ? user.profileAvtar[0] : 0,
          },
          raw: true,
        });
        user.profileUrl = media?.media ? media.media : null;
        /*get followers count */
        let users_followers_count = await database.Friend.count({
          where: {
            user_id: Number(user.id),
            isFriend: true,
          },
        });
        /* is follow user or not */
        let isFollow = await database.Friend.findOne({
          where: {
            user_id: Number(user_id),
            friend_id: Number(user.id),
            // isFriend: true,
          },
        });
        user.isFollow = isFollow ? true : false;
        user.followers_count = users_followers_count;
        users.push(user);
        // console.log("users_followers_count", user.isFollow,);
      }
      return users;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getUsesrsWithFollowers(user_id) {
    try {
      /* following */
      const response = await database.Friend.findAll({
        where: {
          friend_id: Number(user_id),
          isFriend: true,
        },
        include: [
          {
            model: database.User,
            as: "friend",
          },
        ],
      });
      let users = [];
      for (let i = 0; i < response.length; i++) {
        const user = JSON.parse(JSON.stringify(response[i].friend));
        if (!user) continue;
        console.log("user", user.id);
        /* profile url */
        const media = await database.Media.findOne({
          where: {
            id: user.profileAvtar ? user.profileAvtar[0] : 0,
          },
          raw: true,
        });
        user.profileUrl = media?.media ? media.media : null;
        /*get followers count */
        let users_followers_count = await database.Friend.count({
          where: {
            user_id: Number(user.id),
            isFriend: true,
          },
        });
        /* is follow user or not */
        let isFollow = await database.Friend.findOne({
          where: {
            user_id: Number(user_id),
            friend_id: Number(user.id),
            // isFriend: true,
          },
        });
        user.isFollow = isFollow ? true : false;
        user.followers_count = users_followers_count;
        users.push(user);
        // console.log("users_followers_count", user.isFollow,);
      }
      return users;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getSuggestedUsers(user_id) {
    try {
      if (user_id) {
        /* suggested */
        const response = await database.Friend.findAll({
          where: {
            [Op.or]: [
              {
                user_id: Number(user_id),
              },
              // {
              //   friend_id: Number(user_id),
              // },
            ],
          },
        });
        let userIds = [...response.map((item) => item.user_id), ...response.map((item) => item.friend_id), user_id];
        userIds = [...new Set(userIds)];
        const suggestedusers = await database.User.findAll({
          // where: {
          //   id: {
          //     [Op.notIn]: userIds,
          //   },
          // },
          raw: true,
        });
        let users = [];
        for (let i = 0; i < suggestedusers.length; i++) {
          const user = JSON.parse(JSON.stringify(suggestedusers[i]));
          if (!user) continue;
          console.log("user", user.id);
          if (user.profileAvtar.length) {
            /* profile url */
            const media = await database.Media.findOne({
              where: {
                id: user?.profileAvtar ? user.profileAvtar[0] : 0,
              },
              raw: true,
            });
            user.profileUrl = media?.media;
          } else user.profileUrl = null;
          /*get followers count */
          let users_followers_count = await database.Friend.count({
            where: {
              user_id: Number(user.id),
              isFriend: true,
            },
          });
          /* is follow user or not */
          let isFollow = await database.Friend.findOne({
            where: {
              user_id: Number(user_id),
              friend_id: Number(user.id),
              // isFriend: true,
            },
          });
          user.isFollow = isFollow ? true : false;
          user.followers_count = users_followers_count;
          users.push(user);
          // console.log("users_followers_count", user.isFollow,);
        }
        return users;
      } else {
        const suggestedusers = await database.User.findAll();
        let users = [];
        for (let i = 0; i < suggestedusers.length; i++) {
          const user = JSON.parse(JSON.stringify(suggestedusers[i]));
          if (!user) continue;
          if (user.profileAvtar.length) {
            /* profile url */
            const media = await database.Media.findOne({
              where: {
                id: user?.profileAvtar ? user.profileAvtar[0] : 0,
              },
              raw: true,
            });
            user.profileUrl = media?.media;
          } else user.profileUrl = null;
          let users_followers_count = await database.Friend.count({
            where: {
              user_id: Number(user.id),
              isFriend: true,
            },
          });
          let isFollow = await database.Friend.findOne({
            where: {
              friend_id: Number(user.id),
            },
          });
          user.isFollow = false;
          user.followers_count = users_followers_count;
          users.push(user);
        }
        return users;
      }
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async user_id(user_id) {
    try {
      // console.log("Get By User By Status ", user_id, friend_id);
      const response = await database.Friend.findAll({
        where: {
          user_id: Number(user_id),
          isFriend: true,
        },
        include: [
          {
            model: database.User,
            as: "user",
          },
        ],
        raw: true,
      });
      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.Friend.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.Friend.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async updateOrCreate(data, id) {
    try {
      let user = await database.Friend.findOne({
        where: {
          user_id: Number(id),
        },
      });
      let response;
      if (user) {
        response = await database.Friend.update(data, {
          where: {
            user_id: Number(id),
          },
        });
      } else {
        response = await database.Friend.create(data);
      }
      if (response) {
        response = await database.Friend.findOne({
          where: {
            user_id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async delete(user_id, friend_id) {
    try {
      const isDeleteFriend = await database.Friend.destroy({
        where: {
          user_id: Number(user_id),
          friend_id: Number(friend_id),
        },
      });
      if (isDeleteFriend) {
        return {
          message: "Friend Deleted Successfully",
        };
      }
      return {
        message: "Friend Not Found",
      };
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }
}

module.exports = FriendService;
