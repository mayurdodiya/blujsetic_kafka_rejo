const database = require("../models");
class NestedChildSubCategoryService {
  static async add(data) {
    try {
      let response = await database.NestedChildSubcategory.create(data);
      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getAll() {
    try {
      return await database.NestedChildSubcategory.findAll({
        include: [
          {
            model: database.Category,
            as: "mainCategory",
          },
          {
            model: database.Subcategory,
            as: "subCategory",
          },
        ],
      });
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.NestedChildSubcategory.findOne({
        where: {
          id: Number(id),
        },
        include: [
          {
            model: database.Category,
            as: "mainCategory",
          },
          {
            model: database.Subcategory,
            as: "subCategory",
          },
        ],
      });

      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.NestedChildSubcategory.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.NestedChildSubcategory.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.NestedChildSubcategory.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        await database.NestedChildSubcategory.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }
}

module.exports = NestedChildSubCategoryService;
