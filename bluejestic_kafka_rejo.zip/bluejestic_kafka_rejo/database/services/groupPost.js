const database = require("../models");
const { createWriteStream, mkdir } = require("fs");
const Sequelize = require("sequelize");
const Op = Sequelize.Op;

class GroupPostService {
  static async add(data) {
    try {
      let response = await database.Post.create(data);

      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

}

module.exports = GroupPostService;
