const database = require("../models");

class StoreService {
  static async add(data) {
    try {
      let response = await database.Store.create(data);
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async auth(token) {
    try {
      if (!token || token === "" || token == null) {
        return false;
      } else {
        return token;
      }
    } catch (error) {
      return "Internal Server Error" + error;
    }
  }
}

module.exports = StoreService;
