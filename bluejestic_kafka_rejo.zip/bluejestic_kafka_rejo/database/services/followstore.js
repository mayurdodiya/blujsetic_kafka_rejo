const database = require("../models");
class FollowStoreService {
  static async add(data) {
    try {
      let response = await database.FollowStore.create(data);
      // add in elastic search

      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getAll(storeId) {
    try {
      let find_store = await database.FollowStore.findAll({
        where: { store_id: Number(storeId) },
        include: [
          {
            model: database.User,
            as: "user",
          },
        ],
      });
      return JSON.parse(JSON.stringify(find_store));
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }
  static async getAllFollowings(storeId) {
    try {
      return await database.FollowStore.findAll({
        where: { user_id: Number(storeId) },
        include: [
          {
            model: database.User,
            as: "user",
          },
        ],
      });
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getById(storeId, userId) {
    try {
      let response = {};
      if (userId) {
        response = await database.FollowStore.findOne({
          where: {
            store_id: Number(storeId),
            user_id: Number(userId),
          },
        });
      } else {
        response = await database.FollowStore.findOne({
          where: {
            store_id: Number(storeId),
          },
        });
      }

      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.FollowStore.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.FollowStore.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async delete(storeId, userId) {
    try {
      const response = await database.FollowStore.findOne({
        where: {
          store_id: Number(storeId),
          user_id: Number(userId),
        },
      });
      if (response) {
        await database.FollowStore.destroy({
          where: {
            store_id: Number(storeId),
            user_id: Number(userId),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }
}

module.exports = FollowStoreService;
