const database = require("../models");

class AboutService {
  static async add(data) {
    try {
      let response = await database.About.create(data);
      return response;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async getAll() {
    try {
      return await database.About.findAll({});
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.About.findOne({
        where: {
          id: Number(id),
        },
      });
      return response;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.About.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.About.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.About.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        console.log("delete response", response);
        await database.About.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }
}

module.exports = AboutService;
