
const database = require("../models");

class SizeService {
  static async add(data) {
    try {
      let response = await database.Size.create(data);
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAll() {
    try {
      return await database.Size.findAll({});
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.Size.findOne({
        where: {
          id: Number(id),
        }
      });
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.Size.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.Size.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.Size.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        await database.Size.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
}

module.exports = SizeService;
