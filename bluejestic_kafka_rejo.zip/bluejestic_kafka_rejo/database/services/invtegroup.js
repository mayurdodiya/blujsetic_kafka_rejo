const database = require("../models");
const Sequelize = require("sequelize");
const user = require("../models/user");
const Op = Sequelize.Op;

class InviteGroupService {
  static async add(data) {
    try {
      let result = [];
      for (let i = 0; i < data.user_id.length; i++) {
        const user = data.user_id[i];
        let body = {
          user_id: user,
          group_id: data.group_id,
        };
        let response = await database.InviteGroup.create(body);
        result.push(response);
      }
      return result;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAll() {
    try {
      return await database.InviteGroup.findAll({});
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async skipInviteGroups(id) {
    try {
      return await database.InviteGroup.findAll({
        where: {
          id: { [Op.notIn]: id },
        },
      });
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async joinByGroupId(group_id, user_id, isAdmin) {
    try {
      console.log("group_id, user_id", group_id, user_id);
      let response = await database.InviteGroup.update(
        { isJoin: true },
        {
          where: {
            group_id: group_id,
            user_id: user_id,
          },
        }
      );

      console.log("response", response);
      if (response[0] === 1) {
        await database.JoinGroup.create({
          user_id: user_id,
          group_id: group_id,
          isAdmin: isAdmin !== undefined ? isAdmin : false,
        });

        return {
          isSuccess: true,
        };
      } else {
        return {
          isSuccess: false,
        };
      }
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async isExistInviteGroup(user, group) {
    try {
      const response = await database.InviteGroup.findOne({
        where: {
          user_id: Number(user),
          group_id: Number(group),
        },
      });

      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
  static async accept(data) {
    try {
      let [response] = await database.InviteGroup.update(
        { isJoin: true },
        {
          where: {
            id: Number(data.id),
          },
        }
      );
      if (response) {
        response = await database.InviteGroup.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        if (response.isJoin === true) {
          let body = {
            user_id: response.user_id,
            group_id: response.group_id,
            isAdmin: false,
          };
          let joingroup = await database.JoinGroup.create(body);
        }
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.InviteGroup.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.InviteGroup.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.InviteGroup.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        await database.InviteGroup.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
  static async update(data) {
    try {
      let [response] = await database.InviteGroup.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.InviteGroup.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async cancle(user, group) {
    try {
      const response = await database.InviteGroup.findOne({
        where: {
          user_id: user,
          group_id: group,
        },
      });
      if (response) {
        await database.InviteGroup.destroy({
          where: {
            user_id: user,
            group_id: group,
          },
        });
        return response;
      }
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
}

module.exports = InviteGroupService;
