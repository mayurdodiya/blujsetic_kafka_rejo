const database = require("../models");

class CardAndBillingAddressService {
  static async add(data, userId) {
    try {
      await database.CardAndBillingAddress.update(
        {
          isDefault: false,
        },
        {
          where: {
            user_id: userId,
          },
        }
      );
      let response = await database.CardAndBillingAddress.create(data);
      return response;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async getAll(user_id) {
    try {
      return await database.CardAndBillingAddress.findAll({
        where: {
          user_id: Number(user_id),
        },
        order: [["createdAt", "DESC"]],
      });
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async getById(id, user_id) {
    try {
      console.log("IDDDDD", id, user_id);
      const response = await database.CardAndBillingAddress.findOne({
        where: {
          id: Number(id),
          user_id: user_id,
        },
      });
      return response;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async update(data, userId) {
    try {
      await database.CardAndBillingAddress.update(
        {
          isDefault: false,
        },
        {
          where: {
            user_id: userId,
          },
        }
      );

      const cardDetail = await database.CardAndBillingAddress.findOne({
        where: { id: data?.id },
      });

      if (!cardDetail) {
        return null
      }

      // Update
      let { id, ...payload } = data;
      for (let key in payload) {
        cardDetail[key] = payload[key];
      }
      await cardDetail.save();
      return cardDetail;

    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.CardAndBillingAddress.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        console.log("delete response", response);
        await database.CardAndBillingAddress.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }
}

module.exports = CardAndBillingAddressService;
