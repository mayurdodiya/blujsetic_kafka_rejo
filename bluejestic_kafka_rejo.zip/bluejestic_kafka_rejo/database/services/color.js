
const database = require("../models");
const Sequelize = require("sequelize");

class ColorService {
  static async add(data) {
    try {

      let response = await database.Color.create(data);
      return response;

    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async getAll() {
    try {
      return await database.Color.findAll({});
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.Color.findOne({
        where: {
          id: Number(id),
          // isDeleted: false,
        },
        // include: [
        //   {
        //     model: database.Address,
        //     as: "address",
        //     // where: {
        //     //   isDeleted: false,
        //     // },
        //   },
        //   {
        //     model:database.BioDetail,
        //     as:"bio_detail"
        //   }
        // ],
      });
      return response;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.Color.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.Color.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.Color.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        await database.Color.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }
}

module.exports = ColorService;
