
const database = require("../models");

class RatingService {
  static async add(data) {
    try {
      let response = await database.Rating.create(data);
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAll() {
    try {
      return await database.Rating.findAll({});
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.Rating.findOne({
        where: {
          id: Number(id),
        }
      });
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.Rating.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.Rating.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.Rating.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        await database.Rating.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
}

module.exports = RatingService;
