const { Op } = require("sequelize");
const database = require("../models");
const sequelize = require("sequelize");
class StoreService {
  static async add(data) {
    try {
      let response = await database.Store.create(data);
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAll(where) {
    try {
      return await database.BusinessInformation.findAll({
        include: [
          {
            model: database.Product,
            as: "products",
            // if where is empty then it will return all products
            where: where,
          },
        ],
        raw: true,
      });
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getById(id) {
    try {
      console.log("ID", id);
      const response = await database.BusinessInformation.findOne({
        where: {
          id: Number(id),
          // isDeleted: false,
        },
        include: [
          {
            model: database.Product,
            as: "products",
            include: [
              {
                model: database.Comment,
                as: "productComments",
                include: [
                  {
                    model: database.User,
                    as: "user",
                  },
                ],
              },
              {
                model: database.Like,
                as: "productLikes",
                include: [
                  {
                    model: database.User,
                    as: "user",
                  },
                ],
              },
              {
                model: database.Like,
                as: "likes",
                attributes: ["id"],
              },
            ],
          },
          {
            model: database.Post,
            as: "posts",
            include: [
              {
                model: database.Comment,
                as: "comments",
                include: [
                  {
                    model: database.User,
                    as: "user",
                  },
                ],
              },
              {
                model: database.Like,
                as: "likes",
                include: [
                  {
                    model: database.User,
                    as: "user",
                  },
                ],
              },
            ],
          },
        ],
      });
      // console.log(JSON.parse(JSON.stringify(response)));
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getByName(slug, id) {
    try {
      const response = await database.BusinessInformation.findOne({
        where: {
          slug: slug,
          status: "Active",
        },
        include: [
          {
            model: database.User,
            as: "store_owner",
            attributes: ["firstName", "lastName", "userName", "logo_image", "banner_image", "jobTitle", "id"],
          },
          {
            model: database.Seller,
            as: "seller_detail",
            attributes: ["aboutUs", "firstName", "lastName"],
          },
        ],
        // where: {
        //   ...(slug && { slug: slug }),
        //   ...(id && { id: id }),
        // },
        // include: [
        //   {
        //     model: database.Post,
        //     as: "posts",
        //     include: [
        //       {
        //         model: database.Comment,
        //         as: "comments",
        //         include: [
        //           {
        //             model: database.User,
        //             as: "user",
        //           },
        //         ],
        //       },
        //       {
        //         model: database.Like,
        //         as: "likes",
        //         include: [
        //           {
        //             model: database.User,
        //             as: "user",
        //           },
        //         ],
        //       },
        //     ],
        //   },
        // ],
      });

      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async update(data) {
    try {
      const foundStore = await database.BusinessInformation.findOne({
        where: {
          id: Number(data.id),
        },
      });

      if (foundStore) {
        let response = await database.BusinessInformation.update(data, {
          where: {
            id: Number(data.id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.", error);
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.BusinessInformation.findOne({
        where: {
          id: Number(id),
          is_deleted: false,
        },
      });
      if (response) {
        await database.BusinessInformation.update(
          { is_deleted: true },
          {
            where: {
              id: Number(id),
            },
          }
        );
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async deleteStores(store_ids) {
    try {
        await database.BusinessInformation.update(
          { is_deleted: true },
          {
            where: {
              id: {
                [Op.in]: store_ids
              },
            },
          }
        );
        return true;
    } catch (error) {
      console.error("An error occured during deleting stores - service: ", error);
      throw new Error("An error occured during deleting stores!");
    }
  }
}

module.exports = StoreService;
