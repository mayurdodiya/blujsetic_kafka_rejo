const database = require("../models");
const { createWriteStream, mkdir } = require("fs");

class SellerPostService {
  static async add(data) {
    try {
      let response = await database.SellerPost.create(data);

      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAll() {
    try {
      const response = await database.SellerPost.findAll({});
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.SellerPost.findOne({
        where: {
          id: Number(id),
        },
      });

      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.SellerPost.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.SellerPost.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.SellerPost.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        await database.SellerPost.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
}

module.exports = SellerPostService;
