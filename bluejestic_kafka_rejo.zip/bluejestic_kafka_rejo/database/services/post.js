const database = require("../models");
const { createWriteStream, mkdir } = require("fs");

class PostService {
  static async add(data) {
    try {
      console.log(data);
      let response = await database.Post.create(data);

      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
  static async sharePost(data) {
    try {
      console.log(data);
      let response = await database.SharePost.create(data);

      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAll() {
    try {
      const response = await database.Post.findAll({
        include: [
          {
            model: database.Comment,
            as: "comments",
            include: [
              {
                model: database.User,
                as: "user",
              },
            ],
          },
          {
            model: database.Like,
            as: "likes",
            include: [
              {
                model: database.User,
                as: "user",
              },
            ],
          },
          {
            model: database.Media,
            as: "medias",
          },
        ],
      });
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAllUserPost(userId) {
    try {
      const response = await database.Post.findAll({
        where: { user_id: userId },
        include: [
          {
            model: database.Comment,
            as: "comments",
            include: [
              {
                model: database.User,
                as: "user",
              },
            ],
          },
          {
            model: database.Like,
            as: "likes",
            include: [
              {
                model: database.User,
                as: "user",
              },
            ],
          },
          {
            model: database.Media,
            as: "medias",
          },
        ],
      });
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAllGroupPost(groupId) {
    try {
      if (groupId) {
        const response = await database.Post.findAll({
          where: { group_id: groupId, post_for: "GROUP" },
          include: [
            {
              model: database.Comment,
              as: "comments",
              include: [
                {
                  model: database.User,
                  as: "user",
                },
                {
                  model: database.CommentReply,
                  as: "commentReply",
                  include: [
                    {
                      model: database.User,
                      as: "user",
                    },
                    {
                      model: database.Like,
                      as: "commentReplyLike",
                      include: [
                        {
                          model: database.User,
                          as: "user",
                        },
                      ],
                    },
                  ],
                },
                {
                  model: database.Like,
                  as: "likes",
                  include: [
                    {
                      model: database.User,
                      as: "user",
                    },
                  ],
                },
              ],
            },
            {
              model: database.Like,
              as: "likes",
              include: [
                {
                  model: database.User,
                  as: "user",
                },
              ],
            },
            {
              model: database.User,
              as: "user",
            },
          ],
        });
        return response;
      } else {
        const response = await database.Post.findAll({
          where: { post_for: "GROUP" },
          include: [
            {
              model: database.Comment,
              as: "comments",
              include: [
                {
                  model: database.User,
                  as: "user",
                },
                {
                  model: database.CommentReply,
                  as: "commentReply",
                  include: [
                    {
                      model: database.User,
                      as: "user",
                    },
                    {
                      model: database.Like,
                      as: "commentReplyLike",
                      include: [
                        {
                          model: database.User,
                          as: "user",
                        },
                      ],
                    },
                  ],
                },
                {
                  model: database.Like,
                  as: "likes",
                  include: [
                    {
                      model: database.User,
                      as: "user",
                    },
                  ],
                },
              ],
            },
            {
              model: database.Like,
              as: "likes",
              include: [
                {
                  model: database.User,
                  as: "user",
                },
              ],
            },
            {
              model: database.Media,
              as: "medias",
            },
            {
              model: database.User,
              as: "user",
            },
            {
              model: database.Like,
              as: "likes",
            },
          ],
        });
        return response;
      }
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.Post.findOne({
        where: {
          id: Number(id),
        },
        order: [
          [{ model: database.Comment, as: "comments" }, "createdAt", "ASC"],
          [{ model: database.Like, as: "likes" }, "createdAt", "ASC"],
          [{ model: database.Comment, as: "comments" }, { model: database.CommentReply, as: "commentReply" }, "createdAt", "ASC"],
          [{ model: database.Comment, as: "comments" }, { model: database.CommentReply, as: "commentReply" }, { model: database.Like, as: "commentReplyLike" }, "createdAt", "ASC"],
          [{ model: database.Comment, as: "comments" }, { model: database.Like, as: "likes" }, "createdAt", "ASC"],
          ["createdAt", "ASC"],
        ],
        include: [
          {
            model: database.Comment,
            as: "comments",
            include: [
              {
                model: database.User,
                as: "user",
              },
              {
                model: database.CommentReply,
                as: "commentReply",
                include: [
                  {
                    model: database.User,
                    as: "user",
                  },
                  {
                    model: database.Like,
                    as: "commentReplyLike",
                    include: [
                      {
                        model: database.User,
                        as: "user",
                      },
                    ],
                  },
                ],
              },
              {
                model: database.Like,
                as: "likes",
                include: [
                  {
                    model: database.User,
                    as: "user",
                  },
                ],
              },
            ],
          },
          {
            model: database.Like,
            as: "likes",
            include: [
              {
                model: database.User,
                as: "user",
              },
            ],
          },
          // {
          //   model: database.Media,
          //   as: "medias",
          // },
          {
            model: database.Group,
            as: "group",
            include: [
              {
                model: database.User,
                as: "user",
              },
            ],
          },
          {
            model: database.User,
            as: "user",
          },
        ],
      });
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.Post.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.Post.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.Post.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        await database.Post.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
  static async deleteSharePost(id) {
    try {
      const response = await database.SharePost.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        await database.SharePost.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async processUpload(File) {
    try {
      const { createReadStream, filename, mimetype } = await upload;
      const stream = createReadStream();
      const file = await storeUpload({ stream, filename, mimetype });
      // await File.create(Upload);

      return file;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async storeUpload({ stream, filename, mimetype }) {
    try {
      const id = shortid.generate();
      const path = `images/${id}-${filename}`;
      return new Promise((resolve, reject) =>
        stream
          .pipe(createWriteStream(path))
          .on("finish", () => resolve({ id, path, filename, mimetype }))
          .on("error", reject)
      );
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
}

module.exports = PostService;
