const database = require("../models");

class NotificationService {
  static async add(data) {
    try {
      let response = await database.Notification.create(data);
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAll() {
    try {
      return await database.Notification.findAll({});
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.Notification.findOne({
        where: {
          id: Number(id),
        },
      });
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.Notification.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.Notification.findOne({
          where: {
            id: Number(data.id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.Notification.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        await database.Notification.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
}

module.exports = NotificationService;
