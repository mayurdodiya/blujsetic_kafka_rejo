const database = require("../models");

class CreateOrderItemService {
  static async add(data, user_id) {
    try {
      let verifyProduct;
      let notAvailableProduct = [];
      let avilableProduct = [];
      let response;
      for (let i = 0; i < data.length; i++) {
        verifyProduct = await database.Product.findOne({
          where: { id: data[i].productId, is_deleted: false },
          raw: true,
        });
        if (!verifyProduct) {
          notAvailableProduct.push(data[i].productId);
        } else {
          avilableProduct.push({
            productId: verifyProduct.id,
            price: verifyProduct.price,
            quantity: verifyProduct.quantity,
            totalAmount: verifyProduct.quantity * verifyProduct.price,
            user_id: user_id,
          });
        }
      }

      if (notAvailableProduct.length > 0) {
        throw new Error(`Product note Found For this ProductID - ${notAvailableProduct}`);
      } else {
        for (let i = 0; i < avilableProduct.length; i++) {
          response = await database.CreateOrderItem.create(avilableProduct[i]);
        }
      }
      response = await database.CreateOrderItem.findAll({ user_id: user_id });
      console.log("response==============================================", response);
      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }
}

module.exports = CreateOrderItemService;
