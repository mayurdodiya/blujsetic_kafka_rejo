const database = require("../models");
const Sequelize = require("sequelize");
const { response } = require("express");

const Op = Sequelize.Op;

class MediaService {
  static async add(data) {
    try {
      //   let ImageUpload = data.image;
      console.log(data);
      let response = await database.Media.create(data);
      console.log(response);
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAll() {
    try {
      return await database.Media.findAll({});
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.Media.findOne({
        where: {
          id: Number(id),
        },
      });

      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.Media.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.Media.findOne({
          where: {
            id: Number(data.id),
            isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async delete(id) {
    try {
      return await database.Media.destroy({
        where: {
          id: Number(id),
        },
      });
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
}

module.exports = MediaService;
