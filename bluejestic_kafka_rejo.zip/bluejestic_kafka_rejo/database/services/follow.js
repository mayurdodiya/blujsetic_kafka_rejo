const database = require("../models");
class FollowService {
  static async add(data) {
    try {
      let response = await database.Follow.create(data);
      return response;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async getAll() {
    try {
      return await database.Follow.findAll({});
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.Follow.findOne({
        where: {
          id: Number(id),
        },
      });

      return response;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.Follow.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.Follow.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.Follow.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        await database.Follow.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }
}

module.exports = FollowService;
