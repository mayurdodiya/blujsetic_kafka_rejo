const database = require("../models");
const sequelize = require("sequelize");
class CategoryService {
  static async add(data) {
    try {
      let response = await database.Category.create(data);
      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getAll() {
    try {
      return await database.Category.findAll({
        where: {
          is_deleted: false,
        },
        include: [
          {
            model: database.Subcategory,
            as: "subCategory",
            attributes: ["id", "name", "description", "createdAt"],
            include: [
              {
                model: database.Childsubcategory,
                as: "childSubCategory",
                attributes: ["id", "name", "description", "createdAt"],
                // order: sequelize.literal("createdAt asc"),
              },
            ],
          },
        ],
        // deep order sorting
        // order: [
        //   [{ model: database.Subcategory, as: "subCategory" }, { model: database.Childsubcategory, as: "childSubCategory" }, "createdAt", "ASC"],
        //   [{ model: database.Subcategory, as: "subCategory" }, "createdAt", "ASC"],
        //   ["createdAt", "ASC"],
        // ],
      });
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.Category.findOne({
        where: {
          id: Number(id),
        },
      });

      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.Category.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.Category.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async delete(id) {
    try {
      console.log("RESPONSE");
      const response = await database.Category.findOne({
        where: {
          id: Number(id),
        },
      }).catch((e) => {
        console.log(e);
      });
      if (response) {
        await database.Category.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }
}

module.exports = CategoryService;
