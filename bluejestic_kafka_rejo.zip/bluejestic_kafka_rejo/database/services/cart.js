const { Op } = require("sequelize");
const database = require("../models");

class CartService {
  static async add(data) {
    try {
      let response = await database.Cart.create(data);
      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getAll() {
    try {
      return await database.Cart.findAll({});
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.Cart.findOne({
        where: {
          id: Number(id),
        },
      });
      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async getProductById(id, variant_id, user_id) {
    try {
      const response = await database.Cart.findOne({
        where: {
          parent_id: Number(id),
          user_id: user_id,
          ...(variant_id && {
            variant_id: variant_id,
          }),
        },
      });
      return response;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async update(data, userId) {
    try {
      let [response] = await database.Cart.update(data, {
        where: {
          parent_id: Number(data.parent_id),
          user_id: Number(userId),
        },
      });
      if (response) {
        response = await database.Cart.findOne({
          where: {
            parent_id: Number(data.parent_id),
          },
          order: [["createdAt", "DESC"]],
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  static async updateStatus(data, userId) {
    try {
      await database.Cart.update(data, {
        where: {
          user_id: Number(userId),
          status: {
            [Op.in]: ["cart_created", "cart_updated", "cart_abandoned"]
          }
        },
      });
      return true;
    } catch (error) {
      console.error("An error occurred while updating the cart status:", error);
      throw new Error("An error occurred while updating the cart status!");
    }
  }

  static async delete(id) {
    try {
      const response = await database.Cart.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        await database.Cart.update(
          {
            status: "cart_deleted"
          },
          {
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("An error occurred:", error);
      throw error;
    }
  }

  // Delete catrt items
  static async deleteCartItems(ids) {
    try {
        const [deletedCount] = await database.Cart.update(
          {
            status: "cart_deleted",
          },
          {
          where: {
            id: {
              [Op.in]: ids
            },
          },
        });
        return deletedCount;
    } catch (error) {
      console.error("An error occurred during the cart items deletion process: ", error);
      throw new Error("An error occurred during the cart items deletion process!");
    }
  }
}

module.exports = CartService;
