const { Op } = require("sequelize");
const database = require("../models");
class BillingAddressService {
  static async add(data, userId) {
    try {
      await database.BillingAddresses.update(
        {
          isDefault: false,
        },
        {
          where: {
            user_id: userId,
          }
        }
      );
      // console.log(update);
      let response = await database.BillingAddresses.create(data);
      return response;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async getAll(user_id) {
    try {
      return await database.BillingAddresses.findAll({
        where: {
          user_id: Number(user_id),
        },
        // order: [["createdAt", "DESC"]],
      });
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async getById(id, user_id) {
    try {
      const response = await database.BillingAddresses.findOne({
        where: {
          id: Number(id),
          user_id: user_id,
        },
      });
      return response;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async update(data, userId) {
    try {
      await database.BillingAddresses.update(
        {
          isDefault: false,
        },
        {
          where: {
            user_id: userId,
          }
        }
      );
      const billingAddress = await database.BillingAddresses.findOne({
        where: { id: data?.id },
      });

      if (!billingAddress) {
        return null
      }

      // Update
      let { id, ...payload } = data;
      for (let key in payload) {
        billingAddress[key] = payload[key];
      }
      await billingAddress.save();
      return billingAddress;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.BillingAddresses.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        console.log("delete response", response);
        await database.BillingAddresses.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }
}

module.exports = BillingAddressService;
