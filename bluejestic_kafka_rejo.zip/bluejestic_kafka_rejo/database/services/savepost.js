const database = require("../models");

class SavePostService {
  static async add(data) {
    try {
      let response = await database.SavePost.create(data);

      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAll() {
    try {
      const response = await database.SavePost.findAll({
        include: [
          {
            model: database.Post,
            as: "post",
            include: [
              {
                model: database.Comment,
                as: "comments",
              },
              {
                model: database.Like,
                as: "likes",
              }
            ]
          },
        ],
      });

      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.SavePost.findOne({
        where: {
          id: Number(id),
        },
      });

      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.SavePost.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.SavePost.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async delete(where) {
    try {
      const response = await database.SavePost.findOne({
        where: where
      });
      if (response) {
        await database.SavePost.destroy({
          where: where
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
}

module.exports = SavePostService;
