const { Post } = require("../models");
const { createWriteStream } = require("fs");
class PostService {
  static async add(data) {
    try {
      let response = await Post.create(data);

      return response;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async getAll() {
    try {
      return await Post.findAll({});
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.Post.findOne({
        where: {
          id: Number(id),
        },
      });

      return response;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.Post.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.Post.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.Post.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        await database.Post.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async processUpload(File) {
    try {
      const { createReadStream, filename, mimetype } = await upload;
      const stream = createReadStream();
      const file = await storeUpload({ stream, filename, mimetype });
      return file;
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }

  static async storeUpload({ stream, filename, mimetype }) {
    try {
      const id = shortid.generate();
      const path = `images/${id}-${filename}`;
      return new Promise((resolve, reject) =>
        stream
          .pipe(createWriteStream(path))
          .on("finish", () => resolve({ id, path, filename, mimetype }))
          .on("error", reject)
      );
    } catch (error) {
      console.error('An error occurred:', error);
      throw error;
    }
  }
}

module.exports = PostService;
