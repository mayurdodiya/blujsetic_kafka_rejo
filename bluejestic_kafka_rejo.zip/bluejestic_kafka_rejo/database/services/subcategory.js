const database = require("../models");
class SubCategoryService {
  static async add(data) {
    try {
      let response = await database.Subcategory.create(data);
      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getAll() {
    try {
      return await database.Subcategory.findAll({
        include: [
          {
            model: database.Category,
            as: "mainCategory",
          },
        ],
      });
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async getById(id) {
    try {
      const response = await database.Subcategory.findOne({
        where: {
          id: Number(id),
        },
        include: [
          {
            model: database.Category,
            as: "mainCategory",
          },
        ],
      });

      return response;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async update(data) {
    try {
      let [response] = await database.Subcategory.update(data, {
        where: {
          id: Number(data.id),
        },
      });
      if (response) {
        response = await database.Subcategory.findOne({
          where: {
            id: Number(data.id),
            // isDeleted: false,
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }

  static async delete(id) {
    try {
      const response = await database.Subcategory.findOne({
        where: {
          id: Number(id),
        },
      });
      if (response) {
        await database.Subcategory.destroy({
          where: {
            id: Number(id),
          },
        });
        return response;
      }
      return null;
    } catch (error) {
      console.error("Server started.");
      throw error;
    }
  }
}

module.exports = SubCategoryService;
