"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class livestreamProduct extends Model {
    static associate() {
      // DEFINE ASSOCIATION HERE
    }
  }
  livestreamProduct.init(
    {
      product_id: DataTypes.INTEGER,
      uuid: DataTypes.STRING,
      meeting_id: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "livestreamProduct",
    }
  );
  return livestreamProduct;
};
