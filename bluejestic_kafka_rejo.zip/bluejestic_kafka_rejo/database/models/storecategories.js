"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class StoreCategories extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      StoreCategories.belongsTo(models.Subcategory, {
        foreignKey: "subCategory_id",
        as: "subCategory",
      });

      StoreCategories.belongsTo(models.Subcategory, {
        foreignKey: "subCategory_id",
        as: "sub_category_data",
      });
      StoreCategories.belongsTo(models.Category, {
        foreignKey: "category_id",
        as: "category_data",
      });
    }
  }
  StoreCategories.init(
    {
      user_id: DataTypes.INTEGER,
      store_id: DataTypes.INTEGER,
      category_id: DataTypes.INTEGER,
      subCategory_id: DataTypes.INTEGER,
      childSubCategory_id: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "StoreCategories",
    }
  );
  return StoreCategories;
};
