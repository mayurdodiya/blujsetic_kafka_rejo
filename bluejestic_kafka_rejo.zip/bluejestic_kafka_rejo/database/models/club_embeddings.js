"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class club_embeddings extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  club_embeddings.init(
    {
      club_id: DataTypes.INTEGER,
      embedding: DataTypes.ARRAY(DataTypes.FLOAT),
      text: DataTypes.STRING(2000),
    },
    {
      sequelize,
      modelName: "club_embeddings",
      timestamps: false,
    }
  );
  return club_embeddings;
};
