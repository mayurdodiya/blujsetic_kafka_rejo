"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class ProductInventory extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here

      ProductInventory.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "inventoryPrice",
        onDelete: "cascade",
      });
    }
  }

  ProductInventory.init(
    {
      // category_id: DataTypes.INTEGER,
      // subCategory_id: DataTypes.INTEGER,
      // childSubCategory_id: DataTypes.INTEGER,
      price: DataTypes.STRING,
      listPrice: DataTypes.STRING,
      quantity: DataTypes.INTEGER,
      sku: DataTypes.STRING,
      product_id: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "ProductInventory",
    }
  );

  return ProductInventory;
};
