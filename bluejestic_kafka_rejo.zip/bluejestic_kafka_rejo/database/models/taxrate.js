"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Taxrate extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Taxrate.init(
    {
      store_id: DataTypes.STRING,
      seller_id: DataTypes.INTEGER,
      country: DataTypes.STRING,
      state: DataTypes.STRING,
      rate_percentage: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "Taxrate",
    }
  );
  return Taxrate;
};
