"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Message extends Model {
    static associate({ Conversation, User, shareMessage }) {
      // define association here
      this.belongsTo(Conversation, {
        foreignKey: "conversationId",
        as: "conversation",
        onDelete: "CASCADE",
      });

      this.belongsTo(User, {
        foreignKey: "senderId",
        as: "user",
      });

      this.belongsTo(Message, {
        foreignKey: "replyMessageId",
        as: "replyMessage",
      });

      this.hasOne(shareMessage, {
        foreignKey: "message_id",
        as: "shared_content",
      });
    }
  }
  Message.init(
    {
      body: {
        type: DataTypes.STRING,
      },
      images: {
        type: DataTypes.ARRAY(DataTypes.STRING),
        defaultValue: [],
      },
      share_message_type: {
        type: DataTypes.STRING,
      },
      conversationId: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      senderId: {
        type: DataTypes.INTEGER,
        allowNull: false,
      },
      replyMessageId: {
        type: DataTypes.INTEGER,
        allowNull: true,
      },
      isSeen: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
        allowNull: false,
      },
      reaction_emoji_id: DataTypes.INTEGER,
      isEdited: {
        type: DataTypes.BOOLEAN,
      },
    },
    {
      sequelize,
      modelName: "Message",
      tableName: "messages",
    }
  );
  return Message;
};
