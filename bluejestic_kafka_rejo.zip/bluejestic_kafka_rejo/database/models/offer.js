"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Offer extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  Offer.init(
    {
      parent_id: DataTypes.INTEGER,
      title: DataTypes.STRING,
      detail: DataTypes.STRING,
      description: DataTypes.STRING,
      code: DataTypes.STRING,
      expiry_date: DataTypes.DATE,
      offer_for: DataTypes.STRING,
      is_active: { type: DataTypes.BOOLEAN, defaultValue: false },
      is_deleted: { type: DataTypes.BOOLEAN, defaultValue: false },
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
      meta: DataTypes.JSON,
    },
    {
      sequelize,
      modelName: "Offer",
    }
  );
  return Offer;
};
