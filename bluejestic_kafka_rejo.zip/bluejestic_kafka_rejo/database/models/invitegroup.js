"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class InviteGroup extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      InviteGroup.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user",
        onDelete: "cascade",
      });
    }
  }
  InviteGroup.init(
    {
      user_id: DataTypes.INTEGER,
      group_id: DataTypes.INTEGER,
      isJoin: { type: DataTypes.BOOLEAN, defaultValue: false },
    },
    {
      sequelize,
      modelName: "InviteGroup",
    }
  );
  return InviteGroup;
};
