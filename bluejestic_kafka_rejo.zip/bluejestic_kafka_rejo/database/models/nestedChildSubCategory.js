"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class NestedChildSubcategory extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      NestedChildSubcategory.belongsTo(models.Category, {
        foreignKey: "category_id",
        as: "mainCategory",
      });
      NestedChildSubcategory.belongsTo(models.Subcategory, {
        foreignKey: "sub_category_id",
        as: "subCategory",
      });
      NestedChildSubcategory.belongsTo(models.Subcategory, {
        foreignKey: "sub_category_id",
        as: "childSubCategory",
      });
      NestedChildSubcategory.belongsTo(models.Childsubcategory, {
        foreignKey: "child_sub_category_id",
        as: "nestedChildSubCategory",
      });
    }
  }
  NestedChildSubcategory.init(
    {
      category_id: DataTypes.INTEGER,
      sub_category_id: DataTypes.INTEGER,
      child_sub_category_id: DataTypes.INTEGER,
      position: DataTypes.INTEGER,
      name: DataTypes.STRING,
      description: DataTypes.STRING,
      media: DataTypes.STRING,
      banner_media: DataTypes.STRING,
      is_deleted: DataTypes.BOOLEAN,
      slug: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "NestedChildSubcategory",
    }
  );
  return NestedChildSubcategory;
};
