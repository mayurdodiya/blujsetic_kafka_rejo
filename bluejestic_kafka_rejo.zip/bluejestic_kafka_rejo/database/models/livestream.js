"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class LiveStream extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }

  LiveStream.init(
    {
      meeting_id: DataTypes.STRING,
      title: DataTypes.STRING,
      record_on_start: DataTypes.BOOLEAN,
      live_stream_on_start: DataTypes.BOOLEAN,
      status: DataTypes.STRING,
      uuid: DataTypes.STRING,
      seller_id: DataTypes.INTEGER,
      store_id: DataTypes.INTEGER,
      date: DataTypes.STRING,
      time: DataTypes.STRING,
      final_date: DataTypes.DATE,
      media_id: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER,
      endTime: DataTypes.DATE,
      startTime: DataTypes.DATE,
      isQuick: { type: DataTypes.BOOLEAN, defaultValue: false },
    },
    {
      sequelize,
      modelName: "LiveStream",
    }
  );

  return LiveStream;
};
