"use strict";
const { Model } = require("sequelize");
const database = require("../models/index");

module.exports = (sequelize, DataTypes) => {
  class Seller extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Seller.hasOne(models.BusinessInformation, {
        foreignKey: "seller_id",
        as: "personalInformation",
      });
      Seller.hasOne(models.BusinessInformation, {
        foreignKey: "seller_id",
        as: "seller_detail",
      });

      Seller.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user",
        onDelete: "cascade",
      });

      // Seller.hasOne(models.User, {
      //   foreignKey: "user_id",
      //   as: "seller_detail_data",
      // });

      Seller.hasOne(models.SellerPersonalInfo, {
        foreignKey: "seller_id",
        as: "seller_personal_info",
      });
      Seller.hasMany(models.SellerIdentification, {
        foreignKey: "seller_id",
        as: "seller_identification",
      });
      Seller.hasOne(models.SellerBusinessDetail, {
        foreignKey: "seller_id",
        as: "seller_business_detail",
      });
      Seller.hasOne(models.SellerConnectedAccount, {
        foreignKey: "seller_id",
        as: "seller_connected_accounts",
      });
      Seller.hasMany(models.SellerDocumentsApproval, {
        foreignKey: "seller_id",
        as: "seller_documents_info",
      });
    }
  }
  Seller.init(
    {
      firstName: DataTypes.STRING,
      lastName: DataTypes.STRING,
      email: DataTypes.STRING,
      password: DataTypes.STRING,
      ext: DataTypes.STRING,
      mobileNumber: DataTypes.STRING,
      phoneNumber: DataTypes.STRING,
      jobTitle: DataTypes.STRING,
      isDeleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
      status_updated_by_new: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: null
      },
      isOnboardCompleted: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      onboardCompletedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null
      },
      status_updated_at_new: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null
      },
      aboutUs: DataTypes.STRING,
      language: DataTypes.STRING,
      isDetails5OnboardingCompletedNew: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      details5OnboardingCompletedAtNew: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null,
      },
      dateFormat: DataTypes.STRING,
      timeZone: DataTypes.STRING,
      currentQueryForVerification: DataTypes.STRING,
      isSellerInfoVerified: DataTypes.BOOLEAN,
      user_id: {
        type: DataTypes.INTEGER,
        references: {
          model: database.User,
          key: "id",
        },
      },
      is_user: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      isSellerVerify: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      social_type: DataTypes.STRING,
      isSocial: { type: DataTypes.BOOLEAN, defaultValue: false },
      userName: DataTypes.STRING,
      accountType: DataTypes.STRING,
      is_tax_calculation: DataTypes.BOOLEAN,
      is_price_include_tax: DataTypes.BOOLEAN,
      tax_categories: DataTypes.ARRAY(DataTypes.STRING),
      isPopup: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      currentStepForSellerOnboarding: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
      },
      isVerify: { type: DataTypes.BOOLEAN, defaultValue: false },
      profile_image: DataTypes.STRING,
      sellerApprovedStatus: { type: DataTypes.STRING, defaultValue: "pending" },
      sellerApprovedStatusNew: { type: DataTypes.STRING, defaultValue: null, allowNull: true },
      sellerApprovalNote: { type: DataTypes.STRING, allowNull: true, defaultValue: "" },
      isPaymentOnboardingCompleted: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      details_submitted: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      country: {
        type: DataTypes.STRING,
        defaultValue: "US",
      },
      stripeAccountId: {
        type: DataTypes.STRING,
      },
      otpForWithdrawal: {
        type: DataTypes.STRING,
      },
      otpForWithdrawalExpiry: {
        type: DataTypes.DATE,
      },
      otpForVerification: {
        type: DataTypes.STRING,
      },
      otpVerificationExpiry: {
        type: DataTypes.DATE,
      },
      withdrawableAmount: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      // canReceivePayouts: {
      //   type: DataTypes.BOOLEAN,
      //   defaultValue: false
      // },
      // isConnectAccountDeleted: {
      //   type: DataTypes.BOOLEAN,
      //   allowNull: true,
      //   defaultValue: null
      // },

    },
    {
      sequelize,
      modelName: "Seller",
    }
  );
  return Seller;
};
