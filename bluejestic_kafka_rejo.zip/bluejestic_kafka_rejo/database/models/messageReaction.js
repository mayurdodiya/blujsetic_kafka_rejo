"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class MessageReaction extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */

    //* relation between tables
    static associate(models) {
      // define association here
    }
  }
  //* schema init
  MessageReaction.init(
    {
      user_id: DataTypes.INTEGER,
      emoji_id: DataTypes.INTEGER,
      message_id: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "MessageReaction",
    }
  );
  return MessageReaction;
};
