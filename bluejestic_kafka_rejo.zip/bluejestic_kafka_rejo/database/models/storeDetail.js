"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class storeDetail extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      storeDetail.belongsTo(models.BusinessInformation, {
        foreignKey: "store_id",
        as: "store_detail",
      });
    }
  }
  storeDetail.init(
    {
      store_id: DataTypes.INTEGER,
      is_minimum_purchase_amount: DataTypes.BOOLEAN,
      min_amount: DataTypes.INTEGER,
      is_flat_rate: DataTypes.BOOLEAN,
      flat_rate: DataTypes.INTEGER,
      is_internationalShipping: DataTypes.BOOLEAN,
      is_FreeShipping: DataTypes.BOOLEAN,
      tax_rate_in_percentage: DataTypes.INTEGER,
      state_tax_rate_id: DataTypes.INTEGER,
      is_applyTaxShipping: DataTypes.BOOLEAN,
      is_enableLocationBasedTax: DataTypes.BOOLEAN,
      about: DataTypes.STRING,
      owner_name: DataTypes.STRING,
      email: DataTypes.STRING,
      phone: DataTypes.STRING,
      address: DataTypes.STRING,
      zipcode: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "StoreDetail",
    }
  );
  return storeDetail;
};
