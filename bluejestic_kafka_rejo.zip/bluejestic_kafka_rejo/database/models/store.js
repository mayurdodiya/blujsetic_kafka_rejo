'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Store extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Store.hasMany(models.Product,{
        foreignKey:"store_id",
        as:'products'
      })

      Store.hasMany(models.Post,{
        foreignKey:"owner_id",
        as:"posts"
      })

      Store.hasMany(models.Follow,{
        foreignKey:"follower_id",
        as:"following"
      })

      Store.hasMany(models.Follow,{
        foreignKey:"following_id",
        as:"follower"
      })

      Store.hasOne(models.About,{
        foreignKey:"parent_id",
        as:"about"
      })

      Store.hasMany(models.Notification,{
        foreignKey:"send_to",
        as:"notification"
      })
    }
  }
  Store.init({
    parent_id: DataTypes.INTEGER,
    owner_id: DataTypes.INTEGER,
    category_id: DataTypes.INTEGER,
    title:DataTypes.STRING,
    description:DataTypes.STRING,
    city: DataTypes.STRING,
    state: DataTypes.STRING,
    country: DataTypes.STRING,
    total_products: DataTypes.INTEGER,
    sold: DataTypes.INTEGER,
    meta: DataTypes.JSON,
    is_deleted: {type:DataTypes.BOOLEAN, defaultValue:false},
    created_by: DataTypes.STRING,
    updated_by: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'Store',
  });
  return Store;
};