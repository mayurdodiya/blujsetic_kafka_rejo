"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Shipping extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Shipping.belongsTo(models.Product, {
        foreignKey: "parent_id",
        as: "shipping",
      });
    }
  }
  Shipping.init(
    {
      parent_id: DataTypes.INTEGER,
      shippingPrice: DataTypes.FLOAT,
      zipCode: DataTypes.INTEGER,
      processingTime: DataTypes.STRING,
      freeShipping: DataTypes.BOOLEAN,
      handleFee: DataTypes.FLOAT,
      productWeight: DataTypes.FLOAT,
      productLength: DataTypes.FLOAT,
      productHeight: DataTypes.FLOAT,
      productWidth: DataTypes.FLOAT,
      shippingServices: DataTypes.STRING,
      shipping_for: DataTypes.STRING,
      meta: DataTypes.JSON,
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "Shipping",
    }
  );
  return Shipping;
};
