"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class VariationOption extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here

      VariationOption.hasMany(models.ProductConfiguration, {
        foreignKey: "variant_option_id",
        as: "variant_option",
        onDelete: "cascade",
      });
      VariationOption.belongsTo(models.Variation, {
        foreignKey: "variation_id",
        as: "variantion_name",
        onDelete: "cascade",
      });
      VariationOption.belongsTo(models.Variation, {
        foreignKey: "variation_id",
        as: "data",
        // onDelete: "cascade",
      });
    }
  }

  VariationOption.init(
    {
      value: DataTypes.STRING,
      variation_id: DataTypes.INTEGER,
      product_id: DataTypes.INTEGER,
      colorCode: DataTypes.STRING,
      store_id: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "VariationOption",
    }
  );

  return VariationOption;
};
