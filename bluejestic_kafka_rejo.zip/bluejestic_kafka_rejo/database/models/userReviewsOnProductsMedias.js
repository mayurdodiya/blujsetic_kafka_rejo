"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class UserReviewsOnProductsMedias extends Model {
    static associate(models) {
      UserReviewsOnProductsMedias.belongsTo(models.UserReviewsOnProducts, {
        foreignKey: "userReviewsOnProductsId",
        as: "userReviewsOnProducts_details",
      });
    }
  }

  UserReviewsOnProductsMedias.init(
    {
      userReviewsOnProductsId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "UserReviewsOnProducts",
          key: "id",
        },
      },
      position: {
        type: DataTypes.SMALLINT,
        allowNull: true,
      },
      media_type: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
      },
      media_for: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
      },
      url: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
      },
    },
    {
      sequelize,
      modelName: "UserReviewsOnProductsMedias",
      tableName: "UserReviewsOnProductsMedias",
      freezeTableName: true,
    }
  );
  return UserReviewsOnProductsMedias;
};
