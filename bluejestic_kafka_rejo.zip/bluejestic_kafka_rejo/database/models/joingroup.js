"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class JoinGroup extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      JoinGroup.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "joingroups",
        onDelete: "cascade",
      });
      JoinGroup.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "members",
        onDelete: "cascade",
      });
      JoinGroup.belongsTo(models.Group, {
        foreignKey: "group_id",
        as: "groups",
      });
    }
  }
  JoinGroup.init(
    {
      user_id: DataTypes.INTEGER,
      group_id: DataTypes.INTEGER,
      groupType: DataTypes.STRING,
      isAdmin: { type: DataTypes.BOOLEAN, defaultValue: false },
      isOwner: { type: DataTypes.BOOLEAN, defaultValue: false },
    },
    {
      sequelize,
      modelName: "JoinGroup",
    }
  );
  return JoinGroup;
};
