"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class ProductShippingDetails extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      ProductShippingDetails.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "shipping",
        onDelete: "cascade",
      });
    }
  }
  ProductShippingDetails.init(
    {
      user_id: DataTypes.INTEGER,
      product_id: DataTypes.INTEGER,
      weightValue: DataTypes.INTEGER,
      weightUnit: DataTypes.STRING,
      length: DataTypes.INTEGER,
      width: DataTypes.INTEGER,
      height: DataTypes.INTEGER,
      unit: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "ProductShippingDetails",
    }
  );
  return ProductShippingDetails;
};
