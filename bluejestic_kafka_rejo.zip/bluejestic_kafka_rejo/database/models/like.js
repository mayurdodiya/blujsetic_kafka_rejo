"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Like extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Like.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user",
        onDelete: "cascade",
      });
      Like.belongsTo(models.Product, {
        foreignKey: "parent_id",
        as: "productLikes",
      });
      // Like.belongsTo(models.Post, {
      //   foreignKey: "parent_id",
      //   as: "likes"
      // });
      // Like.belongsTo(models.CommentReply, {
      //   foreignKey: "parent_id",
      //   as: "commentReplyLike",
      // });
      // Like.belongsTo(models.SellerPost, {
      //   foreignKey: "parent_id",
      //   as: "sellerpostlike",
      // });
      // Like.belongsTo(models.GroupPost, {
      //   foreignKey: "parent_id",
      //   as: "groupPostLikes",
      // });
      // Like.belongsTo(models.SharePost, {
      //   foreignKey: "share_post_id",
      //   as: "likes",
      // });
    }
  }
  Like.init(
    {
      post_id: DataTypes.INTEGER,
      comment_id: DataTypes.INTEGER,
      comment_reply_id: DataTypes.INTEGER,
      product_id: DataTypes.INTEGER,
      seller_post_id: DataTypes.INTEGER,
      group_post_id: DataTypes.INTEGER,
      share_post_id: DataTypes.INTEGER,
      like_for: DataTypes.STRING,
      user_id: DataTypes.INTEGER,
      meta: DataTypes.JSON,
      parent_id: DataTypes.INTEGER,
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "Like",
    }
  );
  return Like;
};
