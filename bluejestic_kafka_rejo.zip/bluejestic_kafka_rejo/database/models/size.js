'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Size extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Size.belongsTo(models.Product,
        {
          foreignKey: "product_id",
          as: "sizes",
          onDelete: 'cascade'
        })
    }
  }
  Size.init({
    parent_id: DataTypes.INTEGER,
    product_id: DataTypes.INTEGER,
    user_id: DataTypes.INTEGER,
    size: DataTypes.STRING,
    size_for: { type: DataTypes.STRING, defaultValue: "PRODUCT" },
    created_by: DataTypes.STRING,
    updated_by: DataTypes.STRING,
    is_deleted: { type: DataTypes.BOOLEAN, defaultValue: false },
    meta: DataTypes.JSON
  }, {
    sequelize,
    modelName: 'Size',
  });
  return Size;
};