"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Media extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      // Media.belongsTo(models.Post, {
      //   foreignKey: "parent_id",
      //   as: "medias",
      // });

      Media.hasOne(models.ProductItem, {
        foreignKey: "image_id",
        as: "image",
        onDelete: "cascade",
      });
    }
  }
  Media.init(
    {
      parent_id: DataTypes.INTEGER,
      media: DataTypes.STRING(10000),
      media_type: DataTypes.STRING,
      shopify_image_id: DataTypes.STRING,
      media_for: {
        type: DataTypes.STRING,
      },
      meta: DataTypes.STRING,
      media_tags: DataTypes.STRING,
      owner_id: DataTypes.INTEGER,
      media_setting_id: DataTypes.INTEGER,
      is_deleted: { type: DataTypes.BOOLEAN, defaultValue: false },
      created_by: { type: DataTypes.STRING, defaultValue: "system" },
      updated_by: { type: DataTypes.STRING, defaultValue: "system" },
    },
    {
      sequelize,
      modelName: "Media",
    }
  );
  return Media;
};
