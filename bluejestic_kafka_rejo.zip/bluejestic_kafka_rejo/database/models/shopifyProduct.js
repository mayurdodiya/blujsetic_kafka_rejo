"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class ShopifyProduct extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here

      ShopifyProduct.hasMany(models.ProductItem, {
        foreignKey: "product_id",
        as: "variants",
        onDelete: "cascade",
      });

      ShopifyProduct.hasMany(models.ProductMedia, {
        foreignKey: "product_id",
        as: "images",
        // onDelete: "cascade",
      });

      // Product.hasOne(models.ProductSEO, {
      //   foreignKey: "parent_id",
      //   as: "productSEO",
      //   onDelete: "cascade",
      // });
      // // Product.hasOne(models.Shipping, {
      // //   foreignKey: "parent_id",
      // //   as: "shipping",
      // // });
      ShopifyProduct.hasOne(models.ProductShippingDetails, {
        foreignKey: "product_id",
        as: "shipping",
        onDelete: "cascade",
      });

      ShopifyProduct.hasMany(models.Variation, {
        foreignKey: "product_id",
        as: "options",
        onDelete: "cascade",
      });

      ShopifyProduct.hasMany(models.ProductCategories, {
        foreignKey: "product_id",
        as: "categories",
        onDelete: "cascade",
      });

      ShopifyProduct.hasMany(models.ProductAttributes, {
        foreignKey: "product_id",
        as: "attributes",
        onDelete: "cascade",
      });

      // Product.hasMany(models.ProductOtherInformations, {
      //   foreignKey: "product_id",
      //   as: "other",
      //   onDelete: "cascade",
      // });
      // Product.hasMany(models.Color, {
      //   foreignKey: "product_id",
      //   as: "colors",
      //   onDelete: "cascade",
      // });
      // Product.hasMany(models.Size, {
      //   foreignKey: "product_id",
      //   as: "sizes",
      //   onDelete: "cascade",
      // });
      // Product.hasMany(models.ProductAttributes, {
      //   foreignKey: "product_id",
      //   as: "attributes",
      //   onDelete: "cascade",
      // });
      // Product.hasMany(models.ProductCategories, {
      //   foreignKey: "product_id",
      //   as: "categories",
      //   onDelete: "cascade",
      // });
      // Product.hasMany(models.Comment, {
      //   foreignKey: "product_id",
      //   as: "productComments",
      //   onDelete: "cascade",
      // });
      // Product.hasMany(models.SharePost, {
      //   foreignKey: "product_id",
      //   as: "products",
      // });
      // Product.hasMany(models.Like, {
      //   foreignKey: "product_id",
      //   as: "productLikes",
      //   onDelete: "cascade",
      // });
      // Product.belongsTo(models.BusinessInformation, {
      //   foreignKey: "store_id",
      //   as: "store",
      // });
      // Product.belongsTo(models.ConfirmedOrder, {
      //   foreignKey: "productId",
      //   as: "orderProducts",
      // });
    }
  }

  ShopifyProduct.init(
    {
      store_id: DataTypes.INTEGER,
      title: DataTypes.STRING,
      description: DataTypes.STRING(10000),
      isFeature: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      isActive: { type: DataTypes.BOOLEAN, defaultValue: true },
      metaTitle: DataTypes.STRING,
      keywords: DataTypes.STRING,
      metaDescription: DataTypes.STRING,
      isVisible: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      shopify_product_id: DataTypes.STRING,
      isFreeShipping: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      condition: DataTypes.STRING,
      is_deleted: { type: DataTypes.BOOLEAN, defaultValue: false },
    },
    {
      sequelize,
      modelName: "ShopifyProduct",
    }
  );

  return ShopifyProduct;
};
