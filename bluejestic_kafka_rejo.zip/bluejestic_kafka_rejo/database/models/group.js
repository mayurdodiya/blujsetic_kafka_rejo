"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Group extends Model {
    static associate(models) {
      // DEFINE ASSOCIATION HERE
      Group.hasMany(models.JoinGroup, {
        foreignKey: "group_id",
        as: "groups",
        onDelete: "cascade",
      });
      Group.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user",
        onDelete: "cascade",
      });
      Group.belongsTo(models.Category, {
        foreignKey: "category_id",
        as: "categoryDetails",
      });
      Group.belongsTo(models.Subcategory, {
        foreignKey: "subCategory_id",
        as: "sub_Category",
      });
      Group.hasMany(models.Post, {
        foreignKey: "group_id",
        as: "posts",
        onDelete: "cascade",
      });
    }
  }
  Group.init(
    {
      name: DataTypes.STRING,
      description: DataTypes.STRING,
      hashtags: DataTypes.ARRAY(DataTypes.STRING),
      category_id: DataTypes.INTEGER,
      media_id: DataTypes.INTEGER,
      coverImage: DataTypes.STRING,
      bannerImage: DataTypes.STRING,
      meta: DataTypes.JSON,
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
      category: DataTypes.STRING,
      slug: DataTypes.STRING,
      logo_image: DataTypes.STRING,
      banner_image: DataTypes.STRING,
      isActive: {
        type: DataTypes.BOOLEAN,
        defaultValue: true
      },
      privacy: {
        type: DataTypes.STRING,
        defaultValue: "Public",
      },
      user_id: DataTypes.INTEGER,
      subCategory_id: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "Group",
    }
  );
  return Group;
};
