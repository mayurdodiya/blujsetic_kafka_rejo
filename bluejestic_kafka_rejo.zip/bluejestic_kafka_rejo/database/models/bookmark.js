"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Bookmark extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Bookmark.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user",
        onDelete: "cascade",
      });
      Bookmark.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "bookmark",
      });
      Bookmark.belongsTo(models.BookmarkCollection, {
        foreignKey: "collection_id",
        as: "collection",
      });
      Bookmark.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "products",
      });
      Bookmark.belongsTo(models.BookmarkCollection, {
        foreignKey: "collection_id",
        as: "bookmark_product",
      });
    }
  }
  Bookmark.init(
    {
      product_id: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER,
      bookmark_for: DataTypes.STRING,
      collection_id: DataTypes.INTEGER,
      is_deleted: { type: DataTypes.BOOLEAN, defaultValue: false },
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
      meta: DataTypes.JSON,
    },
    {
      sequelize,
      modelName: "Bookmark",
    }
  );
  return Bookmark;
};
