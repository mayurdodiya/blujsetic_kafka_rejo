"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class product_embeddings extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  product_embeddings.init(
    {
      "product_id": DataTypes.INTEGER,
      "text": DataTypes.STRING(2000),
      "product_category_id": DataTypes.INTEGER,
      "embedding": DataTypes.ARRAY(DataTypes.FLOAT),
    },
    {
      sequelize,
      modelName: "product_embeddings",
      timestamps: false,
    }
  );
  return product_embeddings;
};
