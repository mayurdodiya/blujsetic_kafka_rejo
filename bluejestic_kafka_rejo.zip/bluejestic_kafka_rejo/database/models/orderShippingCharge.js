"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class OrderShippingCharge extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      OrderShippingCharge.belongsTo(models.OrderMaster, {
        foreignKey: "order_master_id",
        as: "order_shipping_charge",
        onDelete: "cascade",
      });
    }
  }
  OrderShippingCharge.init(
    {
      store_id: DataTypes.INTEGER,
      amout: DataTypes.FLOAT,
      order_master_id: DataTypes.INTEGER,
      ship_charge: DataTypes.FLOAT
    },
    {
      sequelize,
      modelName: "OrderShippingCharge",
    }
  );
  return OrderShippingCharge;
};
