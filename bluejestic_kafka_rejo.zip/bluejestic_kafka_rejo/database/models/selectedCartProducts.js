"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class SelectedCartItems extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  SelectedCartItems.init(
    {
      product_id: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER,
      store_id: DataTypes.INTEGER,
      quantity: DataTypes.INTEGER,
      isSell: DataTypes.BOOLEAN,
    },
    {
      sequelize,
      modelName: "SelectedCartItems",
    }
  );
  return SelectedCartItems;
};
