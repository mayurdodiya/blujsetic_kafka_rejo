"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class ProductConfiguration extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      // ProductConfiguration.hasOne(models.VariationOption, {
      //   foreignKey: "variant_option_id",
      //   as: "variant_option",
      //   // onDelete: "cascade",
      // });

      ProductConfiguration.belongsTo(models.ProductItem, {
        foreignKey: "product_item_id",
        as: "product_item",
        onDelete: "cascade",
      });

      ProductConfiguration.belongsTo(models.VariationOption, {
        foreignKey: "variant_option_id",
        as: "variant_option",
        onDelete: "cascade",
      });
    }
  }

  ProductConfiguration.init(
    {
      product_id: DataTypes.INTEGER,
      product_item_id: DataTypes.INTEGER,
      variant_option_id: DataTypes.INTEGER,
      store_id: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "ProductConfiguration",
    }
  );

  return ProductConfiguration;
};
