"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class InvitedUsersGroup extends Model {
    static associate({ User, Conversation }) {
      this.belongsTo(User, {
        foreignKey: "user_id",
        as: "user",
      });
      this.belongsTo(User, {
        foreignKey: "invited_user_id",
        as: "invitedUser",
      });
      this.belongsTo(Conversation, {
        foreignKey: "group_id",
        as: "groupDetail",
      });
    }
  }

  InvitedUsersGroup.init(
    {
      group_id: {
        type: DataTypes.INTEGER,
      },
      user_id: {
        type: DataTypes.INTEGER,
      },
      invited_user_id: {
        type: DataTypes.INTEGER,
      },
      status: {
        type: DataTypes.STRING,
        validate: {
          isIn: [["pending", "accepted", "rejected"]],
        },
        defaultValue: "pending",
      },
      is_deleted: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
    },
    {
      sequelize,
      modelName: "InvitedUsersGroup",
      tableName: "InvitedUsersGroups",
    }
  );
  return InvitedUsersGroup;
};
