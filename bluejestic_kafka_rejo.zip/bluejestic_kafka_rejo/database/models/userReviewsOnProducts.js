"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class UserReviewsOnProducts extends Model {
    static associate(models) {
      UserReviewsOnProducts.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user_details",
      });
      UserReviewsOnProducts.belongsTo(models.Seller, {
        foreignKey: "seller_id",
        as: "seller_details",
      });
      UserReviewsOnProducts.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "product_details",
      });
      UserReviewsOnProducts.belongsTo(models.BusinessInformation, {
        foreignKey: "store_id",
        as: "store_details",
      });
      UserReviewsOnProducts.belongsTo(models.OrderMaster, {
        foreignKey: "order_master_id",
        as: "order_master_details",
      });
      UserReviewsOnProducts.belongsTo(models.OrderItems, {
        foreignKey: "order_items_id",
        as: "order_items_details",
      });
      UserReviewsOnProducts.hasMany(models.UserReviewsOnProductsMedias, {
        foreignKey: "userReviewsOnProductsId",
        as: "userReviewsOnProductsMedias",
      });
    }
  }

  UserReviewsOnProducts.init(
    {
      product_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "Products",
          key: "id",
        },
      },
      user_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "Users",
          key: "id",
        },
      },
      seller_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "Sellers",
          key: "id",
        },
      },
      order_items_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "OrderItems",
          key: "id",
        },
      },
      order_master_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "OrderMasters",
          key: "id",
        },
      },
      store_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "BusinessInformations",
          key: "id",
        },
      },
      overAllRating: {
        type: DataTypes.FLOAT,
        validate: {
          max: 5,
          min: 0,
        },
      },
      title: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      details: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
      },
    },
    {
      sequelize,
      modelName: "UserReviewsOnProducts",
      tableName: "UserReviewsOnProducts",
      freezeTableName: true,
    }
  );
  return UserReviewsOnProducts;
};
