"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class SelectedShippingMethod extends Model {
    static associate(models) { 
      SelectedShippingMethod.belongsTo(models.Seller, {
        foreignKey: "seller_id",
        as: "seller",
      });

      // SelectedShippingMethod.hasMany(models.ShippingMethod, {
      //   foreignKey: "shipping_method_id",
      //   as: "selected_shipping_method",
      //   // onDelete: "cascade",
      // });

      SelectedShippingMethod.belongsTo(models.ShippingMethod, {
        foreignKey: "shipping_method_id",
        as: "selected_shipping_method",
        onDelete: "cascade",
      });
    }
  }

  SelectedShippingMethod.init(
    {
      shipping_method_id: DataTypes.INTEGER,
      delivery_service_id: DataTypes.INTEGER,
      seller_id: DataTypes.INTEGER,
      is_active: { type: DataTypes.BOOLEAN, defaultValue: true },
    },
    {
      sequelize,
      modelName: "SelectedShippingMethod",
      timestamps: true,
      paranoid: true,
    }
  );

  return SelectedShippingMethod;
};
