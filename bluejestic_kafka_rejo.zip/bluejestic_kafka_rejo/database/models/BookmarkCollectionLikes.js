"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class BookmarkCollectionLikes extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here

      BookmarkCollectionLikes.belongsTo(models.BookmarkCollection, {
        foreignKey: "collection_id",
        as: "likes",
      });

      BookmarkCollectionLikes.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user",
        onDelete: "cascade",
      });

      BookmarkCollectionLikes.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "like_user",
        onDelete: "cascade",
      });
    }
  }
  BookmarkCollectionLikes.init(
    {
      collection_id: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "BookmarkCollectionLikes",
    }
  );
  return BookmarkCollectionLikes;
};
