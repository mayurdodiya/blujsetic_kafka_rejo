"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Subcategory extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Subcategory.belongsTo(models.Category, {
        foreignKey: "category_id",
        as: "mainCategory",
      });
      Subcategory.belongsTo(models.Category, {
        foreignKey: "category_id",
        as: "subCategory",
      });
      Subcategory.hasMany(models.Childsubcategory, {
        foreignKey: "sub_category_id",
        as: "childSubCategory",
      });
      Subcategory.hasOne(models.StoreCategories, {
        foreignKey: "subCategory_id",
        as: "sub_category_data",
      });
    }
  }
  Subcategory.init(
    {
      category_id: DataTypes.INTEGER,
      product_id: DataTypes.INTEGER,
      name: DataTypes.STRING,
      description: DataTypes.STRING,
      media: DataTypes.STRING,
      banner_media: DataTypes.STRING,
      position: DataTypes.INTEGER,
      meta: DataTypes.JSON,
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
      slug: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "Subcategory",
    }
  );
  return Subcategory;
};
