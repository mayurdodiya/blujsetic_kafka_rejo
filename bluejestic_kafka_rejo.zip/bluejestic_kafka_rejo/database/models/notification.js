'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Notification extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Notification.belongsTo(models.Store,{
        foreignKey:"send_to",
        as:"notification"
      })

    }
  }
  Notification.init({
    parent_id: DataTypes.INTEGER,
    send_to: DataTypes.INTEGER,
    send_by: DataTypes.INTEGER,
    send_for: DataTypes.STRING,
    message: DataTypes.STRING,
    is_status: DataTypes.STRING,
    is_deleted: DataTypes.BOOLEAN,
    created_by: DataTypes.STRING,
    updated_by: DataTypes.STRING,
    meta: DataTypes.JSON
  }, {
    sequelize,
    modelName: 'Notification',
  });
  return Notification;
};