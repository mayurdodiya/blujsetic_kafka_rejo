"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Friend extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Friend.belongsTo(models.User, {
        foreignKey: "friend_id",
        as: "user",
        onDelete: "cascade",
      });
      Friend.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "friend",
        onDelete: "cascade",
      });
    }
  }
  Friend.init(
    {
      user_id: DataTypes.INTEGER,
      friend_id: DataTypes.INTEGER,
      request_id: DataTypes.INTEGER,
      isActive: DataTypes.BOOLEAN,
      isFriend: DataTypes.BOOLEAN,
      meta: DataTypes.JSON,
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "Friend",
    }
  );
  return Friend;
};
