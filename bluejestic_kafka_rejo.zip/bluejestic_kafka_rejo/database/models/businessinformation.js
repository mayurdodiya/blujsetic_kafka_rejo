"use strict";
const { Model, BOOLEAN } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class BusinessInformation extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      BusinessInformation.hasMany(models.Product, {
        foreignKey: "store_id",
        as: "products",
      });
      // BusinessInformation.hasMany(models.SellerPost, {
      //   foreignKey: "store_id",
      //   as: "posts",
      // });
      BusinessInformation.hasMany(models.Post, {
        foreignKey: "store_id",
        as: "posts",
      });
      BusinessInformation.hasMany(models.StoreCategories, {
        foreignKey: "store_id",
        as: "category",
      });
      BusinessInformation.hasMany(models.StoreLike, {
        foreignKey: "store_id",
        as: "store_likes",
      });
      BusinessInformation.hasMany(models.FollowStore, {
        foreignKey: "store_id",
        as: "follow_store",
      });
      BusinessInformation.hasOne(models.StoreLike, {
        foreignKey: "store_id",
        as: "like",
      });
      BusinessInformation.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "store_owner",
        onDelete: "cascade",
      });
      BusinessInformation.belongsTo(models.Seller, {
        foreignKey: "seller_id",
        as: "personalInformation",
      });
      BusinessInformation.belongsTo(models.Seller, {
        foreignKey: "seller_id",
        as: "seller_detail",
      });
      BusinessInformation.hasOne(models.StoreDetail, {
        foreignKey: "store_id",
        as: "store_detail",
      });
    }
  }
  BusinessInformation.init(
    {
      seller_id: DataTypes.INTEGER,
      name: DataTypes.STRING,
      companyLegalName: DataTypes.STRING,
      // title: DataTypes.STRING,
      streetAddress: DataTypes.STRING,
      city: DataTypes.STRING,
      state: DataTypes.STRING,
      postalCode: DataTypes.STRING,
      websiteUrl: DataTypes.STRING,
      isHaveTeam: DataTypes.BOOLEAN,
      annualSale: DataTypes.STRING,
      totalEmployees: DataTypes.STRING,
      product_count: { type: DataTypes.INTEGER, defaultValue: 0 },
      // image: DataTypes.STRING,
      logo: {
        type: DataTypes.ARRAY(DataTypes.STRING),
        defaultValue: [650],
      },
      cover_image: {
        type: DataTypes.ARRAY(DataTypes.STRING),
        defaultValue: [651],
      },
      sellerType: DataTypes.STRING,
      status: DataTypes.STRING,
      businessType: DataTypes.STRING,
      shortDescription: DataTypes.STRING,
      longDescription: DataTypes.STRING,
      country: DataTypes.STRING,
      employmentType: DataTypes.STRING,
      profession: DataTypes.STRING,
      title: DataTypes.STRING,
      isFollow: DataTypes.BOOLEAN,
      isLikeShare: DataTypes.BOOLEAN,
      isNotification: DataTypes.BOOLEAN,
      user_id: DataTypes.INTEGER,
      isMessaging: DataTypes.BOOLEAN,
      isTrends: DataTypes.BOOLEAN,
      firstName: DataTypes.STRING,
      lastName: DataTypes.STRING,
      companyEmail: DataTypes.STRING,
      phoneNumber: DataTypes.STRING,
      accountType: DataTypes.STRING,
      state_name: DataTypes.STRING,
      productType: DataTypes.STRING,
      documents: DataTypes.ARRAY(DataTypes.STRING),
      logo_image: {
        type: DataTypes.STRING,
        defaultValue: "https://bluejestic-media.storage.googleapis.com/bluejestic-stage/emptystate/svgviewer-png-output%20(1)-1714546302692-146679686.png",
      },

      banner_image: DataTypes.STRING,
      BusinessInformationFor: {
        type: DataTypes.STRING,
        defaultValue: "SELLER",
      },
      meta: DataTypes.JSON,
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
      slug: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
      // slug: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "BusinessInformation",
    }
  );
  return BusinessInformation;
};
