'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class UserLocationActivity extends Model {
    static associate(models) {
      // define association here

    }
  }
  UserLocationActivity.init({
    user_id: DataTypes.INTEGER,
    userType: { type: DataTypes.STRING },
    latitude: DataTypes.STRING,
    longitude: DataTypes.STRING,
    isDeleted: { type: DataTypes.BOOLEAN, defaultValue: false },
  }, {
    sequelize,
    modelName: 'UserLocationActivity',
  });
  return UserLocationActivity;
};