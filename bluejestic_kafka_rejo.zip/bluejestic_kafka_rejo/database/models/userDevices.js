'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class UserDevices extends Model {
    static associate(models) {
      // define association here

    }
  }
  UserDevices.init({
    user_id: DataTypes.INTEGER,
    userType: { type: DataTypes.STRING },
    deviceName: DataTypes.STRING,
    isDeleted: { type: DataTypes.BOOLEAN, defaultValue: false },
  }, {
    sequelize,
    modelName: 'UserDevices',
  });
  return UserDevices;
};