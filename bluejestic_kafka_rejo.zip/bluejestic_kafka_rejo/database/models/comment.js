"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Comment extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Comment.belongsTo(models.Post, {
        foreignKey: "parent_id",
        as: "posts",
      });

      Comment.belongsTo(models.Post, {
        foreignKey: "parent_id",
        as: "groupPostComments",
      });
      Comment.belongsTo(models.Product, {
        foreignKey: "parent_id",
        as: "productComments",
        onDelete: "cascade",
      });
      Comment.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user",
        onDelete: "cascade",
      });
      Comment.hasMany(models.Like, {
        foreignKey: "comment_id",
        as: "likes",
      });
      Comment.hasMany(models.CommentReply, {
        foreignKey: "reply_id",
        as: "commentReply",
        allowNull: true,
        defaultValue: null,
      });
      Comment.belongsTo(models.SellerPost, {
        foreignKey: "parent_id",
        as: "sellerpostcomment",
      });
      Comment.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "comments",
      });
    }
  }
  Comment.init(
    {
      parent_id: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER,
      reply_id: DataTypes.INTEGER,
      group_post_id: DataTypes.INTEGER,
      seller_post_id: DataTypes.INTEGER,
      product_id: DataTypes.INTEGER,
      post_id: DataTypes.INTEGER,
      share_post_id: DataTypes.INTEGER,
      image: DataTypes.ARRAY(DataTypes.STRING),
      comment: DataTypes.STRING,
      comment_for: DataTypes.STRING,
      meta: DataTypes.JSON,
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "Comment",
    }
  );
  return Comment;
};
