"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class SellerPost extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      SellerPost.belongsTo(models.BusinessInformation, {
        foreignKey: "store_id",
        as: "posts",
      });
      SellerPost.hasMany(models.Comment, {
        foreignKey: "seller_post_id",
        as: "sellerpostcomment",
      });
      SellerPost.hasMany(models.Like, {
        foreignKey: "seller_post_id",
        as: "sellerpostlike",
      });
    }
  }
  SellerPost.init(
    {
      user_id: DataTypes.INTEGER,
      store_id: DataTypes.INTEGER,
      title: DataTypes.STRING,
      content: DataTypes.STRING,
      published_at: DataTypes.STRING,
      isActive: DataTypes.BOOLEAN,
      isDraft: DataTypes.BOOLEAN,
      isSchedule: DataTypes.BOOLEAN,
      scheduleTime: DataTypes.STRING,
      meta: DataTypes.JSON,
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.INTEGER,
      updated_by: DataTypes.INTEGER,
      media_id: DataTypes.ARRAY(DataTypes.INTEGER),
    },
    {
      sequelize,
      modelName: "SellerPost",
    }
  );
  return SellerPost;
};
