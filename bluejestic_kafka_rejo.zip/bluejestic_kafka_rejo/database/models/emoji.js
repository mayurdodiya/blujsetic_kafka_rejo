"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Emoji extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */

    //* relation between tables
    static associate(models) {
      // define association here
    }
  }
  //* schema init
  Emoji.init(
    {
      name: DataTypes.STRING,
      emoji: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "Emoji",
    }
  );
  return Emoji;
};
