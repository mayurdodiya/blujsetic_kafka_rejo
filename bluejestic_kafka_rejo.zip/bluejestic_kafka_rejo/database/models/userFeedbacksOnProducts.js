"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class UserFeedbacksOnProducts extends Model {
    static associate(models) {
      UserFeedbacksOnProducts.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user_details",
      });
      UserFeedbacksOnProducts.belongsTo(models.Seller, {
        foreignKey: "seller_id",
        as: "seller_details",
      });
      UserFeedbacksOnProducts.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "product_details",
      });
      UserFeedbacksOnProducts.belongsTo(models.BusinessInformation, {
        foreignKey: "store_id",
        as: "store_details",
      });
      UserFeedbacksOnProducts.belongsTo(models.OrderMaster, {
        foreignKey: "order_master_id",
        as: "order_master_details",
      });
      UserFeedbacksOnProducts.belongsTo(models.OrderItems, {
        foreignKey: "order_items_id",
        as: "order_items_details",
      });
    }
  }

  UserFeedbacksOnProducts.init(
    {
      product_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "Products",
          key: "id",
        },
      },
      user_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "Users",
          key: "id",
        },
      },
      seller_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "Sellers",
          key: "id",
        },
      },
      order_items_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "OrderItems",
          key: "id",
        },
      },
      order_master_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "OrderMasters",
          key: "id",
        },
      },
      store_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "BusinessInformations",
          key: "id",
        },
      },
      overAllRating: {
        type: DataTypes.FLOAT,
        validate: {
          max: 5,
          min: 0,
        },
      },
      isUserRecommendedThisSeller: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: null
      },
      communicationRating: {
        type: DataTypes.FLOAT,
        validate: {
          max: 5,
          min: 0,
        },
      },
      shippingRating: {
        type: DataTypes.FLOAT,
        validate: {
          max: 5,
          min: 0,
        },
      },
      itemAccuracyRating: {
        type: DataTypes.FLOAT,
        validate: {
          max: 5,
          min: 0,
        },
      },
      feedback: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
      },
    },
    {
      sequelize,
      modelName: "UserFeedbacksOnProducts",
      tableName: "UserFeedbacksOnProducts",
      freezeTableName: true,
    }
  );
  return UserFeedbacksOnProducts;
};
