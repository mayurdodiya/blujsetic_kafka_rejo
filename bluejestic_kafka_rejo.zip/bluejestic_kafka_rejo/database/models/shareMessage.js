"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class shareMessage extends Model {
    static associate({ Message }) {
      // define association here

      this.belongsTo(Message, {
        foreignKey: "message_id",
        as: "shared_content",
      });
    }
  }
  shareMessage.init(
    {
      message_id: {
        type: DataTypes.INTEGER,
      },
      product_id: {
        type: DataTypes.INTEGER,
      },
      group_id: {
        type: DataTypes.INTEGER,
      },
      store_id: {
        type: DataTypes.INTEGER,
      },
      type: {
        type: DataTypes.STRING,
      },
    },
    {
      sequelize,
      modelName: "shareMessage",
      tableName: "shareMessage",
    }
  );
  return shareMessage;
};
