"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class SavePost extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      SavePost.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "save_posts",
        onDelete: "cascade",
      });
      SavePost.belongsTo(models.Post, {
        foreignKey: "post_id",
        as: "savedPost",
        onDelete: "CASCADE",
      });
      SavePost.belongsTo(models.Post, {
        foreignKey: "post_id",
        as: "post",
        onDelete: "CASCADE",
      });
    }
  }
  SavePost.init(
    {
      post_id: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER,
      meta: DataTypes.JSON,
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "SavePost",
    }
  );
  return SavePost;
};
