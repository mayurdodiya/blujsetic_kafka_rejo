"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class BookmarkCollection extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      BookmarkCollection.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user",
        onDelete: "cascade",
      });

      BookmarkCollection.hasOne(models.BookmarkCollectionSharedPeople, {
        foreignKey: "collection_id",
        as: "collection_data",
      });

      BookmarkCollection.hasOne(models.BookmarkCollectionFollow, {
        foreignKey: "collection_id",
        as: "followed_collection_data",
      });

      BookmarkCollection.hasMany(models.BookmarkCollectionLikes, {
        foreignKey: "collection_id",
        as: "likes",
      });

      // BookmarkCollection.hasOne(models.User, {
      //   foreignKey: "user_id",
      //   as: "user",
      // });

      BookmarkCollection.hasOne(models.SharePost, {
        foreignKey: "collection_id",
        as: "collection",
      });

      BookmarkCollection.hasMany(models.Bookmark, {
        foreignKey: "collection_id",
        as: "bookmark_product",
      });
    }
  }
  BookmarkCollection.init(
    {
      name: DataTypes.STRING,
      user_id: DataTypes.INTEGER,
      image: DataTypes.STRING,
      is_deleted: { type: DataTypes.BOOLEAN, defaultValue: false },
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
      banner_image: DataTypes.STRING,
      colection_for: DataTypes.STRING,
      description: DataTypes.STRING,
      position: DataTypes.INTEGER,
      meta: DataTypes.JSON,
      isPrivate: { type: DataTypes.BOOLEAN, defaultValue: true },
      slug: {
        type: DataTypes.STRING,
        // allowNull: false,
        // unique: true,
      },
    },
    {
      sequelize,
      modelName: "BookmarkCollection",
    }
  );
  return BookmarkCollection;
};
