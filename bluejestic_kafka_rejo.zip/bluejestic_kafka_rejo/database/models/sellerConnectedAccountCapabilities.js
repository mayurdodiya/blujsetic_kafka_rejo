"use strict";
const { Model } = require("sequelize");
const database = require("./index");

module.exports = (sequelize, DataTypes) => {
  class SellerConnectedAccountCapability extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      SellerConnectedAccountCapability.belongsTo(models.Seller, {
        foreignKey: "seller_id",
        as: "seller_info",
      });
    
      SellerConnectedAccountCapability.belongsTo(models.SellerConnectedAccount, {
        foreignKey: "sellerConnectedAccountId",
        as: "sellerConnectedAccount",
      });
    }
  }
  SellerConnectedAccountCapability.init(
    {
      seller_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: "Sellers",
          key: "id"
        }
      },
      stripeAccountId: {
        type: DataTypes.STRING,
        allowNull: true,
        default: null
      },
      sellerConnectedAccountId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "SellerConnectedAccounts",
          key: "id"
        }
      },
      name: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      status: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      }
    },
    {
      sequelize,
      modelName: "SellerConnectedAccountCapability",
      tableName: "SellerConnectedAccountCapabilities",
      freezeTableName: true,
      timestamps: true

    }
  );
  return SellerConnectedAccountCapability;
};
