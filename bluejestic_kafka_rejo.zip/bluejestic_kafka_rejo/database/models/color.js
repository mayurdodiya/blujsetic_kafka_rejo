'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Color extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Color.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "colors",
        onDelete: 'cascade',
      })
    }
  }
  Color.init({
    product_id: {
      type: DataTypes.INTEGER,
    },
    user_id: DataTypes.INTEGER,
    name: DataTypes.STRING,
    color: DataTypes.STRING,
    colorCode: DataTypes.STRING,
    color_for: { type: DataTypes.STRING, defaultValue: "PRODUCT" },
    updated_by: DataTypes.STRING,
    is_deleted: { type: DataTypes.BOOLEAN, defaultValue: false },
    meta: DataTypes.JSON
  }, {
    sequelize,
    modelName: 'Color',
  });
  return Color;
};