"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Cart extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Cart.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "cartItems",
        onDelete: "cascade",
      });
      // Cart.hasOne(models.Product, {
      //   foreignKey: "parent_id",
      //   as: "product",
      // });
      Cart.belongsTo(models.Product, {
        foreignKey: "parent_id",
        as: "product",
      });

      Cart.belongsTo(models.ProductItem, {
        foreignKey: "variant_id",
        as: "variant_data",
      });
      Cart.belongsTo(models.Seller, {
        foreignKey: "seller_id",
        as: "seller_details",
      });
      Cart.belongsTo(models.BusinessInformation, {
        foreignKey: "store_id",
        as: "store_details",
      });
    }
  }
  Cart.init(
    {
      parent_id: DataTypes.INTEGER,
      variant_id: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER,
      cart_for: DataTypes.STRING,
      quantity: DataTypes.INTEGER,
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
      meta: DataTypes.JSON,
      store_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "BusinessInformations",
          key: "id",
        },
      },
      seller_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "Sellers",
          key: "id",
        },
      },
      status: {
        type: DataTypes.STRING,
        defaultValue: "cart_created",
        validate: {
          isIn: [["cart_created", "cart_updated", "cart_abandoned", "cart_deleted", "checkout_initiated", "order_placed", "order_returned", "order_cancelled"]],
        }
      }
    },
    {
      sequelize,
      modelName: "Cart",
    }
  );
  return Cart;
};
