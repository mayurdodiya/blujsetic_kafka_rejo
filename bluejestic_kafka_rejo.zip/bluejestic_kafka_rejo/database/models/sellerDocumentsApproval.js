 "use strict";
const { Model } = require("sequelize");
const database = require("./index");

module.exports = (sequelize, DataTypes) => {
  class SellerDocumentsApproval extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      // sellerDocumentsApproval.hasOne(models.BusinessInformation, {
      //   foreignKey: "seller_id",
      //   as: "personalInformation",
      // });
      // sellerDocumentsApproval.hasOne(models.BusinessInformation, {
      //   foreignKey: "seller_id",
      //   as: "seller_detail",
      // });
      // sellerDocumentsApproval.belongsTo(models.User, {
      //   foreignKey: "user_id",
      //   as: "user",
      // });
      // sellerDocumentsApproval.hasOne(models.User, {
      //   foreignKey: "user_id",
      //   as: "seller_detail_data",
      // });

      SellerDocumentsApproval.belongsTo(models.Seller, {
        foreignKey: "seller_id",
        as: "seller_info",
      });
    }
  }
  SellerDocumentsApproval.init(
    {
      id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true
      },
      seller_id: {
        type: DataTypes.INTEGER,
      },
      document: {
        type: DataTypes.STRING,
      },
      documentType: {
        type: DataTypes.STRING,
      },
      documentName: {
        type: DataTypes.STRING,
      },
      updatedBy: {
        type: DataTypes.INTEGER,
      },
      documentApprovedStatus: {
        type: DataTypes.STRING,
      },
      createdAt: {
        allowNull: false,
        type: DataTypes.DATE
      },
      updatedAt: {
        allowNull: false,
        type: DataTypes.DATE
      }
    },
    {
      sequelize,
      modelName: "SellerDocumentsApproval",
      timestamps: true
    }
  );
  return SellerDocumentsApproval;
};
