"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class PlaidAccount extends Model {
  
    static associate(models) {
  
  
    //   PlaidAccount.belongsTo(models.SharePost, {
    //     foreignKey: "sharepost_id",
    //     as: "sharePosts",
    //     constraints: false,
    //     allowNull: true,
    //     defaultValue: null,
    //   });
    }
  }
  PlaidAccount.init(
    {
        user_id: {
            type:DataTypes.INTEGER,
            allowNull:false,            
        },
        link_token: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue: null
        },
        public_token: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue: null
        },        
        access_token: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue: null
        },
        item_id: {
            type: DataTypes.STRING,
            allowNull: true,
            defaultValue: null
        },
        role: {
          type: DataTypes.STRING,
          allowNull: true,
          defaultValue: null
      },                      
    },
    {
      sequelize,    
      timestamps: true,
      modelName: "PlaidAccount",      

    }
  );
  return PlaidAccount;
};
