"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Category extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      // Category.belongsTo(models.Product, {
      //   foreignKey: "product_id",
      //   as: "categories",
      // });
      Category.hasMany(models.Subcategory, {
        foreignKey: "category_id",
        as: "subCategory",
      });
      Category.hasOne(models.Category, {
        foreignKey: "category_id",
        as: "category_data",
      });
      Category.hasOne(models.SellerPersonalInfo, {
        foreignKey: "primary_product_category_new",
        as: "product_category_details",
      });
    }
  }
  Category.init(
    {
      parent_id: DataTypes.INTEGER,
      product_id: DataTypes.INTEGER,
      name: DataTypes.STRING,
      description: DataTypes.STRING,
      media: DataTypes.STRING,
      banner_media: DataTypes.STRING,
      position: DataTypes.INTEGER,
      meta: DataTypes.JSON,
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
      slug: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "Category",
    }
  );
  return Category;
};
