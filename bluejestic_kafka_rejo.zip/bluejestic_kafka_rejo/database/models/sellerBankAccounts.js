"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class SellerBankAccounts extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      SellerBankAccounts.belongsTo(models.Seller, {
        foreignKey: "seller_id",
        as: "seller_info",
      });
      SellerBankAccounts.belongsTo(models.SellerConnectedAccount, {
        foreignKey: "sellerConnectedAccountId",
        as: "sellerConnectedAccount",
      });
    }
  }
  SellerBankAccounts.init(
    {
      seller_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: "Sellers",
          key: "id",
        },
      },
      type: DataTypes.STRING,
      brand: DataTypes.STRING,
      country: DataTypes.STRING,
      currency: DataTypes.STRING,
      exp_month: DataTypes.STRING,
      exp_year: DataTypes.STRING,
      last4: DataTypes.STRING,
      account_holder_name: DataTypes.STRING,
      bank_name: DataTypes.STRING,
      routing_number: DataTypes.STRING,
      isDefault: { type: DataTypes.BOOLEAN, defaultValue: false },
      isActivated: { type: DataTypes.BOOLEAN, defaultValue: true },
      stripeAccountId: {
        type: DataTypes.STRING,
      },
      sellerConnectedAccountId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "SellerConnectedAccounts",
          key: "id",
        },
      },
      bank_or_card_id: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      }
    },
    {
      sequelize,
      modelName: "SellerBankAccounts",
    }
  );
  return SellerBankAccounts;
};