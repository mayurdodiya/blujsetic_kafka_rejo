'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class CommentReply extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      CommentReply.belongsTo(models.Comment, {
        foreignKey: "reply_id",
        as: "commentReply",
        allowNull: true,
        defaultValue: null
      });
      CommentReply.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user",
        allowNull: true,
        defaultValue: null
      });
      CommentReply.hasMany(models.Like, {
        foreignKey: "comment_reply_id",
        as: "commentReplyLike",
      });
    }
  }
  CommentReply.init({
    user_id: DataTypes.INTEGER,
    reply_id: DataTypes.INTEGER,
    comment: DataTypes.STRING,
    image: DataTypes.ARRAY(DataTypes.STRING),
    comment_for: DataTypes.STRING,
    is_deleted: DataTypes.BOOLEAN,
  }, {
    sequelize,
    modelName: 'CommentReply',
  });
  return CommentReply;
};