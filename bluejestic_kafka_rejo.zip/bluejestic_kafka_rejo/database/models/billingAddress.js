"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class BillingAddresses extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here

      BillingAddresses.hasOne(models.OrderMaster, {
        foreignKey: "shipping_id",
        as: "shipping_detail",
        onDelete: "CASCADE"
      });

      BillingAddresses.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user_details",
        onDelete: "CASCADE"
      });
    }
  }
  BillingAddresses.init(
    {
      user_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "Users",
          key: "id",
        },
      },
      streetAddress: DataTypes.STRING,
      city: DataTypes.STRING,
      firstName: DataTypes.STRING,
      lastName: DataTypes.STRING,
      number: DataTypes.STRING,
      state: DataTypes.STRING,
      country: DataTypes.STRING,
      country_name: DataTypes.STRING,
      state_name: DataTypes.STRING,
      isDefault: DataTypes.BOOLEAN,
      zipcode: DataTypes.STRING,
      buildingName: DataTypes.STRING,
      isPinLocation: DataTypes.BOOLEAN,
      latitude: DataTypes.FLOAT,
      longitude: DataTypes.FLOAT,
    },
    {
      sequelize,
      modelName: "BillingAddresses",
    }
  );
  return BillingAddresses;
};
