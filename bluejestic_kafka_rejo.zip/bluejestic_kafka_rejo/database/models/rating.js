'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Rating extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Rating.belongsTo(models.Store,{
        foreignKey:"parent_id",
        as:"ratings"
      })
    }
  }
  Rating.init({
    parent_id: DataTypes.INTEGER,
    rating: DataTypes.INTEGER,
    review_title: DataTypes.STRING,
    review_message: DataTypes.STRING,
    rating_for: DataTypes.STRING,
    is_deleted: {type:DataTypes.BOOLEAN, defaultValue:false},
    created_by: DataTypes.STRING,
    updated_by: DataTypes.STRING,
    meta: DataTypes.JSON
  }, {
    sequelize,
    modelName: 'Rating',
  });
  return Rating;
};