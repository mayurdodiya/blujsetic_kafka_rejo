"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class LegalDetails extends Model {
    static associate(models) {
      // DEFINE ASSOCIATION HERE
    }
  }
  LegalDetails.init(
    {
      seller_id: DataTypes.INTEGER,
      taxClassification: DataTypes.STRING,
      countryIncorporation: DataTypes.STRING,
      taxId: DataTypes.STRING,
      foundationYear: DataTypes.INTEGER,
      estimatedAnnualSale: DataTypes.STRING,
      numberOfEmployees: DataTypes.STRING,
      LegalDetailsFor: {
        type: DataTypes.STRING,
        defaultValue: "SELLER",
      },
      meta: DataTypes.JSON,
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "LegalDetails",
    }
  );
  return LegalDetails;
};
