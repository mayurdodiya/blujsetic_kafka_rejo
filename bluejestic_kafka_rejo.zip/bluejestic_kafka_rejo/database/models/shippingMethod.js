"use strict";
const { Model } = require("sequelize");

module.exports = (sequelize, DataTypes) => {
  class ShippingMethod extends Model {
    static associate(models) {
      ShippingMethod.belongsTo(models.Seller, {
        foreignKey: "seller_id",
        as: "seller",
      });

      // ShippingMethod.belongsTo(models.SelectedShippingMethod, {
      //   foreignKey: "shipping_method_id",
      //   as: "selected_shipping_method",
      //   onDelete: "cascade",
      // });


      ShippingMethod.hasMany(models.SelectedShippingMethod, {
        foreignKey: "shipping_method_id",
        as: "selected_shipping_method",
        // onDelete: "cascade",
      });

      ShippingMethod.hasOne(models.Product, {
        foreignKey: "shipping_method_id",
        as: "shipping_method",
        onDelete: "cascade",
      });

    }
  }

  ShippingMethod.init(
    {
      delivery_options_type: {
        type: DataTypes.STRING
      },
      name: {
        type: DataTypes.STRING,
      },
      zipcode: {
        type: DataTypes.STRING,
      },
      processing_time: {
        type: DataTypes.STRING,
      },
      processing_time_type: {
        type: DataTypes.STRING,
      },
      // type: {
      //   type: DataTypes.ENUM('flat_rate', 'free', 'threshold', 'calculated'),
      // },
      threshold: {
        type: DataTypes.FLOAT,
      },
      seller_id: {
        type: DataTypes.INTEGER,
      },
      is_free_delivery: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      is_free_international_delivery: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      handling_fee: {
        type: DataTypes.INTEGER,
      },
      is_active: {
        type: DataTypes.BOOLEAN,
      },
      service_code: { type: DataTypes.ARRAY(DataTypes.STRING), defaultValue: [], },
      is_deleted: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      fixed_delivery_options: {
        type: DataTypes.ARRAY(DataTypes.JSONB),
        allowNull: false,
        defaultValue: []
      }
    },
    {
      sequelize,
      modelName: "ShippingMethod",
      timestamps: true,
      paranoid: true,
    }
  );

  return ShippingMethod;
};
