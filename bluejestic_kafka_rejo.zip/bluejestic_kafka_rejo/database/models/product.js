"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Product extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here

      Product.hasMany(models.ProductItem, {
        foreignKey: "product_id",
        as: "variants",
        onDelete: "cascade",
      });

      Product.hasOne(models.ProductItem, {
        foreignKey: "product_id",
        as: "variant",
        onDelete: "cascade",
      });

      Product.hasMany(models.ProductMedia, {
        foreignKey: "product_id",
        as: "images",
        // onDelete: "cascade",
      });

      // Product.hasOne(models.ProductSEO, {
      //   foreignKey: "parent_id",
      //   as: "productSEO",
      //   onDelete: "cascade",
      // });
      // // Product.hasOne(models.Shipping, {
      // //   foreignKey: "parent_id",
      // //   as: "shipping",
      // // });
      Product.hasOne(models.ProductShippingDetails, {
        foreignKey: "product_id",
        as: "shipping",
        onDelete: "cascade",
      });

      Product.hasMany(models.Variation, {
        foreignKey: "product_id",
        as: "options",
        onDelete: "cascade",
      });

      Product.hasMany(models.ProductCategories, {
        foreignKey: "product_id",
        as: "categories",
        onDelete: "cascade",
      });

      Product.hasMany(models.ProductAttributes, {
        foreignKey: "product_id",
        as: "attributes",
        onDelete: "cascade",
      });

      // Product.hasMany(models.ProductOtherInformations, {
      //   foreignKey: "product_id",
      //   as: "other",
      //   onDelete: "cascade",
      // });
      // Product.hasMany(models.Color, {
      //   foreignKey: "product_id",
      //   as: "colors",
      //   onDelete: "cascade",
      // });
      // Product.hasMany(models.Size, {
      //   foreignKey: "product_id",
      //   as: "sizes",
      //   onDelete: "cascade",
      // });
      // Product.hasMany(models.ProductAttributes, {
      //   foreignKey: "product_id",
      //   as: "attributes",
      //   onDelete: "cascade",
      // });
      // Product.hasMany(models.ProductCategories, {
      //   foreignKey: "product_id",
      //   as: "categories",
      //   onDelete: "cascade",
      // });
      // Product.hasMany(models.Comment, {
      //   foreignKey: "product_id",
      //   as: "productComments",
      //   onDelete: "cascade",
      // });
      // Product.hasMany(models.SharePost, {
      //   foreignKey: "product_id",
      //   as: "products",
      // });
      Product.hasMany(models.Like, {
        foreignKey: "product_id",
        as: "productLikes",
        onDelete: "cascade",
      });
      Product.hasOne(models.Like, {
        foreignKey: "product_id",
        as: "likes",
        onDelete: "cascade",
      });
      Product.hasMany(models.SharePost, {
        foreignKey: "product_id",
        as: "shareCount",
        onDelete: "cascade",
      });
      Product.belongsTo(models.BusinessInformation, {
        foreignKey: "store_id",
        as: "store",
      });
      Product.hasMany(models.ProductTag, {
        foreignKey: "product_id",
        as: "tags",
      });
      Product.hasMany(models.UserReviewsOnProducts, {
        foreignKey: "product_id",
        as: "userReviews",
      });
      Product.hasMany(models.UserFeedbacksOnProducts, {
        foreignKey: "product_id",
        as: "userFeedbacks",
      });
      Product.hasOne(models.ProductInventory, {
        foreignKey: "product_id",
        as: "inventoryPrice",
      });
      Product.hasOne(models.ProductImageSize, {
        foreignKey: "product_id",
        as: "size",
        onDelete: "cascade",
      });
      //*COMMENTED_CODE
      Product.hasMany(models.SharePost, {
        foreignKey: "product_id",
        as: "productsharePost",
      });

      Product.hasMany(models.Comment, {
        foreignKey: "product_id",
        as: "productComments",
      });

      // Product.belongsTo(models.Cart, {
      //   foreignKey: "parent_id",
      //   as: "product",
      // });
      Product.hasOne(models.Cart, {
        foreignKey: "parent_id",
        as: "product",
      });
      Product.hasOne(models.Bookmark, {
        foreignKey: "product_id",
        as: "bookmark",
      });
      Product.hasMany(models.Comment, {
        foreignKey: "product_id",
        as: "comments",
      });

      Product.belongsTo(models.ShippingMethod, {
        foreignKey: "shipping_method_id",
        as: "shipping_method",
        onDelete: "cascade",
      });

      // Product.belongsTo(models.OrderItems, {
      //   foreignKey: "product_id",
      //   as: "order_product",
      // });
    }
  }

  Product.init(
    {
      store_id: DataTypes.INTEGER,
      title: DataTypes.STRING,
      description: DataTypes.STRING(1000000),
      isFeature: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      isActive: { type: DataTypes.BOOLEAN, defaultValue: true },
      metaTitle: DataTypes.STRING,
      keywords: DataTypes.STRING,
      metaDescription: DataTypes.STRING,
      isVisible: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      shopify_product_id: DataTypes.STRING,
      isFreeShipping: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      slug: {
        type: DataTypes.STRING,
        // unique: true,
        // allowNull: false,
      },
      status: DataTypes.STRING,
      dis_price: DataTypes.STRING,
      dis_listPrice: DataTypes.STRING,
      colorVariant: DataTypes.INTEGER,
      condition: DataTypes.STRING,
      ratio: DataTypes.STRING,
      is_deleted: { type: DataTypes.BOOLEAN, defaultValue: false },
      brand_id: DataTypes.INTEGER,
      shipping_method_id: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "Product",
    }
  );

  return Product;
};
