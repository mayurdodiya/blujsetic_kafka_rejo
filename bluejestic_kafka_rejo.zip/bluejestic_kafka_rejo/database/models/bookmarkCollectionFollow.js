"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class BookmarkCollectionFollow extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      BookmarkCollectionFollow.belongsTo(models.BookmarkCollection, {
        foreignKey: "collection_id",
        as: "followed_collection_data",
      });

      BookmarkCollectionFollow.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "followed_user_data",
        onDelete: "cascade",
      });
    }
  }
  BookmarkCollectionFollow.init(
    {
      user_id: DataTypes.INTEGER,
      collection_id: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "BookmarkCollectionFollow",
    }
  );
  return BookmarkCollectionFollow;
};
