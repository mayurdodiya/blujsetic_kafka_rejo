'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class About extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */

    //* relation between tables
    static associate(models) {
      // define association here
      About.belongsTo(models.Store,{
        foreignKey:'parent_id',
        as:"about"
      })
    }
  }
  //* schema init
  About.init({
    parent_id: DataTypes.INTEGER,
    address: DataTypes.STRING,
    city: DataTypes.STRING,
    state: DataTypes.STRING,
    country: DataTypes.STRING,
    location: DataTypes.STRING,
    postal_code: DataTypes.INTEGER,
    facebook: DataTypes.STRING,
    twitter: DataTypes.STRING,
    instagram: DataTypes.STRING,
    linkedin: DataTypes.STRING,
    about_for: DataTypes.STRING,
    is_deleted: DataTypes.BOOLEAN,
    created_by: DataTypes.STRING,
    updated_by: DataTypes.STRING,
    meta: DataTypes.JSON
  }, {
    sequelize,
    modelName: 'About',
  });
  return About;
};