"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class DeliveryServices extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }

  DeliveryServices.init(
    {
      carrier_id: DataTypes.STRING,
      carrier_code: DataTypes.STRING,
      name: DataTypes.STRING,
      is_domestic: DataTypes.BOOLEAN,
      is_international: DataTypes.BOOLEAN,
      is_multi_package_supported: DataTypes.BOOLEAN,
      days: DataTypes.STRING,
      is_active: { type: DataTypes.BOOLEAN, defaultValue: true },
      service_code: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "DeliveryServices",
    }
  );

  return DeliveryServices;
};
