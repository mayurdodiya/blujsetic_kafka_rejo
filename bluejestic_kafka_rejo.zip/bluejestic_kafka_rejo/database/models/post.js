"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Post extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Post.hasMany(models.SharePost, {
        foreignKey: "post_id",
        as: "post",
      });
      // Post.belongsTo(models.Store, {
      //   foreignKey: "owner_id",
      //   as: "posts",
      // });
      Post.hasMany(models.Comment, {
        foreignKey: "post_id",
        as: "comments",
      });
      Post.hasMany(models.Like, {
        foreignKey: "post_id",
        as: "likes",
      });
      Post.hasOne(models.SavePost, {
        foreignKey: "post_id",
        as: "savedPost",
      });
      // Post.hasMany(models.Media, {
      //   foreignKey: "parent_id",
      //   as: "medias",
      // });
      Post.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user",
        onDelete: "cascade",
      });
      Post.belongsTo(models.BusinessInformation, {
        foreignKey: "store_id",
        as: "posts",
      });
      Post.belongsTo(models.Group, {
        foreignKey: "group_id",
        as: "group",
      });
      Post.belongsTo(models.SharePost, {
        foreignKey: "sharepost_id",
        as: "sharePosts",
        constraints: false,
        allowNull: true,
        defaultValue: null,
      });
    }
  }
  Post.init(
    {
      title: DataTypes.STRING(1000000),
      content: DataTypes.STRING(1000000),
      media_id: { type: DataTypes.ARRAY(DataTypes.INTEGER), defaultValue: [] },
      user_id: DataTypes.INTEGER,
      group_id: DataTypes.INTEGER,
      store_id: DataTypes.INTEGER,
      store_name: DataTypes.STRING,
      seller_id: DataTypes.INTEGER,
      isActive: { type: DataTypes.BOOLEAN, defaultValue: false },
      isDraft: { type: DataTypes.BOOLEAN, defaultValue: false },
      isSchedule: { type: DataTypes.BOOLEAN, defaultValue: false },
      scheduleTime: DataTypes.STRING,
      visible_for: DataTypes.STRING,
      media_type: DataTypes.STRING,
      post_for: DataTypes.STRING,
      owner_id: DataTypes.INTEGER,
      sharepost_id: DataTypes.INTEGER,
      collection_control: { type: DataTypes.STRING, defaultValue: "" },
    },
    {
      sequelize,
      modelName: "Post",
    }
  );
  return Post;
};
