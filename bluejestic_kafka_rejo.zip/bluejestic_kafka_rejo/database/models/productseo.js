"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class ProductSEO extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      ProductSEO.belongsTo(models.Product, {
        foreignKey: "parent_id",
        as: "productSEO",
        onDelete: 'cascade',
      });
    }
  }
  ProductSEO.init(
    {
      parent_id: DataTypes.INTEGER,
      metaTitle: DataTypes.STRING,
      metaKeywords: DataTypes.STRING,
      metaDescription: DataTypes.STRING,
      metaData: DataTypes.STRING,
      meta: DataTypes.JSON,
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "ProductSEO",
    }
  );
  return ProductSEO;
};
