"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class OrderMaster extends Model {
    static associate(models) {
      // define association here
      OrderMaster.belongsTo(models.BillingAddresses, {
        foreignKey: "shipping_id",
        as: "shipping_detail",
      });

      OrderMaster.hasOne(models.OrderShippingCharge, {
        foreignKey: "order_master_id",
        as: "order_shipping_charge",
        onDelete: "cascade",
      });

      OrderMaster.hasMany(models.OrderItems, {
        foreignKey: "order_master_id",
        as: "orderItems",
        onDelete: "cascade",
      });

      OrderMaster.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "order_detail",
        onDelete: "cascade",
      });
    }
  }
  OrderMaster.init(
    {
      order_id: DataTypes.STRING,
      user_id: DataTypes.INTEGER,
      shipping_id: DataTypes.INTEGER,
      card_id: DataTypes.INTEGER,
      paymentId: DataTypes.STRING,
      orderDate: { type: DataTypes.DATE, defaultValue: new Date() },
      totalAmount: {
        type: DataTypes.FLOAT,
        defaultValue: 0,
      },
      fulfillment_status: {
        type: DataTypes.STRING,
      },
      totalTaxAmount: {
        // tax amount
        type: DataTypes.FLOAT,
        defaultValue: 0,
      },
      totalBasicAmount: {
        // wihtout tax
        type: DataTypes.FLOAT,
        defaultValue: 0,
      },
      pendingAmount: {
        type: DataTypes.FLOAT,
        defaultValue: 0,
      },
      store_id: DataTypes.INTEGER,
      order_status: {
        type: DataTypes.STRING,
        validate: {
          isIn: [["callProcess", "pending", "processing", "approved", "rejected", "delivered", "cancelled"]],
        },
        defaultValue: "pending",
      },
      isActive: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
      },
      shopify_order_status_url: {
        type: DataTypes.STRING,
      },
      shopify_order_confirmation_number: {
        type: DataTypes.STRING,
      },
      shopify_order_id: {
        type: DataTypes.STRING,
      },
      shopify_app_id: {
        type: DataTypes.STRING,
      },
      shopify_order_number: {
        type: DataTypes.STRING,
      },
      isPaymentDone: { type: DataTypes.BOOLEAN, defaultValue: false },
      isBuyAgainOrder: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
    },
    {
      sequelize,
      modelName: "OrderMaster",
    }
  );
  return OrderMaster;
};
