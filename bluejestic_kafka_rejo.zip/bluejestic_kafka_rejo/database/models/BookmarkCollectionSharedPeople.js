"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class BookmarkCollectionSharedPeople extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here

      BookmarkCollectionSharedPeople.belongsTo(models.BookmarkCollection, {
        foreignKey: "collection_id",
        as: "collection_data",
      });

      BookmarkCollectionSharedPeople.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user_data",
        onDelete: "cascade",
      });
    }
  }
  BookmarkCollectionSharedPeople.init(
    {
      collection_id: DataTypes.INTEGER,
      user_id: DataTypes.INTEGER,
      friend_id: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "BookmarkCollectionSharedPeople",
    }
  );
  return BookmarkCollectionSharedPeople;
};
