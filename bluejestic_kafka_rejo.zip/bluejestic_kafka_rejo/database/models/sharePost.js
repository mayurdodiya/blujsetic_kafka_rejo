"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class SharePost extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      SharePost.belongsTo(models.Post, {
        foreignKey: "post_id",
        as: "post",
      });
      SharePost.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user",
        onDelete: "cascade",
      });
      SharePost.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "products",
        onDelete: "cascade",
      });

      SharePost.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "shareCount",
      });
      SharePost.hasMany(models.Like, {
        foreignKey: "share_post_id",
        as: "likes",
      });
      SharePost.hasMany(models.Comment, {
        foreignKey: "share_post_id",
        as: "comments",
      });

      //*COMMENTED_CODE
      SharePost.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "productsharePost",
      });
      SharePost.belongsTo(models.BookmarkCollection, {
        foreignKey: "collection_id",
        as: "collection",
      });
      // SharePost.hasOne(models.Post, {
      //   foreignKey: "sharepost_id",
      //   as: "sharePosts_data",
      //   // onDelete : "cascade"
      // });
    }
  }
  SharePost.init(
    {
      content: DataTypes.STRING,
      image: { type: DataTypes.ARRAY(DataTypes.STRING), defaultValue: [] },
      store_id: DataTypes.INTEGER,
      collection_id: DataTypes.INTEGER,
      group_id: DataTypes.INTEGER,
      store_name: DataTypes.STRING,
      user_id: DataTypes.INTEGER,
      post_id: DataTypes.INTEGER,
      product_id: DataTypes.INTEGER,
      isBookmarked: { type: DataTypes.BOOLEAN, defaultValue: false },
      share_post_for: {
        type: DataTypes.STRING,
      },
      isActive: { type: DataTypes.BOOLEAN, defaultValue: false },
      isShare: { type: DataTypes.BOOLEAN, defaultValue: true },
      isDraft: { type: DataTypes.BOOLEAN, defaultValue: false },
    },
    {
      sequelize,
      modelName: "SharePost",
    }
  );
  return SharePost;
};
