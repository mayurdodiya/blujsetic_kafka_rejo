"use strict";
const { Model } = require("sequelize");
const database = require("./index");

module.exports = (sequelize, DataTypes) => {
  class SellerPersonalInfo extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      // SellerPersonalInfo.hasOne(models.BusinessInformation, {
      //   foreignKey: "seller_id",
      //   as: "personalInformation",
      // });
      // SellerPersonalInfo.hasOne(models.BusinessInformation, {
      //   foreignKey: "seller_id",
      //   as: "seller_detail",
      // });
      // SellerPersonalInfo.belongsTo(models.User, {
      //   foreignKey: "user_id",
      //   as: "user",
      // });
      SellerPersonalInfo.belongsTo(models.Category, {
        foreignKey: "primary_product_category_new",
        as: "product_category_details",
      });
      SellerPersonalInfo.belongsTo(models.Seller, {
        foreignKey: "seller_id",
        as: "seller_personal_info",
      });
    }
  }
  SellerPersonalInfo.init(
    {
      seller_id: DataTypes.INTEGER,
      firstName: DataTypes.STRING,
      middleName: DataTypes.STRING,
      lastName: DataTypes.STRING,
      residential_address: DataTypes.STRING,
      residential_address_detail: DataTypes.STRING,
      city: DataTypes.STRING,
      state: DataTypes.STRING,
      zip_code: DataTypes.STRING,
      country: DataTypes.STRING,
      phone_number: DataTypes.STRING,
      primary_product_category: DataTypes.INTEGER,
      primary_product_category_new: {
        type: DataTypes.INTEGER,
        references: {
          model: database.Category,
          key: "id",
        },
      },
      birthdate: DataTypes.STRING,
      store_name: DataTypes.STRING,

      // business_type: DataTypes.STRING,
      // business_legal_name: DataTypes.STRING,
      // employer_identification_number: DataTypes.STRING,
      // business_address: DataTypes.STRING,
      // business_address_detail: DataTypes.STRING,
      // city: DataTypes.STRING,
      // state: DataTypes.STRING,
      // zip_code: DataTypes.STRING,
      // country: DataTypes.STRING,
      // business_email: DataTypes.STRING,
      // phone_number: DataTypes.STRING,

      // id_type: DataTypes.STRING,
      // document: DataTypes.STRING,
      // birth_date: DataTypes.STRING,
      // birth_year: DataTypes.STRING,
      // birthdate: DataTypes.STRING,
      // expiring_date: DataTypes.STRING,
      // passport_number: DataTypes.STRING,
      // birth_month: DataTypes.STRING,
      // ssn: DataTypes.STRING,
      // itin: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "SellerPersonalInfo",
    }
  );
  return SellerPersonalInfo;
};
