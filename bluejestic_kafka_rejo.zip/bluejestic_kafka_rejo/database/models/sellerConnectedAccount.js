"use strict";
const { Model } = require("sequelize");
const database = require("./index");

module.exports = (sequelize, DataTypes) => {
  class SellerConnectedAccount extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      SellerConnectedAccount.belongsTo(models.Seller, {
        foreignKey: "seller_id",
        as: "seller_info",
      });
      SellerConnectedAccount.hasMany(models.SellerConnectedAccountCapability, {
        foreignKey: "sellerConnectedAccountId",
        as: "seller_connected_account_capabilities",
      });
      SellerConnectedAccount.hasMany(models.SellerBankAccounts, {
        foreignKey: "sellerConnectedAccountId",
        as: "seller_bank_accounts_info",
      });
    }
  }
  SellerConnectedAccount.init(
    {
      seller_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
          model: "Sellers",
          key: "id"
        }
      },
      stripeAccountId: {
        type: DataTypes.STRING,
        allowNull: true,
        default: null
      },
      isConnectAccountDeleted: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        default: false
      },
      isPaymentOnboardingCompleted: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        default: false
      },
      details_submitted: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: false
      },
      type: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      business_type: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      tax_id_provided: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: null
      },
      ssn_last_4_provided: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: null
      },
      dobDay: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: null
      },
      dobMonth: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: null
      },
      dobYear: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: null
      },
      first_name: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      last_name: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      line1: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      line2: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      city: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      state: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      country: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      postal_code: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      isSellerAcceptsTOS: {
        type: DataTypes.BOOLEAN,
        allowNull: true,
        defaultValue: null
      },
      sellerAcceptedTOSFromIPAddress: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      sellerAcceptedTOSFromUserAgent: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      businessName: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      businessUrl: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
    },
    {
      sequelize,
      modelName: "SellerConnectedAccount",
      tableName: "SellerConnectedAccounts",
      freezeTableName: true,
      timestamps: true

    }
  );
  return SellerConnectedAccount;
};
