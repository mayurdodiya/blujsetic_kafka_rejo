 "use strict";
const { Model } = require("sequelize");
const database = require("./index");

module.exports = (sequelize, DataTypes) => {
  class SellerIdentification extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      // SellerIdentification.hasOne(models.BusinessInformation, {
      //   foreignKey: "seller_id",
      //   as: "personalInformation",
      // });
      // SellerIdentification.hasOne(models.BusinessInformation, {
      //   foreignKey: "seller_id",
      //   as: "seller_detail",
      // });
      // SellerIdentification.belongsTo(models.User, {
      //   foreignKey: "user_id",
      //   as: "user",
      // });
      // SellerIdentification.hasOne(models.User, {
      //   foreignKey: "user_id",
      //   as: "seller_detail_data",
      // });

      SellerIdentification.belongsTo(models.Seller, {
        foreignKey: "seller_id",
        as: "seller_personal_info",
      });
    }
  }
  SellerIdentification.init(
    {
      seller_id: DataTypes.INTEGER,
      id_type: DataTypes.STRING,
      document: DataTypes.STRING,
      documentName: DataTypes.STRING,
      birth_date: DataTypes.STRING,
      birth_month: DataTypes.STRING,
      birth_year: DataTypes.STRING,
      birthdate: DataTypes.STRING,
      expiring_date: DataTypes.STRING,
      passport_number: DataTypes.STRING,
      ssn: DataTypes.STRING,
      itin: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "SellerIdentification",
    }
  );
  return SellerIdentification;
};
