"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class CardAndBillingAddress extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  CardAndBillingAddress.init(
    {
      user_id: DataTypes.INTEGER,
      card_number: DataTypes.STRING,
      expiry_date: DataTypes.STRING,
      cvv: DataTypes.STRING,
      streetAddress: DataTypes.STRING,
      country: DataTypes.STRING,
      state: DataTypes.STRING,
      city: DataTypes.STRING,
      zipcode: DataTypes.STRING,
      buildingName: DataTypes.STRING,
      number: DataTypes.STRING,
      color: DataTypes.ARRAY(DataTypes.STRING),
      firstName: DataTypes.STRING,
      lastName: DataTypes.STRING,
      image: DataTypes.STRING,
      cartType: DataTypes.STRING,
      isDefault: DataTypes.BOOLEAN,
    },
    {
      sequelize,
      modelName: "CardAndBillingAddress",
    }
  );
  return CardAndBillingAddress;
};
