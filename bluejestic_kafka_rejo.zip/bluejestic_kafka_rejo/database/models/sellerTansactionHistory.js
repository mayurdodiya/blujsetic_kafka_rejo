"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class SellerTansactionHistory extends Model {
    /*
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  SellerTansactionHistory.init(
    {
      seller_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: "Sellers",
          key: "id",
        },
      },
      transfer_id: {
        type: DataTypes.STRING,
      },
      amount: DataTypes.FLOAT,
      balance_transaction: DataTypes.STRING,
      currency: DataTypes.STRING,
      destination_id: DataTypes.STRING,
      source_type: DataTypes.STRING,
      type: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
      },
      amount_reversed: {
        type: DataTypes.FLOAT,
        allowNull: false,
        defaultValue: 0,
      },
      description: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
      },
      payment_destination: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
      },      
      liveMode: {
        type: DataTypes.BOOLEAN,        
        defaultValue: true,
      },
      reversed: {
        type: DataTypes.BOOLEAN,        
        defaultValue: false,
      },
      created_date_by_stripe: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
      }
    },
    {
      sequelize,
      modelName: "SellerTansactionHistory",
    }
  );
  return SellerTansactionHistory;
};
