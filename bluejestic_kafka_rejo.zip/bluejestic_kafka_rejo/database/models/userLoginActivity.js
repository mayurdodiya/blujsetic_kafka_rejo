'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class UserLoginActivity extends Model {
    static associate(models) {
      // define association here

      // UserLoginActivity.belongsTo(models.User, {
      //   foreignKey: "user_id",
      //   as: "user",
      // });

    }
  }
  UserLoginActivity.init({
    user_id: DataTypes.INTEGER,
    userType: { type: DataTypes.STRING },
    latitude: DataTypes.STRING,
    longitude: DataTypes.STRING,
    deviceName: DataTypes.STRING,
    loginTime: DataTypes.DATE,
    isDeleted: { type: DataTypes.BOOLEAN, defaultValue: false },
  }, {
    sequelize,
    modelName: 'UserLoginActivity',
  });
  return UserLoginActivity;
};