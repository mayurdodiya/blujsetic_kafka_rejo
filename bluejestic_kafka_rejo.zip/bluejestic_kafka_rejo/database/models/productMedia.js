"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class ProductMedia extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here

      ProductMedia.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "images",
        // onDelete: "cascade",
      });
      // ProductMedia.belongsTo(models.ShopifyProduct, {
      //   foreignKey: "image_id",
      //   as: "image",
      //   // onDelete: "cascade",
      // });
    }
  }

  ProductMedia.init(
    {
      product_id: DataTypes.INTEGER,
      media_id: DataTypes.INTEGER,
      src: DataTypes.STRING(10000),
      position: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "ProductMedia",
    }
  );

  return ProductMedia;
};
