"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class GroupPost extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      GroupPost.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "user",
        onDelete: "cascade",
      });
      // GroupPost.hasMany(models.Comment, {
      //   foreignKey: "group_post_id",
      //   as: "groupPostComments",
      // });

      GroupPost.hasMany(models.Like, {
        foreignKey: "group_post_id",
        as: "groupPostLikes",
      });
    }
  }
  GroupPost.init(
    {
      group_id: DataTypes.INTEGER,
      name: DataTypes.STRING,
      description: DataTypes.STRING,
      media_id: {
        type: DataTypes.ARRAY(DataTypes.INTEGER),
        defaultValue: [],
      },
      user_id: DataTypes.INTEGER,
    },
    {
      sequelize,

      modelName: "GroupPost",
    }
  );
  return GroupPost;
};
