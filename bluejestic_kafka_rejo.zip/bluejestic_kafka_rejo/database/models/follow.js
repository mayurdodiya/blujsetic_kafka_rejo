"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Follow extends Model {
    static associate(models) {
      Follow.belongsTo(models.Store, {
        foreignKey: "follower_id",
        as: "following",
      });

      Follow.belongsTo(models.Store, {
        foreignKey: "follower_id",
        as: "follower",
      });
    }
  }
  Follow.init(
    {
      following_id: DataTypes.INTEGER,
      follower_id: DataTypes.INTEGER,
      follow_for: DataTypes.STRING,
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
      meta: DataTypes.JSON,
    },
    {
      sequelize,
      modelName: "Follow",
    }
  );
  return Follow;
};
