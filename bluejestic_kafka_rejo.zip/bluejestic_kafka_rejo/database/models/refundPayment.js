"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class RefundPayment extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here

      RefundPayment.belongsTo(models.OrderItems, {
        foreignKey: "order_item_id",
        as: "order_item",
        onDelete: "cascade",
      });

    }
  }

  RefundPayment.init(
    {
      amount: DataTypes.INTEGER,
      refund_id: DataTypes.STRING,
      balance_transaction: DataTypes.STRING,
      charge: DataTypes.STRING,
      currency: DataTypes.STRING,
      destination_details_type: DataTypes.STRING,
      reference_status: DataTypes.STRING,
      payment_intent: DataTypes.STRING,
      reason: DataTypes.STRING,
      order_item_id: DataTypes.INTEGER
    },
    {
      sequelize,
      modelName: "RefundPayment",
    }
  );

  return RefundPayment;
};
