'use strict';
const {
  Model
} = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class MYFEED extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
    }
  }
  MYFEED.init({
    user_id: DataTypes.INTEGER,
    comments_id: DataTypes.INTEGER,
    store_id: DataTypes.INTEGER,
    likes_id: DataTypes.INTEGER,
    shares_id: DataTypes.INTEGER,
    content: DataTypes.STRING,
    meta: DataTypes.JSON,
    is_deleted: DataTypes.BOOLEAN,
    created_by: DataTypes.STRING,
    updated_by: DataTypes.STRING
  }, {
    sequelize,
    modelName: 'MYFEED',
  });
  return MYFEED;
};