"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class ConfirmedOrder extends Model {
    static associate(models) {
      // define association here
      ConfirmedOrder.belongsTo(models.BillingAddresses, {
        foreignKey: "shippingId",
        as: "shipping",
      });
      ConfirmedOrder.hasMany(models.Product, {
        foreignKey: "productId",
        as: "orderProducts",
      });
    }
  }
  ConfirmedOrder.init(
    {
      userId: DataTypes.INTEGER,
      shippingId: DataTypes.INTEGER,
      cardId: DataTypes.INTEGER,
      paymentId: DataTypes.STRING,
      productId: {
        type: DataTypes.ARRAY(DataTypes.INTEGER),
      },
      quantity: {
        type: DataTypes.ARRAY(DataTypes.INTEGER),
      },
      generate_id: DataTypes.STRING,
      total: DataTypes.INTEGER,
      orderDate: { type: DataTypes.DATE, defaultValue: new Date() }, // DataTypes.NOW()
      isPaymentDone: { type: DataTypes.BOOLEAN, defaultValue: false },
    },
    {
      sequelize,
      modelName: "ConfirmedOrder",
    }
  );
  return ConfirmedOrder;
};
