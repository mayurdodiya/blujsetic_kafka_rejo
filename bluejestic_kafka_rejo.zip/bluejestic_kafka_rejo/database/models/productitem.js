"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class ProductItem extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      ProductItem.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "variants",
        onDelete: "cascade",
      });

      ProductItem.hasOne(models.Cart, {
        foreignKey: "variant_id",
        as: "variant_data",
      });

      ProductItem.hasMany(models.ProductConfiguration, {
        foreignKey: "product_item_id",
        as: "total_variant",
        onDelete: "cascade",
      });

      ProductItem.belongsTo(models.Media, {
        foreignKey: "image_id",
        as: "image",
        onDelete: "cascade",
      });
    }
  }

  ProductItem.init(
    {
      // category_id: DataTypes.INTEGER,
      // subCategory_id: DataTypes.INTEGER,
      // childSubCategory_id: DataTypes.INTEGER,
      title: DataTypes.STRING,
      price: DataTypes.STRING,
      sku: DataTypes.STRING,
      barcode: DataTypes.STRING,
      weightValue: DataTypes.STRING,
      weightUnit: DataTypes.STRING,
      unit: DataTypes.STRING,
      height: {
        type: DataTypes.INTEGER,
        defaultValue: 10,
      },
      width: {
        type: DataTypes.INTEGER,
        defaultValue: 10,
      },
      length: {
        type: DataTypes.INTEGER,
        defaultValue: 10,
      },
      compare_at_price: DataTypes.STRING,
      position: DataTypes.INTEGER,
      on_hand: DataTypes.INTEGER,
      inventory_quantity: DataTypes.INTEGER,
      old_inventory_quantity: DataTypes.INTEGER,
      product_id: DataTypes.INTEGER,
      image_id: DataTypes.INTEGER,
      title: DataTypes.STRING,
      isRequiresShipping: DataTypes.STRING,
      fulfillment_service: DataTypes.STRING,
      inventory_management: DataTypes.STRING,
      isTaxable: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      listPrice: DataTypes.INTEGER,
      store_id: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "ProductItem",
    }
  );

  return ProductItem;
};
