"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class BioDetail extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      BioDetail.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "bio_detail",
        onDelete: "CASCADE",
      });
    }
  }
  BioDetail.init(
    {
      user_id: DataTypes.INTEGER,
      marital_status: DataTypes.STRING,
      occupation: DataTypes.STRING,
      education: DataTypes.STRING,
      interest: DataTypes.STRING,
      about: DataTypes.STRING,
      experience: DataTypes.STRING,
      hobbies: DataTypes.STRING,
      is_deleted: { type: DataTypes.BOOLEAN, defaultValue: false },
      created_by: { type: DataTypes.STRING, defaultValue: "system" },
      updated_by: { type: DataTypes.STRING, defaultValue: "system" },
    },
    {
      sequelize,
      modelName: "BioDetail",
    }
  );
  return BioDetail;
};
