"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Childsubcategory extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      Childsubcategory.belongsTo(models.Category, {
        foreignKey: "category_id",
        as: "mainCategory",
      });
      Childsubcategory.belongsTo(models.Subcategory, {
        foreignKey: "sub_category_id",
        as: "subCategory",
      });
      Childsubcategory.belongsTo(models.Subcategory, {
        foreignKey: "sub_category_id",
        as: "childSubCategory",
      });
      Childsubcategory.hasMany(models.NestedChildSubcategory, {
        foreignKey: "child_sub_category_id",
        as: "nestedChildSubCategory",
      });
    }
  }
  Childsubcategory.init(
    {
      category_id: DataTypes.INTEGER,
      sub_category_id: DataTypes.INTEGER,
      product_id: DataTypes.INTEGER,
      position: DataTypes.INTEGER,
      name: DataTypes.STRING,
      description: DataTypes.STRING,
      media: DataTypes.STRING,
      banner_media: DataTypes.STRING,
      meta: DataTypes.JSON,
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
      slug: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "Childsubcategory",
    }
  );
  return Childsubcategory;
};
