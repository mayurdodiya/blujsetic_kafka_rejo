"use strict";
const { Model } = require("sequelize");
const database = require("./index");

module.exports = (sequelize, DataTypes) => {
  class SellerBusinessDetail extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      // SellerBusinessDetail.hasOne(models.BusinessInformation, {
      //   foreignKey: "seller_id",
      //   as: "personalInformation",
      // });
      // SellerBusinessDetail.hasOne(models.BusinessInformation, {
      //   foreignKey: "seller_id",
      //   as: "seller_detail",
      // });
      // SellerBusinessDetail.belongsTo(models.User, {
      //   foreignKey: "user_id",
      //   as: "user",
      // });
      // SellerBusinessDetail.hasOne(models.User, {
      //   foreignKey: "user_id",
      //   as: "seller_detail_data",
      // });

      SellerBusinessDetail.belongsTo(models.Seller, {
        foreignKey: "seller_id",
        as: "seller_personal_info",
      });
    } 
  }
  SellerBusinessDetail.init(
    {
      seller_id: DataTypes.INTEGER,
      business_type: DataTypes.STRING,
      business_legal_name: DataTypes.STRING,
      employer_identification_number: DataTypes.STRING,
      business_address: DataTypes.STRING,
      business_address_detail: DataTypes.STRING,
      city: DataTypes.STRING,
      state: DataTypes.STRING,
      zip_code: DataTypes.STRING,
      country: DataTypes.STRING,
      business_email: DataTypes.STRING,
      phone_number: DataTypes.STRING,
      business_city: DataTypes.STRING,
      business_state: DataTypes.STRING,
      business_zip_code: DataTypes.STRING,
      business_country: DataTypes.STRING,
      business_phone_number: DataTypes.STRING,
    },
    {
      sequelize,
      modelName: "SellerBusinessDetail",
    }
  );
  return SellerBusinessDetail;
};
