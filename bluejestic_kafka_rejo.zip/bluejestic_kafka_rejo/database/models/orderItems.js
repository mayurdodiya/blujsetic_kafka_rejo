"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class OrderItems extends Model {
    static associate(models) {
      // define association here

      OrderItems.belongsTo(models.OrderMaster, {
        foreignKey: "order_master_id",
        as: "orderMaster",
        onDelete: "cascade",
      });

      OrderItems.hasOne(models.RefundPayment, {
        foreignKey: "order_item_id",
        as: "order_item",
        onDelete: "cascade",
      });

      OrderItems.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "customer",
        onDelete: "cascade",
      });
      OrderItems.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "product",
      });

      OrderItems.belongsTo(models.BillingAddresses, {
        foreignKey: "shipping_id",
        as: "shipping_data",
      });

      OrderItems.belongsTo(models.User, {
        foreignKey: "user_id",
        as: "total_purchase_item",
        onDelete: "cascade",
      });

      // OrderItems.hasOne(models.Product, {
      //   foreignKey: "product_id",
      //   as: "order_product",
      // });
    }
  }
  OrderItems.init(
    {
      order_master_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        // references: {
        //   model: "OrderMaster",
        //   key: "id",
        // },
      },
      serice_code: {
        type: DataTypes.STRING,
      },
      shopify_order_item_id: {
        type: DataTypes.STRING,
      },
      shopify_variant_id: {
        type: DataTypes.STRING,
      },
      fulfillment_status: {
        type: DataTypes.STRING,
      },
      shopify_fulfillment_id: {
        type: DataTypes.STRING,
      },
      delivery_estimate: {
        type: DataTypes.DATE
      },
      delivery_estimate_day: {
        type: DataTypes.INTEGER
      },
      shopify_product_id: {
        type: DataTypes.STRING,
      },
      product_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        // references: {
        //   model: "Product",
        //   key: "id",
        // },
      },
      seller_id: DataTypes.INTEGER,
      store_id: DataTypes.INTEGER,
      quantity: DataTypes.INTEGER,
      variant_id: DataTypes.INTEGER,
      product_price: DataTypes.FLOAT,
      /* (quantity * price) */
      basicAmount: DataTypes.FLOAT,
      isShopifyProduct: DataTypes.BOOLEAN,
      /* basicAmount * tax */
      taxAmount: {
        type: DataTypes.FLOAT,
        defaultValue: 0,
      },
      /* discountAmount */
      discountAmount: {
        type: DataTypes.FLOAT,
        defaultValue: 0,
      },
      /* shipping charges */
      shipment_charges: {
        type: DataTypes.FLOAT,
        defaultValue: 0,
      },
      /* basicAmount + tax - discountAmount */
      totalAmount: DataTypes.FLOAT,
      pendingAmount: {
        type: DataTypes.FLOAT,
        defaultValue: 0,
      },
      tracking_number: DataTypes.STRING,
      shipment_id: DataTypes.STRING,
      label_id: DataTypes.STRING,
      label_url: DataTypes.STRING,
      trackingUrl: DataTypes.STRING,
      /* global charges for seller */
      globalCharges: DataTypes.FLOAT,
      /* seller charges */
      sellerCharges: DataTypes.FLOAT,
      /* getting seller final amount */
      sellerFinalAmount: DataTypes.FLOAT,
      user_id: DataTypes.INTEGER,
      shipping_id: DataTypes.INTEGER,
      shopify_order_id: DataTypes.INTEGER,
      shopify_order_status_url: {
        type: DataTypes.STRING,
      },
      shopify_order_confirmation_number: {
        type: DataTypes.STRING,
      },
      shopify_order_id: {
        type: DataTypes.STRING,
      },
      shopify_app_id: {
        type: DataTypes.STRING,
      },
      shopify_order_number: {
        type: DataTypes.STRING,
      },
      /* order status code*/
      order_status_code: {
        type: DataTypes.STRING,
        validate: {
          isIn: [["AC", "IT", "DE", "EX", "UN", "AT", "NY", "SP", "PN", "CN", "RN"]],
        },
        defaultValue: "PN",
      },
      /* order status */
      order_status: {
        type: DataTypes.STRING,
        validate: {
          isIn: [["N/A", "in_transit", "delivered", "error", "unknown", "N/A", "delivered_to_service_point", "pending", "cancelled", "returned", "confirmed"]],
        },
        defaultValue: "pending",
      },
      paymentStatus: {
        type: DataTypes.STRING,
        validate: {
          isIn: [["pending", "done", "failed", "refunded", "cancelled"]],
        },
        defaultValue: "done",
      },
      refund_reciept_url: {
        type: DataTypes.STRING,
      },
      isBuyAgainOrder: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
    },
    {
      sequelize,
      modelName: "OrderItems",
      freezeTableName: true,
      indexes: [{ fields: ["order_master_id", "product_id"] }, { fields: ["product_id"] }, { fields: ["seller_id"] }, { fields: ["store_id"] }, { fields: ["quantity"] }],
    }
  );
  return OrderItems;
};
