"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class User extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      // User.hasMany(models.Like, {
      //   foreignKey: "user_id",
      //   as: "user",
      // });
      User.hasOne(models.BusinessInformation, {
        foreignKey: "user_id",
        as: "store_likes",
        onDelete: "CASCADE"
      });
      User.hasMany(models.SavePost, {
        foreignKey: "user_id",
        as: "save_posts",
        onDelete: "CASCADE"
      });
      User.hasOne(models.BioDetail, {
        foreignKey: "user_id",
        as: "bio_detail",
        onDelete: "CASCADE"

      });
      // User.hasMany(models.Group, {
      //   foreignKey: "user_id",
      //   as: "groups",
      // });
      User.hasMany(models.JoinGroup, {
        foreignKey: "user_id",
        as: "joingroups",
        onDelete: "CASCADE",
      });
      User.hasMany(models.Cart, {
        foreignKey: "user_id",
        as: "cartItems",
        onDelete: "CASCADE"
      });
      User.hasOne(models.JoinGroup, {
        foreignKey: "user_id",
        as: "members",
      });
      User.hasOne(models.Friend, {
        foreignKey: "friend_id",
        as: "user",
        onDelete: "CASCADE"
      });
      User.hasOne(models.Invitation, {
        foreignKey: "user_id",
        as: "invited_user",
      });
      User.hasOne(models.Friend, {
        foreignKey: "user_id",
        as: "friend",
      });
      User.hasOne(models.InviteGroup, {
        foreignKey: "user_id",
        as: "user_invite_Group",
      });
      User.hasOne(models.Group, {
        foreignKey: "user_id",
        as: "user_group",
      });
      User.hasOne(models.JoinGroup, {
        foreignKey: "user_id",
        as: "user_join_group",
      });
      User.hasMany(models.OrderMaster, {
        foreignKey: "user_id",
        as: "order_detail",
        onDelete: "CASCADE"
      });
      User.hasMany(models.OrderItems, {
        foreignKey: "user_id",
        as: "total_purchase_item",
      });
      User.hasOne(models.StoreLike, {
        foreignKey: "user_id",
        as: "storeLikeUsers",
        onDelete: "CASCADE"
      });
      User.hasOne(models.BookmarkCollectionLikes, {
        foreignKey: "user_id",
        as: "like_user",
        onDelete: "CASCADE"
      });

      User.hasOne(models.Seller, {
        foreignKey: "user_id",
        as: "seller",
      });

      User.hasOne(models.BookmarkCollectionSharedPeople, {
        foreignKey: "user_id",
        as: "user_data",
      });

      User.hasOne(models.BookmarkCollectionFollow, {
        foreignKey: "user_id",
        as: "followed_user_data", 
        onDelete: "CASCADE"
      });

      // User.hasMany(models.UserLoginActivity, {
      //   foreignKey: "user_id",
      //   as: "userLoginActivities",
      // });

      User.hasOne(models.BillingAddresses, {
        foreignKey: "user_id",
        as: "shipping_address",
        onDelete: "CASCADE",
      });

      // User.belongsTo(models.Seller, {
      //   foreignKey: "seller_id",
      //   as: "user_detail",
      // });
    }
  }
  User.init(
    {
      firstName: DataTypes.STRING,
      lastName: DataTypes.STRING,
      email: DataTypes.STRING,
      password: DataTypes.STRING,
      mobileNumber: DataTypes.STRING,
      phoneNumber: DataTypes.STRING,
      ext: DataTypes.INTEGER,
      gender: DataTypes.STRING,
      bday: DataTypes.DATE,
      jobTitle: DataTypes.STRING,
      profileAvtar: {
        type: DataTypes.ARRAY(DataTypes.INTEGER),
        defaultValue: [648],
      },
      profileCoverImage: {
        type: DataTypes.ARRAY(DataTypes.INTEGER),
        defaultValue: [649],
      },
      social_type: DataTypes.STRING,
      isSocial: { type: DataTypes.BOOLEAN, defaultValue: false },
      role: DataTypes.STRING,
      // seller_id: DataTypes.INTEGER,
      isSeller: DataTypes.BOOLEAN,
      isUser: DataTypes.BOOLEAN,
      social_id: DataTypes.STRING,
      address: DataTypes.STRING,
      subAddress: DataTypes.STRING,
      city: DataTypes.STRING,
      state: DataTypes.STRING,
      country: DataTypes.STRING,
      zipCode: DataTypes.STRING,
      status: { type: DataTypes.STRING, defaultValue: "active" },
      userFor: DataTypes.STRING,
      isDetails5OnboardingCompletedNew: {
        type: DataTypes.BOOLEAN,
        defaultValue: false,
      },
      details5OnboardingCompletedAtNew: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null,
      },
      currentStepForSellerOnboarding: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
      },
      meta: DataTypes.JSON,
      becomeSellerStatus: { type: DataTypes.STRING },
      currentQueryForVerification: { 
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
       },
      becomeSellerApprovalNote: { type: DataTypes.STRING, allowNull: true, defaultValue: null },
      isOnboardCompleted: { type: DataTypes.BOOLEAN, defaultValue: false },
      onboardCompletedAt: {
        type: DataTypes.DATE,
        allowNull: true,
        defaultValue: null
      },
      isUserOnboardCompleted: { type: DataTypes.BOOLEAN, defaultValue: false },
      is_deleted: DataTypes.BOOLEAN,
      created_by: DataTypes.STRING,
      updated_by: DataTypes.STRING,
      isRegisterVerified: DataTypes.BOOLEAN,
      logo_image: {
        type: DataTypes.STRING,
        defaultValue: "https://bluejestic-media.storage.googleapis.com/demo-test/dummy-profile (1)-1669122101773-764781589-1669182656605-3255156-1694692268774-918686311.jpg",
      },
      banner_image: {
        type: DataTypes.STRING,
        defaultValue: "https://bluejestic-media.storage.googleapis.com/demo-test/ben-sweet-2LowviVHZ-E-unsplash-1694692287055-141710054.jpg",
      },
      forgotPasswordOTP: {
        type: DataTypes.STRING,
      },
      forgotPasswordOTPExpiry: {
        type: DataTypes.DATE,
      },
      userName: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
      },
    },
    {
      sequelize,
      modelName: "User",
    }
  );
  return User;
};
