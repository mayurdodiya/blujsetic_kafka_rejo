"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class Variation extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here

      Variation.hasOne(models.VariationOption, {
        foreignKey: "variation_id",
        as: "variantion_name",
        onDelete: "cascade",
      });

      Variation.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "options",
        // onDelete: "cascade",
      });

      Variation.hasMany(models.VariationOption, {
        foreignKey: "variation_id",
        as: "data",
        onDelete: "cascade",
      });
    }
  }

  Variation.init(
    {
      name: DataTypes.STRING,
      product_id: DataTypes.INTEGER,
      store_id: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "Variation",
    }
  );

  return Variation;
};
