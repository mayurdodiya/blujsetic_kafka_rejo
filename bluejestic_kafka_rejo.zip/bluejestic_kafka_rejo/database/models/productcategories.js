"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class ProductCategories extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      ProductCategories.belongsTo(models.Category, {
        foreignKey: "category_id",
        as: "category",
      });
      ProductCategories.belongsTo(models.Subcategory, {
        foreignKey: "subCategory_id",
        as: "subCategory",
      });
      ProductCategories.belongsTo(models.Childsubcategory, {
        foreignKey: "childSubCategory_id",
        as: "childSubCategory",
      });

      ProductCategories.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "categories",
        onDelete: "cascade",
      });

      ProductCategories.belongsTo(models.Product, {
        foreignKey: "product_id",
        as: "product_data",
      });
    }
  }
  ProductCategories.init(
    {
      user_id: DataTypes.INTEGER,
      product_id: DataTypes.INTEGER,
      category_id: DataTypes.INTEGER,
      subCategory_id: DataTypes.INTEGER,
      childSubCategory_id: DataTypes.INTEGER,
    },
    {
      sequelize,
      modelName: "ProductCategories",
    }
  );
  return ProductCategories;
};
