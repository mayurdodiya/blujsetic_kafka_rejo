"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class SellerApproval extends Model {
    /**
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here

    }
  }
  SellerApproval.init(
    {
      user_id: DataTypes.INTEGER,
      title: DataTypes.STRING,
      productType: DataTypes.STRING,
      firstName: DataTypes.STRING,
      lastName: DataTypes.STRING,
      email: DataTypes.STRING,
      phoneNumber: DataTypes.STRING,
      accountType: DataTypes.STRING,

      name: DataTypes.STRING,
      companyLegalName: DataTypes.STRING,
      streetAddress: DataTypes.STRING,
      city: DataTypes.STRING,
      state: DataTypes.STRING,
      postalCode: DataTypes.STRING,
      websiteUrl: DataTypes.STRING,
      businessType: DataTypes.STRING,
      state_name: DataTypes.STRING,
      storeDetials: {
        type: DataTypes.JSONB,
        allowNull: true,
        set: function (val) {
          if (!val) {
            return this.setDataValue("storeDetials", null);
          }
          return this.setDataValue("storeDetials", JSON.stringify(val));
        },
        get: function () {
          if (this.getDataValue("storeDetials"))
            return JSON.parse(this.getDataValue("storeDetials"));
          return null;
        },
      }, // storeDetails
      sellerDetails: {
        type: DataTypes.JSONB,
        allowNull: true,
        set: function (val) {
          if (!val) {
            return this.setDataValue("sellerDetails", null);
          }
          return this.setDataValue("sellerDetails", JSON.stringify(val));
        },
        get: function () {
          if (this.getDataValue("sellerDetails"))
            return JSON.parse(this.getDataValue("sellerDetails"));
          return null;
        },
      }, // sellerDetails
      sellerApprovedStatus: {
        type: DataTypes.STRING,
        defaultValue: "pending"
      }
    },
    {
      sequelize,
      modelName: "SellerApproval",
    }
  );
  return SellerApproval;
};
