"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class SellerPayoutHistory extends Model {
    /*
     * Helper method for defining associations.
     * This method is not a part of Sequelize lifecycle.
     * The `models/index` file will call this method automatically.
     */
    static associate(models) {
      // define association here
      SellerPayoutHistory.belongsTo(models.Seller, {
        foreignKey: "seller_id",
        as: "sellerInfo",
      });
    }
  }
  SellerPayoutHistory.init(
    {
      seller_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: "Sellers",
          key: "id",
        },
      },
      custom_txn_id: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      payout_id: {
        type: DataTypes.STRING,
      },
      amount: {
        type: DataTypes.FLOAT,
        defaultValue: 0
      },
      balance_transaction_id: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      currency: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      destination_id: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      source_type: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      status: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      description: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      method: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null
      },
      liveMode: {
        type: DataTypes.BOOLEAN,
        defaultValue: true
      },
      failure_balance_transaction: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: true
      },
      failure_code: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: true
      },
      failure_message: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: true
      },
      statement_descriptor: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: true
      },
      type: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
      },
      application_fee: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
      },
      application_fee_amount: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
      },
      automatic: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      created_date_by_stripe: {
        type: DataTypes.STRING,
        allowNull: true,
        defaultValue: null,
      }
    },
    {
      sequelize,
      modelName: "SellerPayoutHistory",
      tableName: "SellerPayoutHistories",
      freezeTableName: true,
    }
  );
  return SellerPayoutHistory;
};
