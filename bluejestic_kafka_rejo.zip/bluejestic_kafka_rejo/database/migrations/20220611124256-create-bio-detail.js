'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('BioDetails', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      marital_status: {
        type: Sequelize.STRING
      },
      occupation: {
        type: Sequelize.STRING
      },
      education: {
        type: Sequelize.STRING
      },
      interest: {
        type: Sequelize.STRING
      },
      about: {
        type: Sequelize.STRING
      },
      experience: {
        type: Sequelize.STRING
      },
      hobbies: {
        type: Sequelize.STRING
      },
      is_deleted: {
        type: Sequelize.BOOLEAN
      },
      created_by: {
        type: Sequelize.STRING
      },
      updated_by: {
        type: Sequelize.STRING
      },
      user_id: {
        type: Sequelize.INTEGER
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('BioDetails');
  }
};