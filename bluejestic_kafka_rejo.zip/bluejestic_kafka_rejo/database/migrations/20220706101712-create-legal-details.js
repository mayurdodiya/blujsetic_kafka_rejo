'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('LegalDetails', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      seller_id: {
        type: Sequelize.INTEGER
      },
      taxClassification: {
        type: Sequelize.STRING
      },
      countryIncorporation: {
        type: Sequelize.STRING
      },
      taxId: {
        type: Sequelize.STRING
      },
      foundationYear: {
        type: Sequelize.INTEGER
      },
      estimatedAnnualSale: {
        type: Sequelize.STRING
      },
      numberOfEmployees: {
        type: Sequelize.STRING
      },
      LegalDetailsFor: {
        type: Sequelize.STRING
      },
      meta: {
        type: Sequelize.JSON
      },
      is_deleted: {
        type: Sequelize.BOOLEAN
      },
      created_by: {
        type: Sequelize.STRING
      },
      updated_by: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('LegalDetails');
  }
};