'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('Users', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      firstName: {
        type: Sequelize.STRING
      },
      lastName: {
        type: Sequelize.STRING
      },
      email: {
        type: Sequelize.STRING
      },
      mobileNumber: {
        type: Sequelize.INTEGER
      },
      phoneNumber: {
        type: Sequelize.INTEGER
      },
      ext: {
        type: Sequelize.INTEGER
      },
      jobTitle: {
        type: Sequelize.STRING
      },
      name: {
        type: Sequelize.STRING
      },
      companyLegalName: {
        type: Sequelize.STRING
      },
      streetAddress: {
        type: Sequelize.STRING
      },
      city: {
        type: Sequelize.STRING
      },
      state: {
        type: Sequelize.STRING
      },
      postalCode: {
        type: Sequelize.INTEGER
      },
      websiteUrl: {
        type: Sequelize.STRING
      },
      isHaveTeam: {
        type: Sequelize.BOOLEAN
      },
      annualSale: {
        type: Sequelize.STRING
      },
      totalEmployees: {
        type: Sequelize.STRING
      },
      sellerType: {
        type: Sequelize.STRING
      },
      taxClassification: {
        type: Sequelize.STRING
      },
      countryIncorporation: {
        type: Sequelize.STRING
      },
      taxId: {
        type: Sequelize.STRING
      },
      foundationYear: {
        type: Sequelize.INTEGER
      },
      estimatedAnnualSale: {
        type: Sequelize.STRING
      },
      numberOfEmployees: {
        type: Sequelize.STRING
      },
      meta: {
        type: Sequelize.JSON
      },
      is_deleted: {
        type: Sequelize.BOOLEAN
      },
      created_by: {
        type: Sequelize.STRING
      },
      updated_by: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('Users');
  }
};