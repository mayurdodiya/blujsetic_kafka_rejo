'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('BusinessInformations', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      seller_id: {
        type: Sequelize.INTEGER
      },
      name: {
        type: Sequelize.STRING
      },
      companyLegalName: {
        type: Sequelize.STRING
      },
      streetAddress: {
        type: Sequelize.STRING
      },
      city: {
        type: Sequelize.STRING
      },
      state: {
        type: Sequelize.STRING
      },
      postalCode: {
        type: Sequelize.INTEGER
      },
      websiteUrl: {
        type: Sequelize.STRING
      },
      isHaveTeam: {
        type: Sequelize.BOOLEAN
      },
      annualSale: {
        type: Sequelize.STRING
      },
      totalEmployees: {
        type: Sequelize.STRING
      },
      sellerType: {
        type: Sequelize.STRING
      },
      BusinessInformationFor: {
        type: Sequelize.STRING
      },
      meta: {
        type: Sequelize.JSON
      },
      is_deleted: {
        type: Sequelize.BOOLEAN
      },
      created_by: {
        type: Sequelize.STRING
      },
      updated_by: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('BusinessInformations');
  }
};