require("dotenv").config();

module.exports = {
  development: {
    username: process.env.DATABASE_USERNAME,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE_NAME,
    host: process.env.DATABASE_HOST,
    dialect: process.env.DATABASE_DIALECT,
    logging: false,
    dialectOptions: {
      ssl: {
        require: true,
        rejectUnauthorized: false,
      },
    },
  },
  // test: {
  //   username: "bhargav",
  //   password: "D@Rtdl8D9kL&",
  //   database: "database_test",
  //   host: "bj-pg-aurora-prod.cluster-ci5g5g927ppu.us-east-1.rds.amazonaws.com",
  //   dialect: "postgres",
  //   host: "bj-pg-aurora-prod.cluster-ci5g5g927ppu.us-east-1.rds.amazonaws.com",
  //   dialect: "postgres",
  //   use_env_variable: "postgres",
  // },
  // production: {
  //   username: "bhargav",
  //   password: "D@Rtdl8D9kL&",
  //   database: "database_production",
  //   host: "bj-pg-aurora-prod.cluster-ci5g5g927ppu.us-east-1.rds.amazonaws.com",
  //   dialect: "postgres",
  //   host: "bj-pg-aurora-prod.cluster-ci5g5g927ppu.us-east-1.rds.amazonaws.com",
  //   dialect: "postgres",
  //   use_env_variable: "postgres",
  // },
};
