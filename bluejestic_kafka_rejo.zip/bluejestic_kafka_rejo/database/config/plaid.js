const plaid = require("plaid");


console.log("🚀 ~ file: plaid.js:8 ~ PLAID_CLIENT_ID:", process.env.PLAID_CLIENT_ID)
console.log("🚀 ~ file: plaid.js:10 ~ PLAID_SECREST_ID:", process.env.PLAID_SECREST_ID)

// Plaid client setup
const plaidClient = new plaid.Client({
    clientID: process.env.PLAID_CLIENT_ID,
    secret: process.env.PLAID_SECREST_ID,
    env: plaid.environments.sandbox,
  });


  module.exports = plaidClient;




