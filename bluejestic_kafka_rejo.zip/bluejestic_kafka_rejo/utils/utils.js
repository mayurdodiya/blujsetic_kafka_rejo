const database = require("../database/models");
const { Op, where } = require("sequelize");
const client = require("../services/elasticsearch/config/config");
const moment = require("moment");
const user = require("../graphql/schemas/user");
const axios = require("axios");
const redisClient = require("../redis/redisClient");

const stateRegions = {
  "North": [
    "Maine", "New Hampshire", "Vermont", "Massachusetts", "Rhode Island", "Connecticut",
    "New York", "Pennsylvania", "Ohio", "Michigan", "Wisconsin", "Minnesota",
    "North Dakota", "South Dakota", "Montana", "Wyoming"
  ],
  "East": [
    "Delaware", "Maryland", "New Jersey", "Virginia", "West Virginia",
    "North Carolina", "South Carolina", "Georgia", "Florida"
  ],
  "West": [
    "Alaska", "Washington", "Oregon", "California", "Nevada", "Idaho",
    "Montana", "Utah", "Arizona", "Hawaii"
  ],
  "South": [
    "Tex  as", "Oklahoma", "Arkansas", "Louisiana", "Mississippi", "Alabama",
    "Tennessee", "Kentucky", "Missouri"
  ]
};

const countryRegions = {
  "Asia": [
    "China", "India", "Japan", "South Korea", "Indonesia", "Pakistan", "Bangladesh",
    "Russia", "Turkey", "Iran", "Saudi Arabia", "Thailand", "Vietnam", "Malaysia",
    "Singapore", "Philippines", "Nepal", "Sri Lanka", "Afghanistan", "Myanmar",
    "South Korea", "North Korea", "Uzbekistan", "Kazakhstan", "Jordan", "Israel"
  ],
  "America": [
    "United States of America", "Canada", "Mexico", "Brazil", "Argentina", "Colombia",
    "Chile", "Peru", "Venezuela", "Ecuador", "Guatemala", "Cuba", "Bolivia",
    "Paraguay", "Uruguay", "Guyana", "Suriname", "Belize", "Costa Rica",
    "Panama", "Honduras", "El Salvador", "Nicaragua", "Trinidad and Tobago"
  ],
  "Pacific": [
    "United States (California, Hawaii)", "Canada (British Columbia)", "Mexico",
    "Japan", "South Korea", "North Korea", "Russia", "Taiwan", "Philippines",
    "Indonesia", "Malaysia (Borneo)", "Australia", "New Zealand", "Papua New Guinea",
    "Fiji", "Solomon Islands", "Vanuatu", "Samoa", "Tonga", "Kiribati",
    "Micronesia (Federated States of Micronesia)", "Palau", "French Polynesia",
    "New Caledonia", "American Samoa", "Guam"
  ],
  "Middle East": [
    "Saudi Arabia", "Iran", "Turkey", "Israel", "United Arab Emirates", "Qatar",
    "Oman", "Kuwait", "Bahrain", "Lebanon", "Syria", "Jordan", "Iraq", "Yemen",
    "Afghanistan", "Pakistan"
  ],
  "Europe": [
    "United Kingdom", "Germany", "France", "Italy", "Spain", "Netherlands",
    "Sweden", "Norway", "Poland", "Belgium", "Switzerland", "Austria", "Denmark",
    "Finland", "Ireland", "Portugal", "Romania", "Greece", "Czech Republic",
    "Hungary", "Bulgaria", "Slovakia", "Croatia", "Slovenia", "Estonia",
    "Latvia", "Lithuania", "Luxembourg", "Malta", "Cyprus", "Iceland", "Liechtenstein",
    "Monaco", "Andorra", "San Marino", "Vatican City"
  ]
};



module.exports = {
  //   For friend status
  checkStatusesForFriend: async (userId, friendId) => {
    let friend = {};
    if (userId) {
      friend = await database.Friend.findOne({
        where: {
          user_id: userId,
          friend_id: friendId,
        },
        raw: true,
      });
    } else {
      // friend = await database.Friend.findOne({
      //   where: {
      //     friend_id: friendId,
      //   },
      //   raw: true,
      // });
    }
    console.log("friend+++++++++++", friend);
    if (friend) {
      return {
        isActiveForFriendStatus: friend?.isActive || false,
        isFriendForFriendStatus: friend?.isFriend || false,
      };
    } else {
      return {
        isActiveForFriendStatus: false,
        isFriendForFriendStatus: false,
      };
    }
  },
  likeServiceForValidation: async (like_for, database, parent_id) => {
    let body = {};
    let data = false;
    switch (like_for) {
      case "POST":
        console.log("POST");
        data = await database.Post.findOne({ where: { id: parent_id } });
        body["post_id"] = parent_id;
        // console.log("data post", data);
        break;
      case "COMMENT":
        console.log("COMMENT");
        body["comment_id"] = parent_id;
        data = await database.Comment.findOne({ where: { id: parent_id } });
        break;
      case "SELLERPOST":
        console.log("SELLERPOST");
        // body["seller_post_id"] = parent_id
        // data = await database.SellerPost.findOne({ where: { id: parent_id } });
        data = await database.Post.findOne({ where: { id: parent_id, post_for: "SELLER" } });
        body["post_id"] = parent_id;
        break;
      case "GROUP":
        console.log("GROUP");
        // body["group_post_id"] = parent_id
        // data = await database.Post.findOne({ where: { id: parent_id } });
        data = await database.Post.findOne({ where: { id: parent_id, post_for: "GROUP" } });
        body["post_id"] = parent_id;
        break;
      case "COMMENTREPLY":
        console.log("COMMENTREPLY");
        body["comment_reply_id"] = parent_id;
        data = await database.CommentReply.findOne({ where: { id: parent_id } });
        break;
      case "PRODUCT":
        console.log("PRODUCT");
        body["product_id"] = parent_id;
        data = await database.Product.findOne({ where: { id: parent_id, is_deleted: false } });
        break;
      case "SHAREPOST":
        console.log("SHAREPOST");
        body["share_post_id"] = parent_id;
        data = await database.SharePost.findOne({ where: { id: parent_id } });
        break;
      default:
        body = {};
        data = null;
        break;
    }
    // console.log("body", data);
    return { body, data };
  },
  commentServiceForValidation: async (comment_for, database, parent_id) => {
    let body = {};
    let data = false;
    switch (comment_for) {
      case "POST":
        console.log("POST");
        data = await database.Post.findOne({ where: { id: parent_id } });
        body["post_id"] = parent_id;
        // console.log("data post", data);
        break;
      case "USER":
        console.log("USER");
        body["user_id"] = parent_id;
        data = await database.User.findOne({ where: { id: parent_id } });
        break;
      case "STORE":
        console.log("STORE");
        // body["seller_post_id"] = parent_id
        // data = await database.SellerPost.findOne({ where: { id: parent_id } });
        data = await database.Post.findOne({ where: { id: parent_id, post_for: "SELLER" } });
        body["post_id"] = parent_id;
        break;
      case "GROUP":
        console.log("GROUP");
        // body["group_post_id"] = parent_id
        // data = await database.Post.findOne({ where: { id: parent_id } });
        data = await database.Post.findOne({ where: { id: parent_id, post_for: "GROUP" } });
        body["post_id"] = parent_id;
        break;
      case "PRODUCT":
        console.log("PRODUCT");
        body["product_id"] = parent_id;
        data = await database.Product.findOne({ where: { id: parent_id, is_deleted: false } });
        break;
      case "SHAREPOST":
        console.log("SHAREPOST");
        body["share_post_id"] = parent_id;
        data = await database.SharePost.findOne({ where: { id: parent_id } });
        break;
      default:
        body = {};
        data = null;
        break;
    }
    // console.log("body", data);
    return { body, data };
  },
  updateOrDeleteServiceOfProduct: async (database, validationData, updateOrFindQuery, userId, productId, type) => {
    console.log("validationData", validationData);
    let isUpdate = false;
    if (validationData && validationData.length > 0) {
      // Delete all product datas
      let find = await database.findOne(updateOrFindQuery);
      if (find) await database.destroy(updateOrFindQuery);
      let input = {};
      input["user_id"] = userId;
      input["product_id"] = productId;
      for await (const datas of validationData) {
        if (type === "size") {
          input["size"] = datas;
        } else {
          for await (const obj of Object.keys(datas)) {
            input[obj] = datas[obj];
          }
        }
        let data = await database.create(input);
        isUpdate = true;
      }
    } else {
      let find = await database.findOne(updateOrFindQuery);
      if (find) await database.destroy(updateOrFindQuery);
      isUpdate = true;
    }
    return isUpdate;
  },
  findMediaUrlFromId: async (id) => {
    // console.log("ID >>>>>>>>>>>>>>>>>>>>>>>>>>", id);
    if (!id) return 0;
    let media = await database.Media.findOne({ where: { id: id } });
    return media?.media ? media?.media : 0;
  },
  findMediaUrlFromIds: async (id) => {
    if (id && id.length === 0) return [];
    let media = await database.Media.findAll({ where: { id: { [Op.in]: id } } }, { raw: true });
    media = media.map((item) => item.media);
    return media;
  },
  findCropImages: async (cropImages) => {
    // console.log("cropImages", cropImages);
    let findImage = async (id) => {
      let media = await database.Media.findOne({ where: { id: id } });
      return media?.media ? media?.media : null;
    };
    if (cropImages && cropImages.length > 0) {
      for (const cropImage of cropImages) {
        cropImage.oldFile = await findImage(cropImage.oldFile);
        cropImage.croppedFile.baseURL = await findImage(cropImage?.croppedFile?.baseURL);
      }
    } else {
      cropImages = [];
    }
    return cropImages;
  },
  getPreviousDate: async (start_date, end_date) => {
    const startDateCheck = moment(start_date);
    const endDateCheck = moment(end_date);
    const diff = endDateCheck.diff(startDateCheck); // Calculate the difference between dates in milliseconds
    console.log(start_date);
    const previousStartDate = startDateCheck.subtract(diff).toISOString();
    let prev_min_date = previousStartDate;
    let prev_max_date = moment(start_date).toISOString();

    return { previous_start_date: prev_min_date, previous_end_date: prev_max_date };
  },
  userDevicesHelper: async (store_id, start_date, end_date, time_interval, time_zone) => {
    let time_stamp = null;
    let match = { match: { store_id } };
    if (start_date && end_date) time_stamp = { range: { createdAt: { gte: start_date, lte: end_date } } };
    const response = await client.search({
      index: "store-activities",
      body: {
        size: 0,
        ...(time_stamp ? { query: { bool: { must: [match, time_stamp] } } } : { query: match }),
        aggs: {
          device_counts: {
            terms: {
              field: "deviceName",
            },
          },
        },
      },
    });
    // Process the results and calculate percentages
    const deviceCounts = response.aggregations.device_counts.buckets;
    const totalDocuments = deviceCounts.reduce((sum, bucket) => sum + bucket.doc_count, 0);

    let defaultDevices = [
      { deviceName: "Desktop", percentage: 0, count: 0 },
      { deviceName: "Mobile", percentage: 0, count: 0 },
      { deviceName: "Tablet", percentage: 0, count: 0 },
    ];

    const result = deviceCounts.map((bucket) => ({
      deviceName: bucket.key,
      count: bucket.doc_count,
      percentage: parseFloat(((bucket.doc_count / totalDocuments) * 100).toFixed(2)),
    }));

    // replace default devices with actual devices

    defaultDevices.forEach((device, index) => {
      const deviceIndex = result.findIndex((item) => item.deviceName === device.deviceName);
      if (deviceIndex === -1) {
        result.splice(index, 0, device);
      }
    });
    return result;
  },
  visitorsGenderHelper: async (store_id, start_date, end_date, time_interval, time_zone) => {
    let time_stamp = null;
    let match = { match: { store_id: store_id } };
    if (start_date && end_date) time_stamp = { range: { createdAt: { gte: start_date, lte: end_date } } };

    const storeActivities = await client.search({
      index: "store-activities",
      ...(time_stamp ? { query: { bool: { must: [match, time_stamp] } } } : { query: match }),
      body: {
        size: 0,
        aggs: {
          users: {
            terms: {
              field: "user_id",
            },
          },
        },
      },
    });
    let userIds = storeActivities.aggregations.users.buckets.map((item) => item.key);
    // console.log("storeActivities", userIds);

    // return
    const response = await client.search({
      index: "user",
      body: {
        query: {
          terms: {
            id: userIds,
          },
        },
        aggs: {
          device_counts: {
            terms: {
              field: "gender",
            },
          },
        },
      },
    });

    // Process the results and calculate percentages
    const userCounts = response.aggregations.device_counts.buckets;
    const totalDocuments = userCounts.reduce((sum, bucket) => sum + bucket.doc_count, 0);

    let defaultGenders = [
      { gender: "Male", percentage: 0, count: 0 },
      { gender: "Female", percentage: 0, count: 0 },
    ];

    const result = userCounts.map((bucket) => ({
      gender: bucket.key,
      count: bucket.doc_count,
      percentage: parseFloat(((bucket.doc_count / totalDocuments) * 100).toFixed(2)),
    }));

    // replace default gender with actual gender

    defaultGenders.forEach((device, index) => {
      const deviceIndex = result.findIndex((item) => item.gender === device.gender);
      if (deviceIndex === -1) {
        result.splice(index, 0, device);
      }
    });
    return result;
  },
  visitorsLocationHelper: async (store_id, filterType) => {
    let match = { match: { store_id: store_id } };

    const storeActivities = await client.search({
      index: "store-activities",

      body: {
        query: match,
        size: 0,
        aggs: {
          users: {
            terms: {
              field: "user_id",
            },
          },
        },
      },
    });
    let userIds = storeActivities.aggregations.users.buckets.map((item) => item.key);

    // return
    const response = await client.search({
      index: "user",
      body: {
        query: {
          terms: {
            id: userIds,
          },
        },
        aggs: {
          device_counts: {
            terms: {
              field: filterType ? filterType : "country",
              exclude: ["", "null", "undefined"],
            },
          },
        },
      },
    });

    // Process the results and calculate percentages
    const userCounts = response.aggregations.device_counts.buckets;
    const totalDocuments = userCounts.reduce((sum, bucket) => sum + bucket.doc_count, 0);

    const result = userCounts.map((bucket) => ({
      [filterType ? filterType : "country"]: bucket.key,
      count: bucket.doc_count,
      percentage: parseFloat(((bucket.doc_count / totalDocuments) * 100).toFixed(2)),
    }));
    return result;
  },
  customersLocationHelper: async (store_id, filterType) => {
    let match = { match: { store_id: store_id } };

    const orders = await client.search({
      index: "orders",

      body: {
        query: match,
        size: 0,
        aggs: {
          users: {
            terms: {
              field: "user_id",
            },
          },
        },
      },
    });
    let userIds = orders.aggregations.users.buckets.map((item) => item.key);

    // return
    const response = await client.search({
      index: "user",
      body: {
        query: {
          terms: {
            id: userIds,
          },
        },
        aggs: {
          device_counts: {
            terms: {
              field: filterType ? filterType : "country",
              exclude: ["", "null", "undefined"],
            },
          },
        },
      },
    });

    // Process the results and calculate percentages
    const userCounts = response.aggregations.device_counts.buckets;
    const totalDocuments = userCounts.reduce((sum, bucket) => sum + bucket.doc_count, 0);

    const result = userCounts.map((bucket) => ({
      [filterType ? filterType : "country"]: bucket.key,
      count: bucket.doc_count,
      percentage: parseFloat(((bucket.doc_count / totalDocuments) * 100).toFixed(2)),
    }));
    return result;
  },
  storeCustomersMetrics: async ({ store_id, start_date, end_date, time_interval, time_zone }, indexName = "orders") => {
    try {
      let previous_range = await module.exports.getPreviousDate(start_date, end_date);
      const query = {
        size: 0,
        query: {
          match: {
            store_id: store_id,
          },
        },
        aggs: {
          new_customers: {
            filter: {
              range: {
                createdAt: {
                  gte: start_date,
                  lte: end_date,
                },
              },
            },
          },
          repeat_customers: {
            filter: {
              range: {
                createdAt: {
                  gte: previous_range.previous_start_date,
                  lte: previous_range.previous_end_date,
                },
              },
            },
          },
          total_customers: {
            terms: {
              field: "user_id",
            },
          },
        },
      };

      let orders = await client.search({
        index: indexName,
        body: query,
      });
      let total_customer = orders.hits.total.value;
      let new_customers = orders.aggregations.new_customers.doc_count;
      let repeat_customers = orders.aggregations.repeat_customers.doc_count;
      let final = {
        // counts : orders.aggregations.total_customers.buckets.reduce((acc, curr) => acc + curr.doc_count, 0),
        total_customer,
        new_customers,
        repeat_customers,
        new_customers_rate: parseFloat(((new_customers / total_customer) * 100).toFixed(2)),
        repeat_customers_rate: parseFloat(((repeat_customers / total_customer) * 100).toFixed(2)),
      };
      return { success: true, message: "success", data: final };
    } catch (error) {
      return { success: false, message: error.message };
    }
  },
  repeatCustomersHelper: async ({ store_id, start_date, end_date, time_interval, time_zone }, indexName = "order_items") => {
    try {
      let previous_range = await module.exports.getPreviousDate(start_date, end_date);
      /* current customers */
      const curr_query = {
        query: {
          bool: {
            filter: [
              { term: { store_id: store_id } },
              /* range query */
              { range: { createdAt: { gte: start_date, lte: end_date } } },
            ],
          },
        },
        fields: ["user_id"],
        _source: false,
        aggs: {
          customers: {
            terms: { field: "user_id" },
          },
        },
      };

      let current_customers = await client.search({
        index: indexName,
        body: curr_query,
      });

      /* previous customers */
      const prev_query = {
        query: {
          bool: {
            filter: [
              { term: { store_id: store_id } },
              /* range query */
              { range: { createdAt: { gte: previous_range.previous_start_date, lte: previous_range.previous_end_date } } },
            ],
          },
        },
        fields: ["user_id"],
        _source: false,
        aggs: {
          customers: {
            terms: { field: "user_id" },
          },
        },
      };

      let previous_customers = await client.search({
        index: indexName,
        body: prev_query,
      });

      let current_customers_collection = current_customers.aggregations.customers.buckets.map((item) => item.key);
      let current_data = {
        total_customers: current_customers_collection.length,
        customers_collection: current_customers_collection,
      };

      let previous_customers_collection = previous_customers.aggregations.customers.buckets.map((item) => item.key);
      let previous_data = {
        total_customers: previous_customers_collection.length,
        customers_collection: previous_customers_collection,
      };

      let repeat_customers = current_data.customers_collection.filter((rec) => previous_data.customers_collection.includes(rec)).length;
      let repeat_customers_rate = current_data.total_customers === 0 ? 0 : parseFloat(((repeat_customers / current_data.total_customers) * 100).toFixed(2));
      return {
        success: true,
        message: "success",
        data: { repeat_customers_count: repeat_customers, repeat_customers_percentage: repeat_customers_rate },
      };
    } catch (error) {
      return { success: false, message: error.message };
    }
  },
  orderCustomersGenderHelper: async (store_id, start_date, end_date, time_interval, time_zone) => {
    let time_stamp = null;
    let match = { match: { store_id: store_id } };
    if (start_date && end_date) time_stamp = { range: { createdAt: { gte: start_date, lte: end_date } } };

    const usersData = await client.search({
      index: "order_items",
      ...(time_stamp ? { query: { bool: { must: [match, time_stamp] } } } : { query: match }),
      body: {
        size: 0,
        aggs: {
          users: {
            terms: {
              field: "user_id",
            },
          },
        },
      },
    });

    let userIds = usersData.aggregations.users.buckets.map((item) => item.key);

    const response = await client.search({
      index: "user",
      body: {
        query: {
          terms: {
            id: userIds,
          },
        },
        aggs: {
          device_counts: {
            terms: {
              field: "gender.keyword",
            },
          },
        },
      },
    });

    const userCounts = response.aggregations.device_counts.buckets;
    const totalDocuments = userCounts.reduce((sum, bucket) => sum + bucket.doc_count, 0);

    let defaultGenders = [
      { gender: "Male", percentage: 0, count: 0 },
      { gender: "Female", percentage: 0, count: 0 },
    ];

    const result = userCounts.map((bucket) => ({
      gender: bucket.key,
      count: bucket.doc_count,
      percentage: parseFloat(((bucket.doc_count / totalDocuments) * 100).toFixed(2)),
    }));

    // replace default gender with actual gender

    defaultGenders.forEach((device, index) => {
      const deviceIndex = result.findIndex((item) => item.gender === device.gender);
      if (deviceIndex === -1) {
        result.splice(index, 0, device);
      }
    });
    return result;
  },

  customerAgeRatioMetrics: async (store_id, start_date, end_date, time_interval, time_zone) => {
    let time_stamp = null;
    let match = { match: { store_id: store_id } };
    if (start_date && end_date) time_stamp = { range: { createdAt: { gte: start_date, lte: end_date } } };

    const orderData = await client.search({
      index: "order_items",
      ...(time_stamp ? { query: { bool: { must: [match, time_stamp] } } } : { query: match }),
      body: {
        size: 0,
        aggs: {
          users: {
            terms: {
              field: "user_id",
            },
          },
        },
      },
    });
    let userIds = orderData.aggregations.users.buckets.map((item) => item.key);
    const response = await client.search({
      index: "user",
      body: {
        query: {
          terms: {
            id: userIds,
          },
        },
        size: 0,
        aggs: {
          age_ranges: {
            range: {
              field: "bday",
              ranges: [
                // { "from": "now-18y/y", "to": "now/y", "key": "0-17" },
                { from: "now-25y/y", to: "now-18y/y", key: "18-24" },
                { from: "now-45y/y", to: "now-35y/y", key: "35-44" },
                { from: "now-35y/y", to: "now-25y/y", key: "25-34" },
                { from: "now-60y/y", to: "now-45y/y", key: "45-60" },
                { to: "now-60y/y", key: "60+" },
              ],
            },
            aggs: {
              total_count: {
                value_count: {
                  field: "bday.keyword",
                },
              },
              gender: {
                terms: {
                  field: "gender.keyword",
                },
              },
            },
          },
        },
      },
    });
    let total_users_counts = response.aggregations.age_ranges.buckets.reduce((sum, bucket) => sum + bucket.doc_count, 0);
    let users_ages = response.aggregations.age_ranges.buckets;
    let ages_range = users_ages.map((item) => {
      return {
        range: item.key,
        age_count: item.doc_count,
        age_percentage: total_users_counts === 0 ? 0 : parseFloat(((item.doc_count / total_users_counts) * 100).toFixed(2)),
      };
    });
    return ages_range;
  },
  customerAgeBarChartResponse: async (store_id, start_date, end_date, time_interval, time_zone) => {
    let time_stamp = null;
    let match = { match: { store_id: store_id } };
    if (start_date && end_date) time_stamp = { range: { createdAt: { gte: start_date, lte: end_date } } };

    const orderData = await client.search({
      index: "order_items",
      ...(time_stamp ? { query: { bool: { must: [match, time_stamp] } } } : { query: match }),
      body: {
        size: 0,
        aggs: {
          users: {
            terms: {
              field: "user_id",
            },
          },
        },
      },
    });
    let userIds = orderData.aggregations.users.buckets.map((item) => item.key);
    const response = await client.search({
      index: "user",
      body: {
        query: {
          terms: {
            id: userIds,
          },
        },
        size: 0,
        aggs: {
          age_ranges: {
            range: {
              field: "bday",
              ranges: [
                // { "from": "now-18y/y", "to": "now/y", "key": "0-17" },
                { from: "now-25y/y", to: "now-18y/y", key: "18-24" },
                { from: "now-45y/y", to: "now-35y/y", key: "35-44" },
                { from: "now-35y/y", to: "now-25y/y", key: "25-34" },
                { from: "now-60y/y", to: "now-45y/y", key: "45-60" },
                { to: "now-60y/y", key: "60+" },
              ],
            },
            aggs: {
              total_count: {
                value_count: {
                  field: "bday.keyword",
                },
              },
              gender: {
                terms: {
                  field: "gender.keyword",
                },
              },
            },
          },
        },
      },
    });
    let users_ages = response.aggregations.age_ranges.buckets;

    let default_age = [
      { key: "Male", doc_count: 0 },
      { key: "Female", doc_count: 0 },
    ];
    let result = users_ages
      .map((user, index) => {
        return {
          index,
          name: user.key,
          data: [...user.gender.buckets, ...default_age.filter((e) => !user.gender.buckets.find((a) => e.key === a.key))],
        };
      })
      .sort((a, b) => b.index - a.index)
      .map(({ name, data }) =>
        data.map(({ key, doc_count }) => {
          return { name: key, doc_count };
        })
      )
      .reduce((acc, curr) => {
        curr.forEach((item, index) => {
          const name = item.name;
          const doc_count = item.doc_count;

          if (!acc[index]) {
            acc[index] = { name, data: [doc_count] };
          } else {
            acc[index].data.push(doc_count);
          }
        });

        return acc;
      }, []);
    return result;
  },
  customersLocationBySalesHelper: async (store_id, filterType) => {
    let match = { match: { store_id: store_id } };

    const orders = await client.search({
      index: "orders",
      body: {
        query: match,
        size: 0,
        aggs: {
          users: {
            terms: {
              field: "user_id",
            },
            aggs: {
              total_revenue: {
                sum: {
                  field: "total",
                },
              },
            },
          },
          net_revenue: {
            sum_bucket: {
              buckets_path: "users>total_revenue",
            },
          },
        },
      },
    });
    let ordersData = orders.aggregations.users.buckets;
    let net_revenue = orders.aggregations.net_revenue.value;
    let response = await client.search({
      index: "user",
      body: {
        query: {
          terms: {
            id: ordersData.map((item) => item.key),
          },
        },
        aggs: {
          device_counts: {
            terms: {
              field: filterType ? filterType : "country",
              exclude: ["", "null", "undefined"],
            },
            aggs: {
              ids: {
                top_hits: {
                  _source: ["id"],
                  size: 10,
                },
              },
            },
          },
        },
      },
    });
    const userBuckets = response.aggregations.device_counts.buckets;
    const totalDocuments = userBuckets.reduce((sum, bucket) => sum + bucket.doc_count, 0);
    const result = userBuckets.map((bucket) => {
      let revenue = 0;
      revenue = parseFloat(
        bucket.ids.hits.hits
          .map((item) => item._source.id)
          .reduce((sum, id) => {
            let order = ordersData.find((item) => item.key === id);
            return sum + order.total_revenue.value;
          }, 0)
      );
      return {
        [filterType ? filterType : "country"]: bucket.key,
        count: bucket.doc_count,
        user_ids: bucket.ids.hits.hits.map((item) => item._source.id),
        total_revenue: revenue,
        revenue_percentage: parseFloat(((revenue / net_revenue) * 100).toFixed(2)),
        percentage: parseFloat(((bucket.doc_count / totalDocuments) * 100).toFixed(2)),
      };
    });
    return result;
  },
  customersCategoryBySalesHelper: async (store_id, filterType) => {
    let match = { match: { store_id: store_id } };

    const orders = await client.search({
      index: "orders",
      body: {
        query: match,
        size: 0,
        aggs: {
          users: {
            terms: {
              field: "product_id",
            },
            aggs: {
              total_revenue: {
                sum: {
                  field: "total",
                },
              },
            },
          },
        },
      },
    });
    let ordersData = orders.aggregations.users.buckets;
    console.log("ordersData", ordersData);

    // categories

    // let categories = await

    // let response = await client.search({
    //   index: "user",
    //   body: {
    //     query: {
    //       terms: {
    //         id: ordersData.map((item) => item.key),
    //       }
    //     },
    //     aggs: {
    //       device_counts: {
    //         terms: {
    //           field: filterType ? filterType : "country",
    //           exclude: ["", "null", "undefined"]
    //         },
    //         aggs: {
    //           ids: {
    //             top_hits: {
    //               _source: ["id"],
    //               size: 10
    //             }
    //           }
    //         }
    //       },
    //     },
    //   }
    // });
    // const userBuckets = response.aggregations.device_counts.buckets;
    // const totalDocuments = userBuckets.reduce((sum, bucket) => sum + bucket.doc_count, 0);
    // const result = userBuckets.map((bucket) => {
    //   return {
    //     [filterType ? filterType : "country"]: bucket.key,
    //     count: bucket.doc_count,
    //     user_ids: bucket.ids.hits.hits.map((item) => item._source.id),
    //     total_revenue: parseFloat(bucket.ids.hits.hits.map((item) => item._source.id).reduce((sum, id) => {
    //       let order = ordersData.find((item) => item.key === id)
    //       return sum + order.total_revenue.value
    //     }, 0)),
    //     percentage: parseFloat(((bucket.doc_count / totalDocuments) * 100).toFixed(2)),
    //   }
    // });
    // return result;
    return null;
  },

  chargesOnPrices: async (price, rate) => {
    let charges = (price * rate) / 100;
    return { charges: charges, total: price + charges };
  },

  order_number_generator: async () => {
    // get last sequence id
    let lastOrderId = await database.OrderMaster.findOne({
      order: [["order_id", "DESC"]],
      limit: 1,
      raw: true,
    });
    let order_id = lastOrderId?.order_id;
    function getNextSequenceNumber(currentSequence) {
      let roundOff = 11;
      if (!currentSequence)
        return (
          Array(roundOff - 1)
            .fill("0")
            .join("") + "1"
        );
      const currentNumber = parseInt(currentSequence.slice(2));
      const nextNumber = currentNumber + 1;
      const nextSequence = `${nextNumber.toString().padStart(roundOff, "0")}`;
      return nextSequence;
    }
    const nextSequence = getNextSequenceNumber(order_id);
    return nextSequence;
  },

  /* get shipping charges by shipment id */
  shippingChargesbyShipmentId: async (shipment_id) => {
    try {
      let data = JSON.stringify({
        shipment_id: shipment_id,
        rate_options: {
          carrier_ids: [process.env.SHIPENGINE_CARIRER_ID],
          service_codes: [process.env.SHIPENGINE_SERVICE_CODE],
        },
      });
      let config = {
        method: "post",
        maxBodyLength: Infinity,
        url: "https://api.shipengine.com/v1/rates",
        headers: {
          "Content-Type": "application/json",
          "API-Key": process.env.SHIPENGINE_API_KEY,
        },
        data: data,
      };

      let response = await axios(config);
      console.log("response", response.data.rate_response.rates[0], response.data.rate_response.rates[0].shipping_amount);
      return response.data;
    } catch (error) {
      console.log("Ship Enginge - INTERNAL SERVER ERROR 1 : \n", error.message);
      return { success: false, message: error.message };
    }
  },

  /* get estimated charges by detiled address */
  estimatedShippingCharges: async (data) => {
    // {
    //   "carrier_ids": [
    //     "{{ups}}"
    //   ],
    //   "from_country_code": "US",
    //   "from_postal_code": "78756",
    //   "to_country_code": "US",
    //   "to_postal_code": "91521",totalSales
    //   "weight": {
    //     "value": 1,
    //     "unit": "pound"
    //   },
    //     "dimensions": {
    //     "length": 2,
    //     "width": 1,
    //     "height": 2,
    //     "unit": "inch"
    //   }
    // }

    try {
      let config = {
        method: "post",
        maxBodyLength: Infinity,
        url: "https://api.shipengine.com/v1/rates/estimate",
        headers: {
          "Content-Type": "application/json",
          "API-Key": process.env.SHIPENGINE_API_KEY,
        },
        data: data,
      };

      let response = await axios(config);
      let final;
      [final] = response.data.filter((item) => item.service_code === process.env.SHIPENGINE_SERVICE_CODE);
      let charges = final.shipping_amount.amount + final.insurance_amount.amount + final.confirmation_amount.amount + final.other_amount.amount;
      return { data: final, charges };
    } catch (error) {
      console.log("Ship Enginge - INTERNAL SERVER ERROR 2 : \n", error.message.message);
      return { success: false, message: error.message };
    }
  },

  /* create shipment */
  createShipment: async (data) => {
    console.log("datadatadatadata+++++++++++++++++++++++++++++++++++++++++++++++++++", JSON.parse(JSON.stringify(data))?.shipments[0]?.packages);

    // let example = {
    //   shipments: [
    //     {
    //       service_code: "ups_ground",
    //       ship_from: {
    //         name: "Chic Boutique",
    //         company_name: "Chic Boutique",
    //         address_line1: "195 NW 36th St",
    //         city_locality: "Miami",
    //         state_province: "FL",
    //         postal_code: "33101",
    //         country_code: "US",
    //         phone: "7867176711",
    //       },
    //       ship_to: {
    //         name: "Bhargav Patel",
    //         address_line1: "1200 NW 6 AVENUE",
    //         city_locality: "Miami",
    //         state_province: "FL",
    //         postal_code: "33125",
    //         country_code: "US",
    //       },
    //       packages: [{ weight: { value: 3, unit: "pound" }, dimensions: { length: 0, width: 0, height: 0, unit: "inch" } }],
    //     },
    //   ],
    // };

    // let example = {
    //   shipments: [
    //     {
    //       service_code: "ups_ground",
    //       ship_from: {
    //         name: "Chic Boutique",
    //         company_name: "Chic Boutique",
    //         address_line1: "195 NW 36th St",
    //         city_locality: "Miami",
    //         state_province: "FL",
    //         postal_code: "33101",
    //         country_code: "US",
    //         phone: "7867176711",
    //       },
    //       ship_to: {
    //         name: "Bhargav Patel",
    //         address_line1: "1200 NW 6 AVENUE",
    //         city_locality: "Miami",
    //         state_province: "FL",
    //         postal_code: "33125",
    //         country_code: "US",
    //       },
    //       packages: [{ weight: { value: 3, unit: "pound" }, dimensions: { length: 10, width: 10, height: 10, unit: "inch" } }],
    //     },
    //   ],
    // };

    // console.log("JSON.stringify(data)++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", JSON.stringify(example));

    try {
      let config = {
        method: "post",
        maxBodyLength: Infinity,
        url: "https://api.shipengine.com/v1/shipments",
        headers: {
          "Content-Type": "application/json",
          "API-Key": process.env.SHIPENGINE_API_KEY,
        },
        data: data,
      };

      let response = await axios(config);
      console.log("response", response.data);
      return response.data;
    } catch (error) {
      console.log("Ship Enginge - INTERNAL SERVER ERROR 3 : \n", error.message.message);
      return { success: false, message: error.message };
    }
  },

  cancelShipment: async (shipment_id, label_id) => {
    try {
      let labelConfig = {
        method: "put",
        maxBodyLength: Infinity,
        url: `https://api.shipengine.com/v1/labels/${label_id}/void`,
        headers: {
          "Content-Type": "application/json",
          "API-Key": process.env.SHIPENGINE_API_KEY,
        },
      };

      let labelConfigresponse = await axios(labelConfig);

      console.log("labelConfigresponse", labelConfigresponse);

      // if (labelConfigresponse) {
      //   let config = {
      //     method: "post",
      //     maxBodyLength: Infinity,
      //     url: `https://api.shipengine.com/v1/shipments/${shipment_id}/cancel`,
      //     headers: {
      //       "Content-Type": "application/json",
      //       "API-Key": process.env.SHIPENGINE_API_KEY,
      //     },
      //     data: data,
      //   };
      //   let response = await axios(config);
      //   console.log("response", response.data);
      // }

      return response.data;
    } catch (error) {
      console.log("Ship Enginge - INTERNAL SERVER ERROR 4 : \n", error);
      return { success: false, message: error.message };
    }
  },

  /* creae a lable for shipment */
  createLabelForShipment: async (shipment_id) => {
    console.log("lable_creating ++++++++++++++++++++++++++++++++++++++", shipment_id);

    try {
      let config = {
        method: "post",
        maxBodyLength: Infinity,
        url: `https://api.shipengine.com/v1/labels/shipment/${shipment_id}`,
        headers: {
          "Content-Type": "application/json",
          "API-Key": process.env.SHIPENGINE_API_KEY,
        },
      };

      let response = await axios(config);
      console.log("lable_createddasdas ++++++++++++++++++++++++++++++++++++++", response);
      // console.log("response+++++++++++++++++++++++++++++++", response);
      return { data: response.data, success: true };
    } catch (error) {
      console.log("Ship Enginge - INTERNAL SERVER ERROR 5 - createLabelForShipment()+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++  : \n", error?.response?.data?.errors[0]);
      return { success: false, message: error?.response?.data?.errors && error?.response?.data?.errors[0] };
    }
  },

  /* tracking shipment by label id */
  trackUsingLabelId: async (label_id) => {
    try {
      let config = {
        method: "get",
        maxBodyLength: Infinity,
        url: `https://api.shipengine.com/v1/labels/${label_id}/track`,
        headers: {
          "API-Key": process.env.SHIPENGINE_API_KEY,
        },
      };

      let response = await axios(config);
      console.log("response", response.data);
      return response.data;
    } catch (error) {
      console.log("Ship Enginge - INTERNAL SERVER ERROR 6 : \n", error.message);
      return { success: false, message: error.message };
    }
  },

  //* Working on shareposts
  sharePostsForFeed: async (postdd) => {
    //* working with share posts
    // console.log("post.sharePosts+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", postdd);
    let post = JSON.parse(JSON.stringify(postdd));
    if (post.post_for === "SHAREPOST") {
      if (post?.sharePosts?.products) {
        //* This loops helps to add new fields and some oprations
        // for (const sp of shareProducts) {

        //* find store products images
        // let images = post.sharePosts.products.cropImages && post.sharePosts.products.cropImages.map((media) => media.croppedFile?.baseURL);
        post.sharePosts.group_id = post?.group_id;
        let get_product_images = await post?.sharePosts?.products?.images?.map((im) => {
          return im.src;
        });

        post.sharePosts.products.image = get_product_images;
        // post.sharePosts.products.image = post.sharePosts.products.image.map((media) => media?.dataValues?.media);

        //* find store logo
        // let logo = await database.Media.findAll({
        //   where: {
        //     id: {
        //       [Op.in]: post.sharePosts.products.store.logo,
        //     },
        //   },
        // });
        // post.sharePosts.products.store.logo = logo.map((media) => media?.dataValues?.media);
        // console.log("post.sharePosts.products.store.logo", logo);
        //* find store cover image
        // if (Boolean(post?.sharePosts?.products?.store?.cover_image) && post?.sharePosts?.products?.store?.cover_image[0] !== "") {
        //   let cover_image = await database.Media.findAll({
        //     where: {
        //       id: {
        //         [Op.in]: post.sharePosts.products.store.cover_image,
        //       },
        //     },
        //   });
        //   post.sharePosts.products.store.cover_image = cover_image.map((media) => media?.dataValues?.media);
        // }
        /* STORE DETAIL - END */
        post = post.sharePosts;
        return post;
        // }
      } else if (post?.sharePosts?.collection) {
        let find_product_image = [];
        post.id = post?.id;
        for (let i = 0; i < post?.sharePosts?.collection?.bookmark_product?.length; i++) {
          let product = post?.sharePosts?.collection?.bookmark_product[i];
          // let get_product_images = await database.ProductMedia.findAll({ where: { product_id: product?.product_id, position: 1 } }).map((im) => {
          //   return im.src;
          // });
          find_product_image.push({ ...product?.bookmark });
        }
        let image = [];
        let n = 4;
        for (let i = 0; i < post?.sharePosts?.collection?.bookmark_product?.length; i++) {
          if (i == n - 1) break;
          const product = post?.sharePosts?.collection?.bookmark_product[i];
          if (Boolean(product?.bookmark.images?.length)) {
            let cropImages = Boolean(product?.bookmark.images?.length) ? product?.bookmark.images[0]?.src : null;
            if (cropImages) image.push(cropImages);
          }
        }
        post.sharePosts.collection.mainLike = post?.likes;
        post.sharePosts.collection.images = image;
        post.sharePosts.collection.like_count = post?.sharePosts?.collection?.likes?.length;
        post.sharePosts.collection.product_count = post?.sharePosts?.collection?.bookmark_product?.length;
        post.sharePosts.collection.bookmark_product = find_product_image;
        post = { ...post.sharePosts, id: post?.id };
        return post;
      } else {
        return post;
      }
    } else {
      return post;
    }
  },


  totalSellerSales: async (seller_id, time_zone, startDate, endDate, timeInterval) => {
    try {

      const totalSales = await client.search({
        index: "order_items",
        body: {
          size: 0, // Exclude document hits from the response
          query: {
            bool: {
              must: [
                { term: { seller_id: seller_id } }, // Match the seller_id exactly
                {
                  range: {
                    createdAt: {
                      gte: startDate, // Ensure the start date is properly formatted
                      lte: endDate,   // Ensure the end date is properly formatted
                    },
                  },
                },
              ]
            }
          },
          aggs: {
            sellers: {
              terms: {
                field: "seller_id", // Group by seller_id
                size: 1000         // Adjust bucket size as needed
              },
              aggs: {
                total_sales: {
                  sum: { field: "totalAmount" } // Sum totalAmount for each seller
                }
              }
            },
            overall_total: {
              sum_bucket: {
                buckets_path: "sellers>total_sales" // Sum all bucket values
              }
            }
          }
        }
      })

      return totalSales.aggregations.overall_total.value

    } catch (error) {
      console.log("Error getting total Sales:", error)
    }
  },

  totalOrdersOfSeller: async (seller_id, time_zone, startDate, endDate, timeInterval) => {
    try {
      const totalOrders = await client.count({
        index: "order_items",
        body: {
          query: {
            bool: {
              must: [
                { match: { seller_id: seller_id } },
                { range: { createdAt: { gte: startDate, lte: endDate } } }
              ]
            }
          }
        }
      });
      return totalOrders.count
    } catch (error) {
      console.error("Error getting total Orders:", error)
    }
  },

  averageOrderValueOfSeller: async (seller_id, time_zone, startDate, endDate, timeInterval) => {
    try {
      const averageOrderValue = await client.search({
        index: "order_items",
        body: {
          query: {
            bool: {
              must: [
                { match: { seller_id: seller_id } },
                { range: { createdAt: { gte: startDate, lte: endDate } } }
              ]
            }
          },
          aggs: {
            avg_order: {
              avg: { field: "totalAmount" }
            }
          }
        }
      })
      return averageOrderValue.aggregations.avg_order.value === null ? 0 : averageOrderValue.aggregations.avg_order.value
    } catch (error) { console.error("Error getting AOV:", error) }
  },

  totalRevenuOfSeller: async (seller_id, time_zone, startDate, endDate, timeInterval) => {
    try {
      const totalRevenue = await client.search({
        index: "order_items",
        body: {
          size: 0, // Exclude document hits from the response
          query: {
            bool: {
              must: [
                { match: { seller_id: seller_id } }, // Filter by seller_id
                { range: { createdAt: { gte: startDate, lte: endDate } } }
              ]
            }
          },
          aggs: {
            sellers: {
              terms: {
                field: "seller_id", // Group by seller_id
                size: 1000         // Adjust bucket size as needed
              },
              aggs: {
                total_sellerFinalAmount: {
                  sum: { field: "sellerFinalAmount" } // Sum totalAmount for each seller
                }
              }
            },
            overall_total: {
              sum_bucket: {
                buckets_path: "sellers>total_sellerFinalAmount" // Sum all bucket values
              }
            }
          }
        }
      })
      return totalRevenue.aggregations.overall_total.value
    } catch (error) {
      console.error("Error getting total Revenu:", error)
    }
  },

  orderOutOfStockOfSeller: async (seller_id, time_zone, startDate, endDate, timeInterval) => {
    try {
      const orderOutOfStock = await client.count({
        index: "order_items",
        body: {
          query: {
            bool: {
              must: [
                { match: { seller_id: seller_id } },
                { match: { quantity: 0 } },
                { range: { createdAt: { gte: startDate, lte: endDate } } },
              ]
            }
          }
        }
      })
      return orderOutOfStock.count
    } catch (error) {
      console.error("Error getting stock  of orders:", error)
    }
  },

  totalRevenueOverviewOfSeller: async (seller_id, time_zone, startDate, endDate, timeInterval) => {
    try {
      const revenueOverview = await client.search({
        index: "order_items",
        body: {
          query: {
            bool: {
              must: [
                { term: { seller_id: seller_id } }, // Match the seller_id exactly
                {
                  range: {
                    createdAt: {
                      gte: startDate,
                      lt: endDate,
                    },
                  },
                },
              ]
            }
          },
          aggs: {
            // Monthly stats combining revenue and orders
            monthly_stats: {
              date_histogram: {
                field: "createdAt", // Fixed field name based on mapping
                calendar_interval: timeInterval ? timeInterval : "day", // Set the interval to 'day'
                time_zone: time_zone ? time_zone : "Asia/Kolkata", // Use the provided time_zone or default to Asia/Kolkata
                min_doc_count: 0, // Include empty buckets
                extended_bounds: {
                  min: startDate,  // Set the start date for the range
                  max: endDate     // Set the end date for the range
                }
              },
              aggs: {
                revenue: {
                  sum: { field: "sellerFinalAmount" } // Sum the revenue for each date bucket
                },
                orders: {
                  cardinality: { field: "order_master_id" } // Count the distinct order IDs for each date bucket
                }
              }
            }
          }
        }
      });

      return revenueOverview
    } catch (error) {
      console.error("Error getting total Revenu Overview:", error)
    }
  },

  totalEarningsOfSeller: async (seller_id, time_zone, startDate, endDate, timeInterval) => {
    try {
      const totalRevenueAndEarnings = await client.search({
        index: "order_items",
        body: {
          size: 0,
          query: {
            bool: {
              must: [
                { term: { seller_id: seller_id } },
                {
                  range: {
                    createdAt: {
                      gte: startDate,
                      lte: endDate,
                    },
                  },
                },
              ]
            }
          },
          aggs: {
            monthly_data: {
              date_histogram: {
                field: 'createdAt',
                calendar_interval: timeInterval ? timeInterval : 'month',
                time_zone: time_zone ? time_zone : "Asia/Kolkata",
                min_doc_count: 0,
                extended_bounds: {
                  min: startDate,
                  max: endDate
                }
              },
              aggs: {
                total_revenue: { sum: { field: 'basicAmount' } },
                total_earnings: { sum: { field: 'sellerFinalAmount' } }
              }
            }
          }
        }
      });
      return totalRevenueAndEarnings.aggregations.monthly_data.buckets;
    } catch (error) {
      console.error("Error getting total Earnings:", error)
    }
  },

  getProcessingTimeOfSeller: async (seller_id, time_zone, startDate, endDate, timeInterval) => {
    try {
      const processingTime = await client.search({
        index: "order_items",
        body: {
          size: 0,
          query: {
            bool: {
              must: [
                { match: { seller_id: seller_id } },
                { range: { createdAt: { gte: startDate, lt: endDate } } }
              ]
            }
          },
        }
      });
      return processingTime.hits.hits;
    } catch (error) {
      console.error("Error getting total Earnings:", error)
    }
  },

  getProcessingTimeOfSellerForPreviousMonth: async (seller_id, time_zone, startDate, endDate, timeInterval) => {
    try {
      // Calculate startDate and endDate for the previous month
      const startDate = moment().subtract(1, "month").startOf("month").toISOString();
      const endDate = moment().subtract(1, "month").endOf("month").toISOString();


      // Elasticsearch query
      const processingTime = await client.search({
        index: "order_items", // Replace with your Elasticsearch index
        body: {
          size: 0, // No documents returned, only aggregations
          query: {
            bool: {
              must: [
                { match: { seller_id: seller_id } },
                { range: { createdAt: { gte: startDate, lt: endDate } } }
              ]
            }
          },
          aggs: {
            processing_time: {
              date_histogram: {
                field: "createdAt",
                calendar_interval: timeInterval,
                time_zone: time_zone ? time_zone : "Asia/Kolkata",
              }
            }
          }
        }
      });

      return processingTime.aggregations.processing_time.buckets.map((bucket) => ({
        key: bucket.key_as_string,
        doc_count: bucket.doc_count
      }));
    } catch (error) {
      console.error("Error getting processing time for the previous month:", error);
      throw new Error("Failed to fetch processing time");
    }
  },

  // previousMonthProcessingTime: async (seller_id, time_zone, startDate, endDate, timeInterval) => {
  //   try {
  //     const previousMonthProcessingTime = await client.search({
  //       index: "order_items",
  //       body: {
  //         size: 0,
  //         query: {
  //           bool: {
  //             must: [
  //               { match: { seller_id: seller_id } },
  //               { range: { createdAt: { gte: startDate, lte: endDate } } }
  //             ]
  //           }
  //         },
  //       }
  //     });      
  //     return previousMonthProcessingTime.hits.hits;
  //   } catch (error) {
  //     console.error("Error getting total Earnings:", error)
  //   }
  // },


  newCustomesOfSeller: async (seller_id, time_zone, startDate, endDate, timeInterval) => {
    try {
      let newCustomers = await client.search({
        index: 'order_items', // Replace with your index name
        size: 0, // No documents, only aggregation
        body: {
          query: {
            bool: {
              must: [
                {
                  term: {
                    seller_id: {
                      value: seller_id
                    }
                  },
                },
                {
                  term: {
                    isBuyAgainOrder: false
                  }
                }  
              ]
            }
          },
          aggs: {
            distinct_user_count: {
              cardinality: {
                field: 'user_id', // Replace with the actual field name
              },
            },
          },
        },
      });
      return newCustomers.aggregations.distinct_user_count.value;
    } catch (error) {
      console.log("Error getting new customers:", error)
    }
  },

  getTimeRange: (timeRange) => {
    let endDate = new Date().toISOString();
    let startDate = "";

    if (timeRange === 'Last_24_Hours') {
      startDate = moment().utc().subtract(24, "hours").toISOString();
    }

    if (timeRange === "Last_7_Days") {
      // Get the current date
      startDate = moment().utc().subtract(7, "days").toISOString();
    }

    if (timeRange === 'Last_30_Days') {
      startDate = moment().utc().subtract(30, "days").toISOString();      
      
    }

    if (timeRange === 'Last_90_Days') {
      startDate = moment().utc().subtract(90, "days").toISOString();      
    }

    if (timeRange === 'This_Year') {
      startDate = new moment().utc().startOf("year").toISOString();
    }

    if (timeRange === 'This_Month') {
      startDate = moment().utc().startOf("month").toISOString();      
    }

    if (timeRange === 'Previous_Month') {
      startDate = moment().utc().subtract(1, "months").startOf("month").toISOString();
      endDate = moment().utc().subtract(1, "months").endOf("month").toISOString();
    }


    return { startDate, endDate }
  },

  getAverageShippingTime: (shippingDetails) => {
    if (!shippingDetails || shippingDetails.length === 0) {
      return 0;
    }

    const totalOrderTime = shippingDetails.reduce((acc, value) => {
      const createdAt = new Date(value._source.createdAt);
      const updatedAt = new Date(value._source.updatedAt);


      if (isNaN(createdAt) || isNaN(updatedAt)) {
        return acc;
      }

      const orderTime = (updatedAt - createdAt) / (1000 * 60 * 60 * 24);
      return acc + orderTime;
    }, 0);

    return totalOrderTime / shippingDetails.length;
  },

  pendingShipmentsOfSeller: async (seller_id, time_zone, timeRange) => {
    try {

      const { startDate, endDate } = module.exports.getTimeRange(timeRange);
      const previousMonthDates = module.exports.getTimeRange('Last_30_Days')

      const [
        pendingShipmentsQuery,
        percentageChangeInPendingShipmentsQuery,
        inTransistShipmentsQuery,
        previousMonthInTransistQuery,
        deliveredShipmentsQuery,
        previousMonthDeliveredShipmentsQuery,
        cancelledShipmentsQuery,
        previousMonthCancelledShipmentsQuery,
        returnedShippmentsQuery,
        previousMonthReturnedShippmentsQuery,
        averageOrderTimeQuery,
        previousMonthAverageShipmentTime
      ] = await Promise.all([
        client.count({
          index: 'order_items',
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "pending" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: startDate === "" ? new Date(new Date().getTime() - 24 * 60 * 60 * 1000).toISOString() : startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  },
                ]
              }
            }
          }
        }),
        client.count({
          index: 'order_items',
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "pending" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: previousMonthDates.startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  },
                ]
              }
            }
          }
        }),
        client.count({
          index: 'order_items',
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "in_transit" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: startDate === "" ? new Date(new Date().getTime() - 24 * 60 * 60 * 1000).toISOString() : startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  },
                ]
              }
            }
          }
        }),
        client.count({
          index: 'order_items',
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "in_transit" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: previousMonthDates.startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  },
                ]
              }
            }
          }
        }),
        client.count({
          index: 'order_items',
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "delivered" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: startDate === "" ? new Date(new Date().getTime() - 24 * 60 * 60 * 1000).toISOString() : startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  },
                ]
              }
            }
          }
        }),
        client.count({
          index: 'order_items',
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "delivered" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: previousMonthDates.startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  },
                ]
              }
            }
          }
        }),
        client.count({
          index: 'order_items',
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "cancelled" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: startDate === "" ? new Date(new Date().getTime() - 24 * 60 * 60 * 1000).toISOString() : startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  },
                ]
              }
            }
          }
        }),
        client.count({
          index: 'order_items',
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "cancelled" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: previousMonthDates.startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  },
                ]
              }
            }
          }
        }),
        client.count({
          index: 'order_items',
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "returned" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: startDate === "" ? new Date(new Date().getTime() - 24 * 60 * 60 * 1000).toISOString() : startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  },
                ]
              }
            }
          }
        }),
        client.count({
          index: 'order_items',
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "returned" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: previousMonthDates.startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  },
                ]
              }
            }
          }
        }),
        client.search({
          index: "order_items",
          _source: ["createdAt", "updatedAt"],
          body: {
            query: {
              bool: {
                must: [
                  {
                    match: { order_status: "delivered" }
                  },
                  {
                    match: { seller_id: seller_id }
                  },
                  {
                    range: {
                      createdAt: {
                        gte: startDate === "" ? new Date(new Date().getTime() - 24 * 60 * 60 * 1000).toISOString() : startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  },
                ]
              }
            }
          }
        }),
        client.search({
          index: "order_items",
          _source: ["createdAt", "updatedAt"],
          body: {
            query: {
              bool: {
                must: [
                  {
                    match: { order_status: "delivered" }
                  },
                  {
                    match: { seller_id: seller_id }
                  },
                  {
                    range: {
                      createdAt: {
                        gte: previousMonthDates.startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  },
                ]
              }
            }
          }
        })
      ])

      const averageShipmentTime = module.exports.getAverageShippingTime(averageOrderTimeQuery.hits.hits)
      const changeInAverageShipmentTime = module.exports.getAverageShippingTime(previousMonthAverageShipmentTime.hits.hits)

      return {
        inTransistShipments: inTransistShipmentsQuery.count,
        pendingShipments: pendingShipmentsQuery.count,
        deliveredShipments: deliveredShipmentsQuery.count,
        cancelledShipments: cancelledShipmentsQuery.count,
        returnedShippments: returnedShippmentsQuery.count,
        previousMonthPendingShipments: percentageChangeInPendingShipmentsQuery.count,
        previousMonthInTransist: previousMonthInTransistQuery.count,
        previourMonthDelivered: previousMonthDeliveredShipmentsQuery.count,
        previousMonthCancelledShipments: previousMonthCancelledShipmentsQuery.count,
        previousMonthReturnedShippments: previousMonthReturnedShippmentsQuery.count,
        delayedShippings: 0,
        averageShipmentTime,
        changeInAverageShipmentTime
      }

    } catch (error) {
      console.log("Error getting pending shipments:", error)
    }
  },

  orderAnalyticsOfSeller: async (seller_id, time_zone, timeRange) => {
    try {

      const { startDate, endDate } = module.exports.getTimeRange(timeRange);
      const previousMonthDates = module.exports.getTimeRange('Last_30_Days')
      const [
        totalOrdersQuery,
        totalOrdersOfThisMonthQuery,
        totalOrdersOfPreviousMonthQuery,
        pendingOrdersQuery,
        previousMonthPendingOrdersQuery,
        cancelledOrdersQuery,
        previousMonthCancelledOrdersQuery,
        completedOrdersQuery,
        previousMonthCompletedOrdersQuery
      ] = await Promise.all([
        client.count({
          index: "order_items",
          body: {
            query: {
              bool: {
                must: [
                  { match: { seller_id: seller_id } },
                ],
              }
            }
          }
        }),
        client.count({
          index: "order_items",
          body: {
            query: {
              bool: {
                must: [
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: startDate === "" ? new Date(new Date().getTime() - 24 * 60 * 60 * 1000).toISOString() : startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  }
                ],
              }
            }
          }
        }),
        client.count({
          index: "order_items",
          body: {
            query: {
              bool: {
                must: [
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: previousMonthDates.startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  }
                ],
              }
            }
          }
        }),
        client.count({
          index: 'order_items',
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "pending" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: startDate === "" ? new Date(new Date().getTime() - 24 * 60 * 60 * 1000).toISOString() : startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      }
                    }
                  }
                ]
              }
            }
          }
        }),
        client.count({
          index: 'order_items',
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "pending" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: previousMonthDates.startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  },
                ]
              }
            }
          }
        }),
        client.count({
          index: 'order_items',
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "cancelled" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: startDate === "" ? new Date(new Date().getTime() - 24 * 60 * 60 * 1000).toISOString() : startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      }
                    }
                  }
                ]
              }
            }
          }
        }),
        client.count({
          index: 'order_items',
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "cancelled" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: previousMonthDates.startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  },
                ]
              }
            }
          }
        }),
        client.count({
          index: "order_items",
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "confirmed" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: startDate === "" ? new Date(new Date().getTime() - 24 * 60 * 60 * 1000).toISOString() : startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      }
                    }
                  }
                ]
              }
            }
          }
        }),
        client.count({
          index: 'order_items',
          body: {
            query: {
              bool: {
                must: [
                  { match: { order_status: "confirmed" } },
                  { match: { seller_id: seller_id } },
                  {
                    range: {
                      createdAt: {
                        gte: previousMonthDates.startDate,
                        lte: endDate,
                        time_zone: time_zone ? time_zone : 'Asia/Kolkata'
                      },
                    },
                  },
                ]
              }
            }
          }
        })
      ]);

      return {
        totalOrders: totalOrdersQuery.count,
        pendingOrders: pendingOrdersQuery.count,
        previousMonthPendingOrders: previousMonthPendingOrdersQuery.count,
        cancelledOrders: cancelledOrdersQuery.count,
        previousMonthCancelledOrders: previousMonthCancelledOrdersQuery.count,
        completedOrders: completedOrdersQuery.count,
        previousMonthCompletedOrders: previousMonthCompletedOrdersQuery.count,
        totalOrdersOfThisMonth: totalOrdersOfThisMonthQuery.count,
        totalOrdersOfPreviousMonth: totalOrdersOfPreviousMonthQuery.count,
      }

    } catch (error) {
      throw new Error(`Failed to fetch order analytics: ${error.message}`);
    }
  },

  calculatePercentageChange: ( currentMonth, previousMonth) => {
    if (previousMonth === 0) {
      return 0;
    }
    return ((currentMonth - previousMonth) / previousMonth) * 100 === -100 ? 0 : ((currentMonth - previousMonth) / previousMonth) * 100;
  },

  deleteProductCache: async (redisKey) => {
    console.log(`Deleting keys for ${redisKey}`);
    let cursor = '0';
    do {
      const [newCursor, keys] = await new Promise((resolve, reject) => {
        redisClient.scan(cursor, 'MATCH', `${redisKey}:*`, (err, result) => {
          if (err) reject(err);
          resolve(result);
        });
      });

      cursor = newCursor;
      if (keys.length > 0) {
        redisClient.del(keys, (err, response) => {
          if (err) {
            console.error('Error deleting keys:', err);
          } else {
            console.log(`Deleted ${response} product keys.`);
          }
        });
      }

    } while (cursor !== '0');
  },

  getTrafficAndEngagementData: async (store_id) => {
    try {

      const [
        productViews,
        productLikes,
        productShared,
        productSaved,
        genderRatio,
        regionWiseSalesRatio,
        totalVisitors
      ] = await Promise.all([
        client.search({
          index: "product-views",
          body: {
            query: {
              bool: {
                must: [
                  { match: { store_id: store_id } } // Match the store_id
                ]
              }
            },
            aggs: {
              views: {
                terms: {
                  field: "store_id",
                  size: 1000
                },
                aggs: {
                  product_views: {
                    sum: { field: "product_id" }
                  }
                }
              }
            }
          }
        }),
        client.search({
          index: "store-likes",
          body: {
            query: {
              bool: {
                must: [
                  { match: { store_id: store_id } },
                  { match: { like_for: "PRODUCT" } }
                ]
              }
            },
            aggs: {
              likes: {
                terms: {
                  field: "store_id",
                  size: 1000
                },
                aggs: {
                  product_likes: {
                    sum: { field: "product_id" } // Assuming this is a numeric field
                  }
                }
              }
            },
            size: 0 // Exclude document hits, we only care about aggregations
          }
        }),
        database.Post.findAll({
          where: {
            store_id: store_id,
            post_for: "SHAREPOST",
            isActive: true
          }
        }),
        database.Bookmark.findAll({
          includes: [
            {
              model: database.Products,
              where: { store_id: store_id, is_deleted: false, isActive: true },
            },
          ],
        }),
        database.OrderItems.findAll({
          where: {
            store_id: store_id,
          },
          include: [
            {
              model: database.User,
              as: "total_purchase_item",
              attributes: ["gender"],
            },
          ],
        }),
        database.OrderItems.findAll({
          where: {
            store_id: store_id,
          },
          include: [
            {
              model: database.User,
              as: "total_purchase_item",
              attributes: ["country"],
            },
          ],
        }),
        database.StoreActivity.count({
          where: {
            store_id,
            isDeleted: false,
            userType: 'user'
          }
        })
      ]);

      let regions = [];
      for (let i = 0; i < regionWiseSalesRatio.length; i++) {
        let region = await module.exports.getRegiounOfCountry(regionWiseSalesRatio[i].total_purchase_item.country);
        regions.push(region);
      }

      return {
        productViews: productViews.aggregations.views.buckets && productViews.aggregations.views.buckets.length ? productViews.aggregations.views.buckets[0].product_views.value : 0,
        productLikes: productLikes.aggregations.likes.buckets &&productLikes.aggregations.likes.buckets.length ? productLikes.aggregations.likes.buckets[0].product_likes.value : 0,
        productShared: productShared.length,
        productSaved: productSaved.length,
        genderRatio: genderRatio && genderRatio.length === 0 ? [] : genderRatio,
        regionWiseSalesRatio: regions && regions.length === 0 ? [] : regions,
        totalVisitors: totalVisitors
      }

    } catch (error) {
      console.log("Error getting traffic and engagement data:", error);
    }
  },

  getCustomerData: async (store_id) => {
    try {
      const [storeFollowers, totalCustomers, newCustomers] = await Promise.all([
        database.FollowStore.findAll({
          where: {
            store_id: store_id,
          }
        }),
        database.OrderItems.findAll({
          where: {
            store_id: store_id,
          }
        }),
        database.OrderItems.findAll({
          where: {
            store_id: store_id,
            createdAt: {
              [Op.gt]: new Date(new Date().getTime() - 10 * 24 * 60 * 60 * 1000), // Greater than 10 days ago
            }
          }
        })
      ])

      return {
        storeFollowers: storeFollowers.length,
        totalCustomers: totalCustomers.length,
        newCustomers: newCustomers.length
      }
    } catch (error) {
      console.log("Error getting customer details data:", error);
    }
  },

  getRegiounOfAmerica: async (stateName) => {
    try {
      for (const [region, states] of Object.entries(stateRegions)) {
        if (states.includes(stateName.split("/")[0])) {
          return region;
        }
      }
      return "Unknown Region";

    } catch (error) {
      console.log("Error getting region details data:", error);
      throw new Error("Failed to get region details");
    }
  },

  getRegiounOfCountry: async (country) => {
    try {
      for (const [region, countries] of Object.entries(countryRegions)) {
        if (countries.includes(country)) {
          return region;
        }
      }
      return "Unknown Region";
    } catch (error) {
      console.log("Error getting region details data:", error);
      throw new Error("Failed to get region details");
    }
  },

  getNextTXRCustomIdForPayout: async () => {
    try {
      const lastPayoutData = await database.SellerPayoutHistory.findOne({
        attributes: ["custom_txn_id"],
        order: [["id", "DESC"]],
        limit: 1,
        raw: true
      });

      if (!lastPayoutData) {
        return 'TRX-00000001';
      } else {
        return `TRX-${String(Number(lastPayoutData?.custom_txn_id.split("-")[1]) + 1).padStart(8, 0)}`;
      }

    } catch (error) {
      console.error("An error occured while generating TXR custom id: ", error);
      throw new Error("An error occured while generating TXR custom id");
    }
  },


  calculateAge: async (birthDate) => {
    const today = new Date();
    const birthDateObj = new Date(birthDate);
    let age = today.getFullYear() - birthDateObj.getFullYear();
    const m = today.getMonth() - birthDateObj.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDateObj.getDate())) {
      age--;
    }
    return age;
  },

  // sharePostsForFeed: async (post) => {
  //   //* working with share posts
  //   console.log('post++++++++++++++++++++++++++++++++++++++++++++++++++',post);
  //   if (post.post_for === "SHAREPOST") {
  //     post.sharePosts = JSON.parse(JSON.stringify(post.sharePosts));

  //     //* This loops helps to add new fields and some oprations
  //     // for (const sp of shareProducts) {

  //     //* find store products images
  //     // let images = post.sharePosts.products.cropImages && post.sharePosts.products.cropImages.map((media) => media.croppedFile?.baseURL);

  //     let get_product_images = await database.ProductMedia.findAll({ where: { product_id: post.sharePosts.products.id } }).map((im) => {
  //       return im.src;
  //     });

  //     post.sharePosts.products.image = get_product_images;
  //     // post.sharePosts.products.image = post.sharePosts.products.image.map((media) => media?.dataValues?.media);

  //     //* find store logo
  //     let logo = await database.Media.findAll({
  //       where: {
  //         id: {
  //           [Op.in]: post.sharePosts.products.store.logo,
  //         },
  //       },
  //     });
  //     post.sharePosts.products.store.logo = logo.map((media) => media?.dataValues?.media);
  //     // console.log("post.sharePosts.products.store.logo", logo);
  //     //* find store cover image
  //     let cover_image = await database.Media.findAll({
  //       where: {
  //         id: {
  //           [Op.in]: post.sharePosts.products.store.cover_image,
  //         },
  //       },
  //     });
  //     post.sharePosts.products.store.cover_image = cover_image.map((media) => media?.dataValues?.media);
  //     /* STORE DETAIL - END */
  //     post = post.sharePosts;
  //     // }
  //   }
  //   return post;
  // },

  // this api is for to add data or sync data with postgresqlDB
  forAddDataInElasticSearchPlatform: async () => {
    const data = await database.User.findAll({
      // attributes: ["id"],
      // limit: 2
    });
    const responseData = JSON.parse(JSON.stringify(data));

    // first method to add data

    // for (const [index, item] of responseData.entries()) {
    //   console.log(`+++${index}+++`, item);
    //   await client.index({
    //     index: "user",
    //     body: item
    //   });
    // }


    // second method to add data

    // await Promise.all(
    //   responseData.map( async (item, index) => {
    //     console.log(`++++${index}+++`, item);
    //       return client.index({
    //         index: "user",
    //         body: item
    //       })
    //     })
    //   )


    // const elasticSearch = await client.search({
    //   index: "user",
    //   size: 9999
    // });
    // console.log("🚀 ~ abc ~ elasticSearch:", elasticSearch)
  },




}
// module.exports.shippingChargesbyShipmentId()
// module.exports.createLabelForShipment()
// module.exports.trackUsingLabelId()
// module.exports.createShipment()

// Shipment id = se-742558617
