module.exports = {
  validateFields: (data, fields) => {
    let k = 0;
    let data4message = "please enter valid ";
    let array4fields = [];
    for (let i = 0; i < data.length; i++) {
      if (!data[i]) {
        array4fields.push(fields[i]);
        k = 1;
      }
    }

    if (k == 1) {
      for (let i = 0; i < array4fields.length - 1; i++) {
        data4message = data4message + array4fields[i] + ", ";
      }
      data4message = data4message + array4fields[array4fields.length - 1];
      return data4message;
    } else {
      return null;
    }
  },
};
