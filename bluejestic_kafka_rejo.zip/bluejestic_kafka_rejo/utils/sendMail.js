const sgMail = require("@sendgrid/mail");
sgMail.setApiKey(process.env.SENDGRID_API_KEY);

// const sendEmail = async (emailData) => {
//   console.log("Email +++++++++++++++++++++++++++++++++");
//   let transporter = nodemailer.createTransport({
//     host: process.env.EMAIL_HOST,
//     port: process.env.EMAIL_PORT,
//     secure: true,
//     auth: {
//       user: process.env.EMAIL_USER,
//       pass: process.env.EMAIL_PASSWORD,
//     },
//   });

//   let mailOptions = emailData

//   try {
//     await transporter.sendMail(mailOptions);
//     return true;
//   } catch (error) {
//     console.log("mail sending wrror", error);
//     return new Error("mail not sent, plase try again later");
//   }
// };

const sendEmail = async (emailData) => {
  try {
    await sgMail.send(emailData);
    return true;
  } catch (error) {
    console.log("mail sending wrror", error);
    return new Error("mail not sent, plase try again later");
  }
}

module.exports = sendEmail;
