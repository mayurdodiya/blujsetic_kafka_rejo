const { gql } = require("apollo-server-express");

module.exports = gql`
  type Bookmark {
    id: Int!
    parent_id: Int!
    user_id: Int!
    bookmark_for: String!
    product: Product
  }

  extend type Mutation {
    addBookmark(product_id: Int!, collection_id: Int): BookmarkResponse
    createBookmarkCollection(input: BookmarkCollectionInput!): BookmarkCollectionResponse
    accessControlledCollection(slug: String!, isPrivate: Boolean): accessControlledCollectionResponse
    addCollectionLike(collection_id: Int!): addCollectionLikeResponse

    removeBookmarkCollection(id: Int!): BookmarkCollectionResponse
    updateBookmarkCollection(input: BookmarkCollectionInput!): BookmarkCollectionResponse
    updateBookmark(input: BookmarkUpdateInput!): BookmarkResponse
    deleteBookmark(id: Int!): Bookmark
    removeBookmark(id: Int): removeBookmarkResponse
    removeCollection(slug: String): removeCollectionResponse
    updateCollection(slug: String, name: String): updateCollectionResponse
    shareCollectiontoFriend(slug: String!, user_id: [Int!]): shareCollectiontoFriendRes
    followUnfollowcollection(collection_id: Int): followUnfollowcollectionResponse
    assignProductToCollection(collection_id: Int, product_id: Int): assignProductToCollectionResponse
    removeProductFromCollection(collection_id: Int, product_id: Int, isRemoveFromCollectionOnly: Boolean): removeProductFromCollectionResponse
  }

  extend type Query {
    getSingleBookmark(id: Int!): Bookmark
    getCollectionSingleLike(slug: String, user_slug: String): getCollectionSingleLikeResponse
    getSingleCollection(slug: String!, isPrivate: Boolean, user_slug: String): getSingleCollectionResponse
    getSinglePublicCollection(slug: String!, isPrivate: Boolean, user_slug: String): getSingleCollectionResponse
    getJewelryCollection(type: String): [BookmarkCollection]
    getSharedCollection: [BookmarkCollection]
    getFollowedCollection: [BookmarkCollection]
    getAllBookmark(slug: String, page: Int, limit: Int, user_slug: String): getAllBookmarkRes
    getBookmarkCollections(isPrivate: Boolean): [BookmarkCollection]
  }

  type shareCollectiontoFriendRes {
    success: Boolean
    message: String
  }

  type removeProductFromCollectionResponse {
    success: Boolean
    message: String
  }

  type getAllBookmarkRes {
    success: Boolean
    message: String
    data: [getAllBookmarkResData]
    total: Int
  }

  type getAllBookmarkResData {
    products: productsResponse
  }

  type assignProductToCollectionResponse {
    success: Boolean
    message: String
  }

  type updateCollectionResponse {
    success: Boolean
    message: String
    slug: String
  }

  type followUnfollowcollectionResponse {
    success: Boolean
    message: String
  }

  type removeCollectionResponse {
    success: Boolean
    message: String
  }

  type accessControlledCollectionResponse {
    success: Boolean
    message: String
  }

  type getSingleCollectionResponse {
    success: Boolean
    message: String
    data: getSingleCollectionDataResponse
  }

  type getSingleCollectionDataResponse {
    id: Int
    name: String
    user: userResponse
    slug: String
    isPrivate: Boolean
    likes: Int
    product_count: Int
    product_images: [String]
  }

  type getCollectionSingleLikeResponse {
    success: Boolean
    message: String
    isLike: Boolean
    isPrivate: Boolean
    isFollow: Boolean
  }

  type addCollectionLikeResponse {
    success: Boolean
    message: String
  }

  type removeBookmarkResponse {
    success: Boolean
    message: String
    product_id: Int
    id: Int
  }

  input BookmarkCollectionInput {
    id: Int
    name: String
    user_id: Int
    image: String
  }

  type BookmarkCollection {
    id: Int
    name: String
    slug: String
    user_id: Int
    isPrivate: Boolean
    banner_image: String
    description: String
    colection_for: String
    product_images: [String]
    product_count: Int
    user: userResponse
    likes: Int
  }

  type userResponse {
    id: Int
    firstName: String
    userName: String
    lastName: String
    logo_image: String
  }

  type BookmarkCollectionResponse {
    success: Boolean
    message: String
    data: BookmarkCollection
  }
  type BookmarkResponse {
    id: Int
    product_id: Int
    parent_id: Int!
    user_id: Int!
    bookmark_for: String!
  }

  input BookmarkInput {
    product_id: Int
    post_id: Int
    user_id: Int!
    bookmark_for: String!
  }

  input BookmarkUpdateInput {
    id: Int
    parent_id: Int!
    user_id: Int!
    bookmark_for: String!
  }
`;
