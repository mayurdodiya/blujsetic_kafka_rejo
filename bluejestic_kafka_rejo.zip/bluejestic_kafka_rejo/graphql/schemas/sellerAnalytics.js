const { gql } = require("apollo-server-express");

module.exports = gql`
  scalar JSON

  extend type Query {
    getSellerAnalytics(                    
      startDate: String!
      endDate: String!
      timeInterval: String
      time_zone: String
    ): SellerAnalyticsResponse

    getSellerTrafficAndEngagement: SellerEngagementResponse! 

    getCustomersDetails: getCustomersDetailsResponse!

    getSellerSalesData(    
    timeRange: String
    ): SellerSalesData!    

    getSellerSocialActivity: SellerSocialActivityResponse! 

    getSellerStoreFollowers(search: String): SellerStoreFollowersResponse!

    getSellerFinances: SellerFinancesResponse
    
    getOrdersAnalysis(input: getOrdersAnalysisRequest): OrderAnalysisResponse
    getSellerSalesDataInsights(input: getSellerSalesDataInsightsRequest): getSellerSalesDataInsightsResponse
  }

  input getSellerSalesDataInsightsRequest {
    startDate: String
    endDate: String
  }

  type getSellerSalesDataInsightsResponse {
    success: String
    message: String
    data: getSellerSalesDataInsightsData
  }

  type getSellerSalesDataInsightsData {
    productShipped: Int
    conversionRateInPercentage: Float
    cartAbandonmentInPercentage: Float
  }

  input getOrdersAnalysisRequest {
    startDate: String
    endDate: String
  }

  type OrderAnalysisResponse {
    success: Boolean
    message: String
    data: [OrderStats]
  }

  type OrderStats {
    date: String
    orderCount: Int
    totalAmount: Float
  }

  type SellerFinancesResponse {
      success: Boolean
      message: String
      data: SellerFinancesData
    }

  type SellerFinancesData {
      availableFunds: Float
      percentageChangeInAvailableFunds: Float
      totalRevenue: Float
      percentageChangeInRevenue: Float
      monthlyWithdrawedAmount: Float
      percentageChangeInMonthlyWithdrawedAmount: Float
      pendingPayment: Int
      percentageChangeInPendingPayments: Float
    }

  type SellerStoreFollowersResponse {
    success: Boolean!
    message: String!
    data:[storeFollowers]    
  }

  type storeFollowers {
    id: Int!
    user_id: Int
    store_id: Int
    createdAt: String
    updatedAt: String
    totalAmountSum: Float
    totalPurchaseCount: Int
    user: storeFollowersUser
  }

  type storeFollowersUser {
    id: Int!
    firstName: String
    lastName: String
    logo_image: String    
  }
  

  type SellerSocialActivityResponse {
    success: Boolean
    message: String
    data: SellerSocialActivity
  }

  type SellerSocialActivity {
    totalFollowers: Int
    percentageChangeInFollowers: Float
    engagementRate: Float
    percentageChangeInEngagementRange: Float
    averageOrderValue: Float
    percentageChangeInAverageOrderValue: Float
    vipCount: Float    
    percentageChangeInVipUsers: Float
  }

  type SellerSalesData {  
    success: Boolean
    message: String
    data: getSalesData 
  }

  type getSalesData {
    cartAbandunce: Float
    salesByRegion: [salesByRegion]
    categoryPercentages: [categorySalesPercentageObj]
    conversionRate: Float
    deliveredShipments: Float
  }
  
  type categorySalesPercentageObj {
    name: String!
    value: Float!
  }

  type salesByRegion {
    name: String!
    value: Float!
  }

  type getCustomersDetailsResponse {
    success: Boolean!
    message: String!
    data: getCustomersDetails! 
  }

  type getCustomersDetails {
    storeFollowers: Int!
    totalCustomers: Int!
    newCustomers: Int!
    ageRatio: [ageRatio]!
  }

  type ageRatio {
    name: String!
    value: Float!
  }

  type SellerAnalyticsResponse {
    success: Boolean!
    message: String!
    data: SellerAnalytics
  }

  type SellerEngagementResponse{
    success: Boolean!
    message: String!
    data: SellerEngagement
  }

  type SellerEngagement {
    productViews: Int!
    productLikes: Int!
    productShared: Int!
    productSaved: Int!
    genderRatio: genderRatio!
    regionWiseSales: [regionData]!
    totalVisitors: Int!
  }

  type regionData {
    region: String!
    value: Float!
  }
  
  type genderRatio {
    male: Float!
    female: Float!
  }

  type SellerAnalytics {
    totalOrders: Int   
    totalSales: Int
    totalRevenue: Float
    newCustomers: Int
    repeatCustomers: Int
    averageOrderValue: Float
    percentageChangeInSales: Float
    percentageChangeInOrders: Float
    percentageChangeInAOV: Float
    percentageChangeInRevenue:Float
    percentageChangeInRevenueOverview: Float
    outOfStock: Int!      
    revenueOverview: RevenueOverview 
    totalEarningsAndRevenue: [revenueAndEarnings!]!
    processingTime: Float!
    stockReport: stockReportData!
    percentageChangeInProcessingTime: Float!
  }

  type stockReportData {
    stock: JSON
    data: [StockReportData!]!
  }

  type StockReportData {
    status: String!
    product: String!
    units: Int!
    percentageChange: Float!
  }

  type RevenueOverview {
    currentPeriodRevenue: revenue
    previousPeriodRevenue: revenue
    percentageChange: Float
    monthlyRevenue: [revenue]!
  }

  type revenueAndEarnings {
    total_earnings: Float!
    total_revenue: Float!
    date: String!
  }

  type revenue {
    revenue: Float!
    orders: Int!
    date: String!
  }
`;