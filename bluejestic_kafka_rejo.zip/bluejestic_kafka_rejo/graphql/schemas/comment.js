const { gql } = require("apollo-server-express");

module.exports = gql`
  scalar Date
  type Comment {
    id: Int!
    parent_id: Int!
    user_id: Int!
    comment_for: String!
    comment: String!
    image: [String]
    createdAt: Date
    likes: [Like]
    user: User
    commentReply: [CommentReply]
  }
  type CommentReply {
    id: Int!
    reply_id: Int!
    user_id: Int!
    parent_id: Int!
    comment_for: String!
    comment: String!
    image: [String]
    createdAt: Date
    commentReplyLike: [Like]
    user: User
  }

  extend type Query {
    getAllComments: [Comment!]
    getCommentById(id: Int!, comment_for: String!): CommentResponse
    getAllStoreCommentsChartData(store_id: Int, comment_for: String!, start_date: String!, end_date: String!, time_interval: String, time_zone: String): getAllStoreCommentsChartDataResponse
    getCommentCount(id: Int!, comment_for: String!): getCommentCountRes
  }

  type getCommentCountRes {
    count: Int
  }

  extend type Mutation {
    createComment(input: createCommentInput!): CreateCommentResponse
    createCommentReply(input: createCommentReplyInput!): CommentReply
  }
  type getAllStoreCommentsChartDataResponse {
    success: Boolean
    message: String
    data: chartDataForStoreComments
  }
  type chartDataForStoreComments {
    current_total_comments_count: Float
    #previous_revenue: Float
    previous_total_comments_count_percentage: Float
    current_data: [[Float]]
    #previous_data: [[Float]]
  }
  type CreateCommentResponse {
    message: String
    data: Comment
    success: Boolean
  }
  type CommentResponse {
    message: String
    data: [Comment]
    success: Boolean
    count: Int
  }
  input createCommentInput {
    parent_id: Int!
    comment_for: String!
    comment: String!
    image: [String]
  }
  input createCommentReplyInput {
    user_id: Int
    reply_id: Int!
    parent_id: Int!
    comment: String
    image: [String]
    comment_for: String
  }
`;
