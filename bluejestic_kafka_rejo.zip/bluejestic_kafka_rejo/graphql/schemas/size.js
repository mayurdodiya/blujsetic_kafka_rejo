const { gql } = require("apollo-server-express");

module.exports = gql`
  type Size {
    id: Int!
    parent_id:Int!
    size:String!
    size_for:String
  }

  extend type Mutation {
    addSize(input: SizeInput!): SizeResponse
    updateSize(input:SizeUpdateInput!):SizeResponse
    deleteSize(id:Int!):Size
  }

  extend type Query{
    getSingleSize(id:Int!):Size
    getAllSize:[Size!]
  }

  type  SizeResponse{
    id: Int
    parent_id:Int!
    size:String!
    size_for:String
    }

  input SizeInput {
    parent_id:Int!
    size:String!
    size_for:String
  }

  input SizeUpdateInput{
    id:Int!
    parent_id:Int!
    size:String!
    size_for:String
  }
`;
