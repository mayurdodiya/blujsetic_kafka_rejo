const { gql } = require("apollo-server-express");

module.exports = gql`
  type JoinGroup {
    id: Int!
    group_id: Int!
    user_id: Int!
    groupType: String
    isAdmin: Boolean
    isOwner: Boolean
    groups: Group
    user: User
    members: User
    createdAt: String
    updatedAt: String
  }

  #   extend type Query {
  #   }

  extend type Mutation {
    joinGroup(input: JoinGroupInput!): JoinGroupResponse
    leaveGroup(groupId: Int!, userId: Int!): JoinGroupResponse
  }

  type JoinGroupResponse {
    id: Int!
    name: String
    group_id: Int!
    user_id: Int!
    groupType: String
    isAdmin: Boolean
    isOwner: Boolean
  }

  input JoinGroupInput {
    group_id: Int!
    user_id: Int!
    groupType: String
    isAdmin: Boolean
    isOwner: Boolean
  }
`;
