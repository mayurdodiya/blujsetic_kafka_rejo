const { gql } = require("apollo-server-express");

module.exports = gql`
  type BioDetail {
    id: Int
    user_id: Int
    marital_status: String
    occupation: String
    education: String
    interest: String
    about: String
    experience: String
    hobbies: String
    # date_of_birth: Date!

    # posts: [Post!]
  }

  extend type Query {
    getAlluserBioDetails: [BioDetail!]
    getUserBioDetail(id: Int!): BioDetail
  }

  extend type Mutation {
    addUserBio(input: BIoDetailInput!): BioDetailResponse
  }

  type BioDetailResponse {
    id: Int!
    user_id: Int!
    marital_status: String!
    occupation: String!
    education: String!
    interest: String
    about: String
    experience: String
    hobbies: String
  }

  input BIoDetailInput {
    marital_status: String!
    occupation: String!
    education: String!
    interest: String
    about: String
    experience: String
    hobbies: String
  }
`;
