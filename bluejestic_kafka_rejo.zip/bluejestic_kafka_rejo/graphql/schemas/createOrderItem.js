const { gql } = require("apollo-server-express");

module.exports = gql`
  extend type Mutation {
    createOrderItem(input: createOrderItemInput): createOrderItemResponse
  }

  type createOrderItemResponse {
    id: Int!
  }

  input data {
    productId: Int!
    quantity: Int!
  }

  input createOrderItemInput {
    products: [data]
  }
`;
