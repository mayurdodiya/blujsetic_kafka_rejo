const { gql } = require("apollo-server-express");

module.exports = gql`
  type Category {
    id: Int
    parent_id: Int
    description: String
    name: String
    media: String
    banner_media: String
    subCategory: [SubCategory]
    position: Int
    slug: String
  }

  extend type Query {
    getAllCategoryDetail: [Category!]
    getSingleCategoryDetail(id: Int!): Category
    getSingleCategory(type: String, category_name: String, subcategory_slug: String, childsub_slug: String, nested_slug: String): getSingleCategoryRes
  }

  extend type Mutation {
    addCategory(description: String, name: String!, media: String, banner_media: String, position: Int!, type: String!, category_id: Int, sub_category_id: Int, child_sub_category_id: Int): CategoryResponse
    updateCategoryDetail(id: Int!, description: String, name: String!, media: String, banner_media: String, position: Int, type: String!, category_id: Int, sub_category_id: Int, child_sub_category_id: Int): CategoryResponse
    updateCategoryPosition(input: updateCategoryPositionInput!): updateCategoryPositionResponse
    deleteCategoryDetail(id: [Int!], type: String): updateCategoryPositionResponse
  }

  input updateCategoryPositionInput {
    category: [updateCategoryPositionArray]
    type: String
  }

  type updateCategoryPositionResponse {
    success: Boolean
    message: String
  }

  type getSingleCategoryRes {
    success: Boolean
    message: String
    data: [Category!]
  }

  input updateCategoryPositionArray {
    category_id: Int
    position: Int
  }

  type CategoryResponse {
    id: Int!
    description: String
    name: String!
    media: String!
    banner_media: String
  }

  input CategoryUpdateInput {
    id: Int!
    description: String
    name: String
    media: String
    banner_media: String
  }
`;
