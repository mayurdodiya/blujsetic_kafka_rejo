const { gql } = require("apollo-server-express");

module.exports = gql`
  scalar Upload
  scalar Date
  type GroupPost {
    id: Int
    group_id: Int
    name: String
    description: String
    media_id: [Int]
    user_id: Int
    createdAt: Date
    user: User
    media: [Media]
  }

  extend type Query {
    getAllGroupPost(group_id: Int): [Post]
    #   getSingleSellerPost(id: Int!): SellerPost
    #   getPostByStore(store_id: Int): [StorePostResponse]
  }
  extend type Mutation {
    createGroupPost(input: groupPostInput!): CreateGroupPostResponse!
    updateGroupPost(input: groupUpdatePostInput!): CreateGroupPostResponse!
    deleteGroupPost(id: Int!): SellerPost
  }
  input groupPostInput {
    group_id: Int!
    title: String!
    content: String
    description: String
    post_for: String
    media_id: [Int]
  }

  input groupUpdatePostInput {
    id: Int!
    group_id: Int
    title: String
    description: String
    post_for: String
    media_id: [Int]
  }

  type groupPostUser {
    id: Int
    firstName: String
    lastName: String
    userName: String
    phoneNumber: String
    gender: String
    bday: String
    jobTitle: String
    profileCoverImage: String
    profileAvtar: String
    isActiveForFriendStatus: Boolean
    isFriendForFriendStatus: Boolean
  }

  type getGroupPostResponse {
    id: Int
    group_id: Int
    title: String
    description: String
    post_for: String
    media_id: [Int]
    user_id: Int
    createdAt: Date
    media: [Media]
    user: groupPostUser
    groupPostLikes: [Like]
    groupPostComments: [Comment]
  }

  type CreateGroupPostResponse {
    id: Int
    group_id: Int
    title: String!
    content: String
    description: String
    post_for: String
    media_id: [Int]
    createdAt: Date
    user_id: Int
  }
`;
