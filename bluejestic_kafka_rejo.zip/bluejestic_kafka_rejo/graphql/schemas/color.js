const { gql } = require("apollo-server-express");

module.exports = gql`
  type Color {
    id: Int!
    parent_id:Int!
    color:String
    name:String
    colorCode:String
    color_for:String
  }


  extend type Mutation {
    addColor(input: ColorInput!): ColorResponse
    updateColor(input:ColorUpdateInput!):ColorResponse
    deleteColor(id:Int!):Color
  }

  extend type Query{
    getSingleColor(id:Int!):Color
    getAllColor:[Color!]
  }

  type  ColorResponse{
    id: Int
    parent_id:Int!
    color:String!
    color_for:String
    }

  input ColorInput {
    parent_id:Int!
    color:String!
    color_for:String
  }

  input ColorUpdateInput{
    id:Int!
    parent_id:Int!
    color:String!
    color_for:String
  }
`;
