const { gql } = require("apollo-server-express");

module.exports = gql`
  type ProductSEO {
    id: Int
    parent_id: Int
    metaTitle: String
    metaData: String
    metaKeywords: String
    metaDescription: String
  }

  extend type Mutation {
    addProductSEO(input: ProductSEOInput!): ProductSEOResponse
    # update ProductSEO(
    #   input:  ProductSEOUpdateInput!
    # ):  ProductSEOResponse
    # delete ProductSEO(id: Int!):  ProductSEO
  }

  extend type Query {
    # getSingleProductSEO(id: Int!):  ProductSEO
    getAllProductSEO: [ProductSEO!]
  }
  type ProductSEOResponse {
    id: Int
    parent_id: Int
    metaTitle: String
    metaKeywords: String
    metaDescription: String
    metaData: String
  }

  input ProductSEOInput {
    parent_id: Int
    metaTitle: String
    metaKeywords: String
    metaDescription: String
    metaData: String
  }

  input ProductSEOUpdateInput {
    id: Int!
    parent_id: Int
    metaTitle: String
    metaKeywords: String
    metaDescription: String
    metaData: String
  }
`;
