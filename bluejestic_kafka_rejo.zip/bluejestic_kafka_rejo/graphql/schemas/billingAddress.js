const { gql } = require("apollo-server-express");

module.exports = gql`
  type BillingAddress {
    id: Int!
    user_id: Int!
    firstName: String
    userName: String
    lastName: String
    streetAddress: String
    country: String
    country_name: String
    state: String
    state_name: String
    city: String
    zipcode: String
    buildingName: String
    number: String
    isPinLocation: Boolean
    latitude: Float
    longitude: Float
    isDefault: Boolean
  }

  extend type Mutation {
    addBillingAddress(input: addBillingAddressInput!): addBillingAddressResponse
    updateBillingAddress(input: updateBillingAddressInput!): updateBillingAddressResponse
    deleteBillingAddress(id: Int!): BillingAddress
  }

  extend type Query {
    getAllBillingAddress: [BillingAddress!]
    getSingleBillingAddress(id: Int!): BillingAddress!
  }

  type addBillingAddressResponse {
    id: Int!
    user_id: Int
    streetAddress: String
    city: String
    firstName: String
    userName: String
    lastName: String
    number: String
    state: String
    country: String
    zipcode: String
    buildingName: String
    isPinLocation: Boolean
    latitude: Float
    longitude: Float
    isDefault: Boolean
  }

  input addBillingAddressInput {
    streetAddress: String
    city: String
    firstName: String
    lastName: String
    number: String
    state: String
    state_name: String
    country: String
    country_name: String
    zipcode: String
    buildingName: String
    isPinLocation: Boolean
    latitude: Float
    longitude: Float
    isDefault: Boolean
  }

  type updateBillingAddressResponse {
    id: Int!
    user_id: Int
    streetAddress: String
    city: String
    firstName: String
    userName: String
    lastName: String
    number: String
    state: String
    country: String
    zipcode: String
    buildingName: String
    isPinLocation: Boolean
    latitude: Float
    longitude: Float
    isDefault: Boolean
  }

  input updateBillingAddressInput {
    id: Int!
    streetAddress: String
    city: String
    firstName: String
    lastName: String
    number: String
    state: String
    state_name: String
    country: String
    country_name: String
    zipcode: String
    buildingName: String
    isPinLocation: Boolean
    latitude: Float
    longitude: Float
    isDefault: Boolean
  }
`;
