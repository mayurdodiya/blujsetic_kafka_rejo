const { gql } = require("apollo-server-express");

module.exports = gql`


  extend type Mutation {
    createPlaidLinkToken(input: createPlaidLinkTokenRequest): createPlaidLinkTokenRes
    getAccessTokenForPlaid(public_token: String): getAccessTokenForPlaidRes
  }

  type getAccessTokenForPlaidRes {
    success: Boolean
    message: String
    data: getAccessTokenForPlaidResData
  }

  type getAccessTokenForPlaidResData {
    access_token: String
    item_id: String
  }

  input createPlaidLinkTokenRequest {
    country_codes: [String]
    language: String
  }

  type createPlaidLinkTokenRes {
    success: Boolean
    message: String
    data: createPlaidLinkTokenResData
  }

  type createPlaidLinkTokenResData {
    link_token: String
    expiration: String
    request_id: String
  }



`;
