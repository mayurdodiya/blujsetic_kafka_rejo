const { gql } = require("apollo-server-express");

module.exports = gql`
  scalar Upload
  scalar Date
  type Post {
    id: Int
    title: String
    content: String
    author: User
    comments: [Comment]
    comment_count: Int
    likes: [Like]
    medias: [Media]
    media_id: [Int]
    group_id: Int
    store_id: Int
    seller_Id: Int
    isActive: Boolean
    isDraft: Boolean
    isSchedule: Boolean
    scheduleTime: String
    visible_for: String
    post_for: String
    createdAt: Date
    user: User
    store: BusinessInformation
  }

  type SharePost {
    id: Int
    content: String
    image: [String]
    user_id: Int
    post_id: Int
    product_id: Int
    group_id: Int
    store_name: String!
    store_id: Int!
    isActive: Boolean
    isShare: Boolean
    isBookmarked: Boolean
    isDraft: Boolean
    createdAt: Date
    user: User
    post: Post
    likes: [Like]
    share_post_for: String
  }

  extend type Query {
    getAllPost(group_id: Int, myPost: Boolean, user_id: Int, page: Int, limit: Int): getAllPostResponse
    getAllPosts(group_id: Int): [PostResponse]
    getSinglePost(post_id: Int!): PostResponse
    getSavedPost(page: Int, limit: Int): getSavedPostRes
  }
  extend type Mutation {
    addPost(input: postInput!): PostResponseAdd!
    sharePost(input: sharePostInput): sharerPostResponse
    updatePost(input: postUpdateInput!): CreatePostResponse
    deletePost(id: Int!): deletePostResponse
    deleteSharePost(id: Int!): deleteSharePostResponse
    UploadFile(file: Upload!): Media!
    createPost(input: postInput!): CreatePostResponse!
    updatePosts(input: postUpdateInput!): CreatePostResponse
  }

  type getSavedPostRes {
    success: Boolean
    message: String
    data: [getSavedPostDataRes]
  }

  type getSavedPostDataRes {
    title: String
    content: String
    image: String
    likes: Int
    comments: Int
  }

  type getAllPostResponse {
    success: Boolean
    message: String
    data: [PostResponse]
    currentPage: Int
    totalPage: Int
    totalPost: Int
  }
  type sharerPostResponse {
    status: Int
    success: Boolean
    message: String
    data: [SharePost]
  }
  type friends {
    id: Int
  }

  type profileImage {
    url: String
    alternativeText: String
  }

  type coverImage {
    url: String
    alternativeText: String
  }

  type Users {
    id: Int
    firstName: String
    lastName: String
    userName: String
    address: String
    about: String
    country: String
    state: String
    friends: friends
    profileImage: profileImage
    coverImage: coverImage
    logo_image: String
    banner_image: String
    isActiveForFriendStatus: Boolean
    isFriendForFriendStatus: Boolean
    followers: [Friend]
    followings: [Friend]
  }

  type deletePostResponse {
    post: Post
  }
  type deleteSharePostResponse {
    success: Boolean
    message: String
    sharePost: Int
  }

  type PostResponse {
    id: Int
    title: String
    media_type: String
    isShare: Boolean
    isBookmarked: Boolean
    bookmark_id: Int
    savedPost: savedPostRes
    content: String
    owner_id: Int
    post_for: String
    store_id: Int
    store_name: String
    user: Users
    comments: [Comment]
    comment_count: Int
    like_count: Int
    likes: [Like]
    medias: [PostResponseMedias]
    sellerpostcomment: [Comment]
    product: Product
    collection: CollectionRes
    store: BusinessInformation
    group: SingleGroupResponse
    createdAt: Date
    isSave: Boolean
  }

  type savedPostRes {
    id: Int
  }

  type CollectionRes {
    id: Int
    name: String
    isPrivate: Boolean
    user: UserCollectionRes
    user_id: Int
    slug: String
    like_count: Int
    likes: [CollectionLikeRes]
    product_count: Int
    images: [String]
    bookmark_product: [productsResponse]
  }

  type UserCollectionRes {
    userName: String
  }

  type CollectionLikeRes {
    user_id: Int
  }

  type PostResponseMedias {
    id: Int
    url: String
  }
  type S3Object {
    ETag: String!
    Location: String!
    Key: String!
    Bucket: String!
  }
  type PostResponseAdd {
    success: Boolean
    message: String
    data: CreatePostResponse
  }
  type CreatePostResponse {
    id: Int!
    title: String
    content: String
    media_id: [Int]
    user_id: Int
    group_id: Int
    store_id: Int
    seller_Id: Int
    isActive: Boolean
    isDraft: Boolean
    isSchedule: Boolean
    scheduleTime: String
    visible_for: String
    post_for: String
    # createdAt: String!
  }

  input postUpdateInput {
    id: Int!
    title: String
    content: String
    media_id: [Int]
    user_id: Int
    group_id: Int
    store_id: Int
    seller_Id: Int
    isActive: Boolean
    isDraft: Boolean
    isSchedule: Boolean
    scheduleTime: String
    visible_for: String
    post_for: String
  }

  input postInput {
    title: String
    media_type: String
    content: String
    media_id: [Int]
    user_id: Int
    group_id: Int
    store_id: Int
    seller_Id: Int
    isActive: Boolean
    isDraft: Boolean
    isSchedule: Boolean
    scheduleTime: String
    visible_for: String
    post_for: String
  }
  input sharePostInput {
    content: String
    image: [String]
    post_id: Int
    product_id: Int
    bookmark_id: Int
    store_name: String
    store_id: Int
    group_id: [Int]
    share_post_for: String
    collection_id: Int
  }
`;
