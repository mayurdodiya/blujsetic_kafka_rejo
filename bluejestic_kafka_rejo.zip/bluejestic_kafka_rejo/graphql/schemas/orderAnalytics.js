const { gql } = require("apollo-server-express");

module.exports = gql`
    extend type Query {
      getOrderAnalyticsForSeller: getOrderAnalyticsForSellerResponse
        getOrdersOfSeller(
        page: Int
        limit: Int
        search: String
        order_status: String
        ):OrdersResponse!
    }
        
    type getOrderAnalyticsForSellerResponse {
        success: Boolean
        message: String
        data: getOrderAnalyticsForSellerResponseData
      }
     
    type getOrderAnalyticsForSellerResponseData {

      totalOrders: Float
      percentageChangeInTotalOrders: Float
      pendingOrders: Float
      percentageChangeInPendingOrders: Float
      completedOrders: Float
      percentageChangeInCompletedOrders: Float
      cancelledOrders: Float
      percentageChangeInCancelledOrders: Float
    }

    type OrdersResponse {
        success: Boolean
        message: String
        data: OrderResponse!
         
    }
    
    type Orders {
        id:Int!
        order_status: String!
        totalAmount: Int!
        createdAt: String!
        customer: customerDetails!     
      
      }

      type customerDetails {
        fistName: String
        lastName: String
      }

      type OrderResponse {
        count: Int
        rows: [getAllOrdersRes]
      }       
      `