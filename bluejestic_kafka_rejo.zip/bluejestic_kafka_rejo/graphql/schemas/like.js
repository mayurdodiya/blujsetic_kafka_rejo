const { gql } = require("apollo-server-express");

module.exports = gql`
  scalar Date
  type Like {
    id: Int
    post_id: Int
    like_for: String
    user_id: Int
    meta: String
    is_deleted: Boolean
    created_by: String
    updated_by: String
    updatedAt: Date
    createdAt: Date
    user: User
  }

  extend type Query {
    getAllLikes: [Like]
    getAllStoreLikesChartData(store_id: Int, like_for: String!, start_date: String!, end_date: String!, time_interval: String, time_zone: String): getAllStoreLikesChartDataResponse
    getSingleLike(parent_id: Int!, like_for: String!): getSingleLikeRes
  }

  extend type Mutation {
    createLike(input: createLikeInput): LikeOutput
    disLike(input: disLikeInput): disLikeOutput!
    addStoreLike(store_id: Int, user_id: Int, isLike: Boolean): addStoreLikeRes!
  }

  type getSingleLikeRes {
    data: getSingleLikeDataRes
    success: Boolean
    message: String
  }

  type getSingleLikeDataRes {
    isLike: Boolean
    like_id: Int
  }

  type addStoreLikeRes {
    success: Boolean
    message: String
  }

  type getAllStoreLikesChartDataResponse {
    success: Boolean
    message: String
    data: chartDataForStoreLikes
  }
  type chartDataForStoreLikes {
    current_total_likes_count: Float
    #previous_revenue: Float
    previous_total_likes_count_percentage: Float
    current_data: [[Float]]
    #previous_data: [[Float]]
  }
  type Users {
    id: Int
    firstName: String
    lastName: String
    email: String
    userName: String
  }
  input createLikeInput {
    parent_id: Int!
    like_for: String!
  }
  input disLikeInput {
    id: Int!
  }
  type disLikeOutput {
    message: String
    user: Users
  }
  type LikeOutput {
    message: String
    user: Users
    id: Int
  }
`;
