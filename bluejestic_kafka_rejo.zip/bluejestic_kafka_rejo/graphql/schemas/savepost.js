const { gql } = require("apollo-server-express");

module.exports = gql`
  scalar Date
  type Savepost {
    id: Int
    post_id: Int
    user_id: Int
    createdAt: Date
    post: Post
  }

  extend type Query {
    getAllSavepost: [Savepost]
    getSingleSavepost(id: Int!): Savepost
  }
  extend type Mutation {
    createSavePost(input: postInput!): Savepost
    unSavePost(id: Int, post_id: Int): unsavePostResponse
  }

  input postInput {
    post_id: Int
    user_id: Int
  }
  type unsavePostResponse{
    success : Boolean
    message : String
  }
`;
