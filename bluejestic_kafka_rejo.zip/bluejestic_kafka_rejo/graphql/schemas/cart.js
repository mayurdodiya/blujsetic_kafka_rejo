const { gql } = require("apollo-server-express");

module.exports = gql`
  type Cart {
    id: Int
    parent_id: Int!
    user_id: Int
    cart_for: String!
    quantity: Int!
  }

  type selectedCartItems {
    id: Int
    product_id: Int
    user_id: Int
    store_id: Int
    quantity: Int
    isSell: Boolean
  }

  extend type Mutation {
    createCart(input: CartInput!): CartResponse
    updateCart(input: CartUpdateInput!): updateCartRes
    deleteCart(id: Int!): deleteCartResponse
    deleteCartItems(id: [Int!]): deleteCartResponse
    insertSelectedCartItems(input: insertSelectedCartItemsInput): insertSelectedCartItemsReponse
    deleteSelectedCartItems: deleteSelectedCartItemsReponse
    getSelectedProducts(input: getSelectedProductsInput): getSelectedProductsRes
    changeCartItemsStatus: changeCartItemsStatusRes
  }

  type changeCartItemsStatusRes {
    success: Boolean
    message: String
  }

  type deleteCartResponse {
    success: Boolean
    message: String
    cart: Cart
  }

  type getSelectedProductsRes {
    sucess: Boolean
    message: String
    carts: [getSelectedProductsResCarts]
    count: Int
  }

  type updateCartRes {
    success: Boolean
    message: String
    data: Cart
  }

  type getSelectedProductsResCarts {
    id: Int
    qty: Int
    storeDetail: BusinessInformation
    product: [productsResponse]
  }

  extend type Query {
    getSingleCart(id: Int!): Cart
    getAllCart: [getAllCartRes]
    getCartCount: getCartCountRes
    getSelectedCartItems: AllCartResponse
  }

  type getCartCountRes {
    count: Int
    success: Boolean
    message: String
  }

  input getSelectedProductsInput {
    products: [productArray]
  }

  type getAllCartRes {
    success: Boolean
    message: String
    carts: [allCarts]
    count: Int
  }

  type allCarts {
    # id: Int
    # qty: Int
    storeDetail: storeDetailCartRes
    product: [productRescart]
  }

  type productRescart {
    quantity: Int
    product: cartProductsResponse
  }

  type cartProductsResponse {
    id: Int
    store_id: Int
    title: String
    status: String
    dis_price: String
    dis_listPrice: String
    brand_id: Int
    like_count: String
    comment_count: String
    sharepost_count: String
    total_variants: String
    total_inventory_quantity: String
    description: String
    isFeature: Boolean
    isActive: Boolean
    metaTitle: String
    keywords: String
    metaDescription: String
    isVisible: Boolean
    isFreeShipping: Boolean
    condition: String
    is_deleted: Int
    variant: variantsRes
    shipping: shippingRes
    options: [optionsRes]
    images: [imgaesRes]
    inventoryPrice: inventoryPriceRes
    cart_item_id: Int
  }

  type storeDetailCartRes {
    id: Int
    name: String
    logo_url: String
  }

  type deleteCartResponse {
    success: Boolean
    message: String
  }
  input productArray {
    variant_id: Int
    quantity: Int
    product_id: Int
  }
  input insertSelectedCartItemsInput {
    products: [productArray]
  }
  type insertSelectedCartItemsReponse {
    success: Boolean
    message: String
    data: [selectedCartItems]
  }
  type deleteSelectedCartItemsReponse {
    success: Boolean
    message: String
  }
  type cart_input_response {
    quantity: Int
    product: Product
    user: Seller
  }

  type CartResponse {
    success: Boolean
    message: String
    cart: cart_input_response
  }

  type all_carts {
    id: Int
    qty: Int
    storeDetail: BusinessInformation
    product: [Product]
  }

  type AllCartResponse {
    sucess: Boolean
    message: String
    carts: [all_carts]
    count: Int
  }

  input CartInput {
    user_id: Int
    parent_id: Int!
    cart_for: String!
    quantity: Int!
    variant_id: Int
  }

  input CartUpdateInput {
    id: Int
    parent_id: Int!
    variant_id: Int
    cart_for: String!
    quantity: Int!
  }
`;
