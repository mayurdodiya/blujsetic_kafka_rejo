const { gql } = require("apollo-server-express");
const globalResponse = require("./globalResponse");
const userType = require("./user");
const commentType = require("./comment");
const biodetailType = require("./biodetail");
const mediaTypes = require("./media");
const Address = require("./address");
const ProductTypes = require("./product");
const ProductBrandTypes = require("./productBrand");
// const liveStreamTypes = require("./livestream");
const colorTypes = require("./color");
const sizeTypes = require("./size");
const storeTypes = require("./store");
const postTypes = require("./post");
const followTypes = require("./follow");
const offerTypes = require("./offer");
const friendTypes = require("./friend");
const aboutTypes = require("./about");
const notificationTypes = require("./notification");
const cartTypes = require("./cart");
const ratingTypes = require("./rating");
const bookmarkTypes = require("./bookmark");
const categoryTypes = require("./category");
const groupTypes = require("./group");
const businessInformationTypes = require("./businessInformation");
const LegalDetailsTypes = require("./LegalDetails");
const shippingTypes = require("./shipping");
const productSEOTypes = require("./productSEO");
const likeTypes = require("./like");
const sellerType = require("./seller");
const savepostType = require("./savepost");
const analyticsAdminPanelType = require("./analyticsAdminPanel");
const sellerPostType = require("./sellerPost");
const subCategoryType = require("./subcategory");
const childSubCategoryType = require("./childsubcategory");
const randomType = require("./randomArray");
const joinGroupType = require("./joingroup");
const inviteGroupType = require("./invitegroup");
const groupPostType = require("./groupPost");
const followStoreType = require("./followstore");
const cardandbillingaddressType = require("./cardandbillingaddress");
const billingAddressType = require("./billingAddress");
const createOrderItem = require("./createOrderItem");
const paymentType = require("./payment");
const plaidType = require("./plaid");
const orderType = require("./order");
const storeActivitiesType = require("./storeActivity");
const userLocationActivityTypes = require("./userLocationActivity");
const userDevicesType = require("./userDevices");
const userActivityReport = require("./userActivityReport");
const productViewType = require("./productView");
const sellerAnalytics = require("./sellerAnalytics");
const sellerConnectAccountType = require("./sellerConnectAccount");
const shippingAnalytics= require("./shippingAnalytics")
const orderAnalytics = require("./orderAnalytics")

//* Root types  */
const rootType = gql`
  type Query {
    root: String
  }
  type Mutation {
    root: String
  }
`;

module.exports = [
  rootType,
  globalResponse,
  userType,
  commentType,
  biodetailType,
  postTypes,
  mediaTypes,
  Address,
  ProductTypes,
  ProductBrandTypes,
  // liveStreamTypes,
  colorTypes,
  sizeTypes,
  storeTypes,
  followTypes,
  offerTypes,
  aboutTypes,
  notificationTypes,
  cartTypes,
  friendTypes,
  ratingTypes,
  bookmarkTypes,
  categoryTypes,
  groupTypes,
  businessInformationTypes,
  LegalDetailsTypes,
  shippingTypes,
  productSEOTypes,
  likeTypes,
  sellerType,
  savepostType,
  analyticsAdminPanelType,
  sellerPostType,
  subCategoryType,
  childSubCategoryType,
  randomType,
  joinGroupType,
  inviteGroupType,
  groupPostType,
  followStoreType,
  cardandbillingaddressType,
  billingAddressType,
  createOrderItem,
  paymentType,
  plaidType,
  orderType,
  storeActivitiesType,
  userLocationActivityTypes,
  userDevicesType,
  userActivityReport,
  productViewType,
  sellerAnalytics,
  sellerConnectAccountType,
  shippingAnalytics,
  orderAnalytics
];
