const { gql } = require("apollo-server-express");

module.exports = gql`
  type Notification {
    id: Int!
    parent_id:Int!
    send_to: Int!
    send_by: Int!
    send_for: String!
    message: String!
  }

  extend type Mutation {
    addNotification(input: NotificationInput!): NotificationResponse
    updateNotification(input:NotificationUpdateInput!):NotificationResponse
    deleteNotification(id:Int!):Notification
  }

  extend type Query{
    getSingleNotification(id:Int!):Notification
    getAllNotification:[Notification!]
  }

  type  NotificationResponse{
    id: Int!
    parent_id:Int!
    send_to: Int!
    send_by: Int!
    send_for: String!
    message: String!
    }

  input NotificationInput {
    parent_id:Int!
    send_to: Int!
    send_by: Int!
    send_for: String!
    message: String!
  }

  input NotificationUpdateInput{
    id: Int!
    parent_id:Int!
    send_to: Int!
    send_by: Int!
    send_for: String!
    message: String!
  }
`;
