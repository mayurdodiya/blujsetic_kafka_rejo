const { gql } = require("apollo-server-express");

module.exports = gql`
scalar Date  
type ProdutView {
    id: Int
    store_id: Int
    user_id: Int
    userType: String
    startDate: Date
    product_id: Int
    endDate: Date
    createdAt: Date
  }

  extend type Mutation {
    addProductView(input: productViewInput): ProdutViewResponse
  }

  extend type Query{
    getAllProductViews(store_id: Int!): ProdutViewResponse
    getAllProductViewChartData(store_id: Int!, start_date: String!, end_date:String!, time_interval: String, time_zone: String): getAllProdutViewChartDataResponse

  }
  type getAllProdutViewChartDataResponse{
    success: Boolean
    message: String
    data: chartDataForProdutView
  }
  type chartDataForProdutView{
    current_total_user_reached_count: Float
    #previous_revenue: Float
    previous_total_user_reached_count_percentage: Float
    current_data: [[Float]]
    #previous_data: [[Float]]
  }


  input productViewInput {
    store_id: Int!
    user_id: Int
    userType: String
    startDate: Date!
    endDate: Date!
    product_id: Int!
  }
  type ProdutViewResponse {
    success: Boolean
    message: String
    data: [ProdutView]
  }
`;
