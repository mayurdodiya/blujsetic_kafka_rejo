const { gql } = require("apollo-server-express");

module.exports = gql`
  type Rating {
    id: Int!
    parent_id:Int!
    rating:Int!
    rating_for:String!
    review_title:String!
    review_message:String!
  }

  extend type Mutation {
    addRating(input: RatingInput!): RatingResponse
    updateRating(input:RatingUpdateInput!):RatingResponse
    deleteRating(id:Int!):Rating
  }

  extend type Query{
    getAllRating:[Rating!]
    getSingleRating(id:Int!):Rating
  }

  type  RatingResponse{
    id: Int!
    parent_id:Int!
    rating:Int!
    rating_for:String!
    review_title:String!
    review_message:String!
    }

  input RatingInput {
    parent_id:Int!
    rating:Int!
    rating_for:String!
    review_title:String!
    review_message:String!
  }

  input RatingUpdateInput{
    id: Int!
    parent_id:Int!
    rating:Int!
    rating_for:String!
    review_title:String!
    review_message:String!
  }
`;
