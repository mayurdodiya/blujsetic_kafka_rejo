const { gql } = require("apollo-server-express");

module.exports = gql`
  extend type Query {
    getShippingAnalytics(
      seller_id: String                          
      time_zone: String      
      timeRange:String      
    ): ShippingAnalyticsResponse!
  }
  
  type ShippingAnalyticsResponse {
    success: Boolean!
    message: String!
    data: ShippingAnalyticsData!
  }

  type ShippingAnalyticsData {
    pendingShipments: Int!
    percentageChangeInShipments: Float!
    inTransistShipments: Int!
    deliveredShipments: Int!
    cancelledShipments: Int!
    returnedShippments: Int!
    percentageChangeInPendings: Float! 
    percentageChangeInTransist: Float!
    percentageChangeInDelivery: Float!
    percentageChangeInCancelled: Float!
    percentageChangeInReturned : Float!
    delayedShippings: Int!
    averageShipmentTime: Float
    percentageChangeInAverageShipmentTime: Float
  } 
`;