const { gql } = require("apollo-server-express");

module.exports = gql`
  type BusinessInformation {
    id: Int!
    seller_id: Int!
    name: String!
    slug: String
    status: String
    companyLegalName: String
    state_name: String
    streetAddress: String
    city: String
    state: String
    product_count: String
    postalCode: String
    websiteUrl: String
    companyEmail: String
    phoneNumber: String
    isHaveTeam: Boolean
    annualSale: String
    totalEmployees: String
    logo: [String]
    cover_image: [String]
    sellerType: String
    businessType: String
    country: String
    employmentType: String
    profession: String
    title: String
    isExist: Boolean
    isFollow: Boolean
    isLikeShare: Boolean
    isNotification: Boolean
    isMessaging: Boolean
    isTrends: Boolean
    documents: [String]
    BusinessInformationFor: String
    mutualFriends: [User]
    followers: [FollowStore]
    followersCount: Int
    products: [Product]
    logo_image: String
    banner_image: String
    createdAt: Date
    logo_url: String
    store_owner: User
    seller_detail: Seller
    store_detail: getStoreDetailByIdDataRes
  }

  extend type Mutation {
    addBusinessInformation(input: BusinessInformationInput!): BusinessInformationResponse
    updateBusinessInformation(input: BusinessInformationUpdateInput!): BusinessInformationResponse
    updateStoreDetail(input: BusinessInformationUpdateInput): updateStoreDetailResponse
    updateStoreInfo(input: updateStoreInfo): updateStoreInfoRes
    # deleteBusinessInformation(id: Int!): BusinessInformation
  }

  extend type Query {
    getSingleBusinessInformation(id: Int!): BusinessInformationResponse
    getStoreDetail(id: Int!): BusinessInformation
    getAllBusinessInformation: [BusinessInformation!]
    searchStoressWithElasticSearch(search: String, page: Int, limit: Int, category: String, subCategory: String, isCategoryFilter: Boolean): getProductStockReportResponse
  }

  type updateStoreInfoRes{
    success: Boolean
    message: String
  }

  input updateStoreInfo {
    logo_image: String
    banner_image: String
    companyLegalName: String
    streetAddress: String
    state_name: String
    city: String
    state: String
    postalCode: String
    country: String
    phoneNumber: String
  }

  type updateStoreDetailResponse {
    success: Boolean
    message: String
  }

  type BusinessInformationResponse {
    id: Int
    seller_id: Int!
    name: String!
    companyLegalName: String
    streetAddress: String
    city: String
    state: String
    postalCode: String
    websiteUrl: String
    isHaveTeam: Boolean
    annualSale: String
    totalEmployees: String
    logo: [String]
    cover_image: [String]
    slug: String
    sellerType: String
    businessType: String
    BusinessInformationFor: String
  }

  input BusinessInformationInput {
    seller_id: Int
    name: String
    companyLegalName: String
    streetAddress: String
    city: String
    state: String
    postalCode: String
    websiteUrl: String
    isHaveTeam: Boolean
    annualSale: String
    totalEmployees: String
    sellerType: String
    businessType: String
    BusinessInformationFor: String
  }

  input BusinessInformationUpdateInput {
    store_id: Int!
    type: String!
    logo: String
    cover_image: String
    shortDescription: String
    longDescription: String
    isFollow: Boolean
    isLikeShare: Boolean
    isNotification: Boolean
    isMessaging: Boolean
    isTrends: Boolean
    documents: [String]
  }
`;
// seller_id: Int
// name: String
// companyLegalName: String
// streetAddress: String
// city: String
// state: String
// postalCode: String
// websiteUrl: String
// isHaveTeam: Boolean
// annualSale: String
// totalEmployees: String
// sellerType: String
// businessType: String
// BusinessInformationFor: String
