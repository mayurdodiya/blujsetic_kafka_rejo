const { gql } = require("apollo-server-express");

module.exports = gql`
  type Shipping {
    id: Int
    parent_id: Int
    shippingPrice: Int
    zipCode: Int
    processingTime: String
    shippingServices: String
    freeShipping: Boolean
    handleFee: Int
    productWeight: Int
    productWidth: Int
    productLength: Int
    productHeight: Int
    shippingFor: String
  }

  extend type Mutation {
    addShipping(input: ShippingInput!): ShippingResponse
    # update Shipping(
    #   input:  ShippingUpdateInput!
    # ):  ShippingResponse
    # delete Shipping(id: Int!):  Shipping
  }

  extend type Query {
    # getSingleShipping(id: Int!):  Shipping
    getAllShipping: [Shipping!]
  }

  type ShippingResponse {
    id: Int
    parent_id: Int
    shippingPrice: Int
    zipCode: Int
    processingTime: String
    shippingServices: String
    freeShipping: Boolean
    handleFee: Int
    productWeight: Int
    productWidth: Int
    productLength: Int
    productHeight: Int
    shippingFor: String
  }

  input ShippingInput {
    parent_id: Int
    shippingPrice: Int
    zipCode: Int
    processingTime: String
    shippingServices: String
    freeShipping: Boolean
    handleFee: Int
    productWeight: Int
    productWidth: Int
    productLength: Int
    productHeight: Int
    shippingFor: String
  }

  input ShippingUpdateInput {
    id: Int!
    parent_id: Int
    shippingPrice: Int
    zipCode: Int
    processingTime: String
    shippingServices: String
    freeShipping: Boolean
    handleFee: Int
    productWeight: Int
    productWidth: Int
    productLength: Int
    productHeight: Int
    shippingFor: String
  }
`;
