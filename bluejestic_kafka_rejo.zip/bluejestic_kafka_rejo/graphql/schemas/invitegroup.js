const { gql } = require("apollo-server-express");

module.exports = gql`
  type JoinGroup {
    id: Int!
    group_id: Int!
    user_id: Int!
    isJoin: Boolean
    groups: Group
  }

  #   extend type Query {
  #   }

  extend type Mutation {
    inviteGroups(input: inviteGroupInput!): [inviteGroupResponse]
    acceptInviteGroups(group_id: Int!, isAdmin: Boolean): acceptInviteResponse
    cancleInviteGroupRequest(user_id: Int!, group_id: Int!): inviteGroupResponse
  }

  type inviteGroupResponse {
    id: Int!
    group_id: Int!
    user_id: Int!
    isJoin: Boolean
  }

  type acceptInviteResponse {
    isSuccess: String
  }

  input inviteGroupInput {
    group_id: Int!
    user_id: [Int]
    isJoin: Boolean
  }
`;
