const { gql } = require("apollo-server-express");

module.exports = gql`
  type Address {
    id: Int!
    address_1: String!
    address_2: String!
    city: String!
    state: String!
    zip_code: Int!
    country: String!
    address_for: String!
    user_id: Int!
    # date_of_birth: Date!
    # posts: [Post!]
  }

  extend type Mutation {
    address(input: AddressInput!): Address
    getAddress: Address
  }

  input AddressInput {
    address_1: String!
    address_2: String!
    city: String!
    state: String!
    zip_code: Int!
    country: String!
    address_for: String!
  }
`;
