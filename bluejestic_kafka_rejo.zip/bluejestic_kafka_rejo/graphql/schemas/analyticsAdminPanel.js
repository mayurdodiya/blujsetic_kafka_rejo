const { gql } = require("apollo-server-express");

module.exports = gql`
    extend type Query {
        getCustomersAnalytics: getCustomersAnalyticsRes
        getDashboardAnalytics: getDashboardAnalyticsRes
        getSalesAnalytics(dateRange: DateRangeInput!): getSalesAnalyticsRes
        getAdminDashboardData: getAdminDashboardDataResponse
        getStoresAnalytics: getStoresAnalyticsRes
        getNewStoresApplicationsAnalytics: getNewStoresApplicationsAnalyticsRes
        getProductsAnalytics: getProductsAnalyticsRes
        getOrdersAnalytics: getOrdersAnalyticsRes
        getCategoriesAnalytics: getCategoriesAnalyticsRes
        getCategoryDistribution: getCategoryDistributionRes  
        getClubsAnalytics: getClubsAnalyticsRes  
        getClubAnalyticsBySlug(slug: String!): getClubAnalyticsBySlugRes 
        getUserAnalyticsBySlug(slug: String!): getUserAnalyticsBySlugRes
        getStoresAnalyticsBySlug(slug: String!): getStoresAnalyticsBySlugRes
    }

    type getStoresAnalyticsBySlugRes {
        success: Boolean
        message: String        
        data: getStoreAnalyticsBySlugResData
    }

    type getStoreAnalyticsBySlugResData {
        totalProducts: getStoreAnalyticsBySlugResDataPayload 
        ProductsSold: getStoreAnalyticsBySlugResDataPayload 
        followers: getStoreAnalyticsBySlugResDataPayload
        totalRevenure: getStoreAnalyticsBySlugResDataPayload
    }

    type getStoreAnalyticsBySlugResDataPayload {
        total: Float
        lastMonthPercentage: Float
    }

    type getUserAnalyticsBySlugRes {
        success: Boolean
        message: String        
        data: getUserAnalyticsBySlugResData
    }

    type getUserAnalyticsBySlugResData {
        totalOrders: Float
        lastMonthPercentageTotalOrders: Float
        totalSpent: Float
        lastMonthPercentageTotalSpent: Float
        followers: Float
        lastMonthPercentageFollowers: Float
        following: Float
        lastMonthPercentageFollowing: Float
    }

    type getAdminDashboardDataResponse {
        success: Boolean
        message: String        
        data: getAdminDashboardDataRes
    }

    type getAdminDashboardDataRes {
        categoryDistribution: [categoryDistributionRes]
    }

    type categoryDistributionRes {
     value: Float
     name: String
    }

    type getClubAnalyticsBySlugRes {        
        success: Boolean
        message: String
        data: getClubAnalyticsBySlugResData
    }

    type getClubAnalyticsBySlugResData {
        avgPosts: avgPostsData
        memberGrowth: totalDataPayload
        engagementRate: totalDataPayload
    }

    type avgPostsData {
        total: Float
        lastMonthPercentage: Float
    }


    type getClubsAnalyticsRes {
        success: Boolean
        message: String
        data: getClubsAnalyticsResData 
    }

    type getClubsAnalyticsResData {
        totalClubs: totalDataPayload 
        activeClubs: totalDataPayload 
        totalMembers: totalDataPayload 
        averageEngagement: totalDataPayload 
    }



    type getCategoryDistributionRes {
        success: Boolean
        message: String
    }

    type getCustomersAnalyticsRes {
        success: Boolean
        message: String
        data: getCustomersAnalyticsResData
    }
        
    type getCustomersAnalyticsResData {
        totalCustomers: totalDataPayload 
        activeCustomers: totalDataPayload 
        totalOrders: totalDataPayload 
        totalRevenue: totalDataPayload 
    }
     
    
    
    input DateRangeInput {
        start_date: String!
        end_date: String!
        time_interval: String
        time_zone: String
    }

    type getSalesAnalyticsRes {
        success: Boolean
        message: String
        data: [getSalesAnalyticsResData] 
    }

    type getSalesAnalyticsResData {
        date: String
        totalSales: Float
        totalUsers: Int
    }
    
            
    type getDashboardAnalyticsRes {
        success: Boolean
        message: String
        data: getDashboardAnalyticsResData
    }
                
    type getDashboardAnalyticsResData {
        totalUsers: totalDataPayload 
        activeStores: totalDataPayload 
        totalProducts: totalDataPayload 
        totalRevenue: totalDataPayload 
    }
    
    

    type getStoresAnalyticsRes {
        success: Boolean
        message: String
        data: getStoresAnalyticsResData
    }
            
    type getStoresAnalyticsResData {
        totalStores: totalDataPayload 
        activeStores: totalDataPayload 
        totalProducts: totalDataPayload 
        totalSales: totalDataPayload 
    }



    type getNewStoresApplicationsAnalyticsRes {
        success: Boolean
        message: String
        data: getNewStoresApplicationsAnalyticsResData
    }
          
    type getNewStoresApplicationsAnalyticsResData {
        pendingApplications: totalDataPayload 
        approvedThisMonth: totalDataPayload 
        totalApplications: totalDataPayload 
        averageProcessingTime: totalDataPayload 
    }



    type getProductsAnalyticsRes {
        success: Boolean
        message: String
        data: getProductsAnalyticsResData
    }
            
    type getProductsAnalyticsResData {
        totalProducts: totalDataPayload 
        activeProducts: totalDataPayload 
        draftProducts: totalDataPayload 
        totalRevenue: totalDataPayload 
    }



    type getOrdersAnalyticsRes {
        success: Boolean
        message: String
        data: getOrdersAnalyticsResData
    }
          
    type getOrdersAnalyticsResData {
        totalOrders: totalDataPayload 
        totalRevenue: totalDataPayload 
        pendingOrders: totalDataPayload 
        deliveredOrders: totalDataPayload 
    }



    type getCategoriesAnalyticsRes {
        success: Boolean
        message: String
        data: getCategoriesAnalyticsResData
    }
            
    type getCategoriesAnalyticsResData {
        categories: totalDataPayload 
        subCategories: totalDataPayload 
        childSubCategories: totalDataPayload 
        nestedChildSubCategories: totalDataPayload 
    }



    type totalDataPayload {
        total: Int
        lastMonthPercentage: Int
    }

`;