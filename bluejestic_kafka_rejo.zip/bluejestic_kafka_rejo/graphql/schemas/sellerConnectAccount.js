const { gql } = require("apollo-server-express");

module.exports = gql`

  type SellerPayoutPayload {
    id: Int
    seller_id: Int
    custom_txn_id: String
    payout_id: String
    amount: Int
    balance_transaction_id: String
    currency: String
    destination_id: String
    source_type: String
    status: String
    description: String
    method: String
    liveMode: Boolean
    failure_balance_transaction: String
    failure_code: String
    failure_message: String
    statement_descriptor: String
    type: String
    application_fee: String
    application_fee_amount: String
    automatic: Boolean
    created_date_by_stripe: String
    createdAt: String
    updatedAt: String
    sellerInfo: Seller
  } 

  type SellerBankAccountPayload {
    id: Int
    seller_id: Int
    type: String
    brand: String
    country: String
    currency: String
    exp_month: String
    exp_year: String
    last4: String
    account_holder_name: String
    bank_name: String
    routing_number: String
    bank_account_id: String
    bank_or_card_id: String
    isDefault: Boolean
    isActivated: Boolean
    stripeAccountId: String
    account_number: String
    sellerConnectedAccountId: Int
    createdAt: String
    updatedAt: String
  }

  type SellerConnectedAccountCapabilitiesPayload {
    id: Int
    seller_id: Int
    stripeAccountId: String
    sellerConnectedAccountId: Int
    name: String
    status: Boolean
    createdAt: String
    updatedAt: String

  }

  type SellerConnectedAccountPayload {
    id: Int
    seller_id: Int
    stripeAccountId: String
    isConnectAccountDeleted: Boolean,
    isPaymentOnboardingCompleted: Boolean
    details_submitted: Boolean
    type: String
    business_type: String
    tax_id_provided: Boolean
    ssn_last_4_provided: Boolean
    dobDay: Int
    dobMonth: Int
    dobYear: Int
    first_name: String
    last_name: String
    line1: String
    line2: String
    city: String
    state: String
    country: String
    postal_code: String
    isSellerAcceptsTOS: Boolean
    sellerAcceptedTOSFromIPAddress: String
    createdAt: String
    updatedAt: String
    seller_connected_account_capabilities: [SellerConnectedAccountCapabilitiesPayload]
    seller_bank_accounts_info: [SellerBankAccountPayload]
  }

  extend type Mutation {
    createSellerConnectAccount(input: createSellerConnectAccountRequest): createSellerConnectAccountResponse
    addMoreBankAccountOrCard(input: addMoreBankAccountOrCardRequest): addMoreBankAccountOrCardResponse
    removeConnectAccount(input: removeConnectAccountRequest): removeConnectAccountResponse
    sellerWithdrawalFund(input: sellerWithdrawalFundRequest): sellerWithdrawalFundResponse
  }

  extend type Query {
    capabilitiesActiveLink(input: capabilitiesActiveLinkRequest): capabilitiesActiveLinkResponse 
    getTransactionHistoryOfSeller(input: getTransactionHistoryOfSellerRequest): getTransactionHistoryOfSellerResponse 
    getSellerConnectAccountDetails: getSellerConnectAccountDetailsResponse
    getTransactionHistoryOfSellerForAdmin(input: getTransactionHistoryOfSellerRequest): getTransactionHistoryOfSellerResponse
  }

  type addMoreBankAccountOrCardResponse {
    success: Boolean
    message: String
  }

  input addMoreBankAccountOrCardRequest {
    transactionMethod: String
    cardNumber: String
    expMonth: Int
    expYear: Int
    cvc: String
    routingNumber: String
    accountNumber: String
    currency: String
    bankCountry: String
  }



  type getSellerConnectAccountDetailsResponse {
    success: Boolean
    message: String 
    data: SellerConnectedAccountPayload
  }

  input getTransactionHistoryOfSellerRequest {
    page: Int
    limit: Int
  }

  input sellerWithdrawalFundRequest {
    withdrawAmount: Int!
    currency: String!
    stripeAccountId: String! 
    bankOrCardId: String! 
  }

  type sellerWithdrawalFundResponse {
    success: Boolean
    message: String
  }

  type getTransactionHistoryOfSellerResponse {
    success: Boolean
    message: String
    data: [SellerPayoutPayload]
  }

  input removeConnectAccountRequest {
    stripeAccountId: String!
  }

  type removeConnectAccountResponse {
    success: Boolean
    message: String
  }


  input capabilitiesActiveLinkRequest {
    stripeAccountId: String!
  }

  type capabilitiesActiveLinkResponse {
    success: Boolean
    message: String
    url: String
  }

  input createSellerConnectAccountRequest {
    firstName: String
    lastName: String
    acceptTOS: Boolean!
    businessType: String!
    ipAddress: String!
    businessName: String!
    businessUrl: String!
    dob: dobInput
    address: addressInput!
    ssnLast4: String
    taxId: String
    bankCountry: String
    currency: String!
    routingNumber: String
    accountNumber: String
    transactionMethod: String
    cardNumber: String
    expMonth: Int
    expYear: Int
    cvc: String
  }

  input dobInput {
    day: Int
    month: Int
    year: Int
  }

  input addressInput {
    line1: String!
    line2: String
    city: String!
    state: String!
    postalCode: String!
    businessCountry: String!
  }

  type createSellerConnectAccountResponse {
    success: Boolean
    message: String
  }

`;
