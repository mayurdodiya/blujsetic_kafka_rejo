const { gql } = require("apollo-server-express");

module.exports = gql`
  type LegalDetails {
    id: Int
    seller_id: Int
    taxClassification: String
    countryIncorporation: String
    taxId: String
    foundationYear: Int
    estimatedAnnualSale: String
    numberOfEmployees: String
  }

  extend type Mutation {
    addLegalDetails(input: LegalDetailsInput!): LegalDetailsResponse
    # updateLegalDetails(
    #   input: LegalDetailsUpdateInput!
    # ): LegalDetailsResponse
    # deleteLegalDetails(id: Int!): LegalDetails
  }

  extend type Query {
    getSingleLegalDetails(id: Int!): LegalDetails
    getAllLegalDetails: [LegalDetails!]
  }

  type LegalDetailsResponse {
    id: Int
    seller_id: Int
    taxClassification: String
    countryIncorporation: String
    taxId: String
    foundationYear: Int
    estimatedAnnualSale: String
    numberOfEmployees: String
  }

  input LegalDetailsInput {
    seller_id: Int
    taxClassification: String
    countryIncorporation: String
    taxId: String
    foundationYear: Int
    estimatedAnnualSale: String
    numberOfEmployees: String
  }

  input LegalDetailsUpdateInput {
    id: Int!
    seller_id: Int!
    taxClassification: String!
    countryIncorporation: String!
    taxId: String
    foundationYear: Int
    estimatedAnnualSale: String
    numberOfEmployees: String
  }
`;
