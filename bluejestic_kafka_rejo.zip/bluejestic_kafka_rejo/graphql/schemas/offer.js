const { gql } = require('apollo-server-express');

module.exports = gql`

 type Offer {
      id: Int!
      parent_id:Int!
      title:String!
      detail:String!
      description:String!
      code:String!
      expiry_date:String!
      offer_for:String!
      is_active:Boolean!
 }

extend type Query {
    getAllOffers: [Offer!]
    getSingleOffer(id: Int!): Offer
}
 extend type Mutation {
    addOffer(input:Input!): Response
    updateOffer(input:updateInput!):Response
    deleteOffer(id:Int!):Response
 }

 type Response {
      id: Int!
      parent_id:Int!
      title:String!
      detail:String!
      description:String!
      code:String!
      expiry_date:String!
      offer_for:String!
      is_active:Boolean!
    createdAt: String!
 }

 input updateInput{
      id: Int!
      parent_id:Int!
      title:String!
      detail:String
      description:String
      code:String!
      expiry_date:String
      offer_for:String!
      is_active:Boolean
 }

 input Input{
      parent_id:Int!
      title:String!
      detail:String
      description:String
      code:String!
      expiry_date:String
      offer_for:String!
      is_active:Boolean
 }
`;
