const { gql } = require("apollo-server-express");

module.exports = gql`
  scalar Date
  type Seller {
    id: Int
    firstName: String
    lastName: String
    userName: String
    email: String
    confirmEmail: String
    password: String
    confirmPassword: String
    mobileNumber: String
    phoneNumber: String
    ext: String
    jobTitle: String
    accountType: String
    isVerify: Boolean
    userFor: String
    businessInformation: BusinessInformation
    legalDetails: LegalDetails
    address: Address
    bio_detail: BioDetail
    bookmark: [Bookmark]
    createdAt: Date
    personalInformation: BusinessInformation
    language: String
    aboutUs: String
  }

  type connectAccount {
    type: String
    brand: String
    country: String
    currency: String
    exp_month: String
    exp_year: String
    last4: String
    account_holder_name: String
    bank_name: String
    routing_number: String
    isDefault: Boolean
    isActivated: Boolean
  }

  type sellerTransactionHistory {
    seller_id: Int
    tansaction_id: String
    amount: String
    balance_transaction: String
    currency: String
    destination_id: String
    source_type: String
  }

  extend type Mutation {
    registerSeller(input: RegisterSellerInput): RegisterSellerResponse!
    sellerLogin(email: String!, password: String!): LoginResponse!
    updateSellerDetails(input: updateSellerInput): RegisterSellerResponse
    updateSeller(input: updateSellerInputs): RegisterSellerResponse
    sellerOnboarding5Details(input: sellerOnboarding5DetailsInput): sellerOnboarding5DetailsRespose
    directSelleOnboarding5Detail(input: directSelleOnboarding5DetailInput): directSelleOnboarding5DetailRespose
    checkStoreAvailability(store_name: String!): checkStoreAvailabilityRes
    sellerVerified(isVerify: Boolean): Seller
    sellerSignUp(input: sellerInput): RegisterSellerResponse

    addSellerApprovalDetail(input: SellerApprovalInput): SellerApprovalResponse
    updateSellerDetail(input: SellerDetailInput): updateSellerDetailRes
    sellerApproval(email: String!, status: String!, sellerApprovalNote: String): SellerApprovalResponse
    updateBankDetails(connect_id: String!): String
    sendOTPForWithdrawal: GlobalResponse
    sellerOnboard(input: sellerOnboardInput): sellerOnboardRes
  }
  extend type Query {
    singleSelller(id: Int!): Seller
    sellerBankOnboardingStatus: GlobalResponse
    sellerConnectAccounts: connectAccountResponse
    sellerTransactionHistory: sellerTransactionHistoryResponse
    sellerPaymentVerificationPopup(isPopup: Boolean): sellerPaymentVerificationPopupResponse
    sellerAvailableAmount: successResponseForSellerAvailableAmount
    getNewStoreApplications(page: Int, limit: Int): getNewStoreApplicationsResponse
    getSingleNewStoreApplication(id: Int!): getSingleNewStoreApplicationResponse
    sellerWithdrawableAmount: sellerWithdrawableAmountResponse
  }

  input SellerDetailInput{
    firstName: String
    lastName: String
    phoneNumber: String
    profile_image: String
  }

  type updateSellerDetailRes{
    success: Boolean
    message: String
  }

  input directSelleOnboarding5DetailInput{
    personalInformation: personalInformationInput
    businessDetails:businessDetailsInput
    identificationForm: identificationFormInput
  }

  input sellerOnboardInput {
    seller: sellerInput
    sellerIdentification: sellerIdentificationInput
    taxRules: [tax_rulesInput]
    password: passwordInput
    store: storeInput
    business: businessInput
  }

  input sellerInput {
    firstName: String
    lastName: String
    profile_image: String
    phoneNumber: String
    is_tax_calculation: Boolean
    is_price_include_tax: Boolean
    tax_categories: [String]
  }

  input sellerIdentificationInput {
    id_type: String
    document: String
  }

  input tax_rulesInput {
    country: String,
    state: String,
    rate_percentage: String,
  }

  input passwordInput {
    current_password: String
    new_password: String
  }

  input storeInput {
    logo_image: String
    banner_image: String
    store_name: String
    companyLegalName: String
  }

  input businessInput{
    business_address: String
    business_address_detail: String
    business_email: String
    business_city: String
    business_state: String
    business_zip_code: String
    business_country: String
    business_phone_number: String
  }

  input personalInformationInput{
    type: String!
    firstName: String!
    middleName: String!
    lastName: String!
    residential_address: String!
    residential_address_detail: String!
    state: String!
    zip_code: String!
    country: String!
    phone_number: String!
    store_name: String!
    primary_product_category_new: Int!
    city: String
  }

  input businessDetailsInput{
    type: String!
    business_type: String!
    business_legal_name: String!
    employer_identification_number: String!
    business_address: String!
    business_address_detail: String!
    business_city: String!
    business_state: String!
    business_zip_code: String!
    business_country: String!
    business_email: String!
    business_phone_number: String!
    agree: Boolean!
}

input identificationFormInput{
  type: String!
  documentName: String!
  document: String!
  birth_month: String!
  birth_date: String!
  birth_year: String!
  birthdate: String!
  passport_number: String!
  expiring_date: String!
  ssn: String!
  itin: String!
  agree: Boolean!
}

  type sellerWithdrawableAmountResponse {
    success: Boolean
    message: String
    withdrawableAmount: Float    
  }

  type sellerOnboardRes{
    success: Boolean
    message: String
    error: [String]
  }


  type directSelleOnboarding5DetailRespose{
    success: Boolean
    message: String
  }

  type getSingleNewStoreApplicationResponse {
    success: Boolean
    message: String
    data: getNewStoreApplicationsResponseDataRows
  }

  type getNewStoreApplicationsResponse {
    success: Boolean
    message: String
    data: getNewStoreApplicationsResponseData
  }

  type getNewStoreApplicationsResponseData {
    count: Int
    rows: [getNewStoreApplicationsResponseDataRows]
  }

  type getNewStoreApplicationsResponseDataRows {
    id: Int
    firstName: String
    lastName: String
    email: String
    sellerApprovedStatusNew: String
    details5OnboardingCompletedAtNew: String
    phoneNumber: String
    createdAt: String
    seller_personal_info: sellerPersonalInfoData
    seller_business_detail: sellerBusinessDetailData
    seller_documents_info: [sellerDocumentsInfoData]
  }

  type sellerDocumentsInfoData {
    id: Int
    documentType: String
    documentName: String
    document: String
    documentApprovedStatus: String
  }

  type sellerPersonalInfoData {
    store_name: String
    product_category_details: productCategoryDetailsData
  }

  type productCategoryDetailsData {
    id: Int
    name: String
  }

  type sellerBusinessDetailData {
    business_type: String
    business_legal_name: String
    employer_identification_number: String
    business_address: String
    business_address_detail: String
    city: String
    state: String
    zip_code: String
    country: String
    business_email: String
    phone_number: String
    business_city: String
    business_state: String
    business_zip_code: String
    business_country: String
    business_phone_number: String
  }

  type checkStoreAvailabilityRes {
    success: Boolean
    message: String
  }

  input sellerOnboarding5DetailsInput {
    type: String!
    firstName: String
    middleName: String
    lastName: String
    residential_address: String
    residential_address_detail: String
    city: String
    state: String
    zip_code: String
    country: String
    phone_number: String
    business_type: String
    business_legal_name: String
    employer_identification_number: String
    business_address: String
    business_address_detail: String
    business_city: String
    business_state: String
    business_zip_code: String
    business_country: String
    business_email: String
    business_phone_number: String
    documentName: String
    document: String
    birth_month: String
    birth_date: String
    birth_year: String
    birthdate: String
    passport_number: String
    expiring_date: String
    ssn: String
    itin: String
    store_name: String
    primary_product_category_new: Int
    agree: Boolean
  }

  type sellerOnboarding5DetailsRespose {
    success: Boolean
    message: String
  }

  type sellerPaymentVerificationPopupResponse {
    success: Boolean
    message: String
  }

  type successResponseForSellerAvailableAmount {
    success: Boolean
    message: String
    data: sellerAvailableAmount
  }
  type sellerAvailableAmount {
    upcoming_amount: Float
    final_amount: Float
  }

  type sellerTransactionHistoryResponse {
    success: Boolean
    message: String
    data: [sellerTransactionHistory]
  }

  type connectAccountResponse {
    success: Boolean
    message: String
    data: [connectAccount]
  }

  input sellerInput {
    accountType: String
    firstname: String
    lastname: String
    phone: String
    email: String
    company: String
    storeName: String
    password: String
    confirmpassword: String
    city: String
    state: String
    zipcode: Int
    businessURl: String
    businesstype: String
    address: String
  }

  input updateSellerInput {
    id: Int!
    firstName: String
    lastName: String
    email: String
    mobileNumber: String
    phoneNumber: String
    ext: String
    jobTitle: String
    aboutUs: String
    language: String
    dateFormat: String
    timeZone: String
    accountType: String
    userFor: String
    # Business Information
    name: String
    companyLegalName: String
    address: String
    city: String
    state: String
    zipcode: Int
    websiteUrl: String
    isHaveTeam: Boolean
    annualSale: String
    totalEmployees: String
    logo: [String]
    cover_image: [String]
    sellerType: String
    # Legal Details
    taxClassification: String
    countryIncorporation: String
    taxId: String
    foundationYear: Int
    estimatedAnnualSale: String
    isVerify: Boolean
    numberOfEmployees: String
  }

  input updateSellerInputs {
    id: Int!
    firstName: String
    lastName: String
    email: String
    mobileNumber: String
    phoneNumber: String
    ext: String
    jobTitle: String
    aboutUs: String
    language: String
    dateFormat: String
    timeZone: String
    accountType: String
    userFor: String
    # Business Information
    name: String
    companyLegalName: String
    title: String
    address: String
    city: String
    state: String
    country: String
    zipcode: Int
    websiteUrl: String
    isHaveTeam: Boolean
    annualSale: String
    totalEmployees: String
    logo: [String]
    cover_image: [String]
    sellerType: String
    employmentType: String
    profession: String
    # Legal Details
    taxClassification: String
    countryIncorporation: String
    taxId: String
    foundationYear: Int
    estimatedAnnualSale: String
    isVerify: Boolean
    numberOfEmployees: String
  }
  input SellerApprovalInput {
    title: String
    firstName: String
    lastName: String
    accountType: String
    email: String
    phoneNumber: String
    companyLegalName: String
    websiteUrl: String
    streetAddress: String
    city: String
    state: String
    state_name: String
    postalCode: String
    productType: String
    businessType: String
    isApprovedByAdmin: Boolean
  }
  type SellerApprovalResponse {
    success: Boolean
    message: String
  }

  type SellerApprovalDataResponse {
    title: String
    firstName: String
    lastName: String
    userName: String
    accountType: String
    email: String
    phoneNumber: String
    companyLegalName: String
    websiteUrl: String
    streetAddress: String
    city: String
    state: String
    postalCode: String
    productType: String
    businessType: String
  }

  type RegisterSellerResponse {
    id: Int!
    firstName: String!
    lastName: String!
    userName: String
    email: String!
    confirmEmail: String!
    password: String!
    confirmPassword: String!
    mobileNumber: String!
    phoneNumber: String
    ext: String!
    accountType: String
    jobTitle: String
    aboutUs: String
    language: String
    dateFormat: String
    timeZone: String
    BusinessInformation: BusinessInformation
    userFor: String
    isVerify: Boolean
    LegalDetails: LegalDetails
  }

  input RegisterSellerInput {
    firstName: String
    lastName: String
    email: String
    confirmEmail: String
    password: String
    confirmPassword: String
    mobileNumber: String!
    phoneNumber: String
    ext: String
    accountType: String
    jobTitle: String
    userFor: String
    isVerify: Boolean
    businessInformation: BusinessInformationInput
    legalDetails: LegalDetailsInput
  }

  #input LoginInput {
  #  email: String!
  #  password: String!
  #}

  type LoginResponse {
    #jwt: String!
    #seller: User
    jwt: String!
    seller: Seller
  }
`;
