const { gql } = require("apollo-server-express");

module.exports = gql`
  enum AddOrDelete {
    ADD
    DELETE
  }

  type User {
    id: Int!
    username: String!
    profileAvtar: [String]
    createdAt: String!
    latestMessage: Message
  }

  type MsgGroupUser {
    id: Int!
    username: String!
  }

  type Message {
    id: Int!
    body: String!
    conversationId: Int!
    senderId: Int!
    createdAt: String!
    user: MsgGroupUser
  }

  type LoggedUser {
    id: Int!
    username: String!
    token: String!
  }

  type SubbedMessage {
    message: Message!
    type: String!
    participants: [Int!]
  }
  type Query {
    getAllConversationUsers: [User]!
    getPrivateMessages(userId: Int!): [Message]!
    getGlobalMessages: [Message]!
  }

  type Mutation {
    register(username: String!, password: String!): LoggedUser!
    login(username: String!, password: String!): LoggedUser!

    sendPrivateMessage(receiverId: Int!, body: String!): Message!
    sendGlobalMessage(body: String): Message!
  }

  type Subscription {
    newMessage: SubbedMessage!
  }
`;
