const { gql } = require("apollo-server-express");

module.exports = gql`
  type payment {
    id: Int!
    group_id: Int!
    user_id: Int!
    groupType: String
    isAdmin: Boolean
    isOwner: Boolean
    groups: Group
    user: User
    members: User
  }

  #   extend type Query {
  #   }

  extend type Mutation {
    confirmPayment(input: paymentInput!): paymentResponse
    verifyPayment(paymentId: String!, order_id: Int!): paymentResponse
    withDrawPaymentFromSeller(amount: Int!, accountId: String!, otp: String!): GlobalResponse
    refundFromSellerToPlatform(amount: Int!, orderId: Int!): GlobalResponse
    addPayment(amount: Float!): addPaymentResponse
  }

  type paymentObject {
    paymentId: String
    redirectUrl: String
    order_id: String
    generate_id: String
  }

  type paymentResponse {
    success: Boolean!
    message: String
    error: [paymentResponseError]
    data: paymentObject
    generate_id: String
  }

  type paymentResponseError {
    success: Boolean
    message: String
    variant_id: Int
  }

  input productDetail {
    productId: Int!
    quantity: Int!
  }

  type addPaymentResponse {
    client_secret: String
  }
`;
