const { gql } = require("apollo-server-express");

module.exports = gql`
  extend type Query {
    randomArray: response
  }
  type response {
    array: [Int]
  }
`;
