const { gql } = require("apollo-server-express");

module.exports = gql`
  scalar Date
  type User {
    id: Int!
    firstName: String!
    status: String
    lastName: String!
    userName: String
    logo_image: String
    banner_image: String
    email: String!
    confirmEmail: String!
    password: String!
    confirmPassword: String!
    mobileNumber: String!
    phoneNumber: String
    gender: String
    bday: String
    ext: String!
    jobTitle: String
    userFor: String
    businessInformation: BusinessInformation
    legalDetails: LegalDetails
    address: Address
    profileAvtar: [String]
    profileCoverImage: [String]
    bio_detail: BioDetail
    bookmark: [Bookmark]
    createdAt: String
    save_posts: [Savepost]
    joingroups: [JoinGroup]
    isFriendForFriendStatus: Boolean
    isActiveForFriendStatus: Boolean
    profileUrl: String
    profileCoverImageUrl: String
    followers: [Friend]
    followings: [Friend]
    mutualFriends: [User]
    medias: [Media]
    follower_count: Int
    following_count: Int
    becomeSellerStatus: String
    isOnboardCompleted: Boolean
    isFollow: Boolean
    followers_count: Int
    order_detail: [orderMasterRes]
    total_purchase_item: [getAllOrdersRes]
  }

  extend type Query {
    getAllUsersData(id: Int): [User!]
    users(id_nin: [Int]): [User!]
    currentUser: currentUserResponse
    userAnalytics: userAnalyticsResponse
    getUserbyName(slug: String!): UserResponse
    searchUsersWithElasticSearch(isFollow: String, search: String, page: Int, limit: Int): getProductStockReportResponse
    getUserSlugList: getUserSlugListRes
    userSignupVerification(token: String!): userSignupVerificationResponse
    sellerSignupVerification(token: String!): userSignupVerificationResponse
  }

  type getUserSlugListRes {
    success: Boolean
    message: String
    data: [getUserSlugListResData]
  }

  type getUserSlugListResData {
    userName: String
  }

  extend type Mutation {
    signup(input: UserInput!): signupRes
    sellerRegister(input: UserInput!): sellerRegisterRes
    verifyOTPForSeller(otp: String!, email: String!): verifyOTPForForgotResponse
    #registerSeller(input: RegisterSellerInput!): RegisterSellerResponse!
    resendSellerVerificationOtp(email: String!): resendMailVerificationResponse
    signin(input: signinSellerInput!): signinResponse
    updateUserStatus(user_id: Int!, status: String!): updateUserStatusRes
    removeUser(user_ids: [Int!]): removeUserRes
    sellerSignin(input: signinSellerInput!): sellerSigninRes
    login(input: signinSellerInput!): adminLoginRes
    updateUser(input: updateUserInput): updateUserResponse
    updateUserAddress(input: userAdressDatas): updateUserAddressResponse
    updateUserImages(input: userImages): User
    updateBioDetail(input: bioDetailInput): updateBioDetailResponse
    addPostDataIntoElastic(id: Int): addPostDataIntoElasticRes
    addCommentIntoElastic(id: Int): addCommentIntoElasticRes
    addLikeIntoElastic(id: Int): addLikeIntoElasticRes
    sendInvitation(emails: [String]): sendInvitationRes
    getInvitationData: getInvitationDataRes
    forgotPassword(email: String!): forgotPasswordResponse
    changePassword(currentPassword: String!, newPassword: String!): changePasswordResponse
    changeSellerPassword(currentPassword: String!, newPassword: String!): changePasswordResponse
    verifyOTPForForgot(otp: String!, email: String!): verifyOTPForForgotResponse
    resetPassword(email: String!, password: String!, otp: String!): resetPasswordResponse
    sellerRegisterFromUser: signupRes
    resendMailVerification(id: Int!): resendMailVerificationResponse
  }

  type sellerRegisterRes {
    success: Boolean
    message: String
  }
    
  type sellerSigninRes {
    success: Boolean
    message: String
    isSellerInfoVerified: Boolean
    sellerApprovedStatusNew: String
    currentQueryForVerification: String
    isUserOnboardCompleted: Boolean
    isSellerVerify: Boolean
    isDetailsOnboardingCompleted: Boolean
    isOnboardCompleted: Boolean
    currentStepForSellerOnboarding: String
    token: String
  }

  type sendInvitationRes {
    success: Boolean
    message: String
  }

  type getInvitationDataRes {
    success: Boolean
    message: String
    data: [getInvitationRes]
  }

  type getInvitationRes {
    email: String
    count: Int
    user_id: Int
  }

  type changePasswordResponse {
    success: Boolean
    message: String
  }

  type signupRes {
    success: Boolean
    message: String
  }

  type signupResData {
    user: User
    login: LoginResponse
  }

  type addCommentIntoElasticRes {
    success: Boolean
    message: String
  }

  type addLikeIntoElasticRes {
    success: Boolean
    message: String
  }

  type updateUserStatusRes {
    success: Boolean
    message: String
  }

  type removeUserRes {
    success: Boolean
    message: String
  }

  type userAnalyticsData {
    followers: Int
    followings: Int
    savedStore: Int
    joinGroups: Int
    savePosts: Int
  }

  type addPostDataIntoElasticRes {
    id: Int
  }

  type userAnalyticsResponse {
    success: Boolean
    message: String
    data: userAnalyticsData
  }

  type UserResponse {
    id: Int!
    firstName: String!
    userName: String
    lastName: String!
    email: String!
    logo_image: String
    banner_image: String
    confirmEmail: String!
    password: String!
    confirmPassword: String!
    mobileNumber: String!
    phoneNumber: String
    marital_status: String
    subAddress: String
    gender: String
    bday: String
    ext: String!
    jobTitle: String
    userFor: String
    businessInformation: BusinessInformation
    legalDetails: LegalDetails
    address: String
    profileAvtar: [String]
    profileCoverImage: [String]
    bio_detail: BioDetail
    bookmark: [Bookmark]
    createdAt: String
    save_posts: [Savepost]
    joingroups: [JoinGroup]
    isFriendForFriendStatus: Boolean
    isActiveForFriendStatus: Boolean
    profileUrl: String
    profileCoverImageUrl: String
    followers: [Friend]
    followings: [Friend]
    # bio detail
    user_id: Int
    status: String
    occupation: String
    education: String
    city: String
    state: String
    country: String
    zipCode: String
    interest: String
    about: String
    experience: String
    hobbies: String
    mutualFriends: [User]
    medias: [Media]
    post_count: Int
    followers_count: Int
    following_count: Int
    club_count: Int
    followed_stores_count: Int
    purchased_item_count: Int
    total_spent: Float
    shipping_address: shippingAddressRes
  }

  type shippingAddressRes {
    user_id: Boolean
    streetAddress: String
    city: String
    firstName: String
    lastName: String
    number: String
    state: String
    country: String
    country_name: String
    state_name: String
    isDefault: Boolean
    zipcode: String
    buildingName: String
    isPinLocation: Boolean
    latitude: Float
    longitude: Float
  }

  type profileImage {
    url: String
    id: Int
  }

  type profileImageCover {
    url: String
    id: Int
  }

  type currentUserResponse {
    user: currentUserRes
    seller: currentSellerRes
  }

  type currentSellerRes {
    id: Int
    firstName: String
    profile_image: String
    seller_business_detail: sellerBusinessDetailData
    lastName: String
    email: String
    isOnboardCompleted: Boolean
    currentStepForSellerOnboarding: String
    seller_detail: BusinessInformation
    #password: String
    #ext: String
    #mobileNumber: String
    phoneNumber: String
    jobTitle: String
    #isSellerVerify: Boolean
    #isDeleted: String
    aboutUs: String
    language: String
    #dateFormat: String
    #timeZone: String
    currentQueryForVerification: String
    isSellerInfoVerified: Boolean
    user_id: Int
    #accountType: String
    #isPopup: Boolean
    isVerify: Boolean
    sellerApprovedStatusNew: String
    #isPaymentOnboardingCompleted: Boolean
    #details_submitted: Boolean
    country: String
    #stripeAccountId: String
    #otpForWithdrawal: String
    #otpForWithdrawalExpiry: Date
    #createdAt: Date
    #updatedAt: Date
    user: currentUserRes
  }

  type currentUserRes {
    id: Int
    firstName: String
    lastName: String
    email: String
    confirmEmail: String
    password: String
    confirmPassword: String
    mobileNumber: String
    gender: String
    ext: String
    jobTitle: String
    userFor: String
    businessInformation: BusinessInformation
    legalDetails: LegalDetails
    # address: Address
    logo_image: String
    banner_image: String
    profileAvtar: [profileImage]
    profileCoverImage: [profileImageCover]
    bio_detail: BioDetail
    bookmark: [Bookmark]
    seller_id: Int
    seller: currentSellerRes
    isSellerInfoVerified: Boolean
    isSeller: Boolean
    isUser: Boolean
    createdAt: String
    save_posts: [Savepost]
    joingroups: [JoinGroup]
    isFirstTime: Boolean
    bday: Date
    role: String
    address: String
    subAddress: String
    city: String
    state: String
    country: String
    zipCode: String
    phoneNumber: String
    cartCount: Int
    becomeSellerStatus: String
    store: storeDetail
    isOnboardCompleted: Boolean
    isUserOnboardCompleted: Boolean
    userName: String
  }

  type storeDetail {
    id: Int
    name: String
    companyLegalName: String
    logo: String
    logo_id: String
    logo_image: String
    banner_image: String
    cover_image: String
    slug: String
    cover_image_id: String
    seller_token: String
    createdAt: Date
    state: String
    state_name: String
    country: String
    postalCode: String
    streetAddress: String
    city: String  
    phoneNumber: String
  }

  input bioDetailInput {
    id: Int!
    relationshipStatus: String
    subAddress: String
    occupation: String
    education: String
    otherInterests: String
    firstName: String
    lastName: String
    banner_image: String
    logo_image: String
    gender: String
    about: String
    workExperience: String
    hobbies: String
    jobTitle: String
    profileImage: [Int]
    coverImage: [Int]
    bday: String
    phoneNumber: String
    address: String
    city: String
    state: String
    country: String
    zipCode: String
    userName: String
    isUserOnboardCompleted: Boolean
  }

  input userImages {
    profileAvtar: [Int]
    profileCoverImage: [Int]
  }
  input userAdressDatas {
    user_id: Int
    address1: String
    address2: String
    city: String
    state: String
    zipCode: Int
    country: String
    address_for: String
  }

  input userdatas {
    firstName: String
    lastName: String
    email: String
    phoneNumber: String
    gender: String
    bday: String
    city: String
    state: String
    country: String
    zipCode: Int
    address: String
    subAddress: String
    relationshipStatus: String
    jobTitle: String
    education: String
    otherInterests: String
    about: String
    workExperience: String
    hobbies: String
    profileImage: [String]
    coverImage: [String]
  }
  input updateUserInput {
    id: Int
    data: userdatas
  }

  type signinResponse {
    success: Boolean
    message: String
    role: String,
    isSeller: Boolean
    isUserOnboardCompleted: Boolean
    becomeSellerStatus: String
    currentQueryForVerification: String
    isDetails5OnboardingCompletedNew: Boolean
    currentStepForSellerOnboarding: String
    isOnboardCompleted: Boolean
    token: String
  }

  type updateBioDetailResponse {
    id: Int
    user_id: Int
    martial_status: String
    occupation: String
    education: String
    interest: String
    about: String
    experience: String
    hobbies: String
    firstName: String
    userName: String
    lastName: String
    gender: String
  }

  type forgotPasswordResponse {
    success: Boolean
    message: String
  }

  type verifyOTPForForgotResponse {
    success: Boolean
    message: String
    seller_token: String
    isSellerInfoVerified: Boolean
    currentQueryForVerification: String
    isSellerVerify: Boolean
  }

  type resetPasswordResponse {
    success: Boolean
    message: String
  }

  type userSignupVerificationResponse {
    success: Boolean
    message: String
    isVerified: Boolean
  }

  type resendMailVerificationResponse {
    success: Boolean
    message: String
  }

  type updateUserAddressResponse {
    id: Int
    user_id: Int
    address1: String
    address2: String
    city: String
    state: String
    zipCode: Int
    country: String
    address_for: String
  }

  type updateUserResponse {
    id: Int
    firstName: String
    lastName: String
    email: String
    phoneNumber: String
    gender: String
    bday: String
    city: String
    state: String
    country: String
    zipCode: Int
    address: String
    subAddress: String
    relationshipStatus: String
    jobTitle: String
    education: String
    otherInterests: String
    about: String
    workExperience: String
    hobbies: String
    profileImage: [String]
    coverImage: [String]
  }

  #type RegisterSellerResponse {
  #  id: Int!
  #  firstName: String!
  #  lastName: String!
  #  email: String!
  #  confirmEmail: String!
  #  password: String!
  #  confirmPassword: String!
  #  mobileNumber: String!
  #  phoneNumber: String
  #  ext: String!
  #  jobTitle: String
  #  BusinessInformation: BusinessInformation!
  #  userFor: String!
  #  LegalDetails: LegalDetails
  #}
  #
  #input RegisterSellerInput {
  #  firstName: String!
  #  lastName: String!
  #  email: String!
  #  confirmEmail: String!
  #  password: String!
  #  confirmPassword: String!
  #  mobileNumber: String!
  #  phoneNumber: String
  #  ext: String
  #  jobTitle: String
  #  userFor: String
  #  businessInformation: BusinessInformationInput
  #  legalDetails: LegalDetailsInput
  #}

  input UserInput {
    firstName: String
    lastName: String
    email: String
    password: String
    social_type: String
    access_token: String
  }

  input signupInput {
    firstName: String!
    lastName: String!
    email: String!
    password: String!
  }

  type signupResponse {
    id: Int!
    firstName: String!
    lastName: String!
    email: String!
    userName: String
  }

  input LoginInput {
    email: String!
    password: String!
  }

  type adminLoginRes {
    success: Boolean
    message: String
    role: String
    token: String 
  }

  input signinSellerInput {
    email: String
    password: String
    loginActivity: loginActivityInput
    social_type: String
    access_token: String
  }
  input loginActivityInput {
    latitude: String
    longitude: String
    deviceName: String
  }

  type LoginResponse {
    #jwt: String!
    success: Boolean
    message: String
    isMailsend: Boolean
    #seller: User
    token: String
    seller_token: String
    isUserOnboardCompleted: Boolean
    isSeller: Boolean
    isUser: Boolean
    user: User
    role: String
    isSellerVerify: Boolean
    currentQueryForVerification: String
    isSellerInfoVerified: Boolean
    sellerApprovedStatusNew: String
  }
`;
