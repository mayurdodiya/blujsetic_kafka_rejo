const { gql } = require("apollo-server-express");

module.exports = gql`
    type GlobalResponse {
        success: Boolean
        message: String
        data: JSON
    }
`;
