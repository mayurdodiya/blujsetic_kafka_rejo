const { gql } = require("apollo-server-express");

module.exports = gql`
  type Follow {
    id: Int!
    following_id:Int!
    follower_id:Int!
    follow_for:String!
  }

  extend type Query {
    getAllFollowDetails: [Follow!]
    getSingleFollowDetail(id: Int!): Follow
}

extend type Mutation {
    addFollowDetail(input: FollowInput!): FollowResponse
    updateFollowDetail(input:UpdateInput!):FollowResponse
    deleteFollowDetail(id:Int!):FollowResponse
  }

  type FollowResponse {
    id: Int!
    following_id:Int!
    follower_id:Int!
    follow_for:String!
  }

  input FollowInput {
    following_id:Int!
    follower_id:Int!
    follow_for:String!
  }

  input UpdateInput {
    id:Int!
    following_id:Int!
    follower_id:Int!
    follow_for:String!
  }
`;