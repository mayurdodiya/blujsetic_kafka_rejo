const { gql } = require("apollo-server-express");

module.exports = gql`
  type About {
    id: Int!
    parent_id:Int!
    address:String!
    city:String!
    state:String!
    country:String!
    location:String!
    postal_code:Int!
    facebook:String!
    twitter:String!
    instagram:String!
    linkedin:String!
    about_for:String!
  }

  extend type Mutation {
    addAbout(input: aboutInput!): aboutResponse
    updateAbout(input:aboutUpdateInput!):aboutResponse
    deleteAbout(id:Int!):About
  }

  extend type Query{
    getAllAbout:[About!]
    getSingleAbout(id:Int!):About!
  }

  type  aboutResponse{
    id:Int! 
    parent_id:Int!
    address:String!
    city:String!
    state:String!
    country:String!
    location:String!
    postal_code:Int!
    facebook:String!
    twitter:String!
    instagram:String!
    linkedin:String!
    about_for:String!
    }

  input aboutInput {
    parent_id:Int!
    address:String!
    city:String
    state:String
    country:String!
    location:String
    postal_code:Int!
    facebook:String
    twitter:String
    instagram:String
    linkedin:String
    about_for:String
  }

  input aboutUpdateInput{
    id: Int!
    parent_id:Int!
    address:String!
    city:String
    state:String
    country:String!
    location:String
    postal_code:Int!
    facebook:String
    twitter:String
    instagram:String
    linkedin:String
    about_for:String
  }
`;
