const { gql } = require("apollo-server-express");

module.exports = gql`
scalar Date  
type userLocationActivity {
    id: Int
    user_id: Int
    userType: String
    latitude: String
    longitude: String
    createdAt: Date
  }

  extend type Mutation {
    addUserLocationActivity(input: userLocationActivityInput!): userLocationActivityResponse
  }

  extend type Query{
    getAllUserLocationHistory(user_id: Int!): userLocationActivityResponse
  }
  input userLocationActivityInput {
  latitude: String
  longitude: String
  }
  type userLocationActivityResponse {
    success: Boolean
    message: String
    data: [userLocationActivity]
  }
`;
