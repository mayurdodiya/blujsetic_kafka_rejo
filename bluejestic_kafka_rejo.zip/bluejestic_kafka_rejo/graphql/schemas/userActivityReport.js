const { gql } = require("apollo-server-express");

module.exports = gql`
  extend type Query {
    getUserActivityReport(start_date: String!, end_date: String!, time_interval: String): getUserActivityReportRes
  }

  type getUserActivityReportRes {
    success: Boolean
    message: String
    data: getUserActivityReportDataRes
  }

  type getUserActivityReportDataRes {
    current_post_count: Float
    current_post_count_diff: Float
    current_like_count: Float
    current_like_count_diff_pct: Float
    current_comment_count: Float
    current_comment_count_diff_pct: Float
  }
`;
