const { gql } = require("apollo-server-express");

module.exports = gql`
scalar Date  
type userDevices {
    id: Int
    user_id: Int
    userType: String
    deviceName: String
    createdAt: Date
  }

  extend type Mutation {
    addUserDevices(input: userDevicesInput!): userDevicesResponse
  }

  extend type Query{
    getAllUserDevices(user_id: Int!): userDevicesResponse
  }
  input userDevicesInput {
    deviceName: String
  }
  type userDevicesResponse {
    success: Boolean
    message: String
    data: [userDevices]
  }
`;
