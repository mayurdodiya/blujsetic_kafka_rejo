const { gql } = require("apollo-server-express");

module.exports = gql`
  type UserResponseForGroup {
    id: Int!
    firstName: String!
    lastName: String!
    userName: String
    email: String!
    mobileNumber: String
    phoneNumber: String
    gender: String
    bday: String
    ext: String
    jobTitle: String
    userFor: String
    businessInformation: BusinessInformation
    legalDetails: LegalDetails
    address: Address
    profileAvtar: [String]
    profileCoverImage: [String]
    bio_detail: BioDetail
    bookmark: [Bookmark]
    createdAt: String
    save_posts: [Savepost]
    joingroups: [JoinGroup]
    isFriendForFriendStatus: Boolean
    isActiveForFriendStatus: Boolean
    profileUrl: String
    profileCoverImageUrl: String
    followers: [Friend]
    followings: [Friend]
    mutualFriends: [User]
    medias: [Media]
    follower_count: Int
    following_count: Int
    becomeSellerStatus: String
  }
  type Group {
    id: Int!
    name: String
    slug: String
    description: String
    hashtags: [String]
    category_id: Int
    coverImage: String
    bannerImage: String
    logo_image: String
    banner_image: String
    total_members: String
    category: String
    privacy: String
    group_id: Int
    media_id: Int
    user_id: Int
    isExist: Boolean
    subCategory_id: Int
    user: UserResponseForGroup
    isFollow: Boolean
    isActive: Boolean
    totalMembers: Int
    activeMembersToday: Int
    membersAddedLastMonthPercentage: Int
    totalPosts: Int
    newPostsToday: Int
    totalEngagement: Int
    interactionsToday: Int
    postsAddedLastMonthPercentage: Int
    engagedLastMonth: Int
    categoryDetails: Category
    members: [adminAndMember]
  }

  extend type Query {
    # groups(id_nin: [Int]): [Group!]
    groups(type: String, limit: Int, page: Int): groupsRes
    getSuggestedGroups: [Group!]
    getJoinedGroups: [Group!]
    getMyGroups: [Group!]
    groupsRequested: [Group!]
    getCacheClub: getCacheClubRes
    group(slug: String!): SingleGroupResponse
    groupMedia(groupId: Int): [Media]
    searchGroupsWithElasticSearch(search: String, page: Int, limit: Int): searchGroupsResponse
    getAllClubs(type: String, limit: Int, page: Int, user_id: Int, isAdmin: Boolean): getAllClubsRes
    getGroupMember(slug: String!): getGroupMemberRes
    getCacheClub(slug: String): getCacheClubRes
    getClubSlugList: getClubSlugListRes
    checkMemberStatus(group_id: Int!): checkMemberStatusRes
    getClubsForAdmin(input: getClubsForAdminInput): getClubsForAdminRes
  }

  input getClubsForAdminInput {
    status: Boolean
    search: String
    category_id: Int
    slug: String
  }

  type getClubsForAdminRes {
    success: Boolean
    message: String
    data: [Group]
  
  }

  type checkMemberStatusRes {
    success: Boolean
    message: String
    data: checkMemberStatusResData
  }

  type checkMemberStatusResData {
    isAdmin: Boolean
    isOwner: Boolean
  }

  type getClubSlugListRes {
    success: Boolean
    message: String
    data: [getClubSlugListResData]
  }

  type getClubSlugListResData {
    slug: String
  }

  extend type Mutation {
    createGroup(input: GroupInput!): GroupResponse
    updateGroupDetail(input: updateGroupDetailInput): updateGroupDetailResponse
    deleteGroupDetail(id: Int!): GroupResponse
    removeGroupMember(member_id: [Int], club_id: Int!): removeGroupMemberResponse
    deleteGroupsBySlugsForAdmin(slugs: [String]): deleteGroupsBySlugsForAdminRes
  }

  type deleteGroupsBySlugsForAdminRes {
    success: Boolean
    message: String
  }
  
  type getCacheClubRes {
    success: Boolean
    message: String
    }

  type groupsRes {
    success: Boolean
    message: String
    data: [Group!]
  }

  type getAllClubsRes {
    success: Boolean
    message: String
    data: [Group!]
    count: Int
  }

  type getGroupMemberRes {
    success: Boolean
    message: String
    data: [adminAndMember]
  }

  type getCacheClubRes {
    success: Boolean
    message: String
    data: getCacheClubDataRes
  }

  type getCacheClubDataRes {
    id: String
  }

  type removeGroupMemberResponse {
    success: Boolean
    message: String
  }

  type searchGroupsResponse {
    success: Boolean
    message: String
    data: [groupResponseForSearch]
  }
  type groupResponseForSearch {
    id: Int!
    name: String
    description: String
    hashtags: [String]
    category_id: Int
    slug: String
    isExist: Boolean
    #coverImage: String
    #bannerImage: String
    logo_image: String
    banner_image: String
    category: String
    privacy: String
    user_id: Int
    isFollow: Boolean
    total_members: Int
    members: [adminAndMember]
  }

  type GroupMedia {
    id: Int
    url: String
    mediaType: String
  }

  type adminAndMember {
    id: Int
    firstName: String
    lastName: String
    userName: String
    phoneNumber: String
    gender: String
    isAdmin: Boolean
    bday: String
    jobTitle: String
    profileCoverImage: String
    profileAvtar: String
    logo_image: String
    banner_image: String
    isActiveForFriendStatus: Boolean
    isFriendForFriendStatus: Boolean
    mutualFriends: [Int]
    followers: [Friend]
    followings: [Friend]
    joinedAt: String
  }

  type SingleGroupResponse {
    id: Int!
    name: String
    slug: String
    description: String
    hashtags: [String]
    category_id: Int
    logo_image: String
    banner_image: String
    category: String
    privacy: String
    group_id: Int
    sub_Category: categoryResponse
    user_id: Int
    isExist: Boolean
    admins: [adminAndMember]
    members: [adminAndMember]
    user: adminAndMember
    total_members: Int
  }

  type categoryResponse {
    id: Int
    name: String
  }

  type bannerImageRes {
    id: Int
    url: String
  }

  type GroupResponse {
    id: Int!
    name: String
    description: String
    hashtags: [String]
    category_id: Int
    coverImage: String
    bannerImage: String
    category: String
    privacy: String
    group_id: Int
    user_id: Int
    isExist: Boolean
    user: UserResponseForGroup
  }

  type updateGroupDetailResponse {
    success: Boolean
    messsage: String
    slug: String
    id: Int
  }

  input GroupInput {
    name: String!
    description: String!
    hashtags: [String]
    category_id: Int
    logo_image: String
    banner_image: String
    category: String
    privacy: String
    subCategory_id: [Int]
  }

  input updateGroupDetailInput {
    id: Int!
    name: String
    description: String
    hashtags: [String]
    category_id: Int
    logo_image: String
    banner_image: String
    category: String
    privacy: String
    subCategory_id: [Int]
  }

  type getAllGroupsResponse {
    id: Int!
    name: String
    slug: String
    description: String
    hashtags: [String]
    logo_image: String
    banner_image: String
    category_id: Int
    coverImage: String
    bannerImage: String
    category: String
    privacy: String
    group_id: Int
    user_id: Int
    isExist: Boolean
    admins: [adminAndMember]
    members: [adminAndMember]
    user: adminAndMember
    total_members: Int
  }
`;
