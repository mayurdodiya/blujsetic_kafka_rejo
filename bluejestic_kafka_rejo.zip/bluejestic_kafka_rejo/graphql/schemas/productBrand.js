const { gql } = require("apollo-server-express");

module.exports = gql`
  scalar JSON
  scalar Date

  extend type Mutation {
    addProductBrand(name: String, store_id: Int!): addProductBrandRes
  }

  type addProductBrandRes {
    success: Boolean
    message: String
    brand: brandRes
  }

  type brandRes {
    name: String
    id: Int
  }

  extend type Query {
    getBrandByProductId(store_id: Int!): getBrandByProductIdRes
  }

  type getBrandByProductIdRes {
    success: Boolean
    message: String
    data: [getbrandRes]
  }

  type getbrandRes {
    name: String
    id: Int
  }
`;
