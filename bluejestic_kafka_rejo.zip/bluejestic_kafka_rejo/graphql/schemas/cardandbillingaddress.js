const { gql } = require("apollo-server-express");

module.exports = gql`
  type CardAndBillingAddress {
    id: Int!
    user_id: Int!
    card_number: String
    expiry_date: String
    cvv: String
    color: [String]
    streetAddress: String
    country: String
    state: String
    city: String
    zipcode: String
    buildingName: String
    number: String
    isDefault: Boolean
    firstName: String
    userName: String
    lastName: String
    image: String
    cartType: String
  }

  extend type Mutation {
    addCardAndBillingAddress(input: addCardAndBillingAddressInput!): addCardAndBillingAddressResponse
    updateCardAndBillingAddress(input: updateCardAndBillingAddressInput!): updateCardAndBillingAddressResponse
    deleteCardAndBillingAddress(id: Int!): CardAndBillingAddress
  }

  extend type Query {
    getAllCardAndAddress: [CardAndBillingAddress!]
    getSingleCardAndAddress(id: Int!): CardAndBillingAddress!
  }

  input addCardAndBillingAddressInput {
    card_number: String
    expiry_date: String
    cvv: String
    color: [String]
    streetAddress: String
    country: String
    state: String
    city: String
    zipcode: String
    buildingName: String
    number: String
    isDefault: Boolean
    firstName: String
    lastName: String
    image: String
    cartType: String
  }

  type addCardAndBillingAddressResponse {
    id: Int!
    user_id: Int
    card_number: String
    expiry_date: String
    cvv: String
    color: [String]
    streetAddress: String
    country: String
    state: String
    city: String
    zipcode: String
    buildingName: String
    number: String
    isDefault: Boolean
    firstName: String
    lastName: String
    userName: String
    image: String
    cartType: String
  }

  input updateCardAndBillingAddressInput {
    id: Int!
    card_number: String
    expiry_date: String
    cvv: String
    color: [String]
    streetAddress: String
    country: String
    state: String
    city: String
    zipcode: String
    buildingName: String
    number: String
    isDefault: Boolean
    firstName: String
    lastName: String
    image: String
    cartType: String
  }

  type updateCardAndBillingAddressResponse {
    id: Int!
    user_id: Int
    card_number: String
    expiry_date: String
    cvv: String
    color: [String]
    streetAddress: String
    country: String
    state: String
    city: String
    zipcode: String
    buildingName: String
    number: String
    isDefault: Boolean
    firstName: String
    lastName: String
    userName: String
    image: String
    cartType: String
  }
`;
