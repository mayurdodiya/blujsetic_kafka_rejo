const { gql } = require("apollo-server-express");

module.exports = gql`
  type ChildSubCategory {
    id: Int
    category_id: Int
    sub_category_id: Int
    name: String
    description: String
    media: String
    banner_media: String
    mainCategory: Category
    slug: String
    subCategory: SubCategory
    nestedChildSubCategory: [NestedChildSubCategory]
    position: Int
  }

  type NestedChildSubCategory {
    id: Int
    description: String
    name: String
    media: String
    banner_media: String
    position: Int
    slug: String
  }

  extend type Query {
    getAllChildSubCategory: [ChildSubCategory!]
    getSingleChildSubCategory(id: Int!): ChildSubCategory
  }

  extend type Mutation {
    addChildSubCategory(description: String, name: String!, media: String!, banner_media: String, category_id: Int!, sub_category_id: Int!, position: Int!): ChildSubCategoryResponse
    updateChildSubCategory(id: Int!, description: String, name: String!, media: String!, banner_media: String, category_id: Int!, sub_category_id: Int!, position: Int): ChildSubCategoryResponse
    deleteChildSubCategory(id: Int!): ChildSubCategory
  }

  type ChildSubCategoryResponse {
    id: Int
    category_id: Int
    sub_category_id: Int
    name: String
    description: String
    media: String
    banner_media: String
  }

  input ChildSubCategoryInput {
    category_id: Int
    sub_category_id: Int
    name: String
    description: String
    media: String
    banner_media: String
  }

  input ChildSubCategoryUpdateInput {
    id: Int
    category_id: Int
    sub_category_id: Int
    name: String
    description: String
    media: String
    banner_media: String
  }
`;
