const { gql } = require("apollo-server-express");

module.exports = gql`
  scalar Upload
  scalar Date
  type SellerPost {
    id: Int
    user_id: Int
    store_id: Int
    created_by: Int
    updated_by: Int
    title: String
    content: String
    image: [String]
    video: [Int]
    published_at: String
    isActive: Boolean
    isDraft: Boolean
    isSchedule: Boolean
    scheduleTime: Boolean
    createdAt: Date
    sellerpostcomment: [Comment]
    sellerpostlike: [Like]
  }

  extend type Query {
    getAllSellerPost(seller_id: Int): [SellerPostResponse]
    getSingleSellerPost(id: Int!): SellerPost
    getPostByStore(store_id: Int): [StorePostResponse]
  }
  extend type Mutation {
    createSellerPost(input: sellerPostInput!): CreateSellerPostResponse!
    updateSellerPost(input: sellerUpdatePostInput!): CreateSellerPostResponse!
    deleteSellerPost(id: Int!): SellerPost
  }

  input attachmentsInput {
    id: Int
    type: String
  }

  input sellerPostInput {
    user_id: Int
    store_id: Int
    created_by: Int
    updated_by: Int
    title: String
    content: String
    attachments: [attachmentsInput]
    image: [Int]
    video: [Int]
    published_at: String
    isActive: Boolean
    isDraft: Boolean
    isSchedule: Boolean
    scheduleTime: String
  }

  input sellerUpdatePostInput {
    id: Int!
    # user_id: Int
    store_id: Int
    created_by: Int
    updated_by: Int
    title: String
    content: String
    image: [Int]
    video: [Int]
    published_at: String
    isActive: Boolean
    isDraft: Boolean
    isSchedule: Boolean
    scheduleTime: String
  }

  type CreateSellerPostResponse {
    id: Int
    user_id: Int
    store_id: Int
    created_by: Int
    updated_by: Int
    title: String
    content: String
    image: [Int]
    video: [Int]
    published_at: String
    isActive: Boolean
    isDraft: Boolean
    isSchedule: Boolean
    scheduleTime: Boolean
  }

  type attachmentResponse {
    id: Int
    url: String
  }

  type SellerPostResponse {
    id: Int
    user_id: Int
    store_id: Int
    seller_id: Int
    created_by: Int
    updated_by: Int
    title: String
    content: String
    medias: [Media]
    published_at: String
    isActive: Boolean
    isDraft: Boolean
    isSchedule: Boolean
    scheduleTime: Boolean
    createdAt: Date
  }

  type StorePostResponse {
    id: Int
    user_id: Int
    store_id: Int
    created_by: Int
    updated_by: Int
    title: String
    content: String
    image: [attachmentResponse]
    video: [attachmentResponse]
    published_at: String
    isActive: Boolean
    isDraft: Boolean
    isSchedule: Boolean
    scheduleTime: Boolean
    createdAt: Date
  }
`;
