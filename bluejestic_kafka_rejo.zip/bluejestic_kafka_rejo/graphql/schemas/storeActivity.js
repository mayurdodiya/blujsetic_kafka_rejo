const { gql } = require("apollo-server-express");

module.exports = gql`
  scalar Date
  type StoreActivity {
    id: Int
    store_id: Int
    user_id: Int
    userType: String
    startDate: Date
    deviceName: String
    endDate: Date
    createdAt: Date
  }

  extend type Mutation {
    addStoreActivity(input: storeActivityInput!): StoreActivityResponse
  }

  extend type Query {
    getAllStoreActivities(store_id: Int!): StoreActivityResponse
    getAllStoreActivityChartData(store_id: Int, start_date: String!, end_date: String!, time_interval: String, time_zone: String): getAllStoreActivityChartDataResponse
    getUserDevicesData(store_id: Int!, start_date: String!, end_date: String!, time_interval: String, time_zone: String): getUserDevicesDataResponse
    storeVisitorsGender(store_id: Int!, start_date: String!, end_date: String!, time_interval: String, time_zone: String): getStoreVisitorsGenderResponse
    visitorsLocation(store_id: Int!, filter: String): getStoreVisitorsGenderResponse
    getAccountReachedChartData(store_id: Int, start_date: String!, end_date: String!, time_interval: String, time_zone: String): getAllStoreActivityChartDataResponse
  }
  type getStoreVisitorsGenderResponse {
    success: Boolean
    message: String
    data: JSON
  }
  type getUserDevicesDataResponse {
    success: Boolean
    message: String
    data: JSON
  }

  type userDeviceData {
    deviceName: String
    percentage: Float
    diffrence: Float
  }
  type getAllStoreActivityChartDataResponse {
    success: Boolean
    message: String
    data: chartDataForStoreActivity
  }
  type chartDataForStoreActivity {
    current_total_user_reached_count: Float
    #previous_revenue: Float
    previous_total_user_reached_count_percentage: Float
    current_data: [[Float]]
    #previous_data: [[Float]]
  }

  input storeActivityInput {
    store_id: Int!
    user_id: Int
    userType: String
    startDate: Date!
    endDate: Date!
    deviceName: String!
  }
  type StoreActivityResponse {
    success: Boolean
    message: String
    data: [StoreActivity]
  }
`;
