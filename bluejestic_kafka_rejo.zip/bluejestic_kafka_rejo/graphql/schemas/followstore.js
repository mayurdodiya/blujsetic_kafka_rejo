const { gql } = require("apollo-server-express");

module.exports = gql`
  scalar Upload
  scalar Date
  type FollowStore {
    id: Int
    store_id: Int
    user_id: Int
    user: User
  }

  extend type Query {
    getAllStoreFollowers(id: Int!): [followersResponse]
    getAllStoreFollowChartData(store_id: Int, start_date: String!, end_date:String!, time_interval: String, time_zone: String): getAllStoreFollowChartDataResponse
    #   getSingleSellerPost(id: Int!): SellerPost
    #   getPostByStore(store_id: Int): [StorePostResponse]
  }
  extend type Mutation {
    followStore(input: followStoreInput!): FollowStore!
    unFollowStore(storeId: Int!): FollowStore!
    # deleteSellerPost(id: Int!): SellerPost
  }
  type getAllStoreFollowChartDataResponse{
    success: Boolean
    message: String
    data: chartDataForStoreFollowers
  }
  type chartDataForStoreFollowers{
    current_total_followers: Float
    #previous_revenue: Float
    previous_total_followers_percentage: Float
    current_data: [[Float]]
    #previous_data: [[Float]]
  }

  type followersResponse {
    id: Int
    firstName: String
    lastName: String
    userName: String
    phoneNumber: String
    gender: String
    bday: String
    jobTitle: String
    profileCoverImage: String
    profileUrl: String
    isActiveForFriendStatus: Boolean
    isFriendForFriendStatus: Boolean
    follower_count: Int
  }

  input followStoreInput {
    store_id: Int!
    user_id: Int
  }
`;
