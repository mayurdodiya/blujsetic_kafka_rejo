const { gql } = require("apollo-server-express");

module.exports = gql`
  type Store {
    id: Int!
    parent_id: Int!
    owner_id: Int!
    category_id: Int!
    title: String!
    description: String!
    city: String!
    state: String!
    country: String!
    total_products: Int!
    sold: Int!
    products: [Product!]
    posts: [Post!]
    following: [Follow!]
    follower: [Follow!]
    about: About!
    notification: [Notification!]
  }

  extend type Mutation {
    addStore(input: StoreInput!): StroreResponse
    updateStore(input: StoreUpdateInput): updateStoreResponse
    createStore(input: CreateStoreInput!): CreateStroreResponse
    updateAdminStore(input: CreateStoreInput!): updateAdminStoreResponse
    removeStore(store_id: [Int]): removeStoreResponse
    updateStoreStatus(store_id: [Int], status: String): updateStoreStatusResponse
    updateStoreCategory(store_id: [Int], category_id: Int, subCategory_id: Int): updateStoreCategoryResponse
    updateStoreDetailForAdmin(input: storeDetailInput): updateStoreDetailForAdminRes
    deleteStore(id: Int!): Store
    deleteStoresByAdmin(store_ids: [Int!]!): deleteStoresByAdminRes
  }

  type deleteStoresByAdminRes {
    success: Boolean
    message: String
  }

  input storeDetailInput {
    store_id: Int!
    is_minimum_purchase_amount: Boolean
    min_amount: Int
    is_flat_rate: Boolean
    flat_rate: Int
    is_internationalShipping: Boolean
    is_FreeShipping: Boolean
    tax_rate_in_percentage: Int
    state_tax_rate_id: Int
    is_applyTaxShipping: Boolean
    is_enableLocationBasedTax: Boolean
    about: String
    owner_name: String
    email: String
    phone: String
    address: String
    zipcode: String
  }

  type updateStoreDetailForAdminRes{
    success: Boolean
    message: String
  }

  type updateStoreCategoryResponse {
    success: Boolean
    message: String
  }

  type updateStoreStatusResponse {
    success: Boolean
    message: String
  }

  type removeStoreResponse {
    success: Boolean
    message: String
  }

  extend type Query {
    getSingleStore(slug: String, storeId: Int): singleStoreResponse
    getStorePosts(page: Int, limit: Int, slug: String): getStorePostsRes
    getStoreByName(name: String!): singleStoreResponse
    getStorePostsMedia(name: String!): [getStorePostsMediResponse]
    #getAllStore: [AllStoreResponse!]
    getStores(page: Int, limit: Int,type: String ,user_id: Int, search: String):getProductStockReportResponse
    getAllStore(page: Int, limit: Int, type: String, user_id: Int, search: String): getProductStockReportResponse
    getAllAdminStore(page: Int, limit: Int, search: String, status: String, category: [Int], subCategory: [Int], order: String): getAllAdminStoreResponse
    getAllStoreWithProducts: [AllStoreProductsResponse!]
    getAllStoresWithElasticSearch(page: Int, limit: Int): getProductStockReportResponse
    getAllPopularStores(page: Int, limit: Int, category: [Int], subCategory: [Int]): getProductStockReportResponse
    getSuggestedStores(page: Int, limit: Int): getProductStockReportResponse
    getFollowStores(page: Int, limit: Int): getProductStockReportResponse
    getStoreFollow(store_id: Int, product_id: Int): getStoreFollowRes
    getStoreSingleLike(store_id: Int): getStoreSingleLikeRes
    getSingleAdminStore(id: Int!): getSingleAdminStoreRes
    getAllStoreLike(store_id: Int): getAllStoreLikeRes
    addClubsIntoElastic(store_id: Int, category_id: Int, subCategory_id: Int): addClubsIntoElasticRes
    addStoresIntoElastic(id: Int): addStoresIntoElasticRes
    cacheStoreData(store_id: Int): getAllStoreLikeRes
    createStoreForShopify(slug: String!): createStoreForShopifyRes
    getStoreFollowers(slug: String!): getStoreFollowersRes
    getStoreSlugList: getStoreSlugListRes
    generateLogFile: generateLogFileRes
    getStoreDetailById(store_id: Int!): getStoreDetailByIdRes
  }

  type generateLogFileRes {
    success: Boolean
  }

  type getStoreDetailByIdRes {
    success: Boolean
    message: String
    data: getStoreDetailByIdDataRes
  }

  type getStoreDetailByIdDataRes {
    id: Int
    store_id: Int
    min_amount: Int
    flat_rate: Int
    is_minimum_purchase_amount: Boolean
    is_flat_rate: Boolean
    is_internationalShipping: Boolean
    is_FreeShipping: Boolean
    tax_rate_in_percentage: Int
    state_tax_rate_id: Int
    is_applyTaxShipping: Boolean
    is_enableLocationBasedTax: Boolean
    about: String
    owner_name: String
    email: String
    phone: String
    address: String
    zipcode: String
  }

  type getStoreFollowersRes {
    success: Boolean
    message: String
    data: [FollowStore!]
    totalFollowers: Int!
  }

  type getStoreSlugListRes {
    success: Boolean
    message: String
    data: [getStoreSlugListResData]
  }

  type getStoreSlugListResData {
    slug: String
  }

  type createStoreForShopifyRes {
    success: Boolean
    message: String
  }

  type addStoresIntoElasticRes {
    success: Boolean
    message: String
  }

  type addClubsIntoElasticRes {
    success: Boolean
    message: String
    data: [addClubsIntoElasticDataRes]
  }

  type addClubsIntoElasticDataRes {
    title: String
    logo_image: String
    state_name: String
    product_count: String
    slug: String
    name: String
    product_images: [String]
    category_id: String
    subCategory_id: String
  }

  type getAllStoreLikeRes {
    success: Boolean
    message: String
    data: [StoreLikeUsers]
  }

  type StoreLikeUsers {
    user: StoreLikeUserRes
  }

  type StoreLikeUserRes {
    id: Int
    firstName: String
    lastName: String
    userName: String
    profileCoverImage: String
    profileUrl: String
    isActiveForFriendStatus: Boolean
    isFriendForFriendStatus: Boolean
  }

  type getStoreSingleLikeRes {
    success: Boolean
    message: String
    isLike: Boolean
  }

  type getSingleAdminStoreRes {
    success: Boolean
    message: String
    data: getSingleAdminStoreDataRes
  }

  type getSingleAdminStoreDataRes {
    title: String
    firstName: String
    lastName: String
    userName: String
    companyLegalName: String
    name: String
    streetAddress: String
    city: String
    country: String
    sellerType: String
    state_name: String
    status: String
    companyEmail: String
    phoneNumber: String
    websiteUrl: String
    longDescription: String
    logo: getSingleAdminStoreLogoRes
    logo_image: String
    banner_image: String
    cover_image: getSingleAdminStoreLogoRes
    slug: String
    category: [storeCategoryResponse]
  }

  type getSingleAdminStoreLogoRes {
    id: Int
    media: String
  }

  input CreateStoreInput {
    id: Int
    title: String
    firstName: String
    lastName: String
    companyLegalName: String
    name: String
    streetAddress: String
    city: String
    state_name: String
    companyEmail: String
    phoneNumber: String
    websiteUrl: String
    longDescription: String
    logo: [Int]
    cover_image: [Int]
    category: [categoryInput]
  }

  input categoryInput {
    category_id: Int
    subCategory_id: Int
  }

  type CreateStroreResponse {
    success: String
    message: String
  }

  type getStoreFollowRes {
    isFollow: Boolean
    isBookmark: Boolean
    bookmark_id: Int
    collection_id: Int
  }

  type getStorePostsMediResponse {
    post_id: Int
    url: [String]
  }

  type singleStoreResponse {
    success: Boolean
    message: String
    data: BusinessInformation
  }

  type getStorePostsRes {
    success: String
    message: String
    data: [Post!]
  }

  type getAllAdminStoreResponse {
    success: Boolean
    message: String
    data: [sellerInfo]
    total: Int
  }

  type sellerInfo {
    id: String
    title: String
    name: String
    firstName: String
    lastName: String
    userName: String
    companyLegalName: String
    phoneNumber: String
    sellerType: String
    companyEmail: String
    websiteUrl: String
    streetAddress: String
    state: String
    city: String
    postalCode: String
    businessType: String
    productType: String
    accountType: String
    logo: String
    logo_image: String
    cover_image: String
    slug: String
    followers_count: Int
    products_count: Int
    category: [storeCategoryResponse]
    status: String
    createdAt: String
    products_sold: Int
  }

  type storeCategoryResponse {
    subCategory_id: Int
    category_id: Int
    sub_category_data: subCategoryDataRes
    category_data: subCategoryDataRes
  }

  type subCategoryDataRes {
    name: String
  }

  type StroreResponse {
    id: Int!
    parent_id: Int!
    owner_id: Int!
    category_id: Int!
    title: String!
    description: String!
    city: String!
    state: String!
    country: String!
    total_products: Int!
    sold: Int!
    products: [Product!]
  }

  type updateStoreResponse {
    success: Boolean
    message: String
  }

  type AllStoreResponse {
    id: Int
    businessInformation: BusinessInformation
  }

  type AllStoreProductsResponse {
    id: Int
    businessInformation: BusinessInformation
    products: [Product!]
    followers: [FollowStore!]
    mutualFriends: [Int]
  }

  input StoreInput {
    parent_id: Int!
    owner_id: Int!
    category_id: Int!
    title: String!
    description: String!
    city: String
    state: String!
    country: String!
    total_products: Int!
    sold: Int!
  }

  input StoreUpdateInput {
    id: Int!
    title: String
    description: String
    city: String
    state: String
    country: String
    logo: [Int]
    cover_image: [Int]
    name: String
  }

  type updateAdminStoreResponse {
    id: Int
    success: String
    message: String
  }

  input UpdateAdminStoreInput {
    id: Int!
    title: String
    firstName: String
    lastName: String
    companyLegalName: String
    phoneNumber: String
    companyEmail: String
    websiteUrl: String
    streetAddress: String
    state: String
    city: String
    postalCode: String
    businessType: String
    productType: String
    accountType: String
    logo: [Int]
    cover_image: [Int]
  }
`;
