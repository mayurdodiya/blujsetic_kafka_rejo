// const { gql } = require("apollo-server-express");

// module.exports = gql`
//   scalar JSON
//   scalar Date

//   extend type Mutation {
//     createLiveStream(input: createLiveStreamInput): createLiveStreamRes
//     joinLiveStream(input: joinLiveStreamInput): joinLiveStreamRes
//     quickLiveStream(input: quickLiveStreamInput): quickLiveStreamRes
//     endLiveStream(uuid: String, time: String): endLiveStreamRes
//   }

//   input quickLiveStreamInput {
//     store_id: Int!
//     user_id: Int!
//   }

//   type quickLiveStreamRes {
//     success: Boolean
//     message: String
//     authToken: String
//     uuid: String
//     store: joinLiveStreamStoreRes
//     user: joinLiveStreamUserRes
//   }

//   extend type Query {
//     getUpcomingLivestreams(store_id: Int!): getUpcomingLivestreamsRes
//   }

//   type joinLiveStreamRes {
//     success: Boolean
//     message: String
//     authToken: String
//     store: joinLiveStreamStoreRes
//     user: joinLiveStreamUserRes
//   }

//   type endLiveStreamRes {
//     success: String
//     message: String
//   }

//   type joinLiveStreamUserRes {
//     name: String
//     profileAvtar: String
//   }

//   type joinLiveStreamStoreRes {
//     name: String
//     logo: String
//   }

//   input joinLiveStreamInput {
//     meeting_id: String
//   }

//   type getUpcomingLivestreamsRes {
//     success: Boolean
//     message: String
//     data: [upcomingLivestreamsResData]
//   }

//   type upcomingLivestreamsResData {
//     meeting_id: String
//     title: String
//     status: String
//     date: String
//     time: String
//     uuid: String
//     final_date: String
//     media: String
//   }

//   input createLiveStreamInput {
//     store_id: Int!
//     user_id: Int!
//     date: String
//     time: String
//     final_date: String
//     media_id: Int!
//     title: String
//   }

//   type createLiveStreamRes {
//     success: Boolean
//     message: String
//   }
// `;
