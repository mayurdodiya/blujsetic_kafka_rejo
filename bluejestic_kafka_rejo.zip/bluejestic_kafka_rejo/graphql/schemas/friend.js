const { gql } = require("apollo-server-express");

module.exports = gql`
  type Friend {
    id: Int!
    friend_id: Int!
    user_id: Int!
    request_id: Int
    isActive: Boolean
    isFriend: Boolean
    user: User
    friend: User
  }

  extend type Query {
    getAllFriend: [Follow!]
    getSingleFriend(id: Int!): Follow
    getFriendRequest(id: Int!): [FriendResponse!]
    checkRequestStatus(user_id: Int, friend_id: Int): [FriendResponse!]
    deleteFriendByUserAndFriendId(user_id: Int, friend_id: Int): DeleteResponse!
    getMyFriends(user_id: Int): [FriendResponse!]
    getMutualFollowing(user_id: Int): getMutualFollowingRes
    getUserFollowers(user_id: Int!): [User!]
    getUserFollowings(user_id: Int!): [User!]
    getSuggestedUsers(user_id: Int): [User]
    getAllPeople(page: Int, limit: Int, type: String, search: String, gender: String): getAllPeopleRes
    getAllAdminUser(page: Int, limit: Int, type: String, order: String, search: String): getAllAdminUserRes
    getUserDetail(slug: String!): getUserDetailRes
  }

  type getUserDetailRes {
    success: String
    message: String
    data: UserResponse
  }

  type getMutualFollowingRes {
    success: String
    message: String
    data: [Friend]
  }

  type getMutualFollowingDataRes {
    id: Int
  }

  type getAllPeopleRes {
    success: String
    message: String
    data: [User!]
    count: Int
  }

  type getAllAdminUserRes {
    success: String
    message: String
    data: [User!]
    total: Int
  }

  extend type Mutation {
    addFriend(input: FriendInput!): FriendResponse!
    updateFriend(input: UpdateFriendInput!): FriendResponse!
    deleteFriend(user_id: Int!, friend_id: Int!): DeleteResponse!
  }

  type FriendResponse {
    id: Int
    friend_id: Int
    user_id: Int
    request_id: Int
    isActive: Boolean
    isFriend: Boolean
    user: User
    friend: User
  }

  type DeleteResponse {
    message: String
  }

  input FriendInput {
    friend_id: Int!
    user_id: Int!
    isActive: Boolean
    isFriend: Boolean
  }

  input UpdateFriendInput {
    id: Int!
    friend_id: Int
    user_id: Int
    request_id: Int
    isActive: Boolean
    isFriend: Boolean
  }
`;
