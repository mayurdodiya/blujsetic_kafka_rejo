const { gql } = require("apollo-server-express");

module.exports = gql`
  scalar Date
  type Order {
    id: Int
    userId: Int
    cardId: Int
    paymentId: String
    productId: [Int]
    quantity: [Int]
    generate_id: String
    total: Int
    orderDate: Date
    isPaymentDone: Boolean
  }
  type OrderItems {
    id: Int
    quantity: Int
    title: String
    price: Int
    image: [String]
    product_price: Int
    basicAmount: Float
    taxAmount: Float
    discountAmount: Float
    totalAmount: Float
    pendingAmount: Float
    globalCharges: Float
    sellerCharges: Float
    sellerFinalAmount: Float
    createdAt: Date
    order_status: String
    order_master_id: Int
    product_id: Int
    paymentStatus: String
    refund_reciept_url: String
    shipment_charges: Float
    tracking_number: String
    shipment_id: String
    label_id: String
    label_url: String
    trackingUrl: String
    order_status_code: String
    user_id: Int
    shipping_id: Int
  }
  extend type Mutation {
    updateOrdersStatus(input: updateOrderStatusInput): customResponse
    createOrders(input: paymentInput!): paymentResponse
    addShippingMethod(input: addShippingInput): addShippingMethodRes
    updateShippingMethod(input: updateShippingInput): addShippingMethodRes
    cancelOrder(order_item_id: Int!): cancelOrderResponse
    writeAUserReviewOnProduct(input: writeAUserReviewOnProductRequest): writeAUserReviewOnProductResponse
    writeAUserFeedbackOnProduct(input: writeAUserFeedbackOnProductRequest): writeAUserFeedbackOnProductResponse
    taxCalculation(city: String, State: String, zipcode: String!): taxCalculationRes
  }

  input writeAUserFeedbackOnProductRequest {
    order_items_id: Int
    overAllRating: Float
    isUserRecommendedThisSeller: Boolean
    communicationRating: Float
    shippingRating: Float
    itemAccuracyRating: Float
    feedback: String!
  }

  type writeAUserFeedbackOnProductResponse {
    success: String
    message: String
  }

  type taxCalculationRes {
    success: String
    message: String
    data: taxCalculationResData
  }

  type taxCalculationResData {
    zip_code: String
    total_rate: String
    state_rate: String
    city_rate: String
    county_rate: String
    additional_rate: String
  }

  input writeAUserReviewOnProductRequest {
    order_items_id: Int
    overAllRating: Float
    title: String!
    details: String!
    reviewMedias: [reviewMediasData]
  }

  input reviewMediasData {
    media_type: String
    url: String
  }

  type writeAUserReviewOnProductResponse {
    success: Boolean
    message: String
  }

  type getShippingMethodRes {
    success: Boolean
    message: String
    data: [getShippingMethodData]
  }

  type getShippingMethodData {
    id: Int
    delivery_options_type: String
    name: String
    zipcode: String
    processing_time: String
    processing_time_type: String
    threshold: Float
    seller_id: Int
    is_free_delivery: Boolean
    is_free_international_delivery: Boolean
    handling_fee: Int
    is_active: Boolean
    service_code: [String]
    is_deleted: Boolean
    fixed_delivery_options: [FixedDeliveryOptionsResForResponse]
  }

  type FixedDeliveryOptionsResForResponse {
    delivery_service: String
    country: String
    is_free_delivery: Boolean
    one_item: Float
    additional_item: Float
  }

  type addShippingMethodRes {
    success: Boolean
    message: String
  }

  input addShippingInput {
    store_id: Int
    name: String
    zipcode: String
    processing_time: String
    processing_time_type: String
    is_free_delivery: Boolean
    is_free_international_delivery: Boolean
    handling_fee: Int
    is_active: Boolean
    is_deleted: Boolean
    delivery_options_type: String
    delivery_service_id: [deliveryServiceIdRes]
    service_code: [String]
    fixed_delivery_options: [FixedDeliveryOptionsResForInput]
  }

  input FixedDeliveryOptionsResForInput {
    delivery_service: String
    country: String
    is_free_delivery: Boolean
    one_item: Float
    additional_item: Float
  }

  input updateShippingInput {
    store_id: Int
    id: Int
    name: String
    zipcode: String
    processing_time: String
    processing_time_type: String
    is_free_delivery: Boolean
    is_free_international_delivery: Boolean
    handling_fee: Int
    is_active: Boolean
    is_deleted: Boolean
    delivery_options_type: String
    delivery_service_id: [deliveryServiceIdRes]
    service_code: [String]
    fixed_delivery_options: [FixedDeliveryOptionsResForInput]
  }

  input deliveryServiceIdRes {
    id: Int
    is_active: Boolean
  }

  input productDetailInput {
    product_data: [productDataInput]
  }

  input productDataInput {
    product_id: Int
    quantity: Int
    variant_id: Int
    store_id: Int
  }

  type rateEstimateResponse {
    success: Boolean
    message: String
    data: [rateEstimateResponseData]
  }

  type rateEstimateResponseData {
    shipping_amount: shippingAmountData
    carrier_delivery_days: String
    estimated_delivery_date: String
    rate_details: [rateDetailsData]
    service_type: String
  }

  type rateDetailsData {
    rate_detail_type: String
    carrier_description: String
    carrier_billing_code: String
    amount: rateDetailsDataAmount
  }

  type rateDetailsDataAmount {
    currency: String
    amount: Int
  }

  type shippingAmountData {
    amount: Float
  }

  type cancelOrderResponse {
    success: Boolean
    message: String
  }

  type customResponse {
    success: Boolean
    message: String
    data: String
  }
  input updateOrderStatusInput {
    order_id: Int
    order_status: String
  }
  extend type Query {
    getAllOrders(store_id: Int, startDate: String, endDate: String, order_status: [String], search: String, order: String, page: Int, limit: Int, slug: String, isBuyAgainOrder: Boolean): [getAllOrdersRes]
    getShipDetail(input: getShipDetailInput!): [getShipDetailRes]
    getOrderForAdmin(slug: String, search: String, order: String, page: Int!, limit: Int!, order_status: String, order_item_id: Int): getOrderForAdminRes
    getSingleOrder(order_master_id: Int, order_item_id: Int, user_id: Int): getSingleOrderRes
    getSingleOrderForAdmin(order_item_id: Int!): getSingleOrderForAdminRes
    getDateWiseOrderRevenue(store_id: Int, start_date: String!, end_date: String!, time_interval: String, time_zone: String): getDateWiseOrderRevenue
    getAverageOrderValueAndOrdersMetrtics(store_id: Int, start_date: String!, end_date: String!, time_interval: String, time_zone: String): getAverageOrderValueAndOrdersMetrticsResponse
    getDateWiseOrderEarnings(store_id: Int, start_date: String!, end_date: String!, time_interval: String, time_zone: String): getDateWiseOrderRevenue
    getAllOrdersDataWithCustomerDetails(store_id: Int, user_id: Int): getAllOrdersDataWithCustomerDetailsResponse
    getAllOrdersHistory(user_id: Int, store_id: Int!, start_date: String!, end_date: String!, time_interval: String, time_zone: String): getAllOrdersHistoryResponse
    getAllUsersOrdersDetails(status: String): GlobalResponse
    getAllSellerOrderDetails: getAllSellerOrderDetailsResponse
    getOrderCustomerActivity(store_id: Int!, start_date: String!, end_date: String!, time_interval: String, time_zone: String): getOrderCustomerActivityResponse
    getRepeatCustomers(store_id: Int, start_date: String!, end_date: String!, time_interval: String, time_zone: String): GlobalResponse
    getOrderDetails(id: Int): getOrderDetailsResponse
    getOrderMetrics(store_id: Int!): getOrderMetrics
    storeCustomersGender(store_id: Int!, start_date: String!, end_date: String!, time_interval: String, time_zone: String): getStoreVisitorsGenderResponse
    storeCustomersAgeRatio(store_id: Int!, start_date: String!, end_date: String!, time_interval: String, time_zone: String): GlobalResponse
    storeCustomersAgeBarChart(store_id: Int!, start_date: String!, end_date: String!, time_interval: String, time_zone: String): GlobalResponse
    getCustomerAnalyticsChart(store_id: Int!, start_date: String!, end_date: String!, time_interval: String, time_zone: String): GlobalResponse
    customersLocation(store_id: Int!, filter: String): GlobalResponse
    customersLocationBySales(store_id: Int, filter: String): GlobalResponse
    customersCategoryBySales(store_id: Int!, filter: String): GlobalResponse
    getUserOrderAnalysis(user_id: Int!, start_date: String!, end_date: String!, time_interval: String, time_zone: String): getUserOrderAnalysisRes
    getUserOrderCountStats: getUserOrderCountStatsRes
    getOrderCategorySummary(input: getOrderCategorySummaryRequest): getOrderCategorySummaryRes
    getRateEstimate(input: productDetailInput): rateEstimateResponse
    getUSPSServices: getUSPSServicesRes
    getShippingMethod(store_id: Int): getShippingMethodRes
    getDeliveryServicesForFixedType: getDeliveryServicesForFixedTypeRes
  }

  input getOrderCategorySummaryRequest {
    startDate: String
    endDate: String
  }

  type getDeliveryServicesForFixedTypeRes {
    success: Boolean
    message: String
    data: [getDeliveryServicesForFixedTypeResData]
  }

  type getDeliveryServicesForFixedTypeResData {
    carrier_id: String
    carrier_code: String
    service_code: String
    name: String
    domestic: Boolean
    international: Boolean
    is_multi_package_supported: Boolean
  }

  type getUSPSServicesRes {
    success: Boolean
    message: String
    data: [getUSPSServicesResData]
  }

  type getUSPSServicesResData {
    carrier_id: String
    carrier_code: String
    name: String
    service_code: String
    is_domestic: Boolean
    is_international: Boolean
    is_multi_package_supported: Boolean
    days: String
  }

  type getShipDetailRes {
    success: Boolean
    message: String
    isShopifyProduct: Boolean
    is_free_delivery: Boolean
    ship_charge: Float
    product_id: Int
    data: [getShipDetailDataRes]
  }

  input getShipDetailInput {
    products: [paymentInputProductRes]!
  }

  type getShipDetailDataRes {
    #store_id: Int
    #store_name: String
    #totalAmount: Int
    #ship_charge: Float
    rate_details: [rateDetailsRes]
    delivery_days: Int
    estimated_delivery_date: String
    ship_date: String
    service_type: String
    service_code: String
    carrier_code: String
    carrier_friendly_name: String
  }

  type rateDetailsRes {
    amount: rateDetailsResAmount
  }

  type rateDetailsResAmount {
    currency: String
    amount: Float
  }

  type getSingleOrderForAdminRes {
    success: Boolean
    message: String
    data: getAllOrdersRes
  }

  type getOrderForAdminRes {
    success: Boolean
    message: String
    data: [getAllOrdersRes]
    total: Int
  }

  type getOrderCategorySummaryRes {
    success: Boolean
    message: String
    data: getOrderCategorySummaryDataRes
  }

  type getSingleOrderRes {
    success: Boolean
    message: String
    data: getSingleOrderDataRes
  }

  type getSingleOrderDataRes {
    id: Int
    order_id: String
    user_id: Int
    shipping_id: Int
    card_id: Int
    paymentId: String
    orderDate: Date
    totalAmount: Float
    totalTaxAmount: Float
    totalBasicAmount: Float
    pendingAmount: Float
    order_status: String
    isActive: Boolean
    isPaymentDone: Boolean
    createdAt: Date
    updatedAt: Date
    shipping_detail: addressResponseOfOrder
    orderItems: [orderItems]
  }

  type orderItems {
    id: Int
    order_master_id: Int
    product_id: Int
    createdAt: Date
    seller_id: Int
    store_id: Int
    quantity: Int
    product_price: String
    basicAmount: String
    taxAmount: String
    discountAmount: String
    shipping_data: addressResponseOfOrder
    shipment_charges: String
    totalAmount: String
    pendingAmount: String
    tracking_number: String
    shipment_id: String
    label_id: String
    label_url: String
    trackingUrl: String
    globalCharges: String
    sellerCharges: String
    sellerFinalAmount: String
    user_id: Int
    shipping_id: Int
    order_status_code: String
    order_status: String
    paymentStatus: String
    refund_reciept_url: String
    variant_id: Int
    product: productsResponse
  }

  type getOrderCategorySummaryDataRes {
    jewellery: jewelleryRes
    cloth: clothRes
    shoes: shoesRes
  }

  type jewelleryRes {
    jewellerySum: Float
    jewellery_percentage: Float
  }

  type clothRes {
    clothSum: Float
    cloth_percentage: Float
  }

  type shoesRes {
    shoesSum: Float
    shoes_percentage: Float
  }

  type getUserOrderCountStatsRes {
    success: Boolean
    message: String
    data: getUserOrderCountStatsDataRes
  }

  type getUserOrderCountStatsDataRes {
    todayOrders: Float
    percentageChangeInTodayOrders: Float
    totalOrders: Float
    percentageChangeInTotalOrders: Float
    pendingOrders: Float
    percentageChangeInPendingOrders: Float
    completedOrders: Float
    percentageChangeInCompletedOrders: Float
  }

  type getUserOrderAnalysisRes {
    success: Boolean
    message: String
    data: getUserOrderAnalysisDateRes
  }

  type getUserOrderAnalysisDateRes {
    current_revenue: Float
    previous_revenue: Float
    previous_revenue_percentage: Float
    current_data: [[Float]]
    previous_data: [[Float]]
  }

  type getOrderCustomerActivityResponse {
    success: Boolean
    message: String
    data: JSON
  }
  type getOrderDetailsResponse {
    success: Boolean
    message: String
    data: orderHistory
  }
  type getAllUsersOrdersDetailsResponse {
    success: Boolean
    message: String
    data: [OrderItems]
  }
  type getAllOrdersHistoryResponse {
    success: Boolean
    message: String
    data: [orderHistory]
  }

  type getAllSellerOrderDetailsResponse {
    success: Boolean
    message: String
    data: [orderData]
  }

  type orderData {
    customer: customerResponse
    product: productResponse
    order_detail: orderDetailResponse
  }

  type customerResponse {
    firstName: String
    lastName: String
    userName: String
    profileAvtar: String
  }

  type productResponse {
    title: String
    image: String
  }

  type orderDetailResponse {
    generate_id: String
    id: Int
    quantity: Int
    orderDate: String 
    totalAmount: Int
    order_status: String
  }

  input paymentInput {
    products: [paymentInputProductRes]
    payment_id: String!
    isBuyAgainOrder: Boolean
    tax_amount: Float
  }

  input paymentInputProductRes {
    productId: Int
    quantity: Int
    store_id: Int
    variant_id: Int
    service_code: String
    delivery_estimate: String
    delivery_estimate_day: Int
  }

  type orderHistory {
    customer: customerDetails
    product: Product
    shipping_address: addressResponseOfOrder
    card_details: card_details_response
    id: Int
    order_id: Int
    product_id: Int
    store_id: Int
    quantity: Int
    order_status: String
    paymentStatus: String
    tracking_number: Int
    generate_id: String
    price: Int
    total: Int
    user_id: Int
    createdAt: Date
  }
  type card_details_response {
    card_number: String
    expiry_date: String
    cvv: String
  }

  type getAllOrdersDataWithCustomerDetailsResponse {
    success: Boolean
    message: String
    data: [orderWithCustomers]
  }
  type orderWithCustomers {
    total_orders: Int
    total_spent: Float
    customer: customerDetails
    productId: [Int]
  }
  type productDetailsForCustomers {
    product_id: Int
    total_spent: Float
    total_products: Int
    total_quantity: Int
  }
  type customerDetails {
    id: Int
    firstName: String
    lastName: String
    userName: String
    logo_image: String
    banner_image: String
    email: String
    phone: String
    mobile: String
    shipping_address: addressResponseOfOrder
    address: String
    state: String
    city: String
    country: String
    products: [productDetailsForCustomers]
  }
  type getAverageOrderValueAndOrdersMetrticsResponse {
    success: Boolean
    message: String
    data: ordersMetricsDetailsResponse
  }
  type ordersMetricsDetailsResponse {
    current_data: current_data
    previous_data: previous_data
    previous_revenue_percentage: Float
    previous_orders_percentage: Float
    previous_average_order_value_percentage: Float
  }
  type current_data {
    average_order_value: Float
    orders: Int
    revenue: Float
  }
  type previous_data {
    average_order_value: Float
    orders: Int
    revenue: Float
  }
  type getDateWiseOrderRevenue {
    success: Boolean
    message: String
    data: dateWiseOrderRevenueDataResponse
  }
  type dateWiseOrderRevenueDataResponse {
    current_revenue: Float
    previous_revenue: Float
    previous_revenue_percentage: Float
    current_data: [[Float]]
    previous_data: [[Float]]
  }
  type getOrderMetrics {
    success: Boolean
    message: String
    data: OrderMetrics
  }
  type OrderMetrics {
    pending_orders: Int
    shipped_orders: Int
    dispatched_orders: Int
    new_orders: Int
    pending_shipment_orders: Int
    total_orders: Int
  }
  type addressResponseOfOrder {
    streetAddress: String
    city: String
    state: String
    country: String
    zipcode: String
    buildingName: String
  }
  type productResponseOfOrder {
    title: String
    image: [String]
    quantity: Int
    price: Int
  }
  type OrderResponse {
    id: Int
    generate_id: String
    shipping: addressResponseOfOrder
    product: [productResponseOfOrder]
    total: Int
    quantity: [Int]
    createdAt: Date
  }
  type getAllOrdersRes {
    id: Int
    order_master_id: Int
    product_id: Int
    createdAt: Date
    updatedAt: Date
    seller_id: Int
    store_id: Int
    quantity: Int
    product_price: String
    basicAmount: String
    taxAmount: String
    discountAmount: String
    shipment_charges: String
    totalAmount: String
    pendingAmount: String
    tracking_number: String
    shipment_id: String
    label_id: String
    label_url: String
    trackingUrl: String
    globalCharges: String
    sellerCharges: String
    sellerFinalAmount: String
    user_id: Int
    customer: User
    shipping_id: Int
    order_status_code: String
    order_status: String
    paymentStatus: String
    refund_reciept_url: String
    variant_id: Int
    store_details: BusinessInformation
    orderMaster: orderMasterRes
    product: productsResponse
    shipping_data: addressResponseOfOrder
    isBuyAgainOrder: Boolean
  }

  type orderMasterRes {
    id: Int
    order_id: String
    user_id: Int
    shipping_id: Int
    card_id: Int
    paymentId: String
    orderDate: String
    totalAmount: Float
    totalTaxAmount: Float
    totalBasicAmount: Float
    pendingAmount: Float
    order_status: String
    isActive: Boolean
    isPaymentDone: Boolean
    shipping_detail: addressResponseOfOrder
  }
`;
