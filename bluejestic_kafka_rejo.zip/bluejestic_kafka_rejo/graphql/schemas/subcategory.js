const { gql } = require("apollo-server-express");

module.exports = gql`
  type SubCategory {
    id: Int
    category_id: Int
    name: String
    description: String
    media: String
    banner_media: String
    mainCategory: Category
    position: Int
    slug: String
    childSubCategory: [ChildSubCategory]
  }

  extend type Query {
    getAllSubCategory: [SubCategory!]
    getSingleSubCategory(id: Int!): SubCategory
  }

  extend type Mutation {
    addSubCategory(description: String, name: String!, media: String!, banner_media: String, category_id: Int!, position: Int!): SubCategoryResponse
    updateSubCategory(id: Int!, description: String, name: String!, media: String!, banner_media: String, category_id: Int, position: Int): SubCategoryResponse
    deleteSubCategory(id: Int!): SubCategory
  }

  type SubCategoryResponse {
    id: Int
    category_id: Int
    name: String
    description: String
    media: String
    banner_media: String
  }

  input SubCategoryInput {
    category_id: Int
    name: String
    description: String
    media: String
    banner_media: String
  }

  input SubCategoryUpdateInput {
    id: Int!
    category_id: Int
    name: String
    description: String
    media: String
    banner_media: String
  }
`;
