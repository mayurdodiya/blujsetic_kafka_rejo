const { gql } = require("apollo-server-express");

module.exports = gql`
  scalar JSON
  scalar Date
  type Product {
    id: Int
    slug: String
    share_post_id: Int
    bookmark_id: Int
    store_id: Int
    status: String
    # category_id: Int
    productId: Int
    cartId: Int
    qty: Int
    delivery_id: Int
    color_id: Int
    size_id: Int
    title: String
    description: String
    price: Int
    isBookMarked: Boolean
    isFeature: Boolean
    isActive: Boolean
    quantity: Int
    listPrice: Int
    sku: String
    createdAt: Date
    shipping: Shipping
    productSEO: ProductSEO
    productComments: [Comment]
    comment_count: Int
    productLikes: [Like]
    image: [String]
    bookmark: BookmarkProduct
    dis_price: String
    dis_listPrice: String
    video: [String]
    colors: [Color]
    Size: [Size]
    ratings: [Rating]
    categories: [Category]
    category_id: String
    subCategory_id: String
    childSubCategory_id: String
    store: BusinessInformation
    filterImage: [String]
    metaTitle: String
    keywords: String
    metaDescription: String
    isVisible: Boolean
    isFreeShipping: Boolean
    condition: String
    tags: [String]
    shareCount: Int
    ratio: String
    size: sizeData
    cropImages: [cropImageResponse]
    images: [String]
    stock_status: String
    current_stock_status: String
    like_count: Int
  }

  type BookmarkProduct {
    product_id: Int
    id: Int
    collection_id: Int
    collection: BookmarkProductCollectionRes
  }

  type BookmarkProductCollectionRes {
    id: Int
    name: String
    user_id: Int
    slug: String
    isPrivate: Boolean
  }

  extend type Mutation {
    createProduct(input: ProductInput): createProductResponse
    updateProduct(input: ProductInput): createProductResponse
    assignProduct(store_id: Int!, product_id: [Int!]): assignProductRes
    updateBulkProduct(input: BulkInput): updateBulkProductRes
    updateBulkProductSeller(input: updateBulkProductSellerInput): updateBulkProductSellerRes
    removeBulkProduct(input: removeBulkProductInput): removeBulkProductRes
    updateBulkProductStatus(
      input: updateBulkProductStatusInput
    ): updateBulkProductStatusRes
    postProductForRecommendation(
      product_id: Int!
      title: String
      product_category_id: Int
      category_name: String
      subcategory_name: String
      childsubcategory_name: String
    ): postProductForRecommendationRes
    deleteProduct(id: Int): Product
    updateBulkProductStatusCategory(input: updateBulkProductStatusCategoryReq): updateBulkProductStatusCategoryRes
  }

  input updateBulkProductStatusCategoryReq {
    product_ids: [Int!]!
    status: String
    category_id: Int
    sub_category_id: Int
    child_sub_category_id: Int
  }

  type updateBulkProductStatusCategoryRes {
    success: Boolean
    message: String
  }
  
  type postProductForRecommendationRes {
    success: Boolean
    message: String
  }

  input updateBulkProductSellerInput{
    product_id: [Int]!
    category_id: Int!
    subCategory_id: Int!
    childSubCategory_id: Int!
    status: String!
    shipping_method_id: Int!
  }

  type updateBulkProductSellerRes{
    success: Boolean
    message: String
  }

  input updateBulkProductStatusInput {
    product_id: [Int]
    status: String
  }
  type updateBulkProductStatusRes {
    success: Boolean
    message: String
  }

  input removeBulkProductInput {
    product_id: [Int!]!
  }
  type removeBulkProductRes {
    success: Boolean
    message: String
  }

  input object {
    store_id: Int
  }

  input BulkInput {
    products: [BulkProductsInput]
  }

  input BulkProductsInput {
    id: Int
    images: [BulkProductsImageInput]
    status: String
    store_id: Int
    category: [BulkProductsCategoryInput]
    attributes: [BulkProductsAttributesInput]
  }

  input BulkProductsAttributesInput {
    id: Int
    name: String
    value: String
  }

  input BulkProductsImageInput {
    media_id: Int
    position: Int
  }

  input BulkProductsCategoryInput {
    category_id: Int
    subCategory_id: Int
    childSubCategory_id: Int
  }

  type updateBulkProductRes {
    success: Boolean
    message: String
  }

  extend type Query {
    getSingleProduct(slug: String!): productsResponse
    getAllProducts(
      start: Int
      limit: Int
      page: Int
      sort: String
      where: JSON
      category: String
      childSubCategory: String
      subCategory: String
      isShopifyProduct: Boolean
      store_id: Int
      order: String
      imagelimit: Int
      minPrice: Int
      maxPrice: Int
    ): getAllProductsRes
    getAllProductByLike(limit: Int, page: Int): getAllProductsRes
    getProductImages(product_id: Int!): getProductImagesRes
    getAllProductByStore(
      store_id: Int
      page: Int!
      limit: Int!
      isUnassigned: Boolean
      search: String
      category: [Int]
      subCategory: [Int]
      childSubCategory: [Int]
      status: String
      order: String
      minPrice: Int
      maxPrice: Int
    ): getAllProductByStoreRes
    getSingleProductById(id: Int!): productsResponse
    searchProducts(
      start: Int
      ligetTopSellingProductsmit: Int
      sort: String
      search: String
      where: JSON
      category: String
    ): [getAllProductResponse]
    getFeatureProduct(store_id: Int!): [getAllProductResponse]
    getAllProductsByIds(input: inputOfProduct): getAllProductsByIds
    getProductMetrics(store_id: Int): getProductMetrics
    getOrderSales: getOrderSalesRes
    getTopSellingProducts(store_id: Int): getTopSellingProducts
    getProductSoldAndShipped(
      store_id: Int!
      start_date: String!
      end_date: String!
      time_interval: String
      time_zone: String
    ): getProductMetrics
    getAllSaveProductMetrics(
      store_id: Int!
      start_date: String!
      end_date: String!
      time_interval: String
      time_zone: String
    ): GlobalResponse
    getAllShareProductMetrics(
      store_id: Int!
      start_date: String!
      end_date: String!
      time_interval: String
      time_zone: String
    ): GlobalResponse
    getProductSingleLike(slug: String!): getProductSingleLikeResponse
    getProductTraction(
      product_id: Int!
      start_date: String!
      end_date: String!
      time_interval: String
      time_zone: String
    ): getProductTractionResponse
    getProductStockReport(
      store_id: Int
      stock_status: String
    ): productsStockResponse
    searchProductsWithElasticSearch(
      search: String
      page: Int
      limit: Int
      minPrice: Int
      maxPrice: Int
    ): getProductStockReportResponse
    globalSearchWithElasticSearch(
      search: String
      page: Int
      limit: Int
    ): getProductStockReportResponse
    addProductCall(store_id: Int!): addProductCallRes
    getAllProductByCategory(
      category_id: Int
      subCategory_id: Int
      childSubCategory_id: [[Int]]
      limit: Int
      page: Int
    ): getAllProductByCategoryRes
    getLikeByProduct(product_id: Int!): getLikeByProductRes
    verifyProduct(slug: String!): verifyProductRes
    getProductRecommendation(type: String): getProductRecommendationRes
    getMinMaxAvgPriceOfProducts(
      input: getMinMaxAvgPriceOfProductsInput
    ): getMinMaxAvgPriceOfProductsRes

    getAllProductsOfSeller: productsAnalyticsResponse!  
    getProductReviewsBySlug(input: getProductReviewsBySlugRequest): getProductReviewsBySlugResponse
  }

  input getProductReviewsBySlugRequest {
    slug: String!
    rating: Int
    order: String
  }

  type getProductReviewsBySlugResponse {
    success: Boolean
    message: String
    data: productsResponse
  }

  type productsAnalyticsResponse {
    message: String!
    success: Boolean!
    data: productsAnalyticsDataResponse!
  }

  type productsAnalyticsDataResponse {  
    totalProducts: Int
    percentageChangeInTotalProducts: Float
    productsRevenue: Float
    percentageChangeInProductsRevenue: Float
    topSelling: Int
    percentageChangeInTopSellingProducts: Float
    totalActiveProducts: Float
    outOfStock: Float
  }

  input getMinMaxAvgPriceOfProductsInput {
    store_slug: String
    category: String
    subCategory: String
    childSubCategory: String
  }

  type getMinMaxAvgPriceOfProductsRes {
    success: Boolean
    message: String
    data: getMinMaxAvgPriceOfProductsResData
  }

  type getMinMaxAvgPriceOfProductsResData {
    minPrice: Int
    maxPrice: Int
    avgPrice: Float
  }

  type getOrderSalesRes {
    success: Boolean
    message: String
    data: getOrderSalesDataRes
  }

  type getOrderSalesDataRes {
    total_sales: Float
    total_sales_diff_pct: Float
    total_orders: Float
    total_orders_diff_pct: Float
    total_customers: Float
    total_customers_diff_pct: Float
    avg_order: Float
    avg_order_diff_pct: Float
  }

  type getProductRecommendationRes {
    success: Boolean
    message: String
    data: [productsResponse]
    total: Int
  }

  type getProductSingleLikeResponse {
    success: Boolean
    message: String
    isLike: Boolean
    like_id: Int
  }

  type getLikeByProductRes {
    success: Boolean
    message: String
    data: getLikeByProductDataRes
  }

  type getLikeByProductDataRes {
    like_id: Int
  }

  type getProductImagesRes {
    success: Boolean
    message: String
    data: productsResponse
  }

  type verifyProductRes {
    success: Boolean
    message: String
  }

  type getAllProductsRes {
    success: Boolean
    message: String
    data: [productsResponse]
    total: Int
  }

  type getAllProductByCategoryRes {
    success: Boolean
    message: String
    data: [getAllProductByCategoryDataRes]
  }

  type getAllProductByCategoryDataRes {
    products: [getAllProductByCatDataRes]
    total_count: Int
  }

  type getAllProductByCatDataRes {
    product_data: productsResponse
    childSubCategory: childSubCategoryRes
  }

  type childSubCategoryRes {
    id: Int
    name: String
    media: String
    banner_media: String
  }

  type getProductTractionResponse {
    success: Boolean
    message: String
    data: [[Int]]
  }

  type assignProductRes {
    success: Boolean
    message: String
  }

  type getAllProductByStoreRes {
    success: Boolean
    message: String
    data: [productsResponse]
    total: Int
  }

  type addProductCallRes {
    id: Int
  }

  type productsStockResponse {
    success: Boolean
    message: String
    data: [Product]
  }
  type getProductStockReportResponse {
    success: Boolean
    message: String
    data: searchProductsWithElasticSearchResponse
  }
  type searchProductsWithElasticSearchResponse {
    products: [Product]
    total: Int
    stores: [storeSearchResponse]
    users: [UserSearchResponse]
    groups: [groupResponseForSearch]
    count: Int
  }
  type storeSearchResponse {
    id: Int
    name: String
    logo: String
    logo_image: String
    banner_image: String
    slug: String
    cover_image: String
    followers_count: Int
    products_count: Int
    product_count: Int
    like_count: Int
    total_visitors: Int
    like: StoreLikeRes
    past_visitors: Float
    isFollow: Boolean
    isLike: Boolean
    products: [Product]
    product_images: [String]
  }

  type StoreLikeRes {
    id: Int
  }

  type UserSearchResponse {
    id: Int
    firstName: String
    lastName: String
    userName: String
    #profileAvtar: String
    #profileCoverImage: String
    logo_image: String
    banner_image: String
    jobTitle: String
    isFollow: Boolean
    followers_count: Int
  }
  type getProductMetrics {
    success: Boolean
    message: String
    data: ProductMetrics
  }
  type getTopSellingProducts {
    success: Boolean
    message: String
    data: [topSellingProductsResponse]
  }
  type topSellingProductsResponse {
    product_id: Int
    total_orders: Int
    revenue: Float
    past_revenue: Float
    past_revenue_diff: Float
    past_revenue_diff_percentage: Float
    order_details: order_details_reponse
  }
  type order_details_reponse {
    order_id: Int
    product_id: Int
    price: Int
    quantity: Int
    createdAt: Date
    generate_id: String
    isPaymentDone: Boolean
    product_info: Product
  }
  type ProductMetrics {
    store_inventory: store_inventory
    store_overview: store_overview
    store_activity: store_activity
  }
  type store_inventory {
    total_products: Int
    total_products_diff: Int
    out_of_stock_products: Int
    in_stock_products: Int
    low_stock_products: Int
    out_of_stock_products_percentage: String
    low_stock_products_percentage: String
    in_stock_products_percentage: String
  }
  type store_overview {
    total_active_products: Int
    total_active_products_diff: Int
    total_sold_products: Int
    total_sold_products_diff: Int
    total_shipped_products: Int
    total_shipped_products_diff: Int
    total_customers: Int
    total_customers_diff: Int
    total_sold_orders_diff_percentage: Float
    total_shipped_products_diff_percentage: Float
    total_customers_diff_percentage: Float
  }
  type store_activity {
    new_orders: Int
    pending_shipments: Int
    out_of_stock_products: Int
  }

  input productDetail {
    productId: Int!
    quantity: Int!
  }

  input inputOfProduct {
    products: [productDetail]
  }
  type imagesResponse {
    id: String
    url: String
  }
  type all_carts {
    id: Int
    qty: Int
    storeDetail: BusinessInformation
    product: [Product]
  }

  type AllCartResponses {
    carts: [all_carts]
    count: Int
  }
  type getAllProductsByIds {
    success: Boolean
    message: String
    data: [AllCartResponses]
  }

  type getProduct {
    # Response
    id: Int
    store_id: Int
    # category_id: Int
    delivery_id: Int
    color_id: Int
    size_id: Int
    title: String
    description: String
    price: Int
    isFeature: Boolean
    isActive: Boolean
    quantity: Int
    listPrice: Int
    sku: String
    createdAt: Date
    productSEO: ProductSEO
    comment_count: Int
    productComments: [Comment]
    productLikes: [Like]
    image: [imagesResponse]
    video: [imagesResponse]
    ratings: [Rating]
    category_id: String
    subCategory_id: String
    childSubCategory_id: String
    store: BusinessInformation
    filterImage: [String]
    metaTitle: String
    keywords: String
    metaDescription: String
    isVisible: Boolean
    isFreeShipping: Boolean
    condition: String
    tags: [String]
    categories: [ProductCategories]
    attributes: [attributes]
    colors: [Color]
    sizes: [Size]
    other: [other]
    shipping: productShipping
    cropImages: [cropImageResponse]
    ratio: String
    size: sizeData
  }

  type getAllProductResponse {
    id: Int
    store_id: Int
    # category_id: Int
    delivery_id: Int
    color_id: Int
    size_id: Int
    title: String
    description: String
    price: Int
    isFeature: Boolean
    isActive: Boolean
    quantity: Int
    listPrice: Int
    sku: String
    createdAt: Date
    productSEO: ProductSEO
    productComments: [Comment]
    image: [String]
    video: [String]
    ratings: [Rating]
    category_id: String
    subCategory_id: String
    childSubCategory_id: String
    store: BusinessInformation
    filterImage: [String]
    metaTitle: String
    keywords: String
    metaDescription: String
    isVisible: Boolean
    isFreeShipping: Boolean
    condition: String
    tags: [String]
    categories: [ProductCategories]
    attributes: [attributes]
    colors: [Color]
    sizes: [Size]
    other: [other]
    shipping: productShipping
    shareCount: Int
    productLikes: [Like]
    cropImages: [cropImageResponse]
    ratio: String
    size: sizeData
    likeStatus: Boolean
  }

  type UserReviewsOnProducts {
    id: Int
    product_id: Int
    user_id: Int
    seller_id: Int
    order_items_id: Int
    order_master_id: Int
    store_id: Int
    overAllRating: Int
    title: String
    details: String
    createdAt: String
    updatedAt: String
    user_details: User
    userReviewsOnProductsMedias: [UserReviewsOnProductsMedias]
  }

  type UserReviewsOnProductsMedias {
    id: Int
    userReviewsOnProductsId: Int
    position: Int
    media_type: String
    media_for: String
    url: String
    createdAt: String
    updatedAt: String
  }

  type UserFeedbacksOnProducts {
    id: Int
    product_id: Int
    user_id: Int
    seller_id: Int
    order_items_id: Int
    order_master_id: Int
    user_details: User
    store_id: Int
    overAllRating: Int
    isUserRecommendedThisSeller: Boolean
    communicationRating: Int
    shippingRating: Int
    itemAccuracyRating: Int
    feedback: String
    createdAt: String
    updatedAt: String
  }

  type productsResponse {
    id: Int
    userReviews: [UserReviewsOnProducts]
    userFeedbacks: [UserFeedbacksOnProducts]
    store_id: Int
    slug: String
    title: String
    likeCount: Int
    status: String
    dis_price: String
    dis_listPrice: String
    brand_id: Int
    like_count: String
    comment_count: String
    sharepost_count: String
    total_variants: String
    total_variants_inventory_quantity: String
    total_inventory_quantity: String
    total_sold: String
    description: String
    isFeature: Boolean
    isActive: Boolean
    metaTitle: String
    keywords: String
    metaDescription: String
    isVisible: Boolean
    isFreeShipping: Boolean
    bookmark: BookmarkProduct
    condition: String
    is_deleted: Boolean
    variants: [variantsRes]
    variant: variantsRes
    shipping_method: shipping_method_res
    shipping: shippingRes
    options: [optionsRes]
    images: [imgaesRes]
    tags: [tagRes]
    categories: [categoriesRes]
    inventoryPrice: inventoryPriceRes
    attributes: [attributesRes]
    productLikes: [productLikesRes]
    likes: productLikesRes
    shareCount: [shareCountRes]
    size: sizeRes
    ratio: String
    customers: [customerRes]
    store: BusinessInformation
    selected_quantity: Int
    shipping_method_id: Int
    shopify_product_id: String
  }

  type shipping_method_res {
    service_code: [String]
  }

  type customerRes {
    id: Int
    firstName: String
    lastName: String
    userName: String
    profileAvtar: String
  }

  type sizeRes {
    height: Int
    width: Int
  }

  type shareCountRes {
    id: Int
  }

  type productLikesRes {
    id: Int
  }

  type attributesRes {
    id: Int
    name: String
    value: String
    type: String
  }

  type inventoryPriceRes {
    price: String
    listPrice: String
    quantity: Int
    sku: String
  }

  type categoriesRes {
    id: Int
    category: categoryResponse
    subCategory: subCategoryResponse
    childSubCategory: childSubCategoryResponse
    category_id: Int
    subCategory_id: Int
    childSubCategory_id: Int
  }

  type categoryResponse {
    id: Int
    name: String
  }

  type subCategoryResponse {
    id: Int
    name: String
  }

  type childSubCategoryResponse {
    id: Int
    name: String
  }

  type tagRes {
    tag: String
  }

  type imgaesRes {
    media_id: Int
    src: String
    id: Int
    position: Int
  }

  type variantsRes {
    id: Int
    title: String
    price: String
    listPrice: String
    sku: String
    isTaxable: Boolean
    barcode: String
    inventory_quantity: Int
    old_inventory_quantity: Int
    image_id: Int
    on_hand: Int
    image: imageResp
    total_variant: [totalVariantRes]
    weightValue: String
    weightUnit: String
    unit: String
    height: Int
    width: Int
    length: Int
  }

  type imageResp {
    media: String
  }

  type totalVariantRes {
    variant_option_id: Int
    variant_option: variantOptionResponse
    variation: variationRes
  }

  type variationRes {
    name: String
  }

  type variantOptionResponse {
    value: String
    variation_id: String
    data: variantOptionDataResponse
  }

  type variantOptionDataResponse {
    name: String
  }

  type shippingRes {
    weightValue: String
    weightUnit: String
    unit: String
    length: Int
    width: Int
    height: Int
  }

  type optionsRes {
    name: String
    data: [optionsDataRes]
  }

  type optionsDataRes {
    value: String
    colorCode: String
  }

  type Customer {
    id: Int
    firstName: String
    lastName: String
    userName: String
    profileAvtar: [String]
  }

  input sizeInput {
    height: Int
    width: Int
  }

  type sizeData {
    height: Int
    width: Int
  }
  type attributes {
    name: String
    value: String
  }
  type other {
    name: String
    data: [String]
  }
  type productShipping {
    weightValue: Int
    weightUnit: String
    length: Int
    width: Int
    height: Int
    unit: String
  }
  type ProductCategories {
    category_id: Int
    subCategory_id: Int
    childSubCategory_id: Int
    category: Category
    subCategory: SubCategory
    childSubCategory: ChildSubCategory
  }
  type ProductResponse {
    id: Int
    store_id: Int
    # category_id: Int
    delivery_id: Int
    color_id: Int
    size_id: Int
    title: String
    description: String
    price: Int
    isFeature: Boolean
    isActive: Boolean
    quantity: Int
    listPrice: Int
    sku: String
    shipping: Shipping
    productSEO: ProductSEO
    images: [String]
    video: [String]
    category_id: String
    subCategory_id: String
    childSubCategory_id: String
    cropImages: [cropImageResponse]
    ratio: String
    #size: sizeData
  }

  type createProductResponse {
    success: Boolean
    message: String
    product: ProductResponse
  }

  #type Shipping {
  #  zipCode: String
  #  processingTime: String
  #  shippingServices: String
  #  freeShipping: Boolean
  #  handlingFee: Int
  #  productWeight: Int
  #  productLength: Int
  #  productWidth: Int
  #  productHeight: Int
  #  shippingPrice: String
  #}
  # createProduct Input Type

  input ProductInput {
    id: Int
    store_id: Int
    title: String
    status: String!
    description: String
    category: [categoryInput!]!
    options: [optionsInput]
    variants: [variantInput]
    attributes: [attributeInput]
    seo: seoInput
    isVisible: Boolean
    isFeature: Boolean
    shipping: shippingInput
    isFreeShipping: Boolean
    condition: String
    tags: [String]
    images: [Int!]
    removeImages: [Int]
    inventoryPrice: inventoryPriceInput
    ratio: String
    size: sizeInput
    brand_id: Int
    shipping_method_id: Int
  }

  input sizeInput {
    height: Int
    width: Int
  }

  input inventoryPriceInput {
    price: Int
    listPrice: Int
    quantity: Int
    sku: String
  }

  input variantInput {
    title: String
    price: String
    listPrice: String
    sku: String
    barcode: String
    weightValue: String
    weightUnit: String
    length: Int
    width: Int
    height: Int
    unit: String
    inventory_quantity: Int
    old_inventory_quantity: Int
    image_id: Int
    isTaxable: Boolean
    total_variant: [String]
    on_hand: Int
    compare_at_price: String
    position: Int
  }

  input croppedFile {
    baseURL: Int
    zoom: Float
    rotate: Float
    crop: cropDimantions
  }

  input cropDimantions {
    x: Float
    y: Float
  }

  type cropImageResponse {
    id: String
    oldFile: String
    mediaId: Int
    croppedFile: croppedFileReponse
  }
  type croppedFileReponse {
    baseURL: String
    mediaId: Int
    zoom: Float
    rotate: Float
    crop: cropDimantionsResponse
  }

  type cropDimantionsResponse {
    x: Float
    y: Float
  }

  input categoryInput {
    category_id: Int!
    subCategory_id: Int
    childSubCategory_id: Int
  }
  input optionsInput {
    name: String
    data: JSON
  }
  input colorInput {
    name: String
    colorCode: String
    color: String
  }
  input otherInput {
    name: String
    data: [String]
  }
  input attributeInput {
    name: String
    value: String
  }
  input seoInput {
    metaTitle: String
    metaDescription: String
    keywords: String
  }
  input shippingInput {
    weight: weightInput
    length: Int
    width: Int
    height: Int
    unit: String
  }
  input weightInput {
    value: Int
    unit: String
  }
`;
