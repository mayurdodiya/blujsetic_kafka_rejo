const { gql } = require("apollo-server-express");

module.exports = gql`
  type Media {
    id: Int
    parent_id: Int
    owner_id: Int
    media_setting_id: Int
    media: String
    media_type: String
    media_for: String
    media_tags: String
    meta: String
    url: String
    # date_of_birth: Date!

    # posts: [Post!]
  }

  extend type Query {
    getAllMedia: [Media!]
    getSingleMedia(id: Int!): Media
  }

  extend type Mutation {
    addMedia(input: MediaInput!): MediaResponse
  }

  type MediaResponse {
    id: Int!
    parent_id: Int!
    owner_id: Int!
    media_setting_id: Int
    media: String!
    media_type: String
    media_for: String
    media_tags: String
    meta: String
  }

  input MediaInput {
    owner_id: Int
    media_setting_id: Int
    media: String!
    media_type: String
    media_for: String
    media_tags: String
    meta: String
  }
`;
