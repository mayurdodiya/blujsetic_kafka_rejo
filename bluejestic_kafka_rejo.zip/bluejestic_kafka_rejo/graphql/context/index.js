const { User, Seller } = require("../../database/models");
const jwt = require("jsonwebtoken");
const { AuthenticationError } = require("apollo-server-express");

const verifyToken = async (token, userAgent) => {
  try {
    if (!token) return null;
    const { id, type, store_id, store_slug, seller_id } = await jwt.verify(token, process.env.JWT_SECRET);
    if (type === "user") {
      let user = await User.findByPk(id);
      user = JSON.parse(JSON.stringify(user));
      if (!user) throw new AuthenticationError("Invalid token");
      user.token_type = "user";
      user.store_id = store_id;
      user.store_slug = store_slug;
      user.seller_id = seller_id;
      user.userAgent = userAgent;
      return user;
    } else if (type === "seller") {
      let seller = await Seller.findByPk(id);
      seller = JSON.parse(JSON.stringify(seller));
      if (!seller) throw new AuthenticationError("Invalid token");
      seller.token_type = "seller";
      seller.store_id = store_id;
      seller.store_slug = store_slug;
      seller.seller_id = seller_id;
      seller.userAgent = userAgent;
      return seller;
    } else if (type === "admin") {
      let adminUser = await User.findByPk(id);
      adminUser = JSON.parse(JSON.stringify(adminUser));
      if (!adminUser) throw new AuthenticationError("Invalid token");
      adminUser.token_type = "admin";
      adminUser.userAgent = userAgent;
      return adminUser;
    } else {
      let user = await User.findByPk(id);
      user = JSON.parse(JSON.stringify(user));
      if (!user) throw new AuthenticationError("Invalid token");
      user.token_type = "user";
      return user;
    }
  } catch (error) {
    throw new AuthenticationError(error.message);
  }
};

module.exports = async ({ req }) => {
  if (req.headers.authorization !== undefined || null) {
    const token = req.headers.authorization.split(" ")[1];
    const userAgent = req.headers["user-agent"];
    const user = await verifyToken(token, userAgent);
    return { user };
  } else {
    const token = req.headers.token;
    const user = await verifyToken(token);
    return { user: JSON.parse(JSON.stringify(user)) };
  }
};
