const { AuthenticationError } = require("apollo-server-express");
const CategoryService = require("../../../database/services/category");
const SubCategoryService = require("../../../database/services/subcategory");
const ChildSubCategoryService = require("../../../database/services/childsubcategory");
const NestedChildSubCategoryService = require("../../../database/services/nestedchildsubcategory");
const database = require("../../../database/models");
const slugify = require("slugify");

module.exports = {
  addCategory: async (root, { name, media, banner_media, description, is_deleted = false, position, type, category_id, sub_category_id, child_sub_category_id }, { user }) => {
    if (user !== null) {
      let category;
      let slug;
      if (!type) {
        return new AuthenticationError("Please Provide Type");
      }
      switch (type) {
        case "CATEGORY":
          slug = slugify(name, { lower: true, replacement: "-" });
          category = await CategoryService.add({ name, media, banner_media, description, is_deleted, position, slug });
          return category;
        case "SUB_CATEGORY":
          if (!category_id) {
            return new AuthenticationError("category_id is Mandatory!");
          }
          slug = slugify(name, { lower: true, replacement: "-" });
          category = await SubCategoryService.add({ name, media, banner_media, description, is_deleted, category_id, position, slug });
          return category;
        case "CHILD_SUB_CATEGORY":
          if ((!category_id && !sub_category_id) || !category_id || !sub_category_id) {
            return new AuthenticationError("category_id and sub_category_id is Mandatory!");
          }
          slug = slugify(name, { lower: true, replacement: "-" });
          category = await ChildSubCategoryService.add({ name, media, banner_media, description, is_deleted, category_id, sub_category_id, position, slug });
          return category;
        case "NESTED_CHILD_CATEGORY":
          if ((!category_id && !sub_category_id && !child_sub_category_id) || !category_id || !sub_category_id || !child_sub_category_id) {
            return new AuthenticationError("category_id and sub_category_id and child_sub_category_id is Mandatory!");
          }
          slug = slugify(name, { lower: true, replacement: "-" });
          category = await NestedChildSubCategoryService.add({ name, media, banner_media, description, is_deleted, category_id, sub_category_id, child_sub_category_id, position, slug });
          return category;
        default:
          return new AuthenticationError("Enter Valid type");
      }
    }
    return new AuthenticationError("Please Provide Token");
  },

  updateCategoryDetail: async (root, args, { user }) => {
    if (user !== null) {
      if (!args?.id) {
        return new AuthenticationError("Please Provide Id where you update the category");
      }
      if (!args?.type) {
        return new AuthenticationError("Please Provide Type");
      }
      let category;
      let find_entry;
      switch (args?.type) {
        case "CATEGORY":
          find_entry = await database.Category.findOne({
            where: {
              id: args?.id,
            },
          });
          if (!find_entry) {
            return new AuthenticationError("ID is Invalid");
          }
          category = await CategoryService.update({ ...args });
          return category;
        case "SUB_CATEGORY":
          if (!args?.category_id) {
            return new AuthenticationError("category_id is Mandatory!");
          }
          find_entry = await database.Subcategory.findOne({
            where: {
              id: args?.id,
            },
          });
          if (!find_entry) {
            return new AuthenticationError("ID is Invalid");
          }
          category = await SubCategoryService.update({ ...args });
          return category;
        case "CHILD_SUB_CATEGORY":
          if ((!args?.category_id && !args?.sub_category_id) || !args?.category_id || !args?.sub_category_id) {
            return new AuthenticationError("category_id and sub_category_id is Mandatory!");
          }
          find_entry = await database.Childsubcategory.findOne({
            where: {
              id: args?.id,
            },
          });
          if (!find_entry) {
            return new AuthenticationError("ID is Invalid");
          }
          category = await ChildSubCategoryService.update({ ...args });
          return category;
        case "NESTED_CHILD_CATEGORY":
          if ((!args?.category_id && !args?.sub_category_id && !args?.child_sub_category_id) || !args?.category_id || !args?.sub_category_id || !args?.child_sub_category_id) {
            return new AuthenticationError("category_id and sub_category_id and child_sub_category_id is Mandatory!");
          }
          find_entry = await database.NestedChildSubcategory.findOne({
            where: {
              id: args?.id,
            },
          });
          if (!find_entry) {
            return new AuthenticationError("ID is Invalid");
          }
          category = await NestedChildSubCategoryService.update({ ...args });
          return category;
        default:
          return new AuthenticationError("Enter Valid type");
      }
    }
    return new AuthenticationError("Please Provide Token");
  },

  updateCategoryPosition: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input?.type) {
        return new AuthenticationError("Please Provide Type");
      }
      let failed_count = [];
      switch (input?.type) {
        case "CATEGORY":
          for (let i = 0; i < input?.category?.length; i++) {
            let category = input?.category[i];
            let [update_category] = await database.Category.update({ position: category?.position }, { where: { id: category?.category_id } });
            if (!Boolean(update_category)) {
              failed_count.push(update_category);
            }
          }
          if (Boolean(failed_count?.length)) {
            return { success: false, message: "Something went wrong!" };
          }
          return { success: true, message: "Updated Successfully" };
        case "SUB_CATEGORY":
          for (let i = 0; i < input?.category?.length; i++) {
            let category = input?.category[i];
            let [update_category] = await database.Subcategory.update({ position: category?.position }, { where: { id: category?.category_id } });
            if (!Boolean(update_category)) {
              failed_count.push(update_category);
            }
          }
          if (Boolean(failed_count?.length)) {
            return { success: false, message: "Something went wrong!" };
          }
          return { success: true, message: "Updated Successfully" };
        case "CHILD_SUB_CATEGORY":
          for (let i = 0; i < input?.category?.length; i++) {
            let category = input?.category[i];
            let [update_category] = await database.Childsubcategory.update({ position: category?.position }, { where: { id: category?.category_id } });
            if (!Boolean(update_category)) {
              failed_count.push(update_category);
            }
          }
          if (Boolean(failed_count?.length)) {
            return { success: false, message: "Something went wrong!" };
          }
          return { success: true, message: "Updated Successfully" };
        case "NESTED_CHILD_CATEGORY":
          for (let i = 0; i < input?.category?.length; i++) {
            let category = input?.category[i];
            let [update_category] = await database.NestedChildSubcategory.update({ position: category?.position }, { where: { id: category?.category_id } });
            if (!Boolean(update_category)) {
              failed_count.push(update_category);
            }
          }
          if (Boolean(failed_count?.length)) {
            return { success: false, message: "Something went wrong!" };
          }
          return { success: true, message: "Updated Successfully" };
        default:
          return new AuthenticationError("Enter Valid type");
      }
    }
    return new AuthenticationError("Please Provide Token");
  },

  deleteCategoryDetail: async (root, { id, type }, { user }) => {
    if (user !== null) {
      if (!type) {
        return new AuthenticationError("Please Provide Type");
      }
      let remove_category;
      switch (type) {
        case "CATEGORY":
          for (let i = 0; i < id?.length; i++) {
            let category_id = id[i];
            remove_category = await CategoryService.delete(category_id);
          }
          return { success: true, message: "Updated Successfully" };
        case "SUB_CATEGORY":
          for (let i = 0; i < id?.length; i++) {
            let category_id = id[i];
            remove_category = await SubCategoryService.delete(category_id);
          }
          return { success: true, message: "Updated Successfully" };
        case "CHILD_SUB_CATEGORY":
          for (let i = 0; i < id?.length; i++) {
            let category_id = id[i];
            remove_category = await ChildSubCategoryService.delete(category_id);
          }
          return { success: true, message: "Updated Successfully" };
        case "NESTED_CHILD_CATEGORY":
          for (let i = 0; i < id?.length; i++) {
            let category_id = id[i];
            remove_category = await NestedChildSubCategoryService.delete(category_id);
          }
          return { success: true, message: "Updated Successfully" };
        default:
          return new AuthenticationError("Enter Valid type");
      }
    }
    return new AuthenticationError("Please Provide Token");
  },
};
