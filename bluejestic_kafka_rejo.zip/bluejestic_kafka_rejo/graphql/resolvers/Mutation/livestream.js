// const { AuthenticationError, UserInputError } = require("apollo-server-express");
// const database = require("../../../database/models");
// const axios = require("axios");
// const { v4: uuidv4 } = require("uuid");
// const moment = require("moment");

// module.exports = {
//   createLiveStream: async (root, { input }, { user }) => {
//     try {
//       if (user?.token_type === "seller") {
//         let find_user = await database.User.findOne({
//           where: {
//             id: input?.user_id,
//           },
//         });

//         let find_seller = await database.BusinessInformation.findOne({
//           where: {
//             id: input?.store_id,
//           },
//         });

//         let seller = JSON.parse(JSON.stringify(find_seller));

//         if (!find_user) {
//           return { success: false, message: "User not Found" };
//         } else if (!find_seller) {
//           return { success: false, message: "Seller not Found" };
//         } else if (find_user?.becomeSellerStatus !== "approved") {
//           return { success: false, message: "Seller not Approved" };
//         } else if (!find_user?.isOnboardCompleted) {
//           return { success: false, message: "Seller onboarding not Completed" };
//         } else if (!find_user?.isRegisterVerified) {
//           return { success: false, message: "Seller not Verified" };
//         } else if (!find_user?.isUserOnboardCompleted) {
//           return { success: false, message: "User onboarding not completed" };
//         }

//         // const orgID = process.env.DYTE_ORG_ID;
//         // const apiKey = process.env.DYTE_API_KEY;
//         const orgID = "1f6e1dab-1302-4733-a02a-b1f863525e98";
//         const apiKey = "de84adcce79b4701d71d";
//         const base64ApiKey = btoa(`${orgID}:${apiKey}`);

//         const config = {
//           method: "POST",
//           url: "https://api.dyte.io/v2/meetings",
//           headers: {
//             Authorization: `Basic ${base64ApiKey}`,
//             "Content-Type": "application/json",
//           },
//           data: {
//             title: input?.title ? input?.title : "",
//             preferred_region: "ap-south-1",
//             record_on_start: false,
//           },
//         };

//         let response = await axios(config);
//         if (!response?.data?.success) {
//           return { success: false, message: "Something went wrong" };
//         }
//         const key = uuidv4();

//         console.log("response++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", response?.data?.data);

//         let meeting = response?.data?.data;
//         await database.LiveStream.create({
//           meeting_id: meeting.id,
//           title: meeting.title,
//           uuid: key,
//           record_on_start: meeting.record_on_start,
//           live_stream_on_start: meeting.live_stream_on_start,
//           status: meeting.status,
//           // seller_id: find_seller.seller_id,
//           store_id: find_seller?.id,
//           user_id: find_user.id,
//           date: input.date,
//           time: input.time,
//           final_date: input.final_date,
//           media_id: input.media_id,
//         });
//         return { success: true, message: "Live Stream Created Successfully" };
//       } else {
//         return new AuthenticationError("Please Provide Token");
//       }
//     } catch (error) {
//       console.log("error++++++++++++++++++++++++++++++++++", error);
//     }
//   },

//   // joinLiveStream: async (root, { input }, { user }) => {
//   //   const { meeting_id } = input;
//   //   const key = uuidv4();

//   //   console.log("starting++++++++++++++++++++++++++++++", user?.token_type);

//   //   if (user?.token_type === "seller") {
//   //     let store = await database.BusinessInformation.findOne({
//   //       where: {
//   //         id: user?.id,
//   //       },
//   //       raw: true,
//   //     });
//   //     // let store = JSON.parse(JSON.stringify(find_store));
//   //     // console.log("find_store++++++++++++++++++++++++++++++++++++++++++++++", JSON.parse(JSON.stringify(find_store)));
//   //     if (!store) return new Error("Store Not Found");

//   //     let meeting = await database.LiveStream.findOne({
//   //       where: {
//   //         uuid: meeting_id,
//   //         // store_id: user?.id,
//   //       },
//   //       raw: true,
//   //     });
//   //     // console.log("meeting+++++++++++++++++++++++++++", JSON.parse(JSON.stringify(meeting)));
//   //     // let meeting = JSON.parse(JSON.stringify(meeting));
//   //     if (!meeting) return new Error("Livestream Not Found");

//   //     let store_logo = await database.Media.findOne({
//   //       where: {
//   //         id: Number(store.logo[0]),
//   //       },
//   //       raw: true,
//   //     });

//   //     // let store_logo = JSON.parse(JSON.stringify(find_store_logo));
//   //     // console.log("store_logo+++++++++++++++++++++++++++++++++++++++++++++++", store_logo);

//   //     const orgID = process.env.DYTE_ORG_ID;
//   //     const apiKey = process.env.DYTE_API_KEY;
//   //     // const orgID = "1f6e1dab-1302-4733-a02a-b1f863525e98";
//   //     // const apiKey = "de84adcce79b4701d71d";
//   //     const base64ApiKey = btoa(`${orgID}:${apiKey}`);

//   //     const config = {
//   //       method: "POST",
//   //       url: `https://api.dyte.io/v2/meetings/${meeting?.meeting_id}/participants`,
//   //       headers: {
//   //         Authorization: `Basic ${base64ApiKey}`,
//   //         "Content-Type": "application/json",
//   //       },
//   //       data: {
//   //         name: store?.name,
//   //         picture: store_logo ? store_logo?.media : "",
//   //         // preset_name: "livestream_viewer",
//   //         preset_name: "livestream_host",
//   //         custom_participant_id: `${store?.id}`,
//   //       },
//   //     };

//   //     let response = await axios(config);

//   //     if (!response) return new Error("Something went wrong with livestream");

//   //     // console.log("response?.data?.data", response?.data?.data);

//   //     if (response?.data?.data) {
//   //       let member = response?.data?.data;
//   //       let exist_participant = await database.LivestreamParticipants.findOne({
//   //         where: {
//   //           participant_id: member?.id,
//   //           livestream_id: meeting?.id,
//   //         },
//   //       });
//   //       let existed = JSON.parse(JSON.stringify(exist_participant));

//   //       if (!exist_participant) {
//   //         let store_participant = await database.LivestreamParticipants.create({ livestream_id: meeting?.id, name: member?.name, participant_id: member?.id, store_id: store?.id, preset_name: "livestream_host" });
//   //         console.log("store_participant Added successfully>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
//   //       } else {
//   //         let store_participant = await database.LivestreamParticipants.update(
//   //           { livestream_id: meeting?.id, name: member?.name, participant_id: member?.id, store_id: store?.id, preset_name: "livestream_host" },
//   //           {
//   //             where: {
//   //               id: existed?.id,
//   //             },
//   //           }
//   //         );
//   //         console.log("store_parti☺cipant Already Exist>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
//   //       }
//   //       let storeData = {
//   //         name: store?.name,
//   //         logo: member?.picture,
//   //       };

//   //       return { success: true, message: "Token Created Successfully", authToken: member?.token, store: storeData };
//   //     }
//   //     return { success: false, message: "Something went wrong" };
//   //   } else if (user?.token_type === "user") {
//   //     let user_data = await database.User.findOne({
//   //       where: {
//   //         id: user?.id,
//   //       },
//   //       raw: true,
//   //     });
//   //     if (!user_data) return new Error("User Not Found");

//   //     let meeting = await database.LiveStream.findOne({
//   //       where: {
//   //         uuid: meeting_id,
//   //       },
//   //       raw: true,
//   //     });
//   //     if (!meeting) return new Error("Livestream Not Found");

//   //     let store = await database.BusinessInformation.findOne({
//   //       where: {
//   //         id: meeting?.store_id,
//   //       },
//   //       raw: true,
//   //     });

//   //     if (!store) return new Error("Store Not Found");

//   //     let store_logo = await database.Media.findOne({
//   //       where: {
//   //         id: Number(store.logo[0]),
//   //       },
//   //       raw: true,
//   //     });
//   //     let find_user_avtar = await database.Media.findOne({
//   //       where: {
//   //         id: Number(user_data?.profileAvtar[0]),
//   //       },
//   //       raw: true,
//   //     });

//   //     const orgID = process.env.DYTE_ORG_ID;
//   //     const apiKey = process.env.DYTE_API_KEY;
//   //     const base64ApiKey = btoa(`${orgID}:${apiKey}`);

//   //     const config = {
//   //       method: "POST",
//   //       url: `https://api.dyte.io/v2/meetings/${meeting?.meeting_id}/participants`,
//   //       headers: {
//   //         Authorization: `Basic ${base64ApiKey}`,
//   //         "Content-Type": "application/json",
//   //       },
//   //       data: {
//   //         name: user_data?.firstName + " " + user_data?.lastName,
//   //         picture: find_user_avtar ? find_user_avtar?.media : "",
//   //         preset_name: "livestream_viewer",
//   //         // preset_name: "livestream_host",
//   //         custom_participant_id: `${user_data?.id}`,
//   //       },
//   //     };

//   //     let response = await axios(config);

//   //     if (!response) return new Error("Something went wrong with livestream");

//   //     if (response?.data?.data) {
//   //       let member = response?.data?.data;
//   //       let exist_participant = await database.LivestreamParticipants.findOne({
//   //         where: {
//   //           participant_id: member?.id,
//   //           livestream_id: meeting?.id,
//   //         },
//   //       });
//   //       let existed = JSON.parse(JSON.stringify(exist_participant));
//   //       if (!exist_participant) {
//   //         await database.LivestreamParticipants.create({ livestream_id: meeting?.id, name: member?.name, participant_id: member?.id, user_id: user_data?.id, preset_name: "livestream_viewer" });
//   //         console.log("store_participant Added successfully>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
//   //       } else {
//   //         await database.LivestreamParticipants.update(
//   //           { livestream_id: meeting?.id, name: member?.name, participant_id: member?.id, user_id: user_data?.id, preset_name: "livestream_viewer" },
//   //           {
//   //             where: {
//   //               id: existed?.id,
//   //             },
//   //           }
//   //         );
//   //         console.log("store_participant Already Exist>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
//   //       }

//   //       console.log("meeting+++++++++++++++++++++++++++++++++", meeting);

//   //       const userData = {
//   //         name: user_data?.firstName + " " + user_data?.lastName,
//   //         profileAvtar: find_user_avtar ? find_user_avtar?.media : "",
//   //       };

//   //       const storeData = {
//   //         name: store?.name,
//   //         logo: store_logo ? store_logo?.media : "",
//   //       };
//   //       console.log("Token Created Successfully>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>");
//   //       return { success: true, message: "Token Created Successfully", authToken: member?.token, user: userData, store: storeData };
//   //     }
//   //     return { success: false, message: "Something went wrong" };
//   //   } else {
//   //     return new AuthenticationError("Please Provide Token");
//   //   }
//   // },

//   quickLiveStream: async (root, { input }, { user }) => {
//     try {
//       if (user?.token_type === "seller") {
//         const orgID = process.env.DYTE_ORG_ID;
//         const apiKey = process.env.DYTE_API_KEY;
//         // const orgID = "1f6e1dab-1302-4733-a02a-b1f863525e98";
//         // const apiKey = "de84adcce79b4701d71d";
//         const base64ApiKey = btoa(`${orgID}:${apiKey}`);

//         let find_user = await database.User.findOne({
//           where: {
//             id: input?.user_id,
//           },
//           raw: true,
//         });

//         let seller = await database.BusinessInformation.findOne({
//           where: {
//             id: input?.store_id,
//           },
//           raw: true,
//         });

//         // let seller = JSON.parse(JSON.stringify(find_seller));

//         if (!find_user) {
//           return { success: false, message: "User not Found" };
//         } else if (!seller) {
//           return { success: false, message: "Seller not Found" };
//         } else if (find_user?.becomeSellerStatus !== "approved") {
//           return { success: false, message: "Seller not Approved" };
//         } else if (!find_user?.isOnboardCompleted) {
//           return { success: false, message: "Seller onboarding not Completed" };
//         } else if (!find_user?.isRegisterVerified) {
//           return { success: false, message: "Seller not Verified" };
//         } else if (!find_user?.isUserOnboardCompleted) {
//           return { success: false, message: "User onboarding not completed" };
//         }

//         const meetingConfig = {
//           method: "POST",
//           url: "https://api.dyte.io/v2/meetings",
//           headers: {
//             Authorization: `Basic ${base64ApiKey}`,
//             "Content-Type": "application/json",
//           },
//           data: {
//             title: seller?.name ? seller?.name : "",
//             preferred_region: "ap-south-1",
//             record_on_start: false,
//           },
//         };

//         let meetingResponse = await axios(meetingConfig);
//         if (!meetingResponse?.data?.success) {
//           return { success: false, message: "Something went wrong" };
//         }
//         const key = uuidv4();

//         // console.log("response++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", response?.data?.data);

//         let meeting = meetingResponse?.data?.data;
//         if (!meeting) return new Error("Some Problem in Meeting Create");
//         await database.LiveStream.create({
//           meeting_id: meeting.id,
//           title: meeting.title,
//           uuid: key,
//           record_on_start: meeting.record_on_start,
//           live_stream_on_start: meeting.live_stream_on_start,
//           status: meeting.status,
//           // seller_id: find_seller.seller_id,
//           store_id: seller?.id,
//           user_id: find_user.id,
//           date: moment(new Date()).format("YYYY-MM-DD"),
//           time: moment(new Date(), "HH:mm").format("HH:mm"),
//           final_date: new Date(),
//           media_id: seller.logo[0],
//           isQuick: true,
//         });

//         let store_logo = await database.Media.findOne({
//           where: {
//             id: Number(seller.logo[0]),
//           },
//           raw: true,
//         });

//         let find_livestream_id = await database.LiveStream.findOne({
//           where: {
//             meeting_id: meeting?.id,
//           },
//           raw: true,
//         });

//         const config = {
//           method: "POST",
//           url: `https://api.dyte.io/v2/meetings/${meeting?.id}/participants`,
//           headers: {
//             Authorization: `Basic ${base64ApiKey}`,
//             "Content-Type": "application/json",
//           },
//           data: {
//             name: seller?.name,
//             picture: store_logo ? store_logo?.media : "",
//             // preset_name: "livestream_viewer",
//             preset_name: "livestream_host",
//             custom_participant_id: `${seller?.id}`,
//           },
//         };

//         let response = await axios(config);

//         if (!response) return new Error("Something went wrong with livestream");

//         let member = response?.data?.data;
//         if (member) {
//           let exist_participant = await database.LivestreamParticipants.findOne({
//             where: {
//               participant_id: member?.id,
//               livestream_id: find_livestream_id?.id,
//             },
//           });
//           let existed = JSON.parse(JSON.stringify(exist_participant));

//           if (!exist_participant) {
//             let store_participant = await database.LivestreamParticipants.create({ livestream_id: find_livestream_id?.id, name: member?.name, participant_id: member?.id, store_id: seller?.id, user_id: find_user?.id, preset_name: "livestream_host" });
//           } else {
//             let store_participant = await database.LivestreamParticipants.update(
//               { livestream_id: meeting?.id, name: member?.name, participant_id: member?.id, store_id: seller?.id, preset_name: "livestream_host" },
//               {
//                 where: {
//                   id: existed?.id,
//                 },
//               }
//             );
//           }

//           let find_user_avtar = await database.Media.findOne({
//             where: {
//               id: Number(find_user?.profileAvtar[0]),
//             },
//             raw: true,
//           });

//           let storeData = {
//             name: seller?.name,
//             logo: member?.picture,
//           };

//           let userData = {
//             name: find_user?.firstName + " " + find_user?.lastName,
//             profileAvtar: find_user_avtar ? find_user_avtar?.media : "",
//           };

//           return { success: true, message: "Token Created Successfully", authToken: member?.token, store: storeData, user: userData, uuid: key };
//         }
//         return { success: false, message: "Something went wrong" };
//       } else {
//         return new AuthenticationError("Please Provide Token");
//       }
//     } catch (error) {
//       console.log("error++++++++++++++++++++++++++++++++++", error);
//     }
//   },

//   endLiveStream: async (root, { uuid, time }, { user }) => {
//     try {
//       if (user?.token_type === "seller") {
//         let meeting = await database.LiveStream.findOne({
//           where: {
//             uuid: uuid,
//             seller_id: user?.id,
//           },
//           raw: true,
//         });
//         if (!meeting) return { success: false, message: "Livestream Not Found" };
//         if (meeting?.endTime) {
//           return { success: false, message: "Livestream Already Ended!" };
//         }
//         let update_meeting = await database.LiveStream.update(
//           {
//             endTime: time,
//           },
//           {
//             where: {
//               uuid: uuid,
//               seller_id: user?.id,
//             },
//           }
//         );
//         if (update_meeting) {
//           return { success: true, message: "End Livestream Successfully!" };
//         }
//       }
//     } catch (error) {}
//   },
// };
