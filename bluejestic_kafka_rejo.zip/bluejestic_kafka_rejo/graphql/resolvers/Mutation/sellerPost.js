const { AuthenticationError } = require("apollo-server-express");

const PostService = require("../../../database/services/post");

const database = require("../../../database/models");
const SellerPostService = require("../../../database/services/sellerPost");

module.exports = {
  createSellerPost: async (root, { input }, { user }) => {

    if (user === null) {
      return new AuthenticationError("You are not authorized to access this data");
    } else {
      let payload, sellerPost;
      if (input.attachments) {
        let image = input.attachments.filter((img) => img.type === "image").map((v) => v.id);
        let video = input.attachments.filter((img) => img.type === "video").map((v) => v.id);

        payload = {
          ...input,
          // image: image,
          // video: video,
        };
        sellerPost = await database.SellerPost.create(payload);
      } else {
        payload = {
          ...input,
        };
        sellerPost = await database.SellerPost.create(payload);
      }
      return sellerPost;
    }
  },

  updateSellerPost: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError("Please Provide Id where you update the product");
      }

      const isAccessUser = await database.Post.findOne({
        where: { seller_id: user.id, post_for: "SELLER" },
      });

      console.log(JSON.parse(JSON.stringify(isAccessUser)));
      if (!isAccessUser) return new Error("you haven't access to update");

      let payload = {
        ...input,
      };
      let sellerPost = await database.Post.update(payload, {
        where: { id: input.id, post_for: "SELLER" },
      });
      let findSellerPost = database.Post.findOne({
        where: { id: input.id, post_for: "SELLER" },
      });
      if (sellerPost) return findSellerPost;
      else return null;
    }
    return new AuthenticationError("Please Provide Token");
  },
  deleteSellerPost: async (root, { id }, { user }) => {
    if (user !== null) {
      // if (user.token_type !== "seller") return new Error("please provide seller token");
      const isExitPost = await database.Post.findOne({
        where: { id, post_for: "SELLER" },
      });
      if (!isExitPost) return new Error("post not found");
      console.log("user.id +++++++++++++++++++++++++++=", user?.seller_id);
      const isAccessUser = await database.Post.findOne({
        where: { seller_id: user?.seller_id, post_for: "SELLER" },
      });

      if (!isAccessUser) return new Error("you haven't access to delete");

      const post = await database.Post.destroy({
        where: {
          id,
          post_for: "SELLER",
        },
      });

      return isExitPost;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
