const { AuthenticationError } = require("apollo-server-express");
const FollowService = require("../../../database/services/follow");
module.exports = {
  addFollowDetail: async (root, { input }, { user }) => {
    console.log("Add Follow detail", input);

    if (user !== null) {
      const product = await FollowService.add(input);
      return product;
    }
    return new AuthenticationError("Please Provide Token");
  },
  updateFollowDetail: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError(
          "Please Provide Id where you update the product"
        );
      }
      const product = await FollowService.update(input);
      return product;
    }
    return new AuthenticationError("Please Provide Token");
  },
  deleteFollowDetail: async (root, { id }, { user }) => {
    if (user !== null) {
      const product = await FollowService.delete(id);

      return product;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
