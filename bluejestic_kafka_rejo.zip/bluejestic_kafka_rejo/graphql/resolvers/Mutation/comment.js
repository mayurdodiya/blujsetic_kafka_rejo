const database = require("../../../database/models");
const utils = require("../../../utils/utils");
const { AuthenticationError, ApolloError } = require("apollo-server-express");
const { auth } = require("../../../database/services/token");
const elasticClient = require("../../../services/elasticsearch");
module.exports = {
  createComment: async (_, { input }, { user }) => {
    try {
      if (user === null) return { success: false, message: "Please Provide the token", data: null };

      let { parent_id, comment_for, comment, reply_id, image } = input;
      // const token = await auth(user);

      if (!comment_for) {
        return { success: false, message: "Please Provide the comment_for", data: null };
      }

      comment_for = comment_for.toUpperCase();
      const comments = ["USER", "GROUP", "STORE", "PRODUCT", "POST", "SHAREPOST", "PRODUCT"];
      const isValidMedia = comments.includes(comment_for);

      if (isValidMedia === false) {
        return { success: false, message: "comment_for is not valid", data: null };
      }
      let Input = {};
      let { body, data } = await utils.commentServiceForValidation(comment_for, database, parent_id);
      console.log("data", data);
      if (!data) {
        return { success: false, message: "Invalid Request", data: null };
      }
      console.log("body", body);
      Input = body;
      Input["user_id"] = user.id;
      Input["comment_for"] = comment_for;
      Input["comment"] = comment;
      Input["reply_id"] = reply_id;
      Input["image"] = image;
      console.log("Input", Input);
      const commentData = await database.Comment.create(Input);
      /* add like in elastic search */
      if (comment_for == "STORE") {
        /*Get Post and store in elastic search */
        let post = await database.Post.findOne({ where: { id: parent_id } });
        if (!post.store_id) return { message: "Store id not found" };
        let elkBody = {
          id: commentData.id,
          user_id: user.id,
          store_id: post.store_id,
          comment: comment,
          post_id: parent_id,
          image: image,
          isReply: false,
          comment_for,
        };
        let elkData = await elasticClient.storeComments.addStoreComments(elkBody);
        if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");
        /* comment using kafka*/
        // global.kafkaConfig.produce("comments", { data: 1 });
      }
      console.log("sdafsaffdafdasfsfsafsfsafsadfdsafasdfsdafsadfsadfsadfasd");
      if (comment_for == "PRODUCT") {
        /*Get Post and store in elastic search */
        let post = await database.Comment.findOne({ where: { id: parent_id, user_id: user?.id } });
        // console.log("post", post);
        // if (!post.store_id) return { message: "Store id not found" };
        let elkBody = {
          id: commentData.id,
          user_id: user.id,
          // store_id: post.store_id,
          comment: comment,
          product_id: parent_id,
          isDeleted: false,
          reply_id: reply_id ? reply_id : null,
          isReply: reply_id ? true : false,
          comment_for,
        };
        let elkData = await elasticClient.storeComments.addProductComments(elkBody);
        console.log("elkData++++++++++++++++++++++++++++++++++++", elkData);
        if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");
        // global.kafkaConfig.produce("comments", { data: 1 });
      }
      return { success: true, message: "Comment Created", data: commentData };
    } catch (error) {
      console.log(error);
      return error;
    }
  },
  createCommentReply: async (_, { input }, { user }) => {
    try {
      if (user === null) return new AuthenticationError("You are not authenticated");

      let { reply_id, comment_for, comment, image, parent_id } = input;
      if (!comment_for) {
        return new AuthenticationError("Please Provide the comment_for");
      }

      comment_for = comment_for.toUpperCase();
      const comments = ["USER", "GROUP", "STORE", "PRODUCT", "POST"];
      const isValidMedia = comments.includes(comment_for);

      if (isValidMedia === false) {
        return new Error("comment_for is not valid");
      }

      // const post = await database.Post.findByPk(parent_id);

      // if (!post || post === null) {
      //   throw new ApolloError("Post Not Found");
      // } else {
      const data = await database.CommentReply.create({
        comment: comment,
        comment_for: comment_for,
        user_id: user.id,
        reply_id: reply_id,
        parent_id: parent_id,
        image: image,
      });
      console.log("data", data.id);
      /* add like in elastic search */
      if (comment_for == "STORE") {
        /*Get Post and store in elastic search */
        let post = await database.Post.findOne({ where: { id: parent_id } });
        if (!post.store_id) return { message: "Store id not found" };
        let elkBody = {
          id: data.id,
          user_id: user.id,
          store_id: post.store_id,
          post_id: parent_id,
          comment: comment,
          image: image,
          isReply: true,
          reply_id: reply_id,
          comment_for,
        };
        let elkData = await elasticClient.storeComments.addStoreComments(elkBody);
        if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");
        /* comment using kafka*/
        global.kafkaConfig.produce("comments", { data: 1 });
      }

      return data;
      // }
    } catch (error) {
      console.log(error);
      return error;
    }
  },
};
