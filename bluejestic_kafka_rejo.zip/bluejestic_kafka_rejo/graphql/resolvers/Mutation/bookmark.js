const { AuthenticationError } = require("apollo-server-express");
const BookmarkService = require("../../../database/services/bookmark");
const database = require("../../../database/models");
const elasticClient = require("../../../services/elasticsearch");
const { default: slugify } = require("slugify");
module.exports = {
  addBookmark: async (root, args, { user }) => {
    if (user !== null) {
      const product = await database.Product.findOne({ where: { id: args.product_id } });
      if (!product) return new Error("Product not found");
      if (args.collection_id) {
        const collection = await database.BookmarkCollection.findOne({ where: { id: args.collection_id, user_id: user.id, is_deleted: false } });
        if (!collection) return new Error("Bookmark Collection not found");
      }
      args.user_id = user.id;
      let where = { product_id: args.product_id, user_id: user.id };
      let isExistsBookmark = await database.Bookmark.findOne({ where, raw: true });
      if (!isExistsBookmark) {
        if (args.collection_id) where.collection_id = args.collection_id;
        return BookmarkService.add(args);
      } else {
        let bookmark_data = {};
        if (args.collection_id) bookmark_data.collection_id = args.collection_id;
        return BookmarkService.update({ ...bookmark_data, id: isExistsBookmark?.id });
      }
    }
    return new AuthenticationError("Please Provide Token");
  },

  createBookmarkCollection: async (root, { input }, { user }) => {
    try {
      if (user !== null) {
        if (!input.name) return new Error("Please Provide Collection Name");

        let slug = slugify(input?.name, { lower: true, replacement: "" });
        let final_slug;

        let is_exist = await database.BookmarkCollection.findOne({
          where: {
            name: input?.name,
            // user_id: user?.id,
          },
          raw: true,
        });

        if (is_exist?.name.trim() === input?.name.trim()) {
          return { success: false, message: "Bookmark name already exist" };
        }

        let find_unique_user = await database.BookmarkCollection.findOne({
          where: {
            slug: slug,
            // user_id: user?.id,
          },
          raw: true,
        });

        if (find_unique_user) {
          const otp = Math.floor(Math.random() * 900) + 100;
          final_slug = slug + otp;
        } else {
          final_slug = slug;
        }
        input.slug = final_slug;

        const collection = await database.BookmarkCollection.findOne({ where: { name: input.name, user_id: user.id, is_deleted: false, isPrivate: true } });
        if (collection) {
          return {
            success: false,
            message: "Bookmark Collection Already Exists",
          };
        }
        input.user_id = user.id;
        /* create collection */
        let data = await database.BookmarkCollection.create(input);
        return {
          success: true,
          message: "Bookmark Collection added Successfully",
          data,
        };
      }
      return new AuthenticationError("Please Provide Token");

      // let find_collection = await database.BookmarkCollection.findAll({});
      // console.log("find_collection++++++++++++++++", find_collection);
      // for (let i = 0; i < find_collection?.length; i++) {
      //   let collection = find_collection[i];
      //   console.log("collection+++++++++++++++", collection);
      //   let slug = slugify(collection?.name, { lower: true, replacement: "" });
      //   let update_collection = await database.BookmarkCollection.update(
      //     {
      //       slug: slug,
      //     },
      //     {
      //       where: {
      //         id: collection?.id,
      //       },
      //     }
      //   );
      // }
    } catch (error) {
      console.log("error+++++++++++++++++++", error);
    }
  },

  addCollectionLike: async (root, { collection_id }, { user }) => {
    try {
      if (!user) return new AuthenticationError("Please Provide the Token");
      let find_collection = await database.BookmarkCollection.findOne({ where: { id: collection_id } });
      if (!find_collection) return { success: false, message: "Collection Not Found" };
      let find_like = await database.BookmarkCollectionLikes.findOne({ where: { collection_id: collection_id, user_id: user?.id } });
      if (!find_like) {
        let create_like = await database.BookmarkCollectionLikes.create({ collection_id: collection_id, user_id: user?.id });
        return { success: true, message: "Collection Like Successfully!" };
      } else {
        let remove_like = await database.BookmarkCollectionLikes.destroy({
          where: {
            collection_id: Number(collection_id),
          },
        });
        return { success: true, message: "Collection Unlike Successfully!" };
      }
    } catch (error) {
      console.log("error", error);
    }
  },

  accessControlledCollection: async (root, { slug, isPrivate }, { user }) => {
    if (user !== null) {
      if (!slug) return new Error("Please Provide Id where you update the Bookmark Collection");

      let find = await database.BookmarkCollection.findOne({
        where: {
          slug: slug,
          user_id: user?.id,
        },
        raw: true,
      });

      if (!find) {
        return { success: false, message: "Collection not Found" };
      }

      const collection = await database.BookmarkCollection.findOne({ where: { id: find?.id, user_id: user.id } });
      if (!collection) return { success: false, message: "Bookmark Collection Not Found" };
      await database.BookmarkCollection.update({ isPrivate: isPrivate }, { where: { id: find?.id } });
      let find_post_id = await database.SharePost.findAll({
        where: {
          collection_id: find?.id,
          user_id: user?.id,
        },
        raw: true,
      });
      if (Boolean(find_post_id?.length)) {
        for (const iterator of find_post_id) {
          await database.Post.update({ collection_control: isPrivate ? "private" : "public" }, { where: { id: iterator?.post_id } });
        }
      }
      return {
        success: true,
        message: "Collection Public Successfully",
      };
    }
    return new AuthenticationError("Please Provide Token");
  },

  removeBookmarkCollection: async (root, { id }, { user }) => {
    if (user !== null) {
      const collection = await database.BookmarkCollection.findOne({ where: { id, user_id: user.id } });
      if (!collection) return { success: false, message: "Bookmark Collection Not Found" };
      await database.BookmarkCollection.update({ is_deleted: true }, { where: { id: id, user_id: user.id } });
      return {
        success: true,
        message: "Bookmark Collection removed Successfully",
      };
    }
    return new AuthenticationError("Please Provide Token");
  },

  updateBookmarkCollection: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) return new Error("Please Provide Id where you update the Bookmark Collection");
      const collection = await database.BookmarkCollection.findOne({ where: { id: input.id, user_id: user.id } });
      if (!collection) return { success: false, message: "Bookmark Collection Not Found" };
      await database.BookmarkCollection.update(input, { where: { id: input.id } });
      return {
        success: true,
        message: "Bookmark Collection Updated Successfully",
        data: await database.BookmarkCollection.findOne({ where: { id: input.id }, raw: true }),
      };
    }
    return new AuthenticationError("Please Provide Token");
  },

  updateBookmark: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError("Please Provide Id where you update the Bookmark");
      }
      const Bookmark = await BookmarkService.update(input);
      return Bookmark;
    }
    return new AuthenticationError("Please Provide Token");
  },

  deleteBookmark: async (root, { id }, { user }) => {
    if (user !== null) {
      const deletedBookmark = await BookmarkService.delete(id);
      return deletedBookmark;
    }
    return new AuthenticationError("Please Provide Token");
  },

  removeBookmark: async (root, { id }, { user }) => {
    if (user !== null) {
      const bookmark = await database.Bookmark.findOne({ where: { id: id, user_id: user.id } });
      let latest = JSON.parse(JSON.stringify(bookmark));
      if (!bookmark) {
        return {
          success: false,
          message: "Bookmark Not Found",
        };
      }

      let deleteBookmark = await database.Bookmark.destroy({ where: { id: id } });
      // let elkData = await elasticClient.sharePosts.updateSharePostById(id, { isBookmarked: false })
      // if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error")

      return {
        success: true,
        message: "Bookmark Removed Successfully",
        product_id: latest?.product_id ? latest?.product_id : null,
        id: latest?.id ? latest?.id : null,
      };
    }
    return new AuthenticationError("Please Provide Token");
  },

  removeCollection: async (root, { slug }, { user }) => {
    try {
      if (user !== null) {
        let find = await database.BookmarkCollection.findOne({
          where: {
            slug: slug,
            user_id: user?.id,
          },
          raw: true,
        });

        if (!find) {
          return { success: false, message: "Collection not Found" };
        }

        let remove = await database.BookmarkCollection.destroy({
          where: {
            id: find?.id,
            user_id: user?.id,
          },
        });
        if (remove) {
          return { success: true, message: "Collection Remove Successfully" };
        }
        return { success: true, message: "Something went wrong" };
      }
      return new AuthenticationError("Please Provide Token");
    } catch (error) {}
  },

  updateCollection: async (root, { slug, name }, { user }) => {
    try {
      if (user !== null) {
        let find = await database.BookmarkCollection.findOne({
          where: {
            slug: slug,
            user_id: user?.id,
          },
          raw: true,
        });

        if (!find) {
          return { success: false, message: "Collection not Found" };
        }

        // let get_collection = await database.BookmarkCollection.findOne({
        //   where: {
        //     id: find?.id,
        //     user_id: user?.id,
        //   },
        // });

        // if (!get_collection) return { success: false, message: "Collection not found" };

        let new_slug = slugify(name, { lower: true, replacement: "" });
        let final_slug;

        let is_exist = await database.BookmarkCollection.findOne({
          where: {
            name: name,
            user_id: user?.id,
          },
          raw: true,
        });

        if (is_exist?.name.trim() === name.trim()) {
          return { success: false, message: "Bookmark name already exist" };
        }

        let find_unique_user = await database.BookmarkCollection.findOne({
          where: {
            slug: new_slug,
            user_id: user?.id,
          },
          raw: true,
        });

        if (find_unique_user) {
          const otp = Math.floor(Math.random() * 900) + 100;
          final_slug = new_slug + otp;
        } else {
          final_slug = new_slug;
        }
        // name = final_slug;

        let update_collection = await database.BookmarkCollection.update(
          {
            name: name,
            slug: final_slug,
          },
          {
            where: {
              id: find?.id,
              user_id: user?.id,
            },
          }
        );

        let find_updated_item = await database.BookmarkCollection.findOne({
          where: {
            id: find?.id,
            user_id: user?.id,
          },
          raw: true,
        });

        if (update_collection) {
          return { success: true, message: "Collection Updated Successfully", slug: find_updated_item?.slug };
        }
        return { success: false, message: "Something went wrong" };
      }
      return new AuthenticationError("Please Provide Token");
    } catch (error) {
      console.log(error);
    }
  },

  followUnfollowcollection: async (root, { collection_id }, { user }) => {
    if (user !== null) {
      if (!collection_id) return new Error("Please Provide Id where you update the Bookmark Collection");
      const collection = await database.BookmarkCollection.findOne({ where: { id: collection_id }, raw: true });
      // if (!collection) return { success: false, message: "Bookmark Collection Not Found" };
      // if (collection?.isPrivate) return { success: false, message: "You cannot follow this collecition" };
      let find_follow = await database.BookmarkCollectionFollow.findOne({
        where: {
          collection_id: collection_id,
          user_id: user?.id,
        },
      });

      let find_follow_collection = await database.BookmarkCollectionFollow.findOne({
        where: {
          collection_id: collection_id,
        },
        attributes: ["id"],
        raw: true,
      });

      let find_share_people_collection = await database.BookmarkCollectionSharedPeople.findOne({
        where: {
          collection_id: collection_id,
        },
        attributes: ["id"],
        raw: true,
      });

      console.log("find_follow_collection++++++++++++++++++++++++++++++++++++", find_follow_collection, find_share_people_collection);

      if (find_follow_collection || find_share_people_collection) {
        const [updateCollection] = await database.BookmarkCollection.update(
          {
            isPrivate: false,
          },
          {
            where: {
              id: collection_id,
            },
          }
        );
        console.log("updateCollection+++++++++++++++", updateCollection);
      } else {
        const [updateCollection] = await database.BookmarkCollection.update(
          {
            isPrivate: true,
          },
          {
            where: {
              id: collection_id,
            },
          }
        );
        console.log("updateCollection=========================", updateCollection);
      }

      if (find_follow) {
        await database.BookmarkCollectionFollow.destroy({
          where: {
            collection_id: collection_id,
            user_id: user?.id,
          },
        });
        return { success: true, message: "Unfollow collection successfully" };
      } else {
        await database.BookmarkCollectionFollow.create({
          collection_id: collection_id,
          user_id: user?.id,
        });
        return { success: true, message: "Follow collection successfully" };
      }
    }
    return new AuthenticationError("Please Provide Token");
  },

  assignProductToCollection: async (root, { collection_id, product_id }, { user }) => {
    if (user !== null) {
      if (!collection_id) return new Error("Please Provide Id where you update the Bookmark Collection");
      const collection = await database.BookmarkCollection.findOne({ where: { id: collection_id, user_id: user.id }, raw: true });
      if (!collection) return { success: false, message: "Bookmark Collection Not Found" };
      let assign_product = await database.Bookmark.update(
        {
          collection_id: collection_id,
        },
        {
          where: {
            user_id: user?.id,
            product_id: product_id,
          },
        }
      );
      if (assign_product) {
        return { success: true, message: "Updated successfully" };
      }
      return { success: false, message: "Something went wrong" };
    }
    return new AuthenticationError("Please Provide Token");
  },

  removeProductFromCollection: async (root, { collection_id, product_id, isRemoveFromCollectionOnly }, { user }) => {
    if (user !== null) {
      if (!collection_id) return new Error("Please Provide Id where you update the Bookmark Collection");
      const collection = await database.BookmarkCollection.findOne({ where: { id: collection_id, user_id: user.id }, raw: true });
      if (!collection) return { success: false, message: "Bookmark Collection Not Found" };
      const find_entry = await database.Bookmark.findOne({ where: { collection_id: collection_id, user_id: user?.id, product_id: product_id }, raw: true });
      if (!find_entry) return { success: false, message: "Bookmark not found !" };
      if (isRemoveFromCollectionOnly) {
        let assign_product = await database.Bookmark.update(
          {
            collection_id: null,
          },
          {
            where: {
              user_id: user?.id,
              product_id: product_id,
              collection_id: collection_id,
            },
          }
        );
        if (assign_product) {
          return { success: true, message: "Remove from collection successfully" };
        }
      } else {
        let assign_product = await database.Bookmark.destroy({
          where: {
            user_id: user?.id,
            product_id: product_id,
            collection_id: collection_id,
          },
        });
        if (assign_product) {
          return { success: true, message: "Remove successfully" };
        }
      }
      return { success: false, message: "Something went wrong" };
    }
    return new AuthenticationError("Please Provide Token");
  },

  shareCollectiontoFriend: async (root, { slug, user_id }, { user }) => {
    try {
      if (!user) return new AuthenticationError("Please Provide Token");

      const find_collection = await database.BookmarkCollection.findOne({
        where: {
          slug: slug,
        },
        attributes: ["id", "user_id", "isPrivate", "slug"],
        raw: true,
      });
      if (!find_collection) return { success: false, message: "Collection Not Found" };

      if (find_collection?.user_id !== user?.id) {
        if (find_collection?.isPrivate) return { success: false, message: "Collection Not Accessible" };
      }

      const friend = await database.Friend.findOne({
        where: {
          user_id: user?.id,
          friend_id: find_collection?.user_id,
        },
        raw: true,
      });

      // const find_shared_people = await database.BookmarkCollectionSharedPeople.findOne({
      //   where: {
      //     collection_id: find_collection?.id,
      //     user_id: user?.id,
      //     friend_id: user_id,
      //   },
      //   raw: true,
      // });

      // const find_bookmark_collection_follow = await database.BookmarkCollectionFollow.findOne({
      //   where: {
      //     collection_id: find_collection?.id,
      //     user_id: user?.id,
      //   },
      //   raw: true,
      // });

      if (find_collection?.user_id === user?.id) {
        for (let i = 0; i < user_id?.length; i++) {
          let userid = user_id[i];
          let find_collection_entry = await database.BookmarkCollectionSharedPeople.findOne({
            where: {
              collection_id: find_collection?.id,
              friend_id: userid,
              user_id: user?.id,
            },
            attributes: ["id"],
            raw: true,
          });
          if (!find_collection_entry) {
            let add_user = await database.BookmarkCollectionSharedPeople.create({
              collection_id: find_collection?.id,
              user_id: user?.id,
              friend_id: userid,
            });
          }
        }
        let update_collection = await database.BookmarkCollection.update(
          { isPrivate: false },
          {
            where: {
              id: find_collection?.id,
            },
          }
        );
        return { success: true, message: "Share Collection Successfully!" };
      } else {
        return { success: false, message: "You don't have Permission to Access!" };
      }
    } catch (error) {
      console.log("error++++++++++++", error);
    }
  },
};
