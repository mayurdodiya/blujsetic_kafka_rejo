const { AuthenticationError } = require("apollo-server-express");
const JoinGroupService = require("../../../database/services/joingroup");
const elasticClient = require("../../../services/elasticsearch");
const database = require("../../../database/models");
const redisClient = require("../../../redis/redisClient");
module.exports = {
  joinGroup: async (root, { input }, { user }) => {
    if (user !== null) {
      /* is user already joined */
      const isJoined = await database.JoinGroup.findOne({ where: { group_id: input.group_id, user_id: user.id }, raw: true });
      if (isJoined) return new Error("You already joined this group");
      const joingroup = await JoinGroupService.add(input);
      let storeTypes = ["JOIN_CLUBS", "CLUBS_YOU_MANAGE", "SUGGESTED_CLUBS", "ALL_CLUB"];

      process.nextTick(async () => {
        if (!isJoined) {
          await redisClient.del(`PUBLIC:ALL_CLUB`);
          for (let i = 0; i < storeTypes.length; i++) {
            let type = storeTypes[i];
            await redisClient.del(`USER/${user?.id}:${type}`);
          }
        }
      });
      /* join group in elastic search */
      let elkData = await elasticClient.joinGroup.addJoinGroup({ ...input, id: joingroup.id });
      if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");
      console.log("isJoined", joingroup?.group_id);
      const findGroup = await database.Group.findOne({
        where: {
          id: joingroup?.group_id,
        },
        raw: true,
      });
      return findGroup;
    }
    return new AuthenticationError("Please Provide Token");
  },

  leaveGroup: async (root, args, { user }) => {
    if (user !== null) {
      console.log(args);
      const joingroup = await JoinGroupService.leave(args.groupId, args.userId);
      if (!joingroup) return new Error("Member not exists");

      let storeTypes = ["JOIN_CLUBS", "CLUBS_YOU_MANAGE", "SUGGESTED_CLUBS", "ALL_CLUB"];

      process.nextTick(async () => {
        if (joingroup) {
          await redisClient.del(`PUBLIC:ALL_CLUB`);
          for (let i = 0; i < storeTypes.length; i++) {
            let type = storeTypes[i];
            await redisClient.del(`USER/${user?.id}:${type}`);
          }
        }
      });
      // return
      if (joingroup && joingroup.isOwner == true) {
        //* Create a new Admin if admin is deleted
        let updateJoinGroupId = null;
        let updateGroupUserId = null;

        //*Find group admins
        let admins = await database.JoinGroup.findAll({ where: { group_id: args.groupId, isAdmin: true }, order: [["createdAt", "ASC"]], raw: true });

        if (Boolean(admins.length)) {
          updateJoinGroupId = admins[0].id;
          updateGroupUserId = admins[0].user_id;

          console.log("updateJoinGroupId >>>>>>>>>>>>>>>>>>> ", updateJoinGroupId, updateGroupUserId);
        } else {
          //*Find group members
          let members = await database.JoinGroup.findAll({ where: { group_id: args.groupId }, order: [["createdAt", "ASC"]], raw: true });
          console.log("members >>>>>>>>>>>>>>>>>>> ", members);

          if (Boolean(members.length)) {
            updateJoinGroupId = members[0].id;
            updateGroupUserId = members[0].user_id;
            console.log("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< updateJoinGroupId >>>>>>>>>>>>>>>>>>> ", updateJoinGroupId, updateGroupUserId);
          }
          console.log("<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< updateJoinGroupId >>>>>>>>>>>>>>>>>>> ", updateJoinGroupId, updateGroupUserId);
        }
        console.log("updateGroupIdupdateGroupId", updateJoinGroupId, joingroup, updateGroupUserId);

        if (!updateJoinGroupId) {
          await database.Group.destroy({ where: { id: args.groupId } });
          //* delete group from elasticsearch
          let elkDataForGroup = await elasticClient.group.deleteGroup({ id: args.groupId, user_id: updateGroupUserId });
          if (!elkDataForGroup?.success) return new Error(elkDataForGroup?.message || "Elasctic search error");
          console.log("0000000000000000000000000000000000000000000000000");
        } else {
          await database.JoinGroup.update(
            {
              isAdmin: true,
              isOwner: true,
            },
            {
              where: {
                id: updateJoinGroupId,
              },
            }
          );
          console.log("5655555555555555555555555555555555555555555555555");

          let elkData = await elasticClient.joinGroup.updateJoinGroupById(updateJoinGroupId, { isAdmin: true, isOwner: true });
          if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");
          await database.Group.update(
            {
              user_id: updateGroupUserId,
            },
            {
              where: {
                id: args.groupId,
              },
            }
          );
          let elkDataForGroup = await elasticClient.group.updateGroupById(args.groupId, { user_id: updateGroupUserId });
          if (!elkDataForGroup?.success) return new Error(elkData?.message || "Elasctic search error");
        }
      }
      return joingroup;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
