const { AuthenticationError } = require("apollo-server-express");

const PostService = require("../../../database/services/post");

const database = require("../../../database/models");
const GroupPostService = require("../../../database/services/groupPost");

module.exports = {
  createGroupPost: async (root, { input }, { user }) => {
    if (user != null) {
      let payload;
      payload = {
        ...input,
        user_id: user.id,
      };
      if (!input.media_id) {
        payload = {
          ...input,
          media_id: [],
          user_id: user.id,
        };
      }
      const groupPost = await GroupPostService.add(payload);
      return groupPost;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  updateGroupPost: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError(
          "Please Provide Id where you update the product"
        );
      }

      const isAccessUser = await database.GroupPost.findOne({
        where: { user_id: user.id },
      });

      if (!isAccessUser) return new Error("you haven't access to update");
      let payload = {
        ...input,
      };
      let groupPost = await database.GroupPost.update(payload, {
        where: { id: input.id },
      });
      let findGroupPost = database.GroupPost.findOne({
        where: { id: input.id },
      });
      if (groupPost) return findGroupPost;
      else return null;
    }
    return new AuthenticationError("Please Provide Token");
  },
  deleteGroupPost: async (root, { id }, { user }) => {
    if (user !== null) {
      const isExitPost = await database.Post.findOne({
        where: { id },
      });
      if (!isExitPost) return new Error("post not found");
      console.log("isExitPost", JSON.parse(JSON.stringify(isExitPost)));

      const isAccessUser = await database.Post.findOne({
        where: { id, user_id: user.id },
      });
      console.log(
        "isAccessUser",
        JSON.parse(JSON.stringify(isAccessUser)),
        user.id
      );
      if (!isAccessUser) return new Error("you haven't access to delete");
      const post = await database.Post.destroy({
        where: {
          id,
        },
      });

      return isExitPost;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
