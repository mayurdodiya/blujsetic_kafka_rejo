const { AuthenticationError } = require("apollo-server-express");
const ShippingService = require("../../../database/services/shipping");
module.exports = {
  addShipping: async (root, { input }, { user }) => {
    if (user !== null) {
      const Shipping = await ShippingService.add(input);
      return Shipping;
    }
    return new AuthenticationError("Please Provide Token");
  },
  //   updateShippingDetail: async (root, { input }, { user }) => {
  //     if (user !== null) {
  //       if (!input.id) {
  //         return new AuthenticationError(
  //           "Please Provide Id where you update the Shipping"
  //         );
  //       }
  //       const Shipping = await ShippingService.update(input);
  //       return Shipping;
  //     }
  //     return new AuthenticationError("Please Provide Token");
  //   },
  //   deleteShippingDetail: async (root, { id }, { user }) => {
  //     if (user !== null) {
  //       const Shipping = await ShippingService.delete(id);

  //       return Shipping;
  //     }
  //     return new AuthenticationError("Please Provide Token");
  //   },
};
