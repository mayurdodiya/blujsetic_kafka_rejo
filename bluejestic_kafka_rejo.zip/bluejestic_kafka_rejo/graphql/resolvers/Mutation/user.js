const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { AuthenticationError } = require("apollo-server-express");
const database = require("../../../database/models");
const UserService = require("../../../database/services/user");
const { User, LegalDetails, BusinessInformation, Seller, UserLoginActivity } = require("../../../database/models");
const { validateFields } = require("../../../utils/Validation");
const AddressService = require("../../../database/services/address");
const elasticClient = require("../../../services/elasticsearch/index");
const sendEmail = require("../../../utils/sendMail");
const moment = require("moment");
const { default: slugify } = require("slugify");
const auth = require("../../../middlewares/firebaseConfiguration");
const { raw } = require("express");
const { Sequelize } = require("sequelize");
const { Op } = require("sequelize");

module.exports = {
  // registerSeller: async (root, args, context) => {
  //   console.log(args);
  //   const {
  //     firstName,
  //     lastName,
  //     email,
  //     confirmEmail,
  //     password,
  //     confirmPassword,
  //     mobileNumber,
  //     phoneNumber,
  //     ext,
  //     jobTitle,
  //     userFor,
  //   } = args.input;

  //   let userData;
  //   const CheckEmail = await User.findOne({ where: { email } });
  //   if (CheckEmail && CheckEmail.email == email) {
  //     throw new AuthenticationError("Email already exists");
  //   } else {
  //     let userType = args.input.userFor.toUpperCase();
  //     if (userType === "SELLER") {
  //       if (Object.keys(args.input.businessInformation).length === 0) {
  //         return new AuthenticationError(
  //           "Please Provide the Business Information"
  //         );
  //       } else {
  //         if (email != confirmEmail) {
  //           return new AuthenticationError(
  //             "Email and Confirm Email does not match"
  //           );
  //         } else if (password != confirmPassword) {
  //           return new AuthenticationError(
  //             "Password and Confirm Password does not match"
  //           );
  //         } else {
  //           const bcryptPassword = await bcrypt.hash(password, 10);
  //           userData = await UserService.add({
  //             firstName,
  //             lastName,
  //             email,
  //             password: bcryptPassword,
  //             mobileNumber,
  //             phoneNumber,
  //             ext,
  //             jobTitle,
  //             userFor,
  //           });
  //         }
  //         let {
  //           name,
  //           companyLegalName,
  //           streetAddress,
  //           city,
  //           state,
  //           postalCode,
  //         } = args.input.businessInformation;

  //         const fields = [
  //           "name",
  //           "companyLegalName",
  //           "streetAddress",
  //           "city",
  //           "state",
  //           "postalCode",
  //         ];

  //         const data = [
  //           name,
  //           companyLegalName,
  //           streetAddress,
  //           city,
  //           state,
  //           postalCode,
  //         ];
  //         const emptyValidators = validateFields(data, fields);
  //         if (emptyValidators) {
  //           return new Error(emptyValidators);
  //         }

  //         const businessInformation = args.input.businessInformation;
  //         businessInformation.seller_id = userData.id;
  //         const businessInformationData = await BusinessInformation.create(
  //           businessInformation
  //         );
  //       }
  //       if (Object.keys(args.input.legalDetails).length === 0) {
  //         return new AuthenticationError("Please Provide the Legal Detail");
  //       } else {
  //         // Empty Fields Validator
  //         let { taxClassification, countryIncorporation } =
  //           args.input.legalDetails;

  //         const fields = ["taxClassification", "countryIncorporation"];

  //         const data = [taxClassification, countryIncorporation];

  //         const emptyValidators = validateFields(data, fields);
  //         if (emptyValidators) {
  //           return new Error(emptyValidators);
  //         }

  //         const legalDetails = args.input.legalDetails;
  //         legalDetails.seller_id = userData.id;

  //         const legalDetailsData = await LegalDetails.create(legalDetails);
  //       }
  //     }

  //     return userData;
  //   }
  // },

  //* normal user sign in api
  signin: async (root, { input }, context) => {
    const { email, password, loginActivity, social_type, social_id, access_token } = input;
    let emptyValidators;
    let user;

    if (!social_type) {
      return new Error("Please Provide Social Type.");
      // return { success: false, message: "Something went Wrong, Contact your Administrator." };
    }

    const IsUserExist = async (email) => {
      const user = await database.User.findOne({ where: { email }, raw: true });
      return user;
    };

    const VerifiedUserDetail = async (user) => {
      // let token;
      // if (user?.role === "admin") {
      //   token = jwt.sign({ id: user.id, type: "admin" }, process.env.JWT_SECRET);
      // } else {
      // }
      // let sellerToken;  
      const seller = await Seller.findOne({ where: { email: user?.email }, raw: true });
      // if (!seller) sellerToken = null;

      let store;
      if (seller) {
        store = await BusinessInformation.findOne({
          where: {
            seller_id: seller?.id,
          },
          attributes: ["id", 'slug'],
          raw: true,
        });
      }
      // if (seller) sellerToken = jwt.sign({ id: seller.id, type: "seller", store_id: store?.id }, process.env.JWT_SECRET);
      const token = jwt.sign({ id: user?.id, type: "user", user_id: user?.id ?? null, seller_id: seller?.id ?? null, store_id: store?.id ?? null, store_slug: store?.slug ?? null }, process.env.JWT_SECRET);
      // const sellerStatus = seller && seller.sellerApprovedStatusNew === "approved" ? true : false;
      if (loginActivity) {
        let loginActivityData = {
          user_id: user.id,
          loginTime: new Date(),
          userType: "user",
          isDeleted: user?.is_deleted,
          latitude: loginActivity.latitude,
          longitude: loginActivity.longitude,
          deviceName: loginActivity.deviceName,
        };
        await UserLoginActivity.create(loginActivityData);
      }
      return {
        success: true,
        message: "Login Successful",
        role: user?.role,
        isSeller: user?.isSeller,
        isUserOnboardCompleted: user?.isUserOnboardCompleted,
        becomeSellerStatus: user?.becomeSellerStatus,
        currentQueryForVerification: user?.currentQueryForVerification,
        currentStepForSellerOnboarding: user?.currentStepForSellerOnboarding,
        isOnboardCompleted: user?.isOnboardCompleted,
        isDetails5OnboardingCompletedNew: user?.isDetails5OnboardingCompletedNew,
        token: token
        // seller_token: sellerToken,
      };
    };

    const socialAuthentication = async () => {
      const decodedToken = await auth.verifyIdToken(access_token);
      let user_email = "";
      if (social_type === "TWITTER") {
        user_email = email;
        console.log("email", email);
      } else {
        user_email = decodedToken?.email;
      }
      if (decodedToken) {
        user = await IsUserExist(user_email);
        if (!user) return { success: false, message: "User not Exist!" };
        if (!user?.isRegisterVerified) {
          return { success: false, message: "User not Verified!" };
        }
        if (user_email === user?.email && user?.isSocial && social_type === user?.social_type) {
          let IsDetailFound = await VerifiedUserDetail(user);
          if (IsDetailFound) {
            return IsDetailFound;
          }
          return { success: false, message: "Something went Wrong, Contact your Administrator." };
        }
      }
      return { success: false, message: "Something went Wrong, Contact your Administrator." };
    };

    const sendEmailCall = async (user) => {
      const token = jwt.sign({ id: user.id, type: "user" }, process.env.JWT_SECRET, { expiresIn: "24h" });

      const emailData = {
        to: user.email,
        from: process.env.EMAIL_USER,
        subject: "Seller Approval",
        html: `        <div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
        <div style="margin:50px auto;width:70%;padding:20px 0">
          <div style="border-bottom:1px solid #eee">
            <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Bluejestic</a>
          </div>
          <p style="font-size:1.1em">Hi,</p>
          <p>Thank you for choosing Bluejestic. For verification you account click on verification button. This mail is valid for 24 hours.</p>
          <a href="${process.env.FRONTEND_URL}/register-verification/${token}" style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">Verification</a>
          <p style="font-size:0.9em;">Regards,<br />Bluejestic</p>
          <hr style="border:none;border-top:1px solid #eee" />
        </div>
      </div>`,
      };
      let isSend = await sendEmail(emailData);
      if (!isSend) {
        return { success: false, message: "Please try again later", isMailsend: false, isUserOnboardCompleted: false, isSeller: false, token: "" };
      }
      return { success: false, message: "Mail send successfully", isMailsend: true, isSeller: false, token: "", isUserOnboardCompleted: false };
    };

    let validate;

    switch (social_type) {
      case "MANUAL":
        data = [email, password];
        fields = ["email", "password"];
        emptyValidators = validateFields(data, fields);
        if (emptyValidators) {
          // return new Error("Invalid credentials");
          return { success: false, message: "Something went Wrong, Contact your Administrator." };
        }
        user = await IsUserExist(email);
        if (!user?.isRegisterVerified) {
          return { success: false, message: "User not Verified!" };
        }
        if (!user?.isSocial) {
          if (bcrypt.compareSync(password, user?.password)) {
            let validate = await VerifiedUserDetail(user);
            if (validate) {
              return validate;
            }
          }
        }
        break;
      case "GOOGLE":
        data = [access_token];
        fields = ["access_token"];
        emptyValidators = validateFields(data, fields);
        if (emptyValidators) {
          return { success: false, message: "Something went Wrong, Contact your Administrator." };
        }
        // if (!user?.isRegisterVerified) {
        //   return await sendEmailCall(user);
        // }
        validate = await socialAuthentication();
        // if (!validate) return { success: false, message: "Something went Wrong, Contact your Administrator." };
        return validate;
        // if (!validate?.success) return validate;
        // if (!validate?.isRegisterVerified) {
        //   return { success: false, message: "Account not Verify, Please Verify First" };
        // }
        break;
      case "TWITTER":
        data = [access_token];
        fields = ["access_token"];
        emptyValidators = validateFields(data, fields);
        if (emptyValidators) {
          return { success: false, message: "Something went Wrong, Contact your Administratorqqqqqqqqqqqqqq." };
        }
        // if (!user?.isRegisterVerified) {
        //   return await sendEmailCall(user);
        // }
        validate = await socialAuthentication();
        if (!validate) return { success: false, message: "Something went Wrong, Contact your Administratoreeeeeeeeeeeeeeeeeeeee." };
        return validate;
      case "FACEBOOK":
        data = [access_token];
        fields = ["access_token"];
        emptyValidators = validateFields(data, fields);
        if (emptyValidators) {
          return { success: false, message: "Something went Wrong, Contact your AdministratorWWWWWWWWW." };
        }
        // if (!user?.isRegisterVerified) {
        //   return await sendEmailCall(user);
        // }
        validate = await socialAuthentication();
        if (!validate) return { success: false, message: "Something went Wrong, Contact your AdministratorWWWWWWWWwwwwwWdasdasddas." };
        return validate;
      // if (!validate?.success) return validate;
      // if (!validate?.isRegisterVerified) {
      //   return { success: false, message: "Account not Verify, Please Verify First" };
      // }
      default:
        break;
    }

    return { success: false, message: "Invalid credentials" };

    // if (user && bcrypt.compareSync(password, user.password)) {
    //   let token;
    //   if (user.role === "admin") {
    //     token = jwt.sign({ id: user.id, type: "admin" }, process.env.JWT_SECRET);
    //   } else {
    //     token = jwt.sign({ id: user.id, type: "user" }, process.env.JWT_SECRET);
    //   }
    //   let sellerToken;
    //   let seller = await Seller.findOne({ where: { email }, raw: true });
    //   if (seller) sellerToken = jwt.sign({ id: seller.id, type: "seller" }, process.env.JWT_SECRET);
    //   const sellerStatus = seller && seller.sellerApprovedStatusNew === "approved" ? true : false;
    //   if (!seller) sellerToken = null;
    //   /* store login activity */
    //   if (loginActivity) {
    //     let loginActivityData = {
    //       user_id: user.id,
    //       loginTime: new Date(),
    //       userType: "user",
    //       latitude: loginActivity.latitude,
    //       longitude: loginActivity.longitude,
    //       deviceName: loginActivity.deviceName,
    //     };
    //     await UserLoginActivity.create(loginActivityData);
    //   }
    //   return {
    //     token: token,
    //     seller_token: sellerToken,
    //     isSeller: sellerStatus,
    //     isUserOnboardCompleted: user?.isUserOnboardCompleted,
    //     role: user.role,
    //     success: true,
    //     message: "Login Successful",
    //   };
    // } else {
    //   throw new AuthenticationError("Invalid credentials");
    // }
  },

  updateUserStatus: async (root, { status, user_id }, { user }) => {
    if (!user) return new AuthenticationError("Unauthorized");
    if (user.token_type !== "admin") return new AuthenticationError("Unauthorized");
    let types = ["active", "suspended"];
    if (!types.includes(status)) {
      return { success: false, message: "Wrong status provided!" };
    }

    try {

      let find_user = await database.User.findOne({
        where: {
          id: user_id,
        },
      });

      find_user = JSON.parse(JSON.stringify(find_user));

      if (!find_user) {
        return { success: false, message: "User not found!" };
      }

      if (find_user.status === status) {
        return { success: false, message: `User already ${status === "suspended" ? "suspended" : "reactivated"}!` };
      }

      const [update_user] = await database.User.update(
        { status: status },
        {
          where: { id: user_id },
        }
      );
      if (Boolean(update_user)) {
        let data = await elasticClient.user.updateUserById("user", user_id, { status: status });
        if (!data.success) return new Error("Elasticsearch - update user status - " + data.message);
        return { success: true, message: `User ${status === "suspended" ? "suspended" : "reactivated"} successfully.` };
      } else {
        return { success: false, message: "Something went wrong!" };
      }

    } catch (error) {
      console.error("An error occured while updating user status: ", error);
      return {
        success: false,
        message: error?.message ?? "An error occured while updating user status!"
      }
    }
  },

  removeUser: async (root, { user_ids }, { user }) => {
    try {
      if (!user) return new AuthenticationError("Unauthorized");
      if (user.token_type !== "admin") return new AuthenticationError("Unauthorized");

      if (!Array.isArray(user_ids) || !user_ids.length) {
        return {
          success: false,
          message: "Please provide valid user id(s)",
        };
      }

      const remove_user = await database.User.destroy({
        where: {
          id: {
            [Op.in]: user_ids
          },
        },
      });

      let data = await elasticClient.user.deleteUser("user", user_ids);
      if (!data.success) return new Error("Elasticsearch - remove User(s) - " + data.message);
      return { success: true, message: "User(s) removed successfully" };
    } catch (error) {
      console.error("An error occured while removing user(s): ", error);
      return {
        success: false,
        message: error?.message ?? "An error occured while removing user(s)!"
      }

    }
  },

  //* direct channel sign in api
  sellerSignin: async (root, { input }, context) => {
    try {
      const { email, password, loginActivity, social_type, social_id, access_token } = input;
      let emptyValidators;
      let user;

      if (!social_type) {
        return new Error("Please Provide Social Type.");
        // return { success: false, message: "Something went Wrong, Contact your Administrator." };
      }

      const IsUserExist = async (email) => {
        const user = await database.Seller.findOne({ where: { email }, raw: true });
        return user;
      };

      const VerifiedUserDetail = async (user) => {
        // let token;
        // if (user?.role === "admin") {
        //   token = jwt.sign({ id: user.id, type: "admin" }, process.env.JWT_SECRET);
        // } else {
        //   token = jwt.sign({ id: user.id, type: "seller" }, process.env.JWT_SECRET);
        // }
        // let sellerToken;
        let seller = await Seller.findOne({ where: { email: user?.email }, raw: true });
        if (!seller) return { success: false, message: "Seller not found" };
        const store = await BusinessInformation.findOne({
          where: {
            seller_id: seller?.id,
          },
          attributes: ["id", "slug"],
          raw: true,
        });
        const token = jwt.sign({ id: seller?.id, type: "seller", user_id: user?.user_id ?? null, seller_id: seller?.id ?? null, store_id: store?.id ?? null, store_slug: store?.slug ?? null }, process.env.JWT_SECRET);
        // const sellerStatus = seller && seller.sellerApprovedStatusNew === "approved" ? true : false;
        if (loginActivity) {
          let loginActivityData = {
            user_id: user.id,
            loginTime: new Date(),
            userType: "seller",
            isDeleted: user?.isDeleted,
            latitude: loginActivity.latitude,
            longitude: loginActivity.longitude,
            deviceName: loginActivity.deviceName,
          };
          await UserLoginActivity.create(loginActivityData);
        }
        return {
          success: true,
          message: "Login Successful",
          isSellerInfoVerified: user?.isSellerInfoVerified,
          sellerApprovedStatusNew: user?.sellerApprovedStatusNew,
          currentQueryForVerification: user?.currentQueryForVerification,
          isUserOnboardCompleted: user?.isUserOnboardCompleted,
          isSellerVerify: user?.isSellerVerify,
          isDetails5OnboardingCompleted: user?.isDetails5OnboardingCompletedNew,
          isOnboardCompleted: user?.isOnboardCompleted,
          currentStepForSellerOnboarding: user?.currentStepForSellerOnboarding,
          token: token,

          // token: sellerToken,
          // token: user?.sellerApprovedStatusNew === "approved" ? sellerToken : null,
          // isSeller: user?.isSeller,
          // isUser: user?.isUser,
          // role: user.role,
        };
      };

      const socialAuthentication = async () => {
        const decodedToken = await auth.verifyIdToken(access_token);
        let user_email = "";
        if (social_type === "TWITTER") {
          user_email = email;
          console.log("email", email);
        } else {
          user_email = decodedToken?.email;
        }
        if (decodedToken) {
          user = await IsUserExist(user_email);
          if (!user) return;
          if (!user?.isRegisterVerified) {
            return;
          }
          if (user_email === user?.email && user?.isSocial && social_type === user?.social_type) {
            let IsDetailFound = await VerifiedUserDetail(user);
            if (IsDetailFound) {
              return IsDetailFound;
            }
            return;
          }
        }
        return;
      };

      const sendEmailCall = async (user) => {
        const token = jwt.sign({ id: user.id, type: "user" }, process.env.JWT_SECRET, { expiresIn: "24h" });

        const emailData = {
          to: user.email,
          from: process.env.EMAIL_USER,
          subject: "Seller Approval",
          html: `        <div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
          <div style="margin:50px auto;width:70%;padding:20px 0">
            <div style="border-bottom:1px solid #eee">
              <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Bluejestic</a>
            </div>
            <p style="font-size:1.1em">Hi,</p>
            <p>Thank you for choosing Bluejestic. For verification you account click on verification button. This mail is valid for 24 hours.</p>
            <a href="${process.env.FRONTEND_URL}/register-verification/${token}" style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">Verification</a>
            <p style="font-size:0.9em;">Regards,<br />Bluejestic</p>
            <hr style="border:none;border-top:1px solid #eee" />
          </div>
        </div>`,
        };
        let isSend = await sendEmail(emailData);
        if (!isSend) {
          return { success: false, message: "Please try again later", isMailsend: false, isUserOnboardCompleted: false, isSeller: false, token: "" };
        }
        return { success: false, message: "Mail send successfully", isMailsend: true, isSeller: false, token: "", isUserOnboardCompleted: false };
      };

      let validate;

      switch (social_type) {
        case "MANUAL":
          data = [email, password];
          fields = ["email", "password"];
          emptyValidators = validateFields(data, fields);
          if (emptyValidators) {
            return { success: false, message: "Something went Wrong, Contact your Administrator." };
          }
          user = await IsUserExist(email);
          console.log("userdasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasasas", user);
          if (!user) return { success: false, message: "Invalid Credential!" };

          if (!user?.isSocial) {
            if (!user?.isSellerVerify) {
              // return { success: false, message: "Seller Not Exist! Please Register First." };
              let savedUserData = JSON.parse(JSON.stringify(user));
              const otp = Math.floor(100000 + Math.random() * 900000);
              const emailData = {
                to: savedUserData?.email,
                from: process.env.EMAIL_USER,
                subject: "Seller Verification",
                html: `<div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
                <div style="margin:50px auto;width:70%;padding:20px 0">
                  <div style="border-bottom:1px solid #eee">
                    <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Bluejestic</a>
                  </div>
                  <p style="font-size:1.1em">Hi,</p>
                  <p>Thank you for choosing Bluejestic. Use the following OTP to complete your Sign Up procedures. OTP is valid for 5 minutes</p>
                  <h2 style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">${otp}</h2>
                  <p style="font-size:0.9em;">Regards,<br />Bluejestic</p>
                  <hr style="border:none;border-top:1px solid #eee" />
                </div>
              </div>`,
              };
              let isSend = await sendEmail(emailData);
              if (!isSend) return { success: false, message: "OTP not sent, please try again later" };
              const updateOTP = await database.Seller.update(
                { otpForVerification: otp, otpVerificationExpiry: moment().add(5, "minutes").toDate() },
                {
                  where: {
                    id: savedUserData?.id,
                  },
                }
              );

              //* update seller by id - elastic search db 
              await elasticClient.sellers.updateSellerById(savedUserData?.id, {
                otpForVerification: otp,
                otpVerificationExpiry: moment().add(5, "minutes").toDate()
              });

              return { success: true, message: "Please Verify your account First. OTP sent successfully", isSellerVerify: false };
            } else {

              if (user?.sellerApprovedStatusNew === "rejected") {
                return {
                  success: false,
                  message: "You will not be able to login, Your Application for seller is Rejected, Please Try after 3 months.",
                }
              } else if (user?.sellerApprovedStatusNew === "pending") {
                return {
                  success: false,
                  message: "You will not be able to login, You will receive an email once we have verified.",
                }
              } else {
                if (bcrypt.compareSync(password, user?.password)) {
                  let validate = await VerifiedUserDetail(user);
                  if (validate) {
                    return validate;
                  }
                }
              }

            }

            // if (user?.isSellerInfoVerified) {
            // if (user?.sellerApprovedStatusNew === "approved") {
            // } 
            // else if (user?.sellerApprovedStatusNew === "pending") {
            //   return { success: false, message: "You will not be able to login, You will receive an email once we have verified." };
            // } 
            // else {
            //   return { success: false, message: "You will not be able to login, Your Application for seller is Rejected, Please Try after 3 months." };
            // }
            // }
          }
          break;
        case "GOOGLE":
          data = [access_token];
          fields = ["access_token"];
          emptyValidators = validateFields(data, fields);
          if (emptyValidators) {
            return { success: false, message: "Something went Wrong, Contact your Administrator." };
          }
          validate = await socialAuthentication();
          if (!validate) return { success: false, message: "Something went Wrong, Contact your Administrator." };
          return validate;
        case "TWITTER":
          data = [access_token];
          fields = ["access_token"];
          emptyValidators = validateFields(data, fields);
          if (emptyValidators) {
            return { success: false, message: "Something went Wrong, Contact your Administratorqqqqqqqqqqqqqq." };
          }
          validate = await socialAuthentication();
          if (!validate) return { success: false, message: "Something went Wrong, Contact your Administratoreeeeeeeeeeeeeeeeeeeee." };
          return validate;
        default:
          break;
      }

      return { success: false, message: "Invalid credentials" };
    } catch (error) {
      console.log("error >>>>>>>>>>>>>>>>>>>>>>", error);
    }
  },

  //* admin login api
  login: async (root, { input }, context) => {
    const { email, password, loginActivity } = input;
    const user = await database.User.findOne({ where: { email } });
    if (!user) throw new AuthenticationError("Invalid credentials");

    if (user.role !== "admin") {
      throw new AuthenticationError("Invalid credentials");
    }

    console.log(user);

    if (user && bcrypt.compareSync(password, user.password)) {
      let token = jwt.sign({ id: user?.id, type: "admin" }, process.env.JWT_SECRET);

      // let sellerToken;
      /* store login activity */
      // if (loginActivity) {
      //   let loginActivityData = {
      //     user_id: user.id,
      //     loginTime: new Date(),
      //     userType: "user",
      //     latitude: loginActivity.latitude,
      //     longitude: loginActivity.longitude,
      //     deviceName: loginActivity.deviceName,
      //   };
      //   await UserLoginActivity.create(loginActivityData);
      // }
      return {
        success: true,
        message: "Login Successful",
        role: user?.role,
        token: token,
      };
    } else {
      throw new AuthenticationError("Invalid credentials");
    }
  },

  forgotPassword: async (root, { email, otp }, context) => {
    try {
      const user = await User.findOne({ where: { email } });
      if (!user) throw new AuthenticationError("User not Found");
      const otp = Math.floor(100000 + Math.random() * 900000);
      const emailData = {
        to: email,
        from: process.env.EMAIL_USER,
        subject: "Seller Approval",
        html: `        <div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
        <div style="margin:50px auto;width:70%;padding:20px 0">
          <div style="border-bottom:1px solid #eee">
            <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Bluejestic</a>
          </div>
          <p style="font-size:1.1em">Hi,</p>
          <p>Thank you for choosing Bluejestic. Use the following OTP to complete your Sign Up procedures. OTP is valid for 5 minutes</p>
          <h2 style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">${otp}</h2>
          <p style="font-size:0.9em;">Regards,<br />Bluejestic</p>
          <hr style="border:none;border-top:1px solid #eee" />
        </div>
      </div>`,
      };
      let isSend = await sendEmail(emailData);
      if (!isSend) return { success: false, message: "OTP not sent, please try again later" };

      const updateOTP = await database.User.update(
        { forgotPasswordOTP: otp, forgotPasswordOTPExpiry: moment().add(5, "minutes").toDate() },
        {
          where: {
            id: user?.id,
          },
        }
      );
      return { success: true, message: "OTP sent successfully" };
    } catch (error) {
      console.log(error);
      return { success: false, message: error.message };
    }
  },

  changePassword: async (root, { currentPassword, newPassword }, { user }) => {
    try {
      if (user !== null) {
        if (!currentPassword) return { success: false, message: "Current Password is Required" };
        let find_user = await database.User.findOne({
          where: {
            id: user?.id,
          },
          raw: true,
        });
        if (!find_user) return { success: false, message: "User not Found!" };
        if (find_user?.password ? bcrypt.compareSync(currentPassword, find_user?.password) : !find_user?.password) {
          const bcryptPassword = await bcrypt.hash(newPassword, 10);
          const [updateOTP] = await database.User.update(
            { password: bcryptPassword },
            {
              where: {
                id: user?.id,
              },
            }
          );
          if (updateOTP) {
            return { success: true, message: "Password Updated Successfully!" };
          }
        }
        return { success: false, message: "Please Enter valid Current Password" };
      }
      return new AuthenticationError("Please Provide Token");
    } catch (error) {
      console.log(error);
    }
  },

  changeSellerPassword: async (root, { currentPassword, newPassword }, { user }) => {
    try {
      if (user !== null) {
        if (!currentPassword) return { success: false, message: "Current Password is Required" };
        let find_seller = await database.Seller.findOne({
          where: {
            id: user?.seller_id,
          },
          raw: true,
        });
        if (!find_seller) return { success: false, message: "Seller not Found!" };
        if (find_seller?.password ? bcrypt.compareSync(currentPassword, find_seller?.password) : !find_seller?.password) {
          const bcryptPassword = await bcrypt.hash(newPassword, 10);
          const [updateOTP] = await database.Seller.update(
            { password: bcryptPassword },
            {
              where: {
                id: user?.seller_id,
              },
            }
          );
          if (updateOTP) {
            return { success: true, message: "Password Updated Successfully!" };
          }
        }
        return { success: false, message: "Please Enter valid Current Password" };
      }
      return new AuthenticationError("Please Provide Token");
    } catch (error) {
      console.log(error);
    }
  },

  verifyOTPForForgot: async (root, { email, otp }, context) => {
    try {
      const user = await User.findOne({ where: { email } });
      if (!user) throw new AuthenticationError("User not Found");
      if (!user.forgotPasswordOTP) return { success: false, message: "Resend OTP" };
      if (user.forgotPasswordOTP !== otp) return { success: false, message: "OTP does not match" };
      if (user.forgotPasswordOTPExpiry < new Date()) return { success: false, message: "OTP expired" };
      return { success: true, message: "OTP Verified Successfully" };
    } catch (error) {
      console.log(error);
      return { success: false, message: error.message };
    }
  },

  resetPassword: async (root, { email, password, otp }, context) => {
    try {
      const user = await User.findOne({ where: { email } });

      if (!user) throw new AuthenticationError("User not Found");
      if (user.forgotPasswordOTP !== otp) return { success: false, message: "You can not reset password. Please Try agian" };

      const bcryptPassword = await bcrypt.hash(password, 10);
      const updateOTP = await database.User.update(
        { password: bcryptPassword },
        {
          where: {
            id: user?.id,
          },
        }
      );
      return { success: true, message: "Password Changed Successfully" };
    } catch (error) {
      console.log(error);
      return { success: false, message: error.message };
    }
  },

  //* normal user sign up api
  signup: async (root, { input }, context) => {
    try {
      const { firstName, lastName, email, password, social_type, access_token } = input;
      let fields = [];
      let data;

      let user;

      if (!social_type) {
        return new Error("Please Provide Social Type.");
      }

      const createSlug = async (firstName, lastName) => {
        let slug = slugify(`${firstName + lastName}`, { lower: true, replacement: "" });
        let final_userName;

        let find_unique_user = await database.User.findOne({
          where: {
            userName: slug,
          },
          raw: true,
        });

        if (find_unique_user) {
          const otp = Math.floor(Math.random() * 900) + 100;
          final_userName = slug + otp;
        } else {
          final_userName = slug;
        }

        return final_userName;
      };

      const socialAuthentication = async () => {
        const dummy_logo_image = "https://bluejestic-media.storage.googleapis.com/demo-test/dummy-profile (1)-1669122101773-764781589-1669182656605-3255156-1694692268774-918686311.jpg";
        const decodedToken = await auth.verifyIdToken(access_token);
        if (decodedToken) {
          let user_email = "";
          if (social_type === "TWITTER") {
            user_email = email;
            console.log("email", email);
          } else {
            user_email = decodedToken?.email;
          }

          let isUserExist = await IsUserExist(user_email);
          if (isUserExist) {
            return;
          }
          const social_name = decodedToken.name.split(" ");
          let user_slug = await createSlug(Boolean(social_name[0]) ? social_name[0] : "", Boolean(social_name[1]) ? social_name[1] : "");

          user = await database.User.create({
            firstName: Boolean(social_name[0]) ? social_name[0] : "",
            lastName: Boolean(social_name[1]) ? social_name[1] : "",
            email: user_email,
            logo_image: decodedToken?.picture === "" || !decodedToken?.picture ? dummy_logo_image : decodedToken?.picture,
            social_id: decodedToken?.uid,
            social_type: social_type,
            isSocial: true,
            role: "user",
            userName: user_slug,
          });
          user = JSON.parse(JSON.stringify(user));
          //* create user - elastic search db 
          await elasticClient.user.createUser(user);
          return user;
        }
        return;
      };

      const generatePassword = async (password) => {
        return await bcrypt.hash(password, 10);
      };

      const IsUserExist = async (email) => {
        const isExistUser = await database.User.findOne({ where: { email: email }, raw: true });
        if (isExistUser) {
          return true;
        }
        return false;
      };

      let emptyValidators;
      switch (social_type) {
        case "MANUAL":
          data = [firstName, lastName, email, password];
          fields = ["firstName", "lastName", "email", "password"];
          emptyValidators = validateFields(data, fields);
          if (emptyValidators) {
            // return new Error(emptyValidators);
            return { success: false, message: "Something went Wrong, Contact your Administrator" };
          }

          const bcryptPassword = await generatePassword(password);
          let isUserExist = await IsUserExist(email);
          if (isUserExist) {
            // return new Error("User Already Exist!");
            return { success: false, message: "User Already Exist!" };
          }
          let user_slug = await createSlug(firstName, lastName);
          user = await User.create({
            firstName,
            lastName,
            email,
            role: "user",
            isUser: true,
            isSeller: false,
            password: bcryptPassword,
            userName: user_slug,
            social_type: "MANUAL",
          });
          break;
        case "GOOGLE":
          data = [social_type, access_token];
          fields = ["social_type", "access_token"];
          emptyValidators = validateFields(data, fields);
          if (emptyValidators) {
            // return new Error(emptyValidators);
            return { success: false, message: "Something went Wrong, Contact your Administrator" };
          }
          user = await socialAuthentication();
          break;
        case "TWITTER":
          data = [social_type, access_token];
          fields = ["social_type", "access_token"];
          emptyValidators = validateFields(data, fields);
          if (emptyValidators) {
            // return new Error(emptyValidators);
            return { success: false, message: "Something went Wrong, Contact your Administrator" };
          }
          user = await socialAuthentication();
          break;
        case "FACEBOOK":
          data = [social_type, access_token];
          fields = ["social_type", "access_token"];
          emptyValidators = validateFields(data, fields);
          if (emptyValidators) {
            // return new Error(emptyValidators);
            return { success: false, message: "Something went Wrong, Contact your Administrator" };
          }
          user = await socialAuthentication();
          break;
        default:
      }

      if (user && social_type === "MANUAL") {
        const token = jwt.sign({ id: user.id, type: "user" }, process.env.JWT_SECRET);
        const emailData = {
          to: user?.email,
          from: process.env.EMAIL_USER,
          subject: "User Registration",
          html: `        <div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
          <div style="margin:50px auto;width:70%;padding:20px 0">
            <div style="border-bottom:1px solid #eee">
              <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Bluejestic</a>
            </div>
            <p style="font-size:1.1em">Hi,</p>
            <p>Thank you for choosing Bluejestic. For verification you account click on verification button. This mail is valid for 24 hours.</p>
            <a href="${process.env.FRONTEND_URL}/register-verification/${token}" style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">Verification</a>
            <p style="font-size:0.9em;">Regards,<br />Bluejestic</p>  
            <hr style="border:none;border-top:1px solid #eee" />
          </div>
        </div>`,
        };
        let isSend = await sendEmail(emailData);
        if (!isSend) return { success: false, message: "OTP not sent, please try again later" };
        user = JSON.parse(JSON.stringify(user));
        let elkData = await elasticClient.user.createUser(user);
        if (!elkData.success) throw new Error(elkData.message);
        return { data: { user }, success: true, message: "Register Successfully. OTP sent to your email successfully." };
      } else if (user && social_type !== "MANUAL") {
        const update_register = User.update(
          {
            isRegisterVerified: true,
          },
          {
            where: {
              id: user?.id,
            },
          }
        );

        let seller = await Seller.findOne({ where: { email: user?.email }, raw: true });
        let store;
        if (seller) {
          store = await BusinessInformation.findOne({
            where: {
              seller_id: seller?.id,
            },
            attributes: ["id"],
            raw: true,
          });
        }
        const token = jwt.sign({ id: user?.id, type: "user", store_id: store?.id ? store?.id : null }, process.env.JWT_SECRET);
        const sellerStatus = seller && seller.sellerApprovedStatusNew === "approved" ? true : false;
        user = JSON.parse(JSON.stringify(user));
        let elkData = await elasticClient.user.createUser(user);
        if (!elkData.success) throw new Error(elkData.message);
        return {
          success: true,
          message: "Register Successfully",
          data: {
            login: {
              token: token,
              isSeller: sellerStatus,
              isUserOnboardCompleted: user?.isUserOnboardCompleted,
              role: user.role,
              success: true,
              message: "Login Successful",
            },
            user: user,
          },
        };
      }
      return { success: false, message: "Something went wrong" };
    } catch (error) {
      console.log(error);
      throw new Error(error);
    }
  },

  //* direct seller sign up(register) api
  sellerRegister: async (root, { input }, context) => {
    try {
      const { firstName, lastName, email, password, social_type, access_token } = input;
      let fields = [];
      let data;

      let user;

      if (!social_type) {
        return new Error("Please Provide Social Type.");
      }

      const createSlug = async (firstName, lastName) => {
        let slug = slugify(`${firstName + lastName}`, { lower: true, replacement: "" });
        let final_userName;

        let find_unique_user = await database.Seller.findOne({
          where: {
            userName: slug,
          },
          raw: true,
        });

        if (find_unique_user) {
          const otp = Math.floor(Math.random() * 900) + 100;
          final_userName = slug + otp;
        } else {
          final_userName = slug;
        }

        return final_userName;
      };

      const socialAuthentication = async () => {
        const dummy_logo_image = "https://bluejestic-media.storage.googleapis.com/demo-test/dummy-profile (1)-1669122101773-764781589-1669182656605-3255156-1694692268774-918686311.jpg";
        const decodedToken = await auth.verifyIdToken(access_token);
        if (decodedToken) {
          let user_email = "";
          if (social_type === "TWITTER") {
            user_email = email;
          } else {
            user_email = decodedToken?.email;
          }

          let isUserExist = await IsUserExist(user_email);
          if (isUserExist) {
            return;
          }
          const social_name = decodedToken.name.split(" ");
          let user_slug = await createSlug(Boolean(social_name[0]) ? social_name[0] : "", Boolean(social_name[1]) ? social_name[1] : "");

          user = await database.User.create({
            firstName: Boolean(social_name[0]) ? social_name[0] : "",
            lastName: Boolean(social_name[1]) ? social_name[1] : "",
            email: user_email,
            logo_image: decodedToken?.picture === "" || !decodedToken?.picture ? dummy_logo_image : decodedToken?.picture,
            social_id: decodedToken?.uid,
            social_type: social_type,
            isSocial: true,
            role: "seller",
            userName: user_slug,
            isSeller: true,
            isUser: false,
          });

          user = JSON.parse(JSON.stringify(user));

          //* create seller - elastic search db 
          await elasticClient.sellers.createSeller(user);
          return user;
        }
        return;
      };

      const generatePassword = async (password) => {
        return await bcrypt.hash(password, 10);
      };

      const IsUserExist = async (email) => {
        const isExistUser = await database.Seller.findOne({ where: { email: email }, raw: true });
        if (isExistUser) {
          return true;
        }
        return false;
      };

      let emptyValidators;
      switch (social_type) {
        case "MANUAL":
          data = [firstName, lastName, email, password];
          fields = ["firstName", "lastName", "email", "password"];
          emptyValidators = validateFields(data, fields);
          if (emptyValidators) {
            // return new Error(emptyValidators);
            return { success: false, message: "Something went Wrong, Contact your Administrator" };
          }

          const bcryptPassword = await generatePassword(password);
          let isUserExist = await IsUserExist(email);
          if (isUserExist) {
            // return new Error("User Already Exist!");
            return { success: false, message: "User Already Exist!123" };
          }
          let user_slug = await createSlug(firstName, lastName);
          user = await Seller.create({
            firstName,
            lastName,
            email,
            password: bcryptPassword,
            userName: user_slug,
            user_id: null,
            is_user: false,
            social_type: "MANUAL",
          });

          if (!user) return { success: true, message: "User Already Exist!" };

          let savedUserData = JSON.parse(JSON.stringify(user));

          //* create seller - elastic search db 
          await elasticClient.sellers.createSeller(savedUserData);


          const otp = Math.floor(100000 + Math.random() * 900000);
          const emailData = {
            to: savedUserData?.email,
            from: process.env.EMAIL_USER,
            subject: "Seller Registration",
            html: `        <div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
            <div style="margin:50px auto;width:70%;padding:20px 0">
              <div style="border-bottom:1px solid #eee">
                <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Bluejestic</a>
              </div>
              <p style="font-size:1.1em">Hi,</p>
              <p>Thank you for choosing Bluejestic. Use the following OTP to complete your Sign Up procedures. OTP is valid for 5 minutes</p>
              <h2 style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">${otp}</h2>
              <p style="font-size:0.9em;">Regards,<br />Bluejestic</p>
              <hr style="border:none;border-top:1px solid #eee" />
            </div>
          </div>`,
          };
          let isSend = await sendEmail(emailData);
          if (!isSend) return { success: false, message: "OTP not sent, please try again later" };

          const updateOTP = await database.Seller.update(
            { otpForVerification: otp, otpVerificationExpiry: moment().add(5, "minutes").toDate() },
            {
              where: {
                id: savedUserData?.id,
              },
            }
          );

          //* update seller by id - elastic search db 
          await elasticClient.sellers.updateSellerById(savedUserData?.id, {
            otpForVerification: otp,
            otpVerificationExpiry: moment().add(5, "minutes").toDate()
          });


          return { success: true, message: "Register Successfully. OTP sent to your email successfully." };
        case "GOOGLE":
          data = [social_type, access_token];
          fields = ["social_type", "access_token"];
          emptyValidators = validateFields(data, fields);
          if (emptyValidators) {
            // return new Error(emptyValidators);
            return { success: false, message: "Something went Wrong, Contact your Administrator" };
          }
          user = await socialAuthentication();
          break;
        case "TWITTER":
          data = [social_type, access_token];
          fields = ["social_type", "access_token"];
          emptyValidators = validateFields(data, fields);
          if (emptyValidators) {
            // return new Error(emptyValidators);
            return { success: false, message: "Something went Wrong, Contact your Administratorsssssssssssssssssss" };
          }
          user = await socialAuthentication();
          console.log("usedasdasdasdasrwqeeqw++++++++++++++++++", user);
          break;
        case "FACEBOOK":
        default:
      }
      return { success: false, message: "Seller Already Exist!" };
    } catch (error) {
      console.log(error);
      throw new Error(error);
    }
  },

  //* not in used
  sellerRegisterFromUser: async (root, { input }, { user }) => {
    try {
      // const { firstName, lastName, email, password, social_type, access_token } = input;
      let fields = [];
      let data;

      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }

      if (!user?.token_type) {
        return new AuthenticationError("Invalid Token");
      }

      const verify_user = await database.User.findOne({
        where: {
          id: user?.id,
        },
        attributes: ["id", "firstName", "lastName", "email", "social_type"],
        raw: true,
      });

      if (!verify_user) {
        return new AuthenticationError("Please Provide the token");
      }

      const firstName = user?.firstName;
      const lastName = user?.lastName;
      const email = user?.email;
      const password = user?.password;
      const social_type = user?.social_type;

      if (!social_type) {
        return new Error("Please Provide Social Type.");
      }

      const createSlug = async (firstName, lastName) => {
        let slug = slugify(`${firstName + lastName}`, { lower: true, replacement: "" });
        let final_userName;

        let find_unique_user = await database.Seller.findOne({
          where: {
            userName: slug,
          },
          raw: true,
        });

        if (find_unique_user) {
          const otp = Math.floor(Math.random() * 900) + 100;
          final_userName = slug + otp;
        } else {
          final_userName = slug;
        }

        return final_userName;
      };

      const socialAuthentication = async () => {
        const dummy_logo_image = "https://bluejestic-media.storage.googleapis.com/demo-test/dummy-profile (1)-1669122101773-764781589-1669182656605-3255156-1694692268774-918686311.jpg";
        const decodedToken = await auth.verifyIdToken(access_token);
        if (decodedToken) {
          let user_email = "";
          if (social_type === "TWITTER") {
            user_email = email;
          } else {
            user_email = decodedToken?.email;
          }

          let isUserExist = await IsUserExist(user_email);
          if (isUserExist) {
            return;
          }
          const social_name = decodedToken.name.split(" ");
          let user_slug = await createSlug(Boolean(social_name[0]) ? social_name[0] : "", Boolean(social_name[1]) ? social_name[1] : "");

          user = await database.User.create({
            firstName: Boolean(social_name[0]) ? social_name[0] : "",
            lastName: Boolean(social_name[1]) ? social_name[1] : "",
            email: user_email,
            logo_image: decodedToken?.picture === "" || !decodedToken?.picture ? dummy_logo_image : decodedToken?.picture,
            social_id: decodedToken?.uid,
            social_type: social_type,
            isSocial: true,
            role: "seller",
            userName: user_slug,
            isSeller: true,
            isUser: false,
          });
          return user;
        }
        return;
      };

      const generatePassword = async (password) => {
        return await bcrypt.hash(password, 10);
      };

      const IsUserExist = async (email) => {
        const isExistUser = await database.Seller.findOne({ where: { email: email }, raw: true });
        if (isExistUser) {
          return true;
        }
        return false;
      };

      let emptyValidators;
      switch (social_type) {
        case "MANUAL":
          data = [firstName, lastName, email, password];
          fields = ["firstName", "lastName", "email", "password"];
          emptyValidators = validateFields(data, fields);
          if (emptyValidators) {
            // return new Error(emptyValidators);
            return { success: false, message: "Something went Wrong, Contact your Administrator" };
          }

          const bcryptPassword = await generatePassword(password);
          let isUserExist = await IsUserExist(email);
          if (isUserExist) {
            // return new Error("User Already Exist!");
            return { success: false, message: "User Already Exist!" };
          }
          let user_slug = await createSlug(firstName, lastName);
          user = await Seller.create({
            firstName,
            lastName,
            email,
            password: bcryptPassword,
            userName: user_slug,
            social_type: "MANUAL",
          });

          if (!user) return { success: true, message: "User Already Exist!" };

          let savedUserData = JSON.parse(JSON.stringify(user));

          const otp = Math.floor(100000 + Math.random() * 900000);
          const emailData = {
            to: savedUserData?.email,
            from: process.env.EMAIL_USER,
            subject: "Seller Registration",
            html: `        <div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
            <div style="margin:50px auto;width:70%;padding:20px 0">
              <div style="border-bottom:1px solid #eee">
                <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Bluejestic</a>
              </div>
              <p style="font-size:1.1em">Hi,</p>
              <p>Thank you for choosing Bluejestic. Use the following OTP to complete your Sign Up procedures. OTP is valid for 5 minutes</p>
              <h2 style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">${otp}</h2>
              <p style="font-size:0.9em;">Regards,<br />Bluejestic</p>
              <hr style="border:none;border-top:1px solid #eee" />
            </div>
          </div>`,
          };
          let isSend = await sendEmail(emailData);
          if (!isSend) return { success: false, message: "OTP not sent, please try again later" };

          const updateOTP = await database.Seller.update(
            { otpForVerification: otp, otpVerificationExpiry: moment().add(5, "minutes").toDate() },
            {
              where: {
                id: savedUserData?.id,
              },
            }
          );
          return { success: true, message: "Register Successfully. OTP sent successfully." };
        case "GOOGLE":
          data = [social_type, access_token];
          fields = ["social_type", "access_token"];
          emptyValidators = validateFields(data, fields);
          if (emptyValidators) {
            // return new Error(emptyValidators);
            return { success: false, message: "Something went Wrong, Contact your Administrator" };
          }
          user = await socialAuthentication();
          break;
        case "TWITTER":
          data = [social_type, access_token];
          fields = ["social_type", "access_token"];
          emptyValidators = validateFields(data, fields);
          if (emptyValidators) {
            // return new Error(emptyValidators);
            return { success: false, message: "Something went Wrong, Contact your Administratorsssssssssssssssssss" };
          }
          user = await socialAuthentication();
          console.log("usedasdasdasdasrwqeeqw++++++++++++++++++", user);
          break;
        case "FACEBOOK":
        default:
      }
      return { success: false, message: "User Already Exist!" };
    } catch (error) {
      console.log(error);
      throw new Error(error);
    }
  },

  verifyOTPForSeller: async (root, { email, otp }, context) => {
    try {
      const fetch_user = await Seller.findOne({
        where: { email },
        // raw: true,
        attributes: ["id", "firstName", "lastName", "email", "sellerApprovedStatusNew", "isSellerVerify", "userName", "social_type", "otpForVerification", "otpVerificationExpiry", "isSellerInfoVerified", "currentQueryForVerification"],
        include: [
          {
            model: database.User,
            as: "user",
            attributes: ["id", "firstName", "lastName", "email", "becomeSellerStatus", "isOnboardCompleted", "isRegisterVerified", "isUserOnboardCompleted", "userName", "role", "social_type", "isSocial"],
          },
        ],
      });

      const user = JSON.parse(JSON.stringify(fetch_user));
      if (!user) throw new AuthenticationError("Seller not Found");
      if (user.isSellerVerify) return { success: false, message: "User Already Verified." };
      if (!user.otpForVerification) return { success: false, message: "Resend OTP" };
      if (user.otpForVerification !== otp) return { success: false, message: "OTP does not match" };
      if (user.otpVerificationExpiry < new Date()) return { success: false, message: "OTP expired" };

      let token;
      token = jwt.sign({ ...user, isSellerVerify: true, type: "seller" }, process.env.JWT_SECRET);

      let update = await Seller.update(
        {
          isSellerVerify: true,
          currentQueryForVerification: "",
        },
        {
          where: {
            id: user?.id,
          },
        }
      );
      return { success: true, message: "OTP Verified Successfully", seller_token: token, isSellerInfoVerified: user?.isSellerInfoVerified, currentQueryForVerification: "", isSellerVerify: true };
    } catch (error) {
      console.log(error);
      return { success: false, message: error.message };
    }
  },

  resendSellerVerificationOtp: async (root, { email }, context) => {
    try {
      // const { email, password, loginActivity } = input;
      const seller = await database.Seller.findOne({ where: { email } });
      if (!seller) throw new AuthenticationError("Invalid Seller");
      if (seller?.isSellerVerify) throw new AuthenticationError("Seller Already Register");

      const otp = Math.floor(100000 + Math.random() * 900000);

      const emailData = {
        to: seller?.email,
        from: process.env.EMAIL_USER,
        subject: "Seller Registration",
        html: `<div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
        <div style="margin:50px auto;width:70%;padding:20px 0">
          <div style="border-bottom:1px solid #eee">
            <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Bluejestic</a>
          </div>
          <p style="font-size:1.1em">Hi,</p>
          <p>Thank you for choosing Bluejestic. Use the following OTP to complete your Sign Up procedures. OTP is valid for 5 minutes</p>
          <h2 style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">${otp}</h2>
          <p style="font-size:0.9em;">Regards,<br />Bluejestic</p>
          <hr style="border:none;border-top:1px solid #eee" />
        </div>
      </div>`,
      };
      let isSend = await sendEmail(emailData);
      if (!isSend) return { success: false, message: "OTP not sent, please try again later" };
      const updateOTP = await database.Seller.update(
        { otpForVerification: otp, otpVerificationExpiry: moment().add(5, "minutes").toDate() },
        {
          where: {
            id: seller?.id,
          },
        }
      );
      return { success: true, message: "OTP Resend Successfully" };
    } catch (error) {
      console.log(error);
      throw new Error(error);
    }
  },

  resendMailVerification: async (root, { id }, context) => {
    try {
      // const { email, password, loginActivity } = input;
      const user = await database.User.findOne({ where: { id } });
      if (!user) throw new AuthenticationError("Invalid User");
      if (user?.isRegisterVerified) throw new AuthenticationError("User Already Register");

      const token = jwt.sign({ id: user.id, type: "user" }, process.env.JWT_SECRET, { expiresIn: "24h" });
      const emailData = {
        to: user?.email,
        from: process.env.EMAIL_USER,
        subject: "Seller Approval",
        html: `        <div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
        <div style="margin:50px auto;width:70%;padding:20px 0">
          <div style="border-bottom:1px solid #eee">
            <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Bluejestic</a>
          </div>
          <p style="font-size:1.1em">Hi,</p>
          <p>Thank you for choosing Bluejestic. For verification you account click on verification button. This mail is valid for 24 hours.</p>
          <a href="https://bluejestic.com/register-verification/${token}-${user?.id}" style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">Verification</a>
          <p style="font-size:0.9em;">Regards,<br />Bluejestic</p>
          <hr style="border:none;border-top:1px solid #eee" />
        </div>
      </div>`,
      };
      let isSend = await sendEmail(emailData);
      if (!isSend) return { success: false, message: "OTP not sent, please try again later" };
      return { success: true, message: "Mail send successfully" };
    } catch (error) {
      console.log(error);
      throw new Error(error);
    }
  },

  updateUser: async (root, { input }, context) => {
    try {
      const { id, data } = input;

      let userPayload = {
        firstName: data.firstName,
        lastName: data.lastName,
        email: data.email,
        mobileNumber: data.mobileNumber,
        gender: data.gender,
        bday: new Date(data.bday),
      };
      const updateData = await UserService.update(userPayload, id);

      return updateData;
    } catch (error) {
      console.log(error);
      throw new Error(error);
    }
  },

  updateUserAddress: async (root, { input }, { user }) => {
    try {
      if (user !== null) {
        let userPayload = {
          address_1: input.address1,
          address_2: input.address2,
          city: input.city,
          state: input.state,
          zip_code: input.zipCode,
          country: input.country,
          user_id: user.id,
          address_for: "USER",
        };

        const updateData = await AddressService.updateOrCreate(userPayload, user.id);

        let response = {
          id: updateData.id,
          address1: updateData.address_1,
          address2: updateData.address_2,
          zipCode: updateData.zip_code,
          city: updateData.city,
          state: updateData.state,
          country: updateData.country,
        };

        return response;
      }
      return new AuthenticationError("Please Provide Token");
    } catch (error) {
      console.log(error);
      throw new Error(error);
    }
  },

  updateUserImages: async (root, { input }, { user }) => {
    try {
      async function convertImage(images) {
        let img_arr = [];
        for (let i = 0; i < images.length; i++) {
          let mediaData = await database.Media.findOne({
            where: { id: images[i] },
          }).then((data) => data);
          images[i] = mediaData.media;
          img_arr.push(images[i]);
        }
        return img_arr;
      }
      let userPayload = {
        profileAvtar: await convertImage(input.profileAvtar),
        profileCoverImage: await convertImage(input.profileCoverImage),
      };

      const updateData = await UserService.update(userPayload, user.id);

      return updateData;
    } catch (error) {
      console.log(error);
      throw new Error(error);
    }
  },

  updateBioDetail: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    try {
      const isExitstUser = await database.User.findOne({ where: { id: input.id } });

      if (!isExitstUser) {
        return new Error("User Not Exists!");
      }

      // console.log(input);
      let userBioDetailPayload = {
        marital_status: input.relationshipStatus,
        occupation: input.occupation,
        education: input.education,
        interest: input.otherInterests,
        about: input.about,
        experience: input.workExperience,
        hobbies: input.hobbies,
        user_id: input.id,
        firstName: input.firstName,
        lastName: input.lastName,
        gender: input.gender,
        userName: input.userName,
        isUserOnboardCompleted: input.isUserOnboardCompleted,
      };

      let user = {
        jobTitle: input.jobTitle,
        logo_image: input?.logo_image,
        banner_image: input?.banner_image,
        phoneNumber: input.phoneNumber,
        ...(input.bday && {
          bday: input.bday,
        }),
        address: input.address,
        subAddress: input.subAddress,
        city: input.city,
        state: input.state,
        country: input.country,
        zipCode: input.zipCode,
        isUserOnboardCompleted: input.isUserOnboardCompleted,
      };
      console.log(user);

      const updateData = await UserService.updateBiodetail(userBioDetailPayload, input.id);

      await UserService.update(user, input.id);

      // const getMediaUrl = async (mediaId) => {
      //   console.log("mediaIdmediaIdmediaIdmediaIdmediaId", mediaId);
      //   if (!mediaId) return null;
      //   let media = await database.Media.findOne({ where: { id: mediaId } });
      //   return media.media;
      // };
      user.logo_image = input?.logo_image;
      user.banner_image = input?.banner_image;

      /* add user in elastic search */
      let elkData = await elasticClient.user.updateUserById("user", input.id, user);
      if (!elkData.success) throw new Error(elkData.message);

      return updateData;
    } catch (error) {
      console.error("An error occured while updating user's bio details", error);
      throw new Error("An error occured while updating user's bio details");
    }
  },

  addPostDataIntoElastic: async (root, { input }, { user }) => {
    try {
      let get_post_data = await database.Post.findAll({
        include: [
          {
            model: database.SharePost,
            as: "sharePosts",
          },
        ],
        order: [["createdAt", "DESC"]],
      });

      let format_post = JSON.parse(JSON.stringify(get_post_data));

      for (let i = 0; i < format_post.length; i++) {
        let post = format_post[i];
        let final_object = {};
        if (post?.post_for === "SHAREPOST") {
          let post_for_type = "";
          // console.log("post+++++++++++++++", post);
          if (post?.sharePosts?.collection_id && post?.sharePosts?.share_post_for !== "GROUP") {
            post_for_type = "COLLECTION_ON_FEED";
          } else if (post?.sharePosts?.collection_id && post?.sharePosts?.share_post_for === "GROUP") {
            post_for_type = "COLLECTION_ON_GROUP";
          } else if (post?.sharePosts?.product_id && post?.sharePosts?.share_post_for !== "GROUP") {
            post_for_type = "PRODUCT_ON_FEED";
          } else if (post?.sharePosts?.product_id && post?.sharePosts?.share_post_for === "GROUP") {
            post_for_type = "PRODUCT_ON_GROUP";
          }

          final_object = {
            id: post?.id,
            content: post?.sharePosts?.content,
            user_id: post?.user_id,
            group_id: post?.sharePosts?.user_id,
            store_id: post?.sharePosts?.store_id,
            collection_id: post?.sharePosts?.collection_id,
            product_id: post?.sharePosts?.product_id,
            collection_control: post?.collection_control,
            post_for: post?.post_for,
            post_for_type: post_for_type,
            createdAt: post?.createdAt,
          };
        } else {
          final_object = {
            id: post?.id,
            content: post?.id,
            user_id: post?.user_id,
            group_id: post?.user_id,
            store_id: post?.store_id,
            collection_id: post?.collection_id,
            product_id: post?.product_id,
            collection_control: post?.collection_control,
            post_for: post?.post_for,
            post_for_type: post?.post_for_type,
            createdAt: post?.createdAt,
          };
        }

        let elkData = await elasticClient.post.addPost(final_object, "post");

        console.log("elkData>>>>>>>>>>>>>>>>>>>>>>", elkData);

        if (!elkData.success) throw new Error(elkData.message);
      }

      // console.log("get_post_data++++++++++++++++++++++++++", JSON.parse(JSON.stringify(get_post_data)));
    } catch (error) {
      console.log("<<<<<<<<<<<<< error >>>>>>>>>>>>>>", error);
    }
  },

  addCommentIntoElastic: async (root, { input }, { user }) => {
    try {
      // let elkData = await elasticClient.comment.createIndexForComment("comment");
      // console.log("elkData+++++++", elkData);
      let get_comment_data = await database.Comment.findAll({
        order: [["createdAt", "DESC"]],
        raw: true,
      });

      for (let i = 0; i < get_comment_data.length; i++) {
        let comment = get_comment_data[i];

        let final_object = {
          id: comment?.id,
          parent_id: comment?.parent_id,
          user_id: comment?.user_id,
          reply_id: comment?.reply_id,
          group_post_id: comment?.group_post_id,
          seller_post_id: comment?.seller_post_id,
          product_id: comment?.product_id,
          post_id: comment?.post_id,
          share_post_id: comment?.share_post_id,
          image: comment?.image,
          comment: comment?.comment,
          comment_for: comment?.comment_for,
          createdAt: comment?.createdAt,
        };
        let elkData = await elasticClient.comment.addComment(final_object, "comment");
        console.log("elkData", elkData);
      }

      // console.log("get_comment_data", get_comment_data);
    } catch (error) {
      console.log("error+++++++++++++++++++++", error);
    }
  },

  addLikeIntoElastic: async (root, { input }, { user }) => {
    try {
      let elkData = await elasticClient.like.createIndexForLike("like");
      console.log("elkData+++++++", elkData);
      let get_like_data = await database.Like.findAll({
        order: [["createdAt", "DESC"]],
        raw: true,
      });

      for (let i = 0; i < get_like_data.length; i++) {
        let like = get_like_data[i];

        let final_object = {
          id: like?.id,
          post_id: like?.post_id,
          comment_id: like?.comment_id,
          comment_reply_id: like?.comment_reply_id,
          product_id: like?.product_id,
          seller_post_id: like?.seller_post_id,
          group_post_id: like?.group_post_id,
          share_post_id: like?.share_post_id,
          like_for: like?.like_for,
          user_id: like?.user_id,
          createdAt: like?.createdAt,
        };
        let elkData = await elasticClient.like.addLike(final_object, "like");
        console.log("elkData", elkData);
      }

      // console.log("get_like_data", get_like_data);
    } catch (error) {
      console.log("error+++++++++++++++++++++", error);
    }
  },

  sendInvitation: async (root, { emails = [] }, { user }) => {
    console.log("emails++++++++++++++++++++++++++", emails);
    if (!user) throw new AuthenticationError("Invalid credentials");

    for (let i = 0; i < emails?.length; i++) {
      let email = emails[i];

      const find_invitation = await database.Invitation.findOne({
        where: {
          email: email,
          user_id: user?.id,
        },
        raw: true,
      });
      if (find_invitation) {
        const add_invitation = await database.Invitation.update(
          {
            count: find_invitation?.count + 1,
          },
          {
            where: {
              id: find_invitation?.id,
            },
          }
        );
      } else {
        const add_invitation = await database.Invitation.create({
          user_id: user?.id,
          email: email,
        });
      }
      try {
        const adminEmailData = {
          to: email,
          from: process.env.EMAIL_USER,
          subject: "Join the Bluejestic",
          html: `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Bluejestic email template</title>
    <!-- Removed external stylesheet for email compatibility -->
  </head>
  <body style="margin: 0; padding: 0;">
    <div class="email-template-body-main" style="width: 431px; background: #ffffff; box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px; padding: 0 0 19px 0; margin: 0 auto;">
      <div class="email-header-main" style="padding: 27px 30px 29px 30px;">
        <img src="https://bluejestic-media.storage.googleapis.com/bluejestic-stage/store/admin/logo-1729673477030-716112865.png" alt="main-logo" style="display: block; margin: 0 auto;" />
      </div>
      <div class="email-template-body" style="background: #000000; margin: 0 44px 20px 43px; padding: 23px 13px 37px 13px;">
        <div class="template-title" style="margin: 0 0 35px 0;">
          <p style="color: #a855f7; font-family: 'Inter', sans-serif; font-size: 14px; font-weight: 500; text-align: center;">Join the Bluejestic Beta 1.0</p>
        </div>
        <div class="email-template-heading-main" style="margin: 0 0 30px 0;">
          <h1 style="color: #ffffff; text-align: center; font-family: 'Inter', sans-serif; font-size: 20px; font-weight: 600; max-width: 235px; margin: 0 auto;">Shop, Connect, and Have Fun!</h1>
        </div>
        <div class="email-template-body-main-content" style="margin: 0 0 40px 0;">
          <p style="color: #ffffff; font-family: 'Inter', sans-serif; font-size: 12px; font-weight: 400;">
            You are invited to join #name# on Bluejestic Beta 1.0, the social
            shopping marketplace that mixes shopping with social entertainment –
            and we want you to join the fun! 🎉
          </p>
          <div>
            <p style="color: #ffffff; font-family: 'Inter', sans-serif; font-size: 12px; font-weight: 400;">✨ Why Join?</p>
            <ul style="margin: 0 0 0 22px; padding: 0;">
              <li style="color: #ffffff; font-family: 'Inter', sans-serif; font-size: 12px; font-weight: 400;">Entertainment Shopping: Watch live demos, join social clubs, and unlock real-time deals.</li>
              <li style="color: #ffffff; font-family: 'Inter', sans-serif; font-size: 12px; font-weight: 400;">Shop with Friends: Share recommendations, chat and earn groups-exclusive rewards.</li>
              <li style="color: #ffffff; font-family: 'Inter', sans-serif; font-size: 12px; font-weight: 400;">Beta-Only Perks: Early access, giveaways, and insider deals!</li>
            </ul>
          </div>
          <p style="color: #ffffff; font-family: 'Inter', sans-serif; font-size: 12px; font-weight: 400;">
            Be part of this exciting launch and help shape the future of
            Bluejestic!
          </p>
          <p style="color: #ffffff; font-family: 'Inter', sans-serif; font-size: 12px; font-weight: 400;">Let’s make shopping fun together! 🛍️🎬</p>
        </div>
        <div class="join-button-main" style="margin: 0 auto; width: 193px;">
          <button type="submit" style="margin: 0 auto; border-radius: 16px; background: linear-gradient(92deg, #556ee6 0.13%, #6b21a8 100%); border: none; cursor: pointer; width: 193px; height: 37px;">
            <a href="${process.env.FRONTEND_URL}" style="color: #ffffff; font-family: 'Inter', sans-serif; font-size: 15px; font-weight: 500; margin: 0;">Join the fun</a>
          </button>
        </div>
      </div>
      <div class="social-media-links-main" style="margin: 0 auto 27px auto; display: flex; width: 212px;">
   <img src="https://bluejestic-media.storage.googleapis.com/bluejestic-stage/store/admin/instagram-1729673477024-264476129.png" alt="instagram" style="display: block; margin: 0 29px 0 0;" />
        <img src="https://bluejestic-media.storage.googleapis.com/bluejestic-stage/store/admin/linkedin-1729673477029-909116396.png" alt="linkedin" style="display: block; margin: 0 29px 0 0;" />
        <img src="https://bluejestic-media.storage.googleapis.com/bluejestic-stage/store/admin/twitter-1729673477033-933917665.png" alt="twitter" style="display: block; margin: 0 29px 0 0;" />
        <img src="https://bluejestic-media.storage.googleapis.com/bluejestic-stage/store/admin/meta-1729673477031-419116402.png" alt="meta" style="display: block; margin: 0 29px 0 0;" />
      </div>
      <div class="template-links-text" style="display: flex; width: 232px; margin: 0 auto 24px auto;">
        <a href="" style="color: #000000; font-family: 'Inter', sans-serif; font-size: 12px; font-weight: 400; text-decoration: none; margin: 0 29px 0 0;">Home</a>
        <a href="" style="color: #000000; font-family: 'Inter', sans-serif; font-size: 12px; font-weight: 400; text-decoration: none; margin: 0 29px 0 0;">Terms</a>
        <a href="" style="color: #000000; font-family: 'Inter', sans-serif; font-size: 12px; font-weight: 400; text-decoration: none; margin: 0 29px 0 0;">Privacy</a>
        <a href="" style="color: #000000; font-family: 'Inter', sans-serif; font-size: 12px; font-weight: 400; text-decoration: none;">About</a>
      </div>
      <div class="template-copyright-text" style="margin: 0 auto; width: 235px;">
        <p style="color: #000000; font-family: 'Inter', sans-serif; font-size: 12px; font-weight: 400; margin: 0;">© 2024 Bluejestic Inc. All rights reserved.</p>
      </div>
    </div>
  </body>
</html>



`,
        };
        await sendEmail(adminEmailData)
          .then(() => {
            console.log("Send Successfully ");
          })
          .catch((err) => {
            console.log("Error Found", err);
          });
      } catch (error) {
        console.log("error", error);
      }
    }

    return { success: true, message: "Email Send Successfully" };
  },

  getInvitationData: async (root, { }, { user }) => {
    if (!user) throw new AuthenticationError("Invalid credentials");

    const get_invitation = await database.Invitation.findAll({
      where: {
        user_id: user?.id,
      },
      raw: true,
    });

    return { success: true, message: "Fetch Successfully", data: get_invitation };
  },
};
