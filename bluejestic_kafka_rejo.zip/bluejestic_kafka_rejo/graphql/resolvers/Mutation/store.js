const { AuthenticationError } = require("apollo-server-express");
const StoreService = require("../../../database/services/store");
const elasticClient = require("../../../services/elasticsearch");
const { Op, Sequelize } = require("sequelize");
// const elasticClient = require("../../services/elasticsearch");
const database = require("../../../database/models");
const client = require("../../../services/elasticsearch/config/config");
const { default: slugify } = require("slugify");

module.exports = {
  addStore: async (root, { input }, { user }) => {
    if (user !== null) {
      const StoreData = await StoreService.add(input);
      return StoreData;
    }
    return new AuthenticationError("Please Provide Token");
  },

  updateStore: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError("Please Provide Id where you update the product");
      }

      const foundStore = await database.BusinessInformation.findOne({
        where: {
          id: Number(input.id),
        },
      });

      if (foundStore && input?.name) {
        let stringA = foundStore.name.split(" ").join("");
        let stringB = input?.name.split(" ").join("");

        if (stringA === stringB) {
          return { success: null, message: "Store name Already Exist" };
        }
      }

      const StoreData = await StoreService.update(input);

      if (input?.logo?.length > 0 && Boolean(foundStore?.logo?.length) && Number(foundStore?.logo[0]) !== input?.logo) {
        let findStoreMedia = await database.Media.findOne({
          where: {
            id: {
              [Op.in]: input.logo,
            },
          },
        });
        input.logo = findStoreMedia?.media;
      }

      if (input?.cover_image?.length > 0 && Boolean(foundStore?.cover_image?.length) && Number(foundStore?.cover_image[0]) !== input?.cover_image) {
        let findStoreMedia = await database.Media.findOne({
          where: {
            id: {
              [Op.in]: input.cover_image,
            },
          },
        });
        input.cover_image = findStoreMedia?.media;
      }

      let elkData = await elasticClient.store.updateStoreById("store", input?.id, input);
      if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");
      if (Boolean(StoreData?.length)) {
        return { success: true, message: "updated successfully" };
      } else {
        return { success: null, message: "something wen wrong" };
      }
    }
    return new AuthenticationError("Please Provide Token");
  },

  updateAdminStore: async (root, { input }, { user }) => {
    if (user?.token_type !== "admin") return new AuthenticationError("Unauthorized");
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError("Please Provide Id where you update the product");
      }
      const foundStore = await database.BusinessInformation.findOne({
        where: {
          id: Number(input.id),
        },
      });

      // if (foundStore && input?.name) {
      //   let stringA = foundStore.name.split(" ").join("");
      //   let stringB = input?.name.split(" ").join("");

      //   if (stringA === stringB) {
      //     return { success: false, message: "Store name Already Exist" };
      //   }
      // }
      const StoreData = await StoreService.update(input);

      if (Boolean(input?.category?.length)) {
        for await (const cat of input?.category) {
          let find_entry = await database.StoreCategories.findOne({
            where: {
              store_id: input?.id,
              user_id: user?.id,
            },
          });
          if (find_entry) {
            await database.StoreCategories.update(
              { category_id: cat?.category_id, subCategory_id: cat?.subCategory_id },
              {
                where: {
                  store_id: Number(input?.id),
                },
              }
            );
          } else {
            await database.StoreCategories.create({ category_id: cat?.category_id, subCategory_id: cat?.subCategory_id, user_id: user?.id, store_id: input?.id });
          }
        }
      }

      const find_category = await database.Category.findOne({
        where: {
          id: input?.category[0]?.category_id,
        },
        raw: true,
      });

      const find_subCategory = await database.Subcategory.findOne({
        where: {
          id: input?.category[0]?.subCategory_id,
        },
        raw: true,
      });

      if (input?.logo?.length > 0 && Boolean(foundStore?.logo?.length)) {
        let findStoreMedia = await database.Media.findOne({
          where: {
            id: {
              [Op.in]: input.logo,
            },
          },
        });
        input.logo = findStoreMedia?.media;
      }

      if (input?.cover_image?.length > 0 && Boolean(foundStore?.cover_image?.length)) {
        let findStoreMedia = await database.Media.findOne({
          where: {
            id: {
              [Op.in]: input.cover_image,
            },
          },
        });
        input.cover_image = findStoreMedia?.media;
      }

      const elasticsearch_data = {
        seller_id: 152,
        id: input?.id,
        name: input?.name,
        companyLegalName: input?.companyLegalName,
        streetAddress: input?.streetAddress,
        city: input?.city,
        state: "FL",
        state_name: input?.state_name,
        postalCode: "33101",
        websiteUrl: input?.websiteUrl,
        businessType: input?.businessType,
        title: input?.title,
        logo: input?.media,
        cover_image: input?.media,
        shortDescription: input?.longDescription,
        longDescription: input?.longDescription,
        isFollow: true,
        isLikeShare: true,
        isNotification: true,
        isMessaging: true,
        isTrends: true,
        documents: [],
        BusinessInformationFor: "SELLER",
        category_id: input?.category[0]?.category_id,
        category: find_category?.name,
        subCategory_id: input?.category[0]?.subCategory_id,
        subCategory: find_subCategory?.name,
      };

      let elkData = await elasticClient.store.updateStoreById("store", input?.id, elasticsearch_data);
      if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");
      if (Boolean(StoreData?.length) && elkData) {
        return { success: true, message: "updated successfully" };
      } else {
        return { success: null, message: "something wen wrong" };
      }
    }
    return new AuthenticationError("Please Provide Token");
  },

  deleteStore: async (root, { id }, { user }) => {
    if (user !== null) {
      const Store = await StoreService.delete(id);

      return Store;
    }
    return new AuthenticationError("Please Provide Token");
  },

  deleteStoresByAdmin: async (root, { store_ids }, { user }) => {
    if (!user) return new AuthenticationError("Please provide the token!");
    if (user.role !== "admin") return new AuthenticationError("Unauthorized!");
    if (!Array.isArray(store_ids) || !store_ids.length) {
      return {
        success: false,
        message: "Please provide valid store id(s)!"
      }
    }
    try {

      const deletedStores = await StoreService.deleteStores(store_ids);

      const data = await elasticClient.store.deleteStoresByAdmin(store_ids, "store");
      return {
        success: true,
        message: "Store(s) deleted successfully." 
      }

    } catch (error) {
      console.error("An error occured while removing store(s): ", error);
      return {
        success: false,
        message: error?.message ?? "An error occured while removing store(s)!"
      }
    }

  },

  createStore: async (root, { input }, { user }) => {
    try {
      if (user?.token_type !== "admin") return new AuthenticationError("Unauthorized");
      if (!Boolean(input?.category?.length)) return { success: false, message: "Category Not Provided" };

      let slug = slugify(input?.name, { lower: true, replacement: "" });
      let final_slug;

      let is_exist = await database.BusinessInformation.findOne({
        where: {
          name: input?.name,
        },
      });

      if (is_exist) {
        return { success: false, message: "Store name already exist" };
      }

      let find_unique_user = await database.BusinessInformation.findOne({
        where: {
          slug: slug,
        },
        raw: true,
      });

      if (find_unique_user) {
        const otp = Math.floor(Math.random() * 900) + 100;
        final_slug = slug + otp;
      } else {
        final_slug = slug;
      }

      let { dataValues } = await database.BusinessInformation.create({ ...input, seller_id: 152, state: "FL", postalCode: "33101", country: "US", is_deleted: false, status: "Active", slug: final_slug });
      if (input?.category?.length > 0 && dataValues?.id) {
        for await (const cat of input?.category) {
          await database.StoreCategories.create({ category_id: cat?.category_id, subCategory_id: cat?.subCategory_id, store_id: dataValues?.id, user_id: user?.id });
        }
      }

      const find_category = await database.Category.findOne({
        where: {
          id: input?.category[0]?.category_id,
        },
        raw: true,
      });

      const find_subCategory = await database.Subcategory.findOne({
        where: {
          id: input?.category[0]?.subCategory_id,
        },
        raw: true,
      });

      if (dataValues?.id) {
        let find_logo = await database.Media.findOne({
          where: {
            id: input?.logo[0],
          },
          raw: true,
        });

        let find_cover = await database.Media.findOne({
          where: {
            id: input?.cover_image[0],
          },
          raw: true,
        });
        const elasticsearch_data = {
          seller_id: 152,
          id: dataValues?.id,
          slug: final_slug,
          name: input?.name,
          companyLegalName: input?.companyLegalName,
          streetAddress: input?.streetAddress,
          city: input?.city,
          state: "FL",
          state_name: input?.state,
          postalCode: "33101",
          websiteUrl: input?.websiteUrl,
          businessType: input?.businessType,
          title: input?.title,
          logo: find_logo?.media,
          cover_image: find_cover?.media,
          shortDescription: input?.longDescription,
          longDescription: input?.longDescription,
          isFollow: true,
          isLikeShare: true,
          isNotification: true,
          isMessaging: true,
          isTrends: true,
          is_deleted: false,
          documents: [],
          BusinessInformationFor: "SELLER",
          category_id: input?.category[0]?.category_id,
          category: find_category?.name,
          subCategory_id: input?.category[0]?.subCategory_id,
          subCategory: find_subCategory?.name,
          status: "Active",
        };
        let create_store_elastic = await elasticClient.store.createStore(elasticsearch_data);
        if (!create_store_elastic?.success) return new Error(create_store_elastic?.message || "Elasctic search error");
      } else {
        return { success: false, message: "Something went wrong" };
      }
      return { success: true, message: "Store Created Successfully" };
    } catch (error) {
      console.error("Server started.", error);
      throw error;
    }
  },

  removeStore: async (root, { store_id }, { user }) => {
    try {
      if (user.token_type !== "admin") return new AuthenticationError("Unauthorized");
      for (let i = 0; i < store_id?.length; i++) {
        let id = store_id[i];
        const product = await database.BusinessInformation.findOne({ where: { id: id, is_deleted: false } });
        if (!product) {
          return new UserInputError("Store Already Deleted otherwise Store not found");
        }
        if (product) {
          await StoreService.delete(id);
          const isExists = await client.search({
            index: "store",
            body: {
              query: {
                match: {
                  id: id,
                },
              },
            },
          });
          if (Boolean(isExists?.hits?.hits?.length) && isExists.hits.hits[0]?._source) {
            let data = await elasticClient.store.updateStoreById("store", product.id, { ...isExists.hits.hits[0]._source, is_deleted: true });
            if (!data.success) return new Error("Elasticsearch - addProduct - " + data.message);
          }
        }
      }
      return { success: true, message: "Status Updated Successfully" };
    } catch (error) {
      console.log("error++++++++++++++++++++++++++", error);
    }
  },

  updateStoreStatus: async (root, { store_id, status }, { user }) => {
    const status_array = ["Active", "Inactive"];
    if (user.token_type !== "admin") return new AuthenticationError("Unauthorized");
    if (!status_array.includes(status)) return { success: true, message: "Please Provide Valid Status" };
    for (let i = 0; i < store_id?.length; i++) {
      let id = store_id[i];
      const result = await database.BusinessInformation.update(
        { status: status },
        {
          where: {
            id: id,
          },
        }
      );

      if (result) {
        const isExists = await client.search({
          index: "store",
          body: {
            query: {
              match: {
                id: id,
              },
            },
          },
        });

        if (Boolean(isExists?.hits?.hits?.length) && isExists.hits.hits[0]?._source) {
          let data = await elasticClient.store.updateStoreById("store", id, { ...isExists.hits.hits[0]._source, status: status });
          if (!data.success) return new Error("Elasticsearch - addProduct - " + data.message);
        }
        process.nextTick(async () => {
          if (status === "Active") {
            let get_product_count = await database.Product.update(
              {
                status: "Publish",
              },
              {
                where: {
                  store_id: id,
                },
              }
            );
            const updateResponse = await client.updateByQuery({
              index: "products",
              body: {
                script: {
                  source: "ctx._source.status = params.status",
                  params: {
                    status: "Publish",
                  },
                },
                query: {
                  match: {
                    store_id: id,
                  },
                },
              },
              refresh: true,
            });
          } else if (status === "Inactive") {
            let get_product_count = await database.Product.update(
              {
                status: "Draft",
              },
              {
                where: {
                  store_id: id,
                },
              }
            );
            const updateResponse = await client.updateByQuery({
              index: "products",
              body: {
                script: {
                  source: "ctx._source.status = params.status",
                  params: {
                    status: "Draft",
                  },
                },
                query: {
                  match: {
                    store_id: id,
                  },
                },
              },
              refresh: true,
            });
          }
        });
      }
    }
    return { success: true, message: "Status Updated Successfully" };
  },

  updateStoreCategory: async (root, { store_id, category_id, subCategory_id }, { user }) => {
    if (user.token_type !== "admin") return new AuthenticationError("Unauthorized");
    for (let i = 0; i < store_id?.length; i++) {
      let id = store_id[i];
      let updated;
      let get_entry = await database.StoreCategories.findOne({
        where: {
          store_id: id,
        },
      });
      if (get_entry) {
        updated = await database.StoreCategories.update(
          { category_id: category_id, subCategory_id: subCategory_id },
          {
            where: {
              store_id: id,
            },
          }
        );
      } else {
        let get_store = await database.BusinessInformation.findOne({
          where: {
            id: id,
          },
        });
        if (get_store) {
          updated = await database.StoreCategories.create({ category_id: category_id, subCategory_id: subCategory_id, store_id: id, user_id: user?.id });
        }
      }

      let find_category = await database.Category.findOne({
        where: {
          id: category_id,
        },
        raw: true,
      });

      let find_subCategory = await database.Subcategory.findOne({
        where: {
          id: subCategory_id,
        },
        raw: true,
      });

      console.log("find_subCategory++++++++++++++++++++++++++++", find_category?.name, find_subCategory?.name);

      if (updated && find_category && find_subCategory) {
        const isExists = await client.search({
          index: "store",
          body: {
            query: {
              match: {
                id: id,
              },
            },
          },
        });
        if (Boolean(isExists?.hits?.hits?.length) && isExists.hits.hits[0]?._source) {
          let data = await elasticClient.store.updateStoreById("store", id, {
            ...isExists.hits.hits[0]._source,
            category: find_category?.name ? find_category?.name : "",
            category_id: find_category?.id ? find_category?.id : "",
            subCategory: find_subCategory?.name ? find_subCategory?.name : "",
            subCategory_id: find_subCategory?.id ? find_subCategory?.id : "",
          });
          if (!data.success) return new Error("Elasticsearch - addProduct - " + data.message);
        }
      }
    }
    return { success: true, message: "Status Updated Successfully" };
  },

  updateStoreDetailForAdmin: async (root, { input }, { user }) => {
    if (user?.token_type !== "admin") return new AuthenticationError("Unauthorized");
    if (!input?.store_id) {
      return { success: false, message: "Please Provide store_id" }
    }
    try {
      const find_storeDetail = await database.StoreDetail.findOne({
        where: {
          store_id: input?.store_id
        },
        attributes: ['id'],
        raw: true
      })

      if (find_storeDetail) {
        const [update_store_detail] = await database.StoreDetail.update({
          ...input
        }, {
          where: {
            store_id: input?.store_id
          }
        })
        if (update_store_detail) {
          return { success: true, message: 'Store Detail Updated!' }
        } else {
          return { success: true, message: 'Something went wrong!' }
        }
      } else {
        const create_store_detail = await database.StoreDetail.create({
          ...input
        })
        return { success: true, message: 'Store Detail Generated!' }
      }

    } catch (error) {
      console.log('error', error);
    }
  }
};
