const {AuthenticationError} = require('apollo-server-express');
const OfferService = require('../../../database/services/offer');
module.exports = {
addOffer : async(root, {input}, {user}) => {
    console.log("Add Follow detail", input);
    
    if(user !== null){
        const offer = await OfferService.add(input);
        return offer
    }
    return new AuthenticationError("Please Provide Token")
},
updateOffer:async(root, {input}, {user} ) => {
    
    if(user !== null){
        if(!input.id){
            return  new AuthenticationError("Please Provide Id where you update the offer")
        }
        const offer = await OfferService.update(input)
        return offer
    }
    return new AuthenticationError("Please Provide Token")
},
deleteOffer:async(root, {id}, {user} ) => {
    
    if(user !== null){
        
        const offer = await OfferService.delete(id)
        
        return offer
    }
    return new AuthenticationError("Please Provide Token")
}
}