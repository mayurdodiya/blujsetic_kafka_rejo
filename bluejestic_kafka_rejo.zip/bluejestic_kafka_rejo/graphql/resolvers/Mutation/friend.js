const { AuthenticationError } = require("apollo-server-express");
const FriendService = require("../../../database/services/friend");
const elasticClient = require("../../../services/elasticsearch");
const database = require("../../../database/models");
const redisClient = require("../../../redis/redisClient");
module.exports = {
  addFriend: async (root, { input }, { user }) => {
    console.log("Add Friend ", input);

    if (user !== null) {
      const isExist = await database.Friend.findOne({
        where: {
          user_id: input.user_id,
          friend_id: input.friend_id,
        },
      });
      if (isExist) {
        return new Error("Friend request already sent");
      }
      const friend = await FriendService.add(input);
      let userType = ["FOLLOWERS", "FOLLOWING", "SUGGESTED_PEOPLE", "ALL_PEOPLE"];

      process.nextTick(async () => {
        await redisClient.del(`PUBLIC:ALL_PEOPLE`);
        for (let i = 0; i < userType.length; i++) {
          let type = userType[i];
          await redisClient.del(`USER/${user?.id}:${type}`);
        }
      });
      let elasticData = { ...input, id: friend.id };
      let elkData = await elasticClient.userFriends.addUserFriends(elasticData);
      if (!elkData.success) return new Error(elkData.message);
      return friend;
    }
    return new AuthenticationError("Please Provide Token");
  },

  updateFriend: async (root, { input }, { user }) => {
    console.log("Update Friend ", input);
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError("Please Provide Id where you update the friend");
      }
      const friend = await FriendService.update(input);
      /* update user friends details in elastic search */
      let elkData = await elasticClient.userFriends.updateUserFriendsById(input.id, input);
      if (!elkData.success) return new Error(elkData.message);
      return friend;
    }
    return new AuthenticationError("Please Provide Token");
  },

  deleteFriend: async (root, { user_id, friend_id }, { user }) => {
    if (user !== null) {
      const friend = await FriendService.delete(user_id, friend_id);
      console.log("Delete Friend ", friend);
      /* delete user friends details in elastic search */
      let storeTypes = ["FOLLOWERS", "FOLLOWING", "SUGGESTED_PEOPLE", "ALL_PEOPLE"];

      process.nextTick(async () => {
        await redisClient.del(`PUBLIC:ALL_PEOPLE`);
        for (let i = 0; i < storeTypes.length; i++) {
          let type = storeTypes[i];
          await redisClient.del(`USER/${user?.id}:${type}`);
        }
      });
      let elkData = await elasticClient.userFriends.deleteUserFriend({ user_id, friend_id });
      if (!elkData.success) return new Error(elkData.message);
      return friend;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
