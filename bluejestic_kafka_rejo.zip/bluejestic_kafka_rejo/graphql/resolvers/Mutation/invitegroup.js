const { AuthenticationError } = require("apollo-server-express");
const InviteGroupServices = require("../../../database/services/invtegroup");
module.exports = {
  inviteGroups: async (root, { input }, { user }) => {
    if (user !== null) {
      if (input.user_id.length > 0) {
        const inviteGroup = await InviteGroupServices.add(input);
        return inviteGroup;
      } else {
        return new AuthenticationError("Please Provide User Id in array");
      }
    }
    return new AuthenticationError("Please Provide Token");
  },
  acceptInviteGroups: async (root, { group_id, isAdmin }, { user }) => {
    if (user !== null) {
      let inviteGroup = await InviteGroupServices.joinByGroupId(
        group_id,
        user.id,
        isAdmin
      );
      return inviteGroup;
    }
    return new AuthenticationError("Please Provide Token");
  },
  cancleInviteGroupRequest: async (root, args, { user }) => {
    if (user !== null) {
      let isInviteGroupExist = await InviteGroupServices.isExistInviteGroup(
        args.user_id,
        args.group_id
      );
      if (!isInviteGroupExist)
        return new AuthenticationError("Invite Group Not Found");
      const inviteGroup = await InviteGroupServices.cancle(
        args.user_id,
        args.group_id
      );

      return inviteGroup;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
