const { AuthenticationError } = require("apollo-server-express");
const SubCategoryService = require("../../../database/services/subcategory");
module.exports = {
  addSubCategory: async (root, { name, image_id, banner_id, description, is_deleted = false, category_id, position }, { user }) => {
    if (user !== null) {
      const subcategory = await SubCategoryService.add({ name, image_id, banner_id, description, is_deleted, category_id, position });
      return subcategory;
    }
    return new AuthenticationError("Please Provide Token");
  },

  updateSubCategory: async (root, args, { user }) => {
    if (user !== null) {
      if (!args?.id) {
        return new AuthenticationError("Please Provide Id where you update the category");
      }
      const category = await SubCategoryService.update({ ...args });
      return category;
    }
    return new AuthenticationError("Please Provide Token");
  },

  deleteSubCategory: async (root, { id }, { user }) => {
    if (user !== null) {
      const category = await SubCategoryService.delete(id);

      return category;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
