const {AuthenticationError} = require('apollo-server-express')
const NotificationService = require('../../../database/services/notification')
module.exports = {
addNotification : async(root, {input}, {user}) => {
    if(user !== null){
        const notificationData = await NotificationService.add(input);
        return notificationData
    }
    return new AuthenticationError("Please Provide Token")
},
updateNotification: async(root, {input}, {user} ) => {
    
    if(user !== null){
        if(!input.id){
            return  new AuthenticationError("Please Provide Id where you update the Notification detail")
        }

        const notificationData = await NotificationService.update(input)
        return notificationData
    }
    return new AuthenticationError("Please Provide Token")
},
deleteNotification: async(root, {id}, {user} ) => {
    if(user !== null){
        if(!id){
            return  new AuthenticationError("Please Provide Id where you delete the Notification detail")
        }
        
        const notification = await NotificationService.delete(id)
        return notification
    }
    return new AuthenticationError("Please Provide Token")
}
}