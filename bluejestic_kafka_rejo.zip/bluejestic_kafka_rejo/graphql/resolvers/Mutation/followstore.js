const { AuthenticationError } = require("apollo-server-express");
const FollowStoreService = require("../../../database/services/followstore");
const elasticClient = require("../../../services/elasticsearch");
const redisClient = require("../../../redis/redisClient");
const client = require("../../../services/elasticsearch/config/config");
module.exports = {
  followStore: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!user.id) {
        new AuthenticationError("Please Provide Valid Token Can't get id");
      }
      input.user_id = user.id;

      const isFollowStore = await FollowStoreService.getById(input.store_id, input.user_id);
      if (isFollowStore) {
        return new AuthenticationError("You are already following this store");
      }
      const followStore = await FollowStoreService.add(input);
      let storeTypes = ["JOIN_STORES", "SUGGESTED_STORES", "ALL_STORE"];

      process.nextTick(async () => {
        if (!isFollowStore) {
          await redisClient.del(`PUBLIC:ALL_STORE`);
          for (let i = 0; i < storeTypes.length; i++) {
            let type = storeTypes[i];
            await redisClient.del(`USER/${user?.id}:${type}`);
          }
          const indexName = "store";
          const fieldToUpdate = "followers_count";
          const increaseValue = 1;
          console.log("follow >>>>>>>>>>>>>>>>> called ");
          const {
            hits: { hits },
          } = await client.search({
            index: indexName,
            body: {
              query: {
                bool: {
                  must: [
                    {
                      match: { id: input?.store_id },
                    },
                  ],
                },
              },
            },
          });

          if (Boolean(hits?.length)) {
            let data = hits[0];
            const updatedQuantity = data?._source[fieldToUpdate] + increaseValue;
            const update_query = await client.update({
              index: indexName,
              id: data?._id,
              body: {
                doc: {
                  [fieldToUpdate]: updatedQuantity,
                },
              },
            });
            console.log("existData+++++++++++++++++++++++", update_query);
          }
        }
      });

      return followStore;
    }
    return new AuthenticationError("Please Provide Token");
  },

  updateFollowStore: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError("Please Provide Id where you update the followStore");
      }
      const followStore = await FollowStoreService.update(input);
      return followStore;
    }
    return new AuthenticationError("Please Provide Token");
  },

  unFollowStore: async (root, { storeId }, { user }) => {
    if (user !== null) {
      if (!user.id) {
        new AuthenticationError("Please Provide Valid Token Can't get id");
      }
      const followStore = await FollowStoreService.delete(storeId, user.id);
      let storeTypes = ["JOIN_STORES", "SUGGESTED_STORES", "ALL_STORE"];

      process.nextTick(async () => {
        await redisClient.del(`PUBLIC:ALL_STORE`);
        for (let i = 0; i < storeTypes.length; i++) {
          let type = storeTypes[i];
          await redisClient.del(`USER/${user?.id}:${type}`);
        }
        const indexName = "store";
        const fieldToUpdate = "followers_count";
        const increaseValue = 1;
        console.log("unfollow >>>>>>>>>>>>>>>>> called ");

        const {
          hits: { hits },
        } = await client.search({
          index: indexName,
          body: {
            query: {
              bool: {
                must: [
                  {
                    match: { id: storeId },
                  },
                ],
              },
            },
          },
        });

        if (Boolean(hits?.length)) {
          let data = hits[0];
          const updatedQuantity = data?._source[fieldToUpdate] === 0 ? 0 : data?._source[fieldToUpdate] - increaseValue;
          const update_query = await client.update({
            index: indexName,
            id: data?._id,
            body: {
              doc: {
                [fieldToUpdate]: updatedQuantity,
              },
            },
          });
          console.log("existData+++++++++++++++++++++++", update_query);
        }
      });

      // if (!elkData.success) {
      //   return new Error(elkData.message);
      // }
      /* comment using kafka*/
      // global.kafkaConfig.produce("store-followers", { data: -1 })
      return followStore;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
