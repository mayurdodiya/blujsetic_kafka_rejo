const { AuthenticationError } = require("apollo-server-express");
const database = require("../../../database/models");
module.exports = {
  addUserLocationActivity: async (root, { input }, { user }) => {
    if (user !== null) {
      input.userType = user.token_type;
      input.user_id = user.id;
      console.log(input);
      const UserLocationActivity = await database.UserLocationActivity.create(input);
      return { success: true, message: "activity stored", data: [UserLocationActivity] };
    }
    return new AuthenticationError("Please Provide Token");
  },
  updateUserLocationActivity: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError(
          "Please Provide Id where you update the UserLocationActivity detail"
        );
      }

      const UserLocationActivity = await UserLocationActivityService.update(input);
      return UserLocationActivity;
    }
    return new AuthenticationError("Please Provide Token");
  },
  deleteUserLocationActivity: async (root, { id }, { user }) => {
    if (user !== null) {
      if (!id) {
        return new AuthenticationError(
          "Please Provide Id where you delete the UserLocationActivity detail"
        );
      }

      const UserLocationActivity = await UserLocationActivityService.delete(id);

      return UserLocationActivity;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
