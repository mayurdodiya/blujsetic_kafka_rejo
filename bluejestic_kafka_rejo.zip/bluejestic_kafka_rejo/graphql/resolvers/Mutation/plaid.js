const { AuthenticationError } = require("apollo-server-express");
const database = require("../../../database/models");


module.exports = {
  //* For create plaid link token
  createPlaidLinkToken: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide Token!");
    try {

        const response = await plaidClient.linkTokenCreate({
            user: { client_user_id: user?.id },
            client_name: `${user?.firstName} ${user?.lastName}`,
            products: ['auth', "transactions", "identity", "balance", "payment_initiation"],
            country_codes:  input?.country_codes ?? ['US'],
            language: input?.language ?? 'en',
          });

          if (response) {
            await database.PlaidAccount.create({
              user_id: user?.id,
              role: user?.role ?? "seller",
              link_token: response?.link_token
            });
          }

        return {
            success: true,
            message: "Plaid link token fetched successfully.",
            data: response
        }
    } catch (error) {
      console.log("An error while creating plain token link", error);
      throw new Error("An error while creating plain token link");
    }
  },
  
  getAccessTokenForPlaid: async (root, { public_token }, { user }) => {
    try {
      const response = await plaidClient.itemPublicTokenExchange({
        public_token
      });

      if (response) {
        await database.PlaidAccount.update({
          public_token: public_token,
          access_token: response?.access_token,
          item_id: response?.item_id
        }, {
          where: {
            user_id: user?.id
          }
        })
      }

      return {
        success: true,
        message: "Access token fetched successfully.",
        data: response
      }
    } catch (error) {
      console.log("An error while getting access token for plaid", error);
      throw new Error("An error while getting access token for plaid");
    }
  },
};  


