const {AuthenticationError} = require('apollo-server-express')
const SizeService = require('../../../database/services/size')
module.exports = {
addSize : async(root, {input}, {user}) => {
    
    if(user !== null){
        const ColoeData = await SizeService.add(input);
        return ColoeData
    }
    return new AuthenticationError("Please Provide Token")
},
updateSize:async(root, {input}, {user} ) => {
    
    if(user !== null){
        if(!input.id){
            return  new AuthenticationError("Please Provide Id where you update the product")
        }

        const ColorData = await SizeService.update(input)
        return ColorData
    }
    return new AuthenticationError("Please Provide Token")
},
deleteSize:async(root, {id}, {user} ) => {
    
    if(user !== null){
        
        const Color = await SizeService.delete(id)
        
        return Color
    }
    return new AuthenticationError("Please Provide Token")
}
}