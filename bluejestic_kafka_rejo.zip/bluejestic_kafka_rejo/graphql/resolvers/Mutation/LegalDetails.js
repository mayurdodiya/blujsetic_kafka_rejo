const { AuthenticationError } = require("apollo-server-express");
const LegalDetailsService = require("../../../database/services/LegalDetails");
module.exports = {
  addLegalDetails: async (root, { input }, { user }) => {
    if (user !== null) {
      const LegalDetails = await LegalDetailsService.add(input);
      return LegalDetails;
    }
    return new AuthenticationError("Please Provide Token");
  },
  //   updateLegalDetailsDetail: async (root, { input }, { user }) => {
  //     if (user !== null) {
  //       if (!input.id) {
  //         return new AuthenticationError(
  //           "Please Provide Id where you update the LegalDetails"
  //         );
  //       }
  //       const LegalDetails = await LegalDetailsService.update(input);
  //       return LegalDetails;
  //     }
  //     return new AuthenticationError("Please Provide Token");
  //   },
  //   deleteLegalDetailsDetail: async (root, { id }, { user }) => {
  //     if (user !== null) {
  //       const LegalDetails = await LegalDetailsService.delete(id);

  //       return LegalDetails;
  //     }
  //     return new AuthenticationError("Please Provide Token");
  //   },
};
