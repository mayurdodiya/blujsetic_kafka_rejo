const { AuthenticationError } = require("apollo-server-express");
const CartService = require("../../../database/services/cart");
const database = require("../../../database/models/index");
const { stringToUrl, findCropImages } = require("../../../utils/utils");
const { Op } = require("sequelize");

module.exports = {
  createCart: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide Token");
    try {
      
      const userData = await database.Seller.findOne({
        where: { id: user.id },
      });
      input.user_id = user.id;

      // const product = await database.Product.findOne({ where: { id: input.parent_id, is_deleted : false } });
      let product = await database.Product.findOne({
        where: {
          id: input.parent_id,
          is_deleted: false,
        },
        include: [
          {
            model: database.BusinessInformation,
            as: "store",
            attributes: ["id"],
            include: [
              {
                model: database.Seller,
                as: "personalInformation",
                attributes: ["id"],
              }
            ]
          }
        ]
      });

      if (!product) {
        return { success: false, message: "Product not found" };
      }

      product = JSON.parse(JSON.stringify(product));

      const productData = await CartService.getProductById(input.parent_id, input?.variant_id, user.id);
      // let payload = {
      //   product,
      //   user: userData,
      // };
      let CartData;
      if (!productData) {
        CartData = await CartService.add({ ...input, status: "cart_created",store_id: product?.store?.id ?? null, seller_id: product?.store?.personalInformation.id ?? null });
        // payload.quantity = CartData.quantity;
      } else {
        let data = {
          id: productData.id, 
          quantity: productData.quantity + input.quantity,
        };
        let [response] = await database.Cart.update({ ...data, status:"cart_updated"}, {
          where: {
            parent_id: Number(input.parent_id),
            user_id: Number(user.id),
            // variant_id: input?.variant_id,
            // ...(input?.variant_id && {
            //   variant_id: input?.variant_id,
            // }),
          },
        });
        if (response) {
          CartData = await database.Cart.findOne({
            where: {
              parent_id: Number(input.parent_id),
              user_id: Number(user.id),
              // variant_id: input.variant_id,
              // ...(input?.variant_id && {
              //   variant_id: input?.variant_id,
              // }),
            },
          });
        }
        // payload.quantity = CartData.quantity;
      }
      return { success: true, message: "Product added to the cart successfully.", cart: { product: { id: input.parent_id }, quantity: CartData.quantity } };

    } catch (error) {
      console.error("An error occured while adding product to the cart: ", error);
      return { success: false, message: error?.message ?? "An error occured while adding product to the cart!" };
    }
    
  },

  updateCart: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide Token");
      try {
        const { parent_id, variant_id, quantity, cart_for } = input;
        const find_product = await database.Product.findOne({
          where: {
            id: parent_id,
          },
          include: [
            {
              model: database.ProductItem,
              as: "variants",
              // ...(variant_id && {
              //   where: {
              //     id: variant_id,
              //   },
              // }),
              attributes: ["id", "inventory_quantity", "old_inventory_quantity"],
            },
            {
              model: database.ProductInventory,
              as: "inventoryPrice",
              attributes: ["price", "listPrice", "quantity", "sku"],
            },
          ],
        });

        const product = JSON.parse(JSON.stringify(find_product));

        if (product?.variants?.length) {
          if (!variant_id) return { success: false, message: "Please Provide variant_id!" };
          const find_variant = await product.variants.find((v) => v?.id === variant_id);

          if (!find_variant) return { success: false, message: "Variant not Found" };

          if (variant_id === find_variant?.id) {
            if (quantity <= find_variant?.inventory_quantity) {
              let [response] = await database.Cart.update({ ...input, status: "cart_updated" }, {
                where: {
                  parent_id: Number(parent_id),
                  user_id: Number(user?.id),
                  status: {
                    [Op.in]: ["cart_created", "cart_updated", "checkout_initiated", "cart_abandoned"]
                  }
                },
              });
              return { success: true, message: "Quantity Updated Successfully" };
            } else {
              return { success: false, message: "Quantity not found" };
            }
          } else {
            return { success: false, message: "Variant not Found" };
          }
        } else {
          if (quantity <= product?.inventoryPrice?.quantity) {
            // console.log("dsasdasdasdasdasda555555555555", quantity <= product?.inventoryPrice?.quantity);
            let [response] = await database.Cart.update(
              {
                parent_id: parent_id,
                quantity: quantity,
                cart_for: cart_for,
                status: "cart_updated",
              },
              {
                where: {
                  parent_id: Number(parent_id),
                  user_id: Number(user?.id),
                  status: {
                    [Op.in]: ["cart_created", "cart_updated", "checkout_initiated", "cart_abandoned"]
                  }
                },
              }
            );
            if (response) {
              return { success: true, message: "Quantity Updated Successfully" };
            } else {
              return { success: false, message: "Something went wrong" };
            }
          } else {
            return { success: false, message: "Quantity not found" };
          }
        }
      } catch (error) {
        console.log("An error occurred while updating the cart item quantity: ", error);
        return { success: false, message: error?.message ?? "An error occurred while updating the cart item quantity!" };
      }
  },

  deleteCart: async (root, { id }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide Token");
    try {
      
      if (!id) {
        return new AuthenticationError("Please Provide Id where you delete the Cart item");
      }
      const Cart = await CartService.delete(id);
      return { success: true, message: "Cart Deleted Successfully", cart: Cart };
      
    } catch (error) {
      console.error("An Error occurred while deleting the cart: ", error);
    }
  },

  deleteCartItems: async (root, { id }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide Token!");
    if (!id || !id.length) {
      return {
        success: false,
        message: "Please Provide Id/s whereas you want to delete the Cart items!"
      }
    }
    try {
      
      const deletedCount = await CartService.deleteCartItems(id);
      if (deletedCount === 0) return { success: false, message: "Cart Items Not Found!" };
      return { success: true, message: `${deletedCount} cart item${deletedCount > 1 ? "s" : ""} Deleted Successfully.` };
    } catch (error) {
      console.error("An error occured while deleting the cart items: ", error);
      return { success: false, message: error?.message ?? "An error occurred while deleting the cart items!" };
    }
  },

  insertSelectedCartItems: async (_, { input }, { user }) => {
    if (!user) {
      return {
        success: false,
        message: "Please Provide Token",
        data: [],
      };
    }
    let userId = user.id;
    let { products } = input;
    if (products.length <= 0) {
      return {
        success: false,
        message: "Products can't be empty",
        data: [],
      };
    }
    let selectedProducts = [];
    for (const product of products) {
      /* Found Products  */
      let productData = await database.Product.findOne({
        where: { id: product.productId, is_deleted: false },
      });
      // console.log("productData", JSON.parse(JSON.stringify(productData)));
      // console.log("[[[[[[[[[[[[[]]]]]]]]]]]]]", product.productId);
      if (!productData) return { success: false, message: "Products Not Found", data: [] };
      selectedProducts.push({
        product_id: productData.id,
        user_id: userId,
        store_id: productData.store_id,
        quantity: product.quantity,
        isSell: false,
      });
    }
    for (const product of selectedProducts) {
      await database.SelectedCartItems.create(product);
    }
    return { success: true, message: "Selected Products stored", data: selectedProducts };
  },

  deleteSelectedCartItems: async (_, { input }, { user }) => {
    if (!user) {
      return {
        success: false,
        message: "Please Provide Token",
        data: [],
      };
    }
    let userId = user.id;

    await database.SelectedCartItems.destroy({
      where: {
        user_id: Number(userId),
        isSell: false,
      },
    });
    return { success: true, message: "Selected Products Deleted" };
  },

  getSelectedProducts: async (_, { input }, { user }) => {
    try {
      if (!user) {
        return {
          success: false,
          message: "Please Provide Token",
          data: [],
        };
      }

      let variant_id = input.products.map((i) => i.variant_id);
      if (variant_id.length <= 0) {
        return { success: false, message: "Store's Product Not Found", carts: [], count: 0 };
      }

      let product_id_array = input.products.map((i) => i.product_id);

      let quantity = input.products.map((i) => i.quantity);
      if (quantity.length <= 0 || quantity.length <= 0) {
        return { success: false, message: "Store's Product Not Found", carts: [], count: 0 };
      }

      let products = [];

      for (const iterator of input?.products) {
        let get_allProduct = await database.Product.findOne({
          where: {
            id: iterator?.product_id,
          },
          include: [
            {
              model: database.ProductItem,
              ...(iterator.variant_id && {
                where: {
                  id: iterator.variant_id,
                },
              }),
              as: "variant",
              attributes: ["id", "title", "price", "listPrice", "sku", "barcode", "inventory_quantity", "old_inventory_quantity", "isTaxable", "image_id", "height", "width", "length", "weightValue", "weightUnit", "product_id"],
              include: [
                {
                  model: database.ProductConfiguration,
                  as: "total_variant",
                  attributes: ["id", "variant_option_id"],
                  include: [
                    {
                      model: database.VariationOption,
                      as: "variant_option",
                      attributes: ["value", "variation_id", "colorCode"],
                      include: [{ model: database.Variation, as: "data", attributes: ["name"] }],
                    },
                  ],
                },
                {
                  model: database.Media,
                  as: "image",
                  attributes: ["media"],
                },
              ],
            },
            {
              model: database.ProductShippingDetails,
              as: "shipping",
            },
            {
              model: database.ShippingMethod,
              as: "shipping_method",
              attributes: ["service_code"],
            },
            {
              model: database.ProductMedia,
              as: "images",
              attributes: ["id", "src", "media_id"],
            },
            {
              model: database.ProductInventory,
              as: "inventoryPrice",
              attributes: ["id", "price", "listPrice", "quantity", "sku"],
            },
            {
              model: database.BusinessInformation,
              as: "store",
              attributes: ["id", "name", "logo"],
            },
          ],
        });
        const updated_product = JSON.parse(JSON.stringify(get_allProduct));
        products.push(updated_product);
      }

      console.log("products===================", products);

      // const products = JSON.parse(JSON.stringify(products_all));

      for await (const iterator of products) {
        let matchingVariant = await input.products.find((firstItem) => firstItem.variant_id === iterator?.variant?.id);
        let matchingProduct = await input.products.find((firstItem) => firstItem.product_id === iterator.id);

        if (matchingVariant) {
          iterator.selected_quantity = matchingVariant.quantity;
        } else if (matchingProduct) {
          iterator.selected_quantity = matchingProduct.quantity;
        } else {
          iterator.selected_quantity = 0;
        }
      }

      let result = products;

      function unique(array, propertyName) {
        return array.filter((e, i) => array.findIndex((a) => a[propertyName] === e[propertyName]) === i);
      }

      let store = unique(
        result.map((i) => i.store),
        "id"
      );
      function arrayOfCartItem(store, array) {
        let arr = [];
        store.forEach((s) => {
          let product = array.filter((i) => i.store.id === s.id);
          arr.push({ storeDetail: s, product: product });
        });
        return arr;
      }

      let final = [];

      for (const { storeDetail, product } of arrayOfCartItem(store, result)) {
        let store_logo = await database.Media.findOne({
          where: { id: Number(storeDetail?.logo[0]) },
        });
        await final.push({
          storeDetail: { ...storeDetail, logo_url: store_logo?.dataValues?.media },
          product: product,
        });
      }

      return { sucess: true, message: "Selected cart items get successfully", carts: final, count: 0 };
    } catch (error) {
      console.log("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", error);
    }
  },

  getCalculation: async (_, { input }, { user }) => {
    try {
      let { product_data } = input;
    } catch (error) {
      console.log("error", error);
    }
  },

  changeCartItemsStatus: async (_, {}, { user }) => {
    if (!user) return new AuthenticationError("Please Provide Token");
    try {
      const response = await CartService.updateStatus({ status: "checkout_initiated" }, user?.id);
      if (response) {
        return { 
          success: true,
          message: "Cart status changed successfully."
         };
      }

    } catch (error) {
      console.error("An error occured while changing cart items status: ", error);
      return {
        success: false,
        message: error?.message ?? "An error occurred while changing cart items status!"
      }
    }
  },
};
