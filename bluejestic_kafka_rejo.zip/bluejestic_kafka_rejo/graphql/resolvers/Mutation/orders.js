const elasticClient = require("../../../services/elasticsearch");
const database = require("../../../database/models");
const config = require("../../../database/config/stripe");
const { chargesOnPrices, order_number_generator, createShipment, estimatedShippingCharges, createLabelForShipment, trackUsingLabelId, cancelShipment } = require("../../../utils/utils");
const { Sequelize } = require("sequelize");
const { default: axios } = require("axios");
const { AuthenticationError } = require("apollo-server-express");
const stripe = require("stripe")(config.stripeSecretKey);
const countries = require("i18n-iso-countries");
countries.registerLocale(require("i18n-iso-countries/langs/en.json"));
const states = require("us-state-converter");

module.exports = {
  createOrders: async (root, { input }, { user }) => {
    if (user !== null) {
      let orderMaster;

      const find_user = await database.User.findOne({
        where: {
          id: user?.id,
        },
        raw: true,
      });
      if (!find_user) return new AuthenticationError("Please Provide Token");

      try {
        let { products, payment_id, tax_amount = 0 } = input;

        const shipping = await database.BillingAddresses.findOne({
          where: {
            isDefault: true,
            user_id: user?.id,
          },
          raw: true,
        });

        if (shipping) {
          let orderItems = [];
          let orderShipTotal = [];
          let order_master = {
            user_id: user.id,
            shipping_id: shipping.id,
            // card_id: card.id,
            isPaymentDone: false,
            totalAmount: 0,
            totalBasicAmount: 0,
            isActive: false,
            order_id: await order_number_generator(),
            isBuyAgainOrder: input?.isBuyAgainOrder !== undefined && input?.isBuyAgainOrder,
          };
          for (const p of products) {
            if (!p.productId || !p.quantity) {
              return { success: false, message: "Please Provide Valid Products" };
            }
            let single_product = await database.Product.findOne({
              where: {
                id: p.productId,
                is_deleted: false,
              },
              include: [
                {
                  model: database.ProductItem,
                  as: "variant",
                  ...(p?.variant_id && {
                    where: {
                      id: p?.variant_id,
                    },
                  }),
                  attributes: ["id", "title", "price", "listPrice", "sku", "barcode", "inventory_quantity", "old_inventory_quantity", "isTaxable", "image_id", "height", "width", "length", "weightValue", "weightUnit"],
                  include: [
                    {
                      model: database.ProductConfiguration,
                      as: "total_variant",
                      attributes: ["id", "variant_option_id"],
                      include: [
                        {
                          model: database.VariationOption,
                          as: "variant_option",
                          attributes: ["value", "variation_id", "colorCode"],
                        },
                      ],
                    },
                    {
                      model: database.Media,
                      as: "image",
                      attributes: ["media"],
                    },
                  ],
                },
                {
                  model: database.ProductShippingDetails,
                  as: "shipping",
                },
                {
                  model: database.Variation,
                  as: "options",
                  attributes: ["name"],
                  include: [{ model: database.VariationOption, as: "data", attributes: ["value", "colorCode"] }],
                },
                {
                  model: database.ProductMedia,
                  as: "images",
                  attributes: ["src", "media_id"],
                },
                {
                  model: database.ProductTag,
                  as: "tags",
                  attributes: ["tag"],
                },
                {
                  model: database.ProductCategories,
                  as: "categories",
                  attributes: ["category_id", "subCategory_id", "childSubCategory_id"],
                  include: [
                    {
                      model: database.Category,
                      as: "category",
                    },
                    {
                      model: database.Subcategory,
                      as: "subCategory",
                    },
                    {
                      model: database.Childsubcategory,
                      as: "childSubCategory",
                    },
                  ],
                },
                {
                  model: database.ProductInventory,
                  as: "inventoryPrice",
                  attributes: ["price", "listPrice", "quantity", "sku"],
                },
                {
                  model: database.ProductAttributes,
                  as: "attributes",
                  attributes: ["id", "type", "name", "value"],
                },
                {
                  model: database.ProductImageSize,
                  as: "size",
                },
                {
                  model: database.BusinessInformation,
                  as: "store",
                  attributes: ["id", "name", "logo", "seller_id"],
                  include: [
                    {
                      model: database.StoreDetail,
                      as: "store_detail",
                    },
                  ],
                },
              ],
            });
            let product = JSON.parse(JSON.stringify(single_product));

            console.log("fasdfasfdsasafsdafsd++++++++++++++++++++", product);

            if (!product) {
              return { success: false, message: "Product not found" };
            }
            /* Check Product Quantity */
            if (product?.variant?.inventory_quantity < p.quantity) {
              return { success: false, message: "Quantity is not available" };
            }

            /* order amount calculation */
            let basicAmount = Number(product?.variant ? product?.variant?.price : product?.inventoryPrice?.price) * p.quantity;
            let taxAmount = tax_amount;
            // let taxAmount = find_tax?.rate_percentage ? Number(find_tax?.rate_percentage) / 100 : 0
            let totalAmount = Number(product?.variant ? product?.variant?.price : product?.inventoryPrice?.price) * p.quantity + taxAmount;
            let platFormCharges = (await chargesOnPrices(totalAmount, process.env.GLOBAL_CHARGES_FOR_PLATFORM)).charges;
            /* order items - payload */

            let orderShipCalculation = {
              store_id: product?.store?.id,
              store_detail: {
                min_amount: product?.store?.store_detail?.min_amount,
                flat_rate: product?.store?.store_detail?.flat_rate,
                is_FreeShipping: product?.store?.store_detail?.is_FreeShipping,
                is_minimum_purchase_amount: product?.store?.store_detail?.is_minimum_purchase_amount,
                is_flat_rate: product?.store?.store_detail?.is_flat_rate,
              },
              isShopifyProduct: product?.shopify_product_id === "" || !product?.shopify_product_id ? false : true,
              taxAmount: taxAmount,
              totalAmount: totalAmount,
              ship_charge: 0,
              user_id: user.id,
            };

            let orderItemsPayload = {
              title: product?.title,
              inventory_price: product?.inventoryPrice?.price,
              store_id: product?.store.id,
              seller_id: product?.store.seller_id,
              user_id: user.id,
              service_code: product?.service_code ? product?.service_code : "",
              product_id: p.productId,
              variant_id: p.variant_id,
              quantity: p.quantity,
              product_price: Number(product?.variant ? product?.variant?.price : product?.inventoryPrice?.price),
              basicAmount: basicAmount,
              totalAmount: totalAmount,
              delivery_estimate: p?.delivery_estimate,
              delivery_estimate_day: p?.delivery_estimate_day,
              globalCharges: platFormCharges,
              sellerFinalAmount: totalAmount - platFormCharges,
              isShopifyProduct: product?.shopify_product_id === "" || !product?.shopify_product_id ? false : true,
              isBuyAgainOrder: input?.isBuyAgainOrder !== undefined && input?.isBuyAgainOrder,
            };
            orderItems.push(orderItemsPayload);
            orderShipTotal.push(orderShipCalculation);
            /* order master */
            order_master.totalAmount += totalAmount;
            order_master.totalBasicAmount += basicAmount;
            order_master.store_id = product?.store?.id;
          }

          console.log("fasdfasdfasfdsafsafsdafsdafsafdsaf++++++++++++++", order_master, orderItems);

          const groupedByStore = orderShipTotal.reduce((acc, item) => {
            if (!acc[item.store_id]) {
              acc[item.store_id] = { store_id: item.store_id, totalAmount: 0 };
            }
            acc[item.store_id].totalAmount += item.totalAmount;
            acc[item.store_id].store_detail = item.store_detail;
            acc[item.store_id].isShopifyProduct = item.isShopifyProduct;
            return acc;
          }, {});

          const shipResult = Object.values(groupedByStore);

          const calculateShipping = (stores) => {
            return stores.map((store) => {
              const { store_detail, totalAmount } = store;

              let ship_charge = 0;

              if (store_detail.is_FreeShipping) {
                ship_charge = 0;
              } else if (store_detail.is_flat_rate) {
                ship_charge = store_detail.flat_rate;
              } else if (store_detail.is_minimum_purchase_amount) {
                ship_charge = totalAmount < store_detail.min_amount ? store_detail.flat_rate : 0;
              }

              return { ...store, ship_charge };
            });
          };

          const updatedStores = await calculateShipping(shipResult);
          console.log("updatedStores ======", updatedStores);

          /* create order master in DB and elasticsearch */
          let orderMaster = JSON.parse(JSON.stringify(await database.OrderMaster.create(order_master)));
          let elkData = await elasticClient.order.addSingleDataForOrderMaster("order_master", orderMaster);
          console.log("orderMaster+++++++++++++++", order_master);
          // /* bulk create order items */
          await Promise.all(
            orderItems.map(async (o) => {
              o.order_master_id = orderMaster.id;
              let orderItem = JSON.parse(JSON.stringify(await database.OrderItems.create(o)));
              console.log("orderIdsdasdasdasdasdadatem", orderItem);
              if (orderItem) {
                let elkData = await elasticClient.order.addSingleDataForOrderItems("order_items", orderItem);
              }
              return (o.id = orderItem.id);
              /* add in elastic search */
            })
          );

          await Promise.all(
            updatedStores.map(async (o) => {
              o.order_master_id = orderMaster.id;
              let ship_orderItem = JSON.parse(
                JSON.stringify(
                  await database.OrderShippingCharge.create({
                    store_id: o?.store_id,
                    amout: o.totalAmount,
                    order_master_id: orderMaster.id,
                    ship_charge: o?.ship_charge,
                  })
                )
              );
              console.log("ship_orderItem", ship_orderItem);
            })
          );

          // return
          // return { success: true, message: "Order Created Successfully" };

          /* Payment Method - Validation */
          // let { type = "card" } = input;
          // if (type == "card") {
          // let paymentmethod = await stripe.paymentMethods.create({
          //   type: type,
          //   card: {
          //     number: card.card_number,
          //     exp_month: Number(card.expiry_date.split("/")[0]),
          //     exp_year: Number(card.expiry_date.split("/")[1]),
          //     cvc: Number(card.cvv),
          //   },
          // });

          // let paymentIntent = await stripe.paymentIntents.create({
          //   payment_method: payment_id,
          //   amount: order_master.totalAmount * 100,
          //   currency: "usd",
          //   confirm: true,
          //   payment_method_types: ["card"],
          //   shipping: {
          //     name: shipping.firstName + " " + shipping.lastName,
          //     address: {
          //       line1: "510 Townsend St",
          //       postal_code: "98140",
          //       city: "San Francisco",
          //       state: "CA",
          //       country: "US",
          //     },
          //   },
          //   description: "BLUEJESTIC",
          // });
          // const paymentId = paymentIntent.id;

          const paymentIntentForPayemnt = await stripe.paymentIntents.retrieve(payment_id);
          if (paymentIntentForPayemnt.status == "succeeded") {
            /* Payment Done - History Save */
            let payload = { isPaymentDone: true, paymentStatus: "done", isActive: true, paymentId: paymentIntentForPayemnt.id };
            await database.OrderMaster.update(payload, { where: { id: orderMaster.id } });
            /* elastic search update */
            let elkData = await elasticClient.order.updateOrderMasterById("order_master", orderMaster.id, payload);
            /* update productqty and delete cart */

            let shopify_products = orderItems.filter((o) => o?.isShopifyProduct);
            let general_products = orderItems.filter((o) => !o?.isShopifyProduct);

            let updated_shopify_product = [];
            if (shopify_products?.length > 0) {
              console.log("shopify Product Called");

              for (let i = 0; i < shopify_products?.length; i++) {
                let shopify_prd = shopify_products[i];
                const find_shipify_product = await database.Product.findOne({
                  where: {
                    id: shopify_prd?.product_id,
                  },
                  attributes: ["shopify_product_id"],
                });
                let find_shipify_product_variant;
                if (shopify_prd?.variant_id) {
                  find_shipify_product_variant = await database.ProductItem.findOne({
                    where: {
                      id: shopify_prd?.variant_id,
                    },
                    attributes: ["title"],
                    raw: true,
                  });
                  console.log("find_shipify_product?.shopify_product_id", find_shipify_product?.shopify_product_id, find_shipify_product_variant?.title);
                  try {
                    let productConfig = {
                      method: "get",
                      maxBodyLength: Infinity,
                      url: `https://f3ad3d-3.myshopify.com/admin/api/2023-07/products/${find_shipify_product?.shopify_product_id}.json`,
                      headers: {
                        "X-Shopify-Access-Token": "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",
                        "Content-Type": "application/json",
                      },
                    };

                    let productResponse = await axios(productConfig);
                    const find_shopify_variant = await productResponse?.data?.product?.variants.find((v) => v?.title === find_shipify_product_variant?.title);
                    console.log("find_user++++++++++++++++++++++++++++++++++", find_shopify_variant);
                    updated_shopify_product.push({ ...shopify_prd, shopify_variant_id: find_shopify_variant?.id });
                    await database.OrderItems.update(
                      { shopify_variant_id: String(find_shopify_variant?.id), shopify_product_id: String(find_shipify_product?.shopify_product_id) },
                      {
                        where: {
                          // order_master_id: orderMaster.id,
                          id: shopify_prd.id,
                        },
                      }
                    );
                  } catch (error) {
                    console.log("error from shopify Error", error);
                  }
                  await database.Cart.update({ status: "order_completed" }, { where: { user_id: user?.id, parent_id: shopify_prd?.product_id, status: "checkout_initiated" } });
                } else {
                  await database.OrderItems.update(
                    { shopify_product_id: String(find_shipify_product?.shopify_product_id) },
                    {
                      where: {
                        // order_master_id: orderMaster.id,
                        id: shopify_prd.id,
                      },
                    }
                  );
                  updated_shopify_product.push({ title: shopify_prd?.title, price: shopify_prd?.inventory_price });
                }
              }

              for (let i = 0; i < updated_shopify_product.length; i++) {
                let shopify_product = updated_shopify_product[i];
                let orderPayload;
                if (shopify_product?.shopify_variant_id) {
                  orderPayload = {
                    order: {
                      line_items: [
                        {
                          variant_id: shopify_product?.shopify_variant_id,
                          quantity: shopify_product?.quantity,
                        },
                      ],
                      shipping_address: {
                        first_name: find_user?.firstName,
                        last_name: find_user?.lastName,
                        address1: shipping?.streetAddress,
                        // address2: "Apt 4B",
                        phone: shipping?.number,
                        city: shipping?.city,
                        province: shipping?.state,
                        country: shipping?.country,
                        zip: shipping?.zipcode,
                      },
                      email: find_user?.email,
                      financial_status: "paid",
                    },
                  };
                } else {
                  orderPayload = {
                    order: {
                      line_items: [
                        {
                          title: shopify_product?.title,
                          price: shopify_product?.price,
                          quantity: shopify_product?.quantity,
                        },
                      ],
                      shipping_address: {
                        first_name: find_user?.firstName,
                        last_name: find_user?.lastName,
                        address1: shipping?.streetAddress,
                        phone: shipping?.number,
                        city: shipping?.city,
                        province: shipping?.state,
                        country: shipping?.country,
                        zip: shipping?.zipcode,
                      },
                      email: find_user?.email,
                      financial_status: "paid",
                    },
                  };
                }
                let config = {
                  method: "post",
                  maxBodyLength: Infinity,
                  url: "https://f3ad3d-3.myshopify.com/admin/api/2024-07/orders.json",
                  headers: {
                    "X-Shopify-Access-Token": "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",
                    "Content-Type": "application/json",
                  },
                  data: orderPayload,
                };

                let response = await axios(config);
                console.log("respodsdsdsdsdsdsdsdsdsdsdsdsdsdsdsdsdsdsdsnse", response.data);
                if (response.data.order) {
                  // await database.OrderMaster.update(
                  //   {
                  //     shopify_order_status_url: response.data.order.order_status_url,
                  //     shopify_order_confirmation_number: response.data.order.confirmation_number,
                  //     shopify_order_id: response.data.order.id,
                  //     shopify_app_id: response.data.order.app_id,
                  //     shopify_order_number: response.data.order.order_number,
                  //   },
                  //   { where: { id: orderMaster.id } }
                  // );
                  for (let i = 0; i < response.data.order.line_items?.length; i++) {
                    let orderItem = response.data.order.line_items[i];
                    console.log("orderItem++++++++++++++++++++++++++++", orderItem);

                    if (orderItem.product_id) {
                      let [update_order] = await database.OrderItems.update(
                        // { paymentStatus: "done", },
                        // orderUpdatePayload,
                        {
                          shopify_order_item_id: String(orderItem?.id),
                          shopify_order_status_url: response.data.order.order_status_url,
                          shopify_order_confirmation_number: response.data.order.confirmation_number,
                          shopify_order_id: response.data.order.id,
                          shopify_app_id: response.data.order.app_id,
                          shopify_order_number: response.data.order.order_number,
                        },
                        { where: { order_master_id: orderMaster.id, shopify_product_id: String(orderItem.product_id), ...(orderItem?.variant_id && { shopify_variant_id: orderItem?.variant_id ? String(orderItem?.variant_id) : null }) } }
                      );
                      console.log("update_order", update_order);
                    }
                  }
                }
              }
            }

            if (general_products?.length > 0) {
              console.log("general Product Called");
              for (let i = 0; i < general_products?.length; i++) {
                //* NEW +++++++++++++++++++++++++++++++++++++++++++++
                let general_prd = general_products[i];
                let product = await database.Product.findOne({ where: { id: general_prd.product_id, is_deleted: false }, raw: true });

                /* ================ SHIPMENT & TRACKIMG ================== */
                let store = await database.BusinessInformation.findOne({
                  where: {
                    id: product.store_id,
                  },
                  raw: true,
                });
                let ProductShippingDetails;
                console.log("o?.variant_id++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", general_prd?.variant_id);
                if (general_prd?.variant_id) {
                  ProductShippingDetails = await database.ProductItem.findOne({ where: { id: general_prd?.variant_id }, raw: true });
                } else {
                  ProductShippingDetails = await database.ProductShippingDetails.findOne({ where: { product_id: product.id }, raw: true });
                }

                /* ============= for Create shipment for orders [START] ================ */

                console.log("ProductShippingDetails++++++++++++++++++++++++++++++", ProductShippingDetails);

                // let data = {
                //   shipments: [
                //     {
                //       service_code: process.env.SHIPENGINE_SERVICE_CODE,
                //       // validate_address: "validate_and_clean",
                //       ship_from: {
                //         name: store.name,
                //         company_name: store.companyLegalName,
                //         address_line1: store.streetAddress,
                //         city_locality: store.city,
                //         state_province: store.state,
                //         postal_code: store.postalCode,
                //         country_code: store.country || "US",
                //         phone: "7867176711",
                //       },
                //       ship_to: {
                //         name: user.firstName + " " + user.lastName,
                //         address_line1: shipping.streetAddress,
                //         city_locality: shipping.city,
                //         state_province: shipping.state,
                //         postal_code: shipping.zipcode,
                //         country_code: shipping.country,
                //       },
                //       packages: [
                //         {
                //           weight: {
                //             value: ProductShippingDetails.weightValue,
                //             // unit: ProductShippingDetails.weightUnit ,
                //             unit: "pound",
                //           },
                //           dimensions: {
                //             length: ProductShippingDetails.length,
                //             width: ProductShippingDetails.width,
                //             height: ProductShippingDetails.height,
                //             unit: "inch",
                //             // unit: ProductShippingDetails.unit ? ProductShippingDetails.unit : "inch",
                //           },
                //         },
                //       ],
                //     },
                //   ],
                // };

                // let shipmentForOrders = await createShipment(data);
                // console.log("shipmentForOrders", shipmentForOrders);
                /* ============= for Create shipment for orders [END] ================ */

                /* ============= for Create label for orders [START] ================ */
                // console.log("shipment_id_created +++++++++++++++++++++++++++++++++++++", shipmentForOrders.shipments[0].shipment_id);

                // if (!shipmentForOrders.shipments[0].shipment_id) {
                //   await database.OrderItems.update(
                //     {
                //       order_status: "error",
                //     },
                //     { where: { id: general_prd.id } }
                //   );
                // }

                // let labelForShipment = await createLabelForShipment(shipmentForOrders.shipments[0].shipment_id);
                // console.log("labelForShipment_created ++++++++++++++++++++++++++++++++++", labelForShipment);
                // if (!labelForShipment?.success) {
                //   await database.OrderItems.update(
                //     {
                //       order_status: "error",
                //     },
                //     { where: { id: general_prd.id } }
                //   );
                //   // return { success: false, message: labelForShipment?.message?.message, variant_id: o?.variant_id };
                // }

                /* ============= for Create label for orders [END] ================ */

                /* ============= for get tracking details for orders [START] ================ */

                // let trackingDetails = await trackUsingLabelId(labelForShipment?.data.label_id);
                // if (!trackingDetails?.tracking_number) {
                //   await database.OrderItems.update(
                //     {
                //       order_status: "error",
                //     },
                //     { where: { id: general_prd.id } }
                //   );
                // }
                // console.log("trackingDetails", trackingDetails);

                /* ============= for get tracking details for orders [END] ================ */

                /* ================ SHIPMENT & TRACKIMG ================== */

                const getISO2FromCountryName = (countryName) => {
                  const iso2 = countries.getAlpha2Code(countryName, "en");
                  return iso2 || "Country not found";
                };

                function convertStateToISO2(stateName) {
                  const abbr = states.abbr(stateName);
                  console.log(abbr); // <- Logs 'IL'
                  return abbr || "Invalid state name";
                }

                console.log("ehuqwgrehwbfdjaknsbajhfsdhjan", store.country, store.state, convertStateToISO2(store.state), getISO2FromCountryName(store.country));

                const fromAddress = {
                  name: store.name,
                  company_name: store.companyLegalName,
                  address_line1: store.streetAddress,
                  city_locality: store.city,
                  state_province: convertStateToISO2(store.state),
                  postal_code: store.postalCode,
                  country_code: getISO2FromCountryName(store.country) || "US",
                  phone: "7867176711",
                };

                const toAddress = {
                  name: user.firstName + " " + user.lastName,
                  address_line1: shipping.streetAddress,
                  city_locality: shipping.city,
                  state_province: shipping.state,
                  postal_code: shipping.zipcode,
                  country_code: shipping.country,
                };

                const packageDetails = {
                  weight: {
                    value: ProductShippingDetails.weightValue,
                    unit: "pound",
                  },
                  dimensions: {
                    length: ProductShippingDetails.length,
                    width: ProductShippingDetails.width,
                    height: ProductShippingDetails.height,
                    unit: "inch",
                  },
                };

                const payload = {
                  shipment: {
                    service_code: general_prd?.service_code ? general_prd?.service_code : "usps_priority_mail",
                    ship_to: toAddress,
                    ship_from: fromAddress,
                    packages: [packageDetails],
                  },
                };

                const baseURL = "https://api.shipengine.com/v1";
                const headers = {
                  "API-Key": process.env.SHIPENGINE_API_KEY,
                  "Content-Type": "application/json",
                };

                const response = await axios.post(`${baseURL}/labels`, payload, { headers });
                let created_order;
                console.log("created_order=============", response?.data);

                if (response?.data) {
                  created_order = response?.data;
                } else {
                  await database.OrderMaster.destroy({ where: { id: orderMaster.id } });
                  return { success: false, message: "Payment Failed", data: paymentIntentForPayemnt?.status };
                }

                let charges = created_order.shipment_cost?.amount || 0 + created_order.insurance_cost?.amount || 0 + labelForShipment.data.confirmation_cost?.amount || 0 + labelForShipment.data.other_cost?.amount || 0;

                let orderUpdatePayload = {
                  shipment_charges: charges,
                  tracking_number: created_order.tracking_number,
                  shipment_id: created_order.shipment_id,
                  delivery_estimate: general_prd?.delivery_estimate,
                  delivery_estimate_day: general_prd?.delivery_estimate_day,
                  label_id: created_order.label_id,
                  label_url: created_order.label_download?.href,
                  order_status: created_order.tracking_status,
                  trackingUrl: created_order.tracking_url,
                  paymentStatus: "done",
                };
                console.log("orderUpdatePayload", orderUpdatePayload);
                /* order items - payload */
                await database.OrderItems.update(
                  // { paymentStatus: "done", },
                  orderUpdatePayload,
                  { where: { id: general_prd.id } }
                );

                // let updateElasticssearchOrder = await elasticClient.product.updateProductById("products", product.id, elasticPayload);
                /** product qty update */

                let find_variant = await database.ProductItem.update({ inventory_quantity: Sequelize.literal(`inventory_quantity - ${general_prd.quantity}`) }, { where: { id: general_prd?.variant_id } });
                let find_inventory = await database.ProductInventory.update({ quantity: Sequelize.literal(`quantity - ${general_prd.quantity}`) }, { where: { product_id: general_prd?.product_id } });

                await database.Cart.update({ status: "order_completed" }, { where: { user_id: user?.id, parent_id: general_prd?.product_id, status: "checkout_initiated" } });

                // await database.Product.update({ inventory_quantity: Sequelize.literal(`inventory_quantity - ${o.quantity}`) }, { where: { id: o.variant_id } });
                /* cart delete */
                // await database.Cart.destroy({ where: { user_id: user.id, parent_id: shopify_prd.product_id } });
                // return { success: true, message: "success", variant_id: product.id ? product.id : shopify_prd?.variant_id };
                // } catch (error) {
                //   console.log("error from shopify Error", error);
                // }
              }
            }

            // return { success: true, message: "success", variant_id: product.id ? product.id : o?.variant_id };

            // * ============================ OLD_METHOD ================================
            // orderItems.map(async (o) => {
            //   console.log("odhjaisdnasdasdasb basdyhasbd asdbhd asdhasbdv43421321", o);

            //   if (o?.isShopifyProduct) {
            //     const find_shipify_product = await database.Product.findOne({
            //       where: {
            //         id: o?.product_id,
            //       },
            //       attributes: ["shopify_product_id"],
            //     });

            //     const find_shipify_product_variant = await database.ProductItem.findOne({
            //       where: {
            //         id: o?.variant_id,
            //       },
            //       attributes: ["title"],
            //     });

            //     console.log("find_shipify_product?.shopify_product_id", find_shipify_product?.shopify_product_id);

            //     try {
            //       let productConfig = {
            //         method: "get",
            //         maxBodyLength: Infinity,
            //         url: `https://f3ad3d-3.myshopify.com/admin/api/2023-07/products/${find_shipify_product?.shopify_product_id}.json`,
            //         headers: {
            //           "X-Shopify-Access-Token": "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",
            //           "Content-Type": "application/json",
            //         },
            //       };

            //       let productResponse = await axios(productConfig);
            //       const find_shopify_variant = await productResponse?.data?.product?.variants.find((v) => v?.title === find_shipify_product_variant?.title);

            //       console.log("find_user++++++++++++++++++++++++++++++++++", find_user);

            //       let orderPayload = {
            //         order: {
            //           line_items: [
            //             {
            //               variant_id: find_shopify_variant?.id,
            //               quantity: o?.quantity,
            //             },
            //           ],
            //           shipping_address: {
            //             first_name: find_user?.firstName,
            //             last_name: find_user?.lastName,
            //             address1: shipping?.streetAddress,
            //             // address2: "Apt 4B",
            //             phone: shipping?.number,
            //             city: shipping?.city,
            //             province: shipping?.state,
            //             country: shipping?.country,
            //             zip: shipping?.zipcode,
            //           },
            //           email: find_user?.email,
            //           financial_status: "paid",
            //         },
            //       };

            //       console.log("orderPayload++++++++++++++++++++++++++++++++++++++++++++", JSON.stringify(orderPayload));

            //       let config = {
            //         method: "post",
            //         maxBodyLength: Infinity,
            //         url: "https://f3ad3d-3.myshopify.com/admin/api/2024-07/orders.json",
            //         headers: {
            //           "X-Shopify-Access-Token": "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",
            //           "Content-Type": "application/json",
            //         },
            //         data: orderPayload,
            //       };

            //       let response = await axios(config);
            //       console.log("respodsdsdsdsdsdsdsdsdsdsdsdsdsdsdsdsdsdsdsnse", response.data);
            //       if (response.data.order) {
            //         await database.OrderMaster.update(
            //           {
            //             shopify_order_status_url: response.data.order.order_status_url,
            //             shopify_order_confirmation_number: response.data.order.confirmation_number,
            //             shopify_order_id: response.data.order.id,
            //             shopify_app_id: response.data.order.app_id,
            //             shopify_order_number: response.data.order.order_number,
            //           },
            //           { where: { id: orderMaster.id } }
            //         );

            //         // return response.data;

            //         return { success: true, product: response.data };
            //       } else {
            //       }
            //     } catch (error) {
            //       console.log("Ship Enginge - INTERNAL SERVER ERROR  : \n", error.message.message);
            //       return { success: false, message: error.message };
            //     }
            //   } else {
            //     let product = await database.Product.findOne({ where: { id: o.product_id, is_deleted: false }, raw: true });

            //     /* ================ SHIPMENT & TRACKIMG ================== */
            //     let store = await database.BusinessInformation.findOne({
            //       where: {
            //         id: product.store_id,
            //       },
            //       raw: true,
            //     });
            //     let ProductShippingDetails;
            //     console.log("o?.variant_id++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", o?.variant_id);
            //     if (o?.variant_id) {
            //       ProductShippingDetails = await database.ProductItem.findOne({ where: { id: o?.variant_id }, raw: true });
            //     } else {
            //       ProductShippingDetails = await database.ProductShippingDetails.findOne({ where: { product_id: product.id }, raw: true });
            //     }

            //     /* ============= for get shipping estimate charges [START] ================ */
            //     // let sellerChargesDetails = JSON.stringify({
            //     //   "carrier_ids": [
            //     //     "se-5264045"
            //     //   ],
            //     //   "from_country_code": store.country,
            //     //   "from_postal_code": store.postalCode,
            //     //   "to_country_code": shipping.country,
            //     //   "to_postal_code": shipping.zipcode,
            //     //   "weight": {
            //     //     "value": ProductShippingDetails.weightValue,
            //     //     "unit": ProductShippingDetails.weightUnit
            //     //   },
            //     //   "dimensions": {
            //     //     "length": ProductShippingDetails.length,
            //     //     "width": ProductShippingDetails.width,
            //     //     "height": ProductShippingDetails.height,
            //     //     "unit": ProductShippingDetails.unit
            //     //   }
            //     // });

            //     // let shipmentCharges = await estimatedShippingCharges(sellerChargesDetails);
            //     // console.log("shipmentCharges", shipmentCharges);
            //     /* ============= for get shipping estimate charges [END] ================ */

            //     /* ============= for Create shipment for orders [START] ================ */

            //     console.log("ProductShippingDetails++++++++++++++++++++++++++++++", ProductShippingDetails);
            //     // unit_Enum: ["pound" "ounce" "gram" "kilogram"]
            //     // dimensions_Enum: ["inch" "centimeter"]

            //     let data = {
            //       shipments: [
            //         {
            //           service_code: process.env.SHIPENGINE_SERVICE_CODE,
            //           // validate_address: "validate_and_clean",
            //           ship_from: {
            //             name: store.name,
            //             company_name: store.companyLegalName,
            //             address_line1: store.streetAddress,
            //             city_locality: store.city,
            //             state_province: store.state,
            //             postal_code: store.postalCode,
            //             country_code: store.country || "US",
            //             phone: "7867176711",
            //           },
            //           ship_to: {
            //             name: user.firstName + " " + user.lastName,
            //             address_line1: shipping.streetAddress,
            //             city_locality: shipping.city,
            //             state_province: shipping.state,
            //             postal_code: shipping.zipcode,
            //             country_code: shipping.country,
            //           },
            //           packages: [
            //             {
            //               weight: {
            //                 value: ProductShippingDetails.weightValue,
            //                 // unit: ProductShippingDetails.weightUnit ,
            //                 unit: "pound",
            //               },
            //               dimensions: {
            //                 length: ProductShippingDetails.length,
            //                 width: ProductShippingDetails.width,
            //                 height: ProductShippingDetails.height,
            //                 unit: "inch",
            //                 // unit: ProductShippingDetails.unit ? ProductShippingDetails.unit : "inch",
            //               },
            //             },
            //           ],
            //         },
            //       ],
            //     };
            //     let shipmentForOrders = await createShipment(data);
            //     console.log("shipmentForOrders", shipmentForOrders);
            //     /* ============= for Create shipment for orders [END] ================ */

            //     /* ============= for Create label for orders [START] ================ */
            //     console.log("shipment_id_created +++++++++++++++++++++++++++++++++++++", shipmentForOrders.shipments[0].shipment_id);

            //     let labelForShipment = await createLabelForShipment(shipmentForOrders.shipments[0].shipment_id);
            //     console.log("labelForShipment_created ++++++++++++++++++++++++++++++++++", labelForShipment);
            //     if (!labelForShipment?.success) {
            //       return { success: false, message: labelForShipment?.message?.message, variant_id: o?.variant_id };
            //     }

            //     // return;
            //     /* ============= for Create label for orders [END] ================ */

            //     /* ============= for get tracking details for orders [START] ================ */

            //     let trackingDetails = await trackUsingLabelId(labelForShipment?.data.label_id);
            //     console.log("trackingDetails", trackingDetails);

            //     /* ============= for get tracking details for orders [END] ================ */

            //     /* ================ SHIPMENT & TRACKIMG ================== */

            //     let charges = labelForShipment.data.shipment_cost?.amount || 0 + labelForShipment.data.insurance_cost?.amount || 0 + labelForShipment.data.confirmation_cost?.amount || 0 + labelForShipment.data.other_cost?.amount || 0;

            //     let orderUpdatePayload = {
            //       shipment_charges: charges,
            //       tracking_number: trackingDetails.tracking_number,
            //       shipment_id: shipmentForOrders.shipments[0].shipment_id,
            //       label_id: labelForShipment.data.label_id,
            //       label_url: labelForShipment.data.label_download?.href,
            //       order_status: labelForShipment.data.tracking_status,
            //       trackingUrl: trackingDetails.tracking_url,
            //       paymentStatus: "done",
            //     };
            //     console.log("orderUpdatePayload", orderUpdatePayload);
            //     /* order items - payload */
            //     await database.OrderItems.update(
            //       // { paymentStatus: "done", },
            //       orderUpdatePayload,
            //       { where: { id: o.id } }
            //     );

            //     // let updateElasticssearchOrder = await elasticClient.product.updateProductById("products", product.id, elasticPayload);
            //     /** product qty update */

            //     let find_variant = await database.ProductItem.update({ inventory_quantity: Sequelize.literal(`inventory_quantity - ${o.quantity}`) }, { where: { id: o?.variant_id } });
            //     let find_inventory = await database.ProductInventory.update({ quantity: Sequelize.literal(`quantity - ${o.quantity}`) }, { where: { product_id: o?.product_id } });

            //     // await database.Product.update({ inventory_quantity: Sequelize.literal(`inventory_quantity - ${o.quantity}`) }, { where: { id: o.variant_id } });
            //     /* cart delete */
            //     await database.Cart.destroy({ where: { user_id: user.id, parent_id: o.product_id } });
            //     return { success: true, message: "success", variant_id: product.id ? product.id : o?.variant_id };
            //   }
            // })
            // );

            // console.log("response++++++++++++++++", response);

            // let final_error = response.filter((k) => !k?.success);
            // console.log("final_error++++++++++++++++++++++++++++", final_error);

            // if (Boolean(final_error?.length)) {
            //   await database.OrderMaster.destroy({ where: { id: orderMaster.id } });
            //   return { success: false, message: final_error[0]?.message, error: final_error };
            // }
            let data = { paymentId: paymentIntentForPayemnt.id, redirectUrl: null, order_id: orderMaster.order_id };
            return { success: true, message: "Payment Confirmed", data, generate_id: orderMaster.order_id };
          } else if (paymentIntentForPayemnt.status == "requires_action") {
            await database.OrderMaster.destroy({ where: { id: orderMaster.id } });
            return {
              success: true,
              message: "Payment Pending",
              data: { order_id: confirmOrder.id, paymentId, redirectUrl: paymentIntentForPayemnt?.next_action?.use_stripe_sdk?.stripe_js },
            };
          } else {
            await database.OrderMaster.destroy({ where: { id: orderMaster.id } });
            return { success: false, message: "Payment Failed", data: paymentIntentForPayemnt?.status };
          }
          // }
          //  else {
          //   return new AuthenticationError("Please Provide Valid Payment Type");
          // }
        }
      } catch (err) {
        console.log("err==========", JSON.parse(JSON.stringify(err)));
        if (orderMaster) {
          await database.OrderMaster.destroy({ where: { id: orderMaster?.id } });
        }
        return { success: false, message: err.message };
      }
    }
    return new AuthenticationError("Please Provide Token");
  },

  updateOrdersStatus: async (root, { input }, { user }) => {
    if (user !== null) {
      try {
        let { order_id, order_status } = input;
        /*update order in elastic search */
        let data = await elasticClient.order.updateOrderById("order_items", order_id, { order_status });
        console.log("updateOrder", data);
        if (data.success) return { data: "Update order successfully " };
        else return { data: data.message || "Somthing went wrong" };
      } catch (err) {
        console.log("err", err);
        return { success: false, message: "Somthing Went Wrong" };
      }
    }
    return new AuthenticationError("Please Provide Token");
  },

  cancelOrder: async (root, { order_master_id, order_item_id }, { user }) => {
    try {
      if (user !== null) {
        const order_data = await database.OrderItems.findOne({
          where: {
            id: order_item_id,
          },
          include: [
            {
              model: database.OrderMaster,
              as: "orderMaster",
            },
          ],
        });

        const order_item = JSON.parse(JSON.stringify(order_data));
        if (!order_item?.isShopifyProduct && order_item?.label_id) {
          try {
            const response = await axios.put(`https://api.shipengine.com/v1/labels/${order_item?.label_id}/void`, null, {
              headers: {
                "API-Key": "TEST_DBE8TiruvYap/UhUvEjKhtKoYViVg8DM3MsU8n+1hn4",
                "Content-Type": "application/json",
              },
            });

            if (response?.data?.approved) {
              const [order_item] = await database.OrderItems.update(
                {
                  order_status: "cancelled",
                },
                {
                  where: {
                    id: order_item_id,
                  },
                }
              );
              // return { success: true, message: "order cancelled Successfully" };
              try {
                const refund = await stripe.refunds.create({
                  payment_intent: order_item?.orderMaster?.paymentId,
                  amount: order_item?.totalAmount, // Amount in cents
                  reason: "requested_by_customer", // Optional: 'duplicate', 'fraudulent', or 'requested_by_customer'
                  metadata: {
                    refund_reason: "requested_by_customer",
                    partial_refund: true,
                  },
                });
                console.log("Partial refund successful:", refund?.status === "succeeded");
                if (refund?.status === "succeeded") {
                  const find_refund_detail = await database.RefundPayment.findOne({
                    where: { order_item_id: order_item?.id },
                    attributes: ["id"],
                    raw: true,
                  });
                  console.log("find_refund_detail=====", find_refund_detail, order_item?.id);

                  if (!find_refund_detail) {
                    const add_refund_entry = await database.RefundPayment.create({
                      amount: refund?.amount,
                      refund_id: refund?.id,
                      balance_transaction: refund?.balance_transaction,
                      charge: refund?.charge,
                      currency: refund?.currency,
                      destination_details_type: refund?.destination_details?.type,
                      reference_status: refund?.destination_details?.card?.reference_status,
                      payment_intent: refund?.payment_intent,
                      reason: refund?.reason,
                      order_item_id: order_item?.id,
                    });
                  }
                  return { success: true, message: "order cancelled Successfully" };
                }
              } catch (error) {
                console.error("Error creating partial refund:", error);
                // throw new Error('Failed to create partial refund');
              }
              // return { success: true, message: "order cancelled Successfully" };
            } else {
              return { success: true, message: "Failed to cancel Order" };
            }
          } catch (error) {
            console.error("Error cancelling shipment:", error);
          }
        } else {
          if (order_item?.shopify_order_id) {
            try {
              let cancelOrderConfig = {
                method: "post",
                maxBodyLength: Infinity,
                url: `https://f3ad3d-3.myshopify.com/admin/api/2024-10/orders/${Number(order_item?.shopify_order_id)}/cancel.json`,
                headers: {
                  "X-Shopify-Access-Token": "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",
                  "Content-Type": "application/json",
                },
              };
              let cancelOrderResponse = await axios(cancelOrderConfig);
              if (cancelOrderResponse.data.order.id) {
                const [update_order] = await database.OrderItems.update(
                  {
                    order_status: "cancelled",
                  },
                  {
                    where: {
                      id: order_item?.id,
                    },
                  }
                );
                try {
                  const refund = await stripe.refunds.create({
                    payment_intent: order_item?.orderMaster?.paymentId,
                    amount: order_item?.totalAmount, // Amount in cents
                    reason: "requested_by_customer", // Optional: 'duplicate', 'fraudulent', or 'requested_by_customer'
                    metadata: {
                      refund_reason: "requested_by_customer",
                      partial_refund: true,
                    },
                  });
                  console.log("Partial refund successful:", refund?.status === "succeeded");
                  if (refund?.status === "succeeded") {
                    const find_refund_detail = await database.RefundPayment.findOne({
                      where: { order_item_id: order_item?.id },
                      attributes: ["id"],
                      raw: true,
                    });
                    console.log("find_refund_detail", find_refund_detail, order_item?.id);

                    if (!find_refund_detail) {
                      const add_refund_entry = await database.RefundPayment.create({
                        amount: refund?.amount,
                        refund_id: refund?.id,
                        balance_transaction: refund?.balance_transaction,
                        charge: refund?.charge,
                        currency: refund?.currency,
                        destination_details_type: refund?.destination_details?.type,
                        reference_status: refund?.destination_details?.card?.reference_status,
                        payment_intent: refund?.payment_intent,
                        reason: refund?.reason,
                        order_item_id: order_item?.id,
                      });
                    }
                    return { success: true, message: "order cancelled Successfully" };
                  }
                } catch (error) {
                  console.error("Error creating partial refund:", error);
                  // throw new Error('Failed to create partial refund');
                }
                return { success: true, message: "order cancelled Successfully" };
              } else {
                return { success: false, message: "Failed to cancel Order" };
              }
            } catch (error) {
              console.log("errordasdasdasdasdsdd", error);
            }
          }
        }
      }
    } catch (error) {
      console.log("error", error);
      return new AuthenticationError(error);
    }
  },

  addShippingMethod: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");

    let seller_id = user?.seller_id;

    try {
      if (user?.token_type === "admin") {
        if (!input?.store_id) {
          return { success: false, message: "store_id is mandatory!" };
        }
        const find_seller = await database.BusinessInformation.findOne({
          where: {
            id: input?.store_id,
          },
          raw: true,
        });
        seller_id = find_seller?.seller_id;
      } else {
        seller_id = user.seller_id;
      }

      const find_seller = await database.Seller.findOne({
        where: { id: seller_id },
        attributes: ["id"],
        raw: true,
      });

      if (!find_seller) {
        return { success: false, message: "Seller not found" };
      }

      // const activeMethods = await database.ShippingMethod.findAll({
      //   where: { is_active: true, seller_id: seller_id },
      //   raw: true,
      // });

      // if (activeMethods.length > 0) {
      //   await database.ShippingMethod.update(
      //     { is_active: false },
      //     { where: { id: activeMethods.map((method) => method.id) } }
      //   );
      // }

      const newMethod = await database.ShippingMethod.create({
        ...input,
        is_active: true,
        seller_id: seller_id,
      });

      // for (let i = 0; i < input.delivery_service_id?.length; i++) {
      //   let delivery = input.delivery_service_id[i]
      //   let find_entry = await database.SelectedShippingMethod.findOne({
      //     where: {
      //       delivery_service_id: delivery?.id,
      //       seller_id: user?.seller_id
      //     }
      //   })
      //   let add_shipping_method
      //   if (find_entry) {
      //     add_shipping_method = await database.SelectedShippingMethod.update(
      //       {
      //         shipping_method_id: newMethod?.id,
      //         delivery_service_id: delivery?.id,
      //         seller_id: user.seller_id,
      //         is_active: delivery?.is_active,
      //       },
      //       {
      //         where: {
      //           delivery_service_id: delivery?.id,
      //           seller_id: user?.seller_id
      //         }
      //       })
      //   } else {
      //     add_shipping_method = await database.SelectedShippingMethod.create({
      //       shipping_method_id: newMethod?.id,
      //       delivery_service_id: delivery?.id,
      //       seller_id: user.seller_id,
      //       is_active: delivery?.is_active,
      //     })
      //   }
      //   console.log('add_shipping_method', add_shipping_method);
      // }
      return { success: true, message: "Shipping Method Added Successfully!" };
    } catch (error) {
      console.error("Erro while adding shipping method", error);
      throw new Error("An error occurred while adding shipping method");
    }
  },

  updateShippingMethod: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    let seller_id = user?.seller_id;

    try {
      if (user?.token_type === "admin") {
        if (!input?.store_id) {
          return { success: false, message: "store_id is mandatory!" };
        }
        const find_seller = await database.BusinessInformation.findOne({
          where: {
            id: input?.store_id,
          },
          raw: true,
        });
        seller_id = find_seller?.seller_id;
      } else {
        seller_id = user.seller_id;
      }

      const find_shipping_method = await database.ShippingMethod.findOne({
        where: {
          id: input?.id,
          seller_id: seller_id,
        },
      });

      if (!find_shipping_method) {
        return {
          success: false,
          message: "Shipping Method not found!",
        };
      }

      const find_seller = await database.Seller.findOne({
        where: { id: seller_id },
        attributes: ["id"],
        raw: true,
      });

      if (!find_seller) {
        return { success: false, message: "seller not Found" };
      }

      // const activeMethods = await database.ShippingMethod.findAll({
      //   where: { is_active: true, seller_id: seller_id },
      //   raw: true,
      // });

      // if (activeMethods.length > 0) {
      //   await database.ShippingMethod.update(
      //     { is_active: false },
      //     { where: { id: activeMethods.map((method) => method.id) } }
      //   );
      // }

      if (find_shipping_method?.dataValues?.delivery_options_type === "calculated") {
        await database.ShippingMethod.update(
          {
            ...input,
            is_active: true,
          },
          {
            where: {
              id: find_shipping_method?.id,
            },
          }
        );
      } else if (find_shipping_method?.dataValues?.delivery_options_type === "fixed") {
        Object.keys(input).map((key) => {
          if (key) {
            if (key === "fixed_delivery_options") {
              const updatedOptions = find_shipping_method[key].map((existingOption) => {
                const matchingOption = input[key]?.find((newOption) => {
                  return newOption.country === existingOption?.country;
                });
                if (matchingOption) {
                  return { ...existingOption, ...matchingOption };
                }
                return existingOption;
              });

              find_shipping_method.fixed_delivery_options = updatedOptions;
            } else {
              find_shipping_method[key] = input[key];
            }
          }
        });
        await find_shipping_method.save();
      }

      // find_shipping_method.processing_time = input?.processifind_shipping_method?.ng_time;

      // await find_shipping_method.save();

      // for (let i = 0; i < input?.delivery_service_id?.length; i++) {
      //   let delivery = input.delivery_service_id[i]
      //   let find_entry = await database.SelectedShippingMethod.findOne({
      //     where: {
      //       delivery_service_id: delivery?.id,
      //       seller_id: user?.seller_id
      //     }
      //   })
      //   let update_shipping_method
      //   if (find_entry) {
      //     update_shipping_method = await database.SelectedShippingMethod.update(
      //       {
      //         shipping_method_id: newMethod?.id,
      //         delivery_service_id: delivery?.id,
      //         seller_id: user.seller_id,
      //         is_active: delivery?.is_active,
      //       },
      //       {
      //         where: {
      //           delivery_service_id: delivery?.id,
      //           seller_id: user?.seller_id
      //         }
      //       })
      //   } else {
      //     update_shipping_method = await database.SelectedShippingMethod.create({
      //       shipping_method_id: newMethod?.id,
      //       delivery_service_id: delivery?.id,
      //       seller_id: user.seller_id,
      //       is_active: delivery?.is_active,
      //     })
      //   }
      //   console.log('update_shipping_method', update_shipping_method);
      // }

      return { success: true, message: "Shipping Method Updated Successfully!" };
    } catch (error) {
      console.error("Erro while updating shipping method", error);
      throw new Error("An error occurred while updating shipping method");
    }
  },

  writeAUserReviewOnProduct: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please provide the token!");
    try {
      if (!input?.order_items_id) {
        return {
          success: false,
          message: "Order items id is required!",
        };
      }

      const result = await database.OrderItems.findOne({
        where: {
          id: input?.order_items_id,
        },
        attributes: ["id"],
        include: [
          {
            model: database.OrderMaster,
            as: "orderMaster",
            attributes: ["id"],
          },
          {
            model: database.Product,
            as: "product",
            attributes: ["id"],
            include: [
              {
                model: database.BusinessInformation,
                as: "store",
                attributes: ["id"],
                include: [
                  {
                    model: database.Seller,
                    as: "personalInformation",
                    attributes: ["id"],
                  },
                ],
              },
            ],
          },
        ],
      });

      const sanitizedResult = JSON.parse(JSON.stringify(result));

      if (!sanitizedResult) {
        return {
          success: false,
          message: "Order items id is invalid!",
        };
      }

      if (!sanitizedResult?.product || !sanitizedResult?.product?.id) {
        return {
          success: false,
          message: "Product not found!",
        };
      }

      const isAlreadywrittenReview = await database.UserReviewsOnProducts.findOne({
        where: {
          order_items_id: sanitizedResult?.id,
          user_id: user?.id,
          product_id: sanitizedResult?.product?.id,
        },
      });
      if (isAlreadywrittenReview) {
        return {
          success: false,
          message: "You have already written a review for this product!",
        };
      }

      const createdReview = await database.UserReviewsOnProducts.create({
        user_id: user?.id,
        order_items_id: sanitizedResult?.id ?? null,
        order_master_id: sanitizedResult?.orderMaster?.id ?? null,
        store_id: sanitizedResult?.product?.store?.id ?? null,
        seller_id: sanitizedResult?.product?.store?.personalInformation?.id ?? null,
        product_id: sanitizedResult?.product?.id ?? null,
        ...input,
      });

      if (createdReview && createdReview?.dataValues && createdReview?.dataValues?.id) {
        if (input?.reviewMedias && input?.reviewMedias?.length) {
          let position = 1;
          for await (const media of input?.reviewMedias) {
            await database.UserReviewsOnProductsMedias.create({
              userReviewsOnProductsId: createdReview?.dataValues?.id,
              position: position,
              media_type: media?.media_type,
              media_for: "PRODUCT",
              url: media?.url,
            });
            position = position + 1;
          }
        }

        return { success: true, message: "Review Submitted Successfully!" };
      }
    } catch (error) {
      console.error("An error occured while submitting user review on product", error);
      throw new Error("An error occurred while submitting user review on product");
    }
  },

  writeAUserFeedbackOnProduct: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please provide the token!");
    try {
      if (!input?.order_items_id) {
        return {
          success: false,
          message: "Order items id is required!",
        };
      }

      const result = await database.OrderItems.findOne({
        where: {
          id: input?.order_items_id,
        },
        attributes: ["id"],
        include: [
          {
            model: database.OrderMaster,
            as: "orderMaster",
            attributes: ["id"],
          },
          {
            model: database.Product,
            as: "product",
            attributes: ["id"],
            include: [
              {
                model: database.BusinessInformation,
                as: "store",
                attributes: ["id"],
                include: [
                  {
                    model: database.Seller,
                    as: "personalInformation",
                    attributes: ["id"],
                  },
                ],
              },
            ],
          },
        ],
      });

      const sanitizedResult = JSON.parse(JSON.stringify(result));

      if (!sanitizedResult) {
        return {
          success: false,
          message: "Order items id is invalid!",
        };
      }

      if (!sanitizedResult?.product || !sanitizedResult?.product?.id) {
        return {
          success: false,
          message: "Product not found!",
        };
      }

      const isAlreadywrittenFeedback = await database.UserFeedbacksOnProducts.findOne({
        where: {
          order_items_id: sanitizedResult?.id,
          user_id: user?.id,
          product_id: sanitizedResult?.product?.id,
        },
      });
      if (isAlreadywrittenFeedback) {
        return {
          success: false,
          message: "You have already written a feedback for this product!",
        };
      }

      const createdFeedback = await database.UserFeedbacksOnProducts.create({
        user_id: user?.id,
        order_items_id: sanitizedResult?.id ?? null,
        order_master_id: sanitizedResult?.orderMaster?.id ?? null,
        store_id: sanitizedResult?.product?.store?.id ?? null,
        seller_id: sanitizedResult?.product?.store?.personalInformation?.id ?? null,
        product_id: sanitizedResult?.product?.id ?? null,
        ...input,
      });

      if (createdFeedback && createdFeedback?.dataValues && createdFeedback?.dataValues?.id) {
        return { success: true, message: "Feedback Submitted Successfully!" };
      }
    } catch (error) {
      console.error("An error occured while submitting user feedback on product", error);
      throw new Error("An error occurred while submitting user feedback on product");
    }
  },

  taxCalculation: async (root, { zipcode }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");

    const find_user = await database.User.findOne({
      where: {
        id: user?.id,
      },
      attributes: ["id"],
      raw: true,
    });
    if (!find_user) {
      return new AuthenticationError("User Not Found!");
    }

    try {
      let config = {
        method: "get",
        maxBodyLength: Infinity,
        url: `https://api.api-ninjas.com/v1/salestax?zip_code=${zipcode}`,
        // url: `https://api.api-ninjas.com/v1/salestax?city=${encodeURIComponent("San Francisco")}&state=${encodeURIComponent("CA")}`,
        // url: "http://34.138.21.186:5000/v1/userfeed/separate-recommendation",
        headers: {
          "Content-Type": "application/json",
          "X-Api-Key": process.env.NINJAS_TAX_API_KEY,
        },
        // data: Payload,
      };

      let response = await axios(config);
      if (response?.data?.length > 0) {
        return { success: true, message: "Fetch Successfully", data: response?.data[0] };
      } else {
        return { success: false, message: "Something went wrong" };
      }
    } catch (error) {
      console.log("error++++++++++++++++++++++", error);
      return { success: false, message: error?.response?.data?.error };
    }
  },
};
