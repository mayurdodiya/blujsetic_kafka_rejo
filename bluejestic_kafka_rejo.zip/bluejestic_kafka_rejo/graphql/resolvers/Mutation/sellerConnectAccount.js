const { AuthenticationError } = require("apollo-server-express");
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-08-16",
});
const database = require("../../../database/models");

module.exports = {
  createSellerConnectAccount: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    try {

      let { email, userAgent } = user;

      input.transactionMethod = "bank_account";

      const {
        firstName,
        lastName,
        acceptTOS,
        businessType,
        ipAddress,
        businessName,
        businessUrl,
        dob,
        address,
        ssnLast4,
        taxId,
        bankCountry,
        currency,
        routingNumber,
        accountNumber,
        transactionMethod,
        cardNumber,
        expMonth,
        expYear,
        cvc,
      } = input;

      let find_seller = await database.Seller.findOne({
        where: { email },
      });
      const seller = JSON.parse(JSON.stringify(find_seller));
      if (!seller) {
        return {
          success: false,
          message: "Seller not found!"
        }
      }

      const findSellerConnectedAccount = await database.SellerConnectedAccount.findOne({
        where: {
          seller_id: find_seller?.id,
        },
        raw: true
      });

      if (findSellerConnectedAccount) {
        return {
          success: false,
          message: "Seller already has a connect account!"
        }
      }

      if (acceptTOS !== true) {
        return {
          success: false,
          message: "Seller must accept Terms of Service first!"
        }
      }

      if (!transactionMethod) {
        return {
          success: false,
          message: "Transaction method is required!"
        }
      }

      if (transactionMethod !== "bank_account" && transactionMethod !== "card") {
        return {
          success: false,
          message: "Transaction method must be either bank_account or card!"
        }
      }

      if (businessType !== "individual" && businessType !== "company") {
        return {
          success: false,
          message: "Business typemust be either individual or company!"
        }
      }

      // Validation for individual accounts
      if (businessType && businessType === "individual") {
        if (!firstName || !lastName) {
          return {
            success: false,
            message: "First name and Last name are required for individuals!",
          };
        }
        if (!dob || !dob.day || !dob.month || !dob.year) {
          return {
            success: false,
            message: "Date of birth (day, month, year) is required for individuals!",
          };
        }
        if (!ssnLast4) {
          return {
            success: false,
            message: "Last 4 digits of SSN are required for U.S. individuals!",
          };
        }
      }

      // Validation for company accounts
      if (businessType && businessType === "company") {
        if (!taxId) {
          return {
            success: false,
            message: "Tax ID is required for companies!",
          };
        }
      }

      // Validate required fields for card transaction method
      if (transactionMethod && transactionMethod === "card") {
        if (!cardNumber) {
          return {
            success: false,
            message: "Card number is required for card transaction method!",
          };
        }
        if (!expMonth) {
          return {
            success: false,
            message: "Expiration month is required for card transaction method!",
          };
        }
        if (!expYear) {
          return {
            success: false,
            message: "Expiration year is required for card transaction method!",
          };
        }
        if (!cvc) {
          return {
            success: false,
            message: "CVC is required for card transaction method!",
          };
        }
      }


      if (transactionMethod && transactionMethod === "bank_account") {
        // Validate required fields for bank account transaction method
        if (!bankCountry) {
          return {
            success: false,
            message: "Bank country is required for bank account transaction method!",
          };
        }
        if (!routingNumber) {
          return {
            success: false,
            message: "Routing number is required for bank account transaction method!",
          };
        }
        if (!accountNumber) {
          return {
            success: false,
            message: "Account number is required for bank account transaction method!",
          };
        }
        if (!firstName && businessType === "individual") {
          return {
            success: false,
            message: "First name is required for individual account holders!",
          };
        }
        if (!lastName && businessType === "individual") {
          return {
            success: false,
            message: "Last name is required for individual account holders!",
          };
        }
        if (!businessName && businessType === "company") {
          return {
            success: false,
            message: "Business name is required for company account holders!",
          };
        }
      }


      //* Stripe custom account creation
      const account = await stripe.accounts.create({
        type: "custom",
        country: seller?.country || "US",
        email: seller?.email,
        business_type: businessType,
        capabilities: {
          // card_payments: { requested: true },
          transfers: { requested: true },
        },
        tos_acceptance: {
          date: Math.floor(Date.now() / 1000),
          ip: ipAddress,
          user_agent: userAgent ?? "Unknown",
        },
        business_profile: {
          name: businessName,
          url: businessUrl,
        },
        ...(businessType && businessType === "individual" && {
          individual: {
            first_name: firstName,
            last_name: lastName,
            dob: {
              day: dob?.day,
              month: dob?.month,
              year: dob?.year,
            },
            address: {
              line1: address?.line1,
              line2: address?.line2,
              city: address?.city,
              state: address?.state,
              postal_code: address?.postalCode,
              country: address?.businessCountry
            },
            ssn_last_4: ssnLast4,
          },
        }),
        ...(businessType && businessType === "company" && {
          company: {
            name: businessName,
            tax_id: taxId,
            address: {
              line1: address?.line1,
              line2: address?.line2,
              city: address?.city,
              state: address?.state,
              postal_code: address?.postalCode,
              country: address?.businessCountry,
            },
          },
        })
      });

  
      let cardToken;
      if (transactionMethod && transactionMethod === "card") {
        cardToken = await stripe.tokens.create({
          card: {
            currency: currency,
            number: cardNumber,
            exp_month: expMonth,
            exp_year: expYear,
            cvc: cvc,
          },
        });
      }


      if (account && account.id) {

        if (transactionMethod && transactionMethod === "bank_account") {
          const externalAccount = await stripe.accounts.createExternalAccount(account?.id, {
            external_account: {
              object: 'bank_account',
              country: bankCountry,
              currency: currency,
              routing_number: routingNumber,
              account_number: accountNumber,
              account_holder_name: businessType === 'individual'
                ? `${firstName} ${lastName}`
                : businessName,
              account_holder_type: businessType === 'individual' ? 'individual' : 'company',
              metadata: {
                seller_id: seller?.id,
              },
            }
            });
        }

          if (transactionMethod && transactionMethod === "card") {
          const externalAccount = await stripe.accounts.createExternalAccount(account?.id, {
            external_account: cardToken?.id
          });
        }


        const sellerConnectAccount = await database.SellerConnectedAccount.create(
          {
            seller_id: seller?.id,
            stripeAccountId: account?.id,
            isConnectAccountDeleted: false,
            isPaymentOnboardingCompleted: false,
            details_submitted: false,
            isSellerAcceptsTOS: acceptTOS,
          },
        );


        const capabilities = Object.keys(account?.capabilities);

        const sanitizedSellerConnectAccount = JSON.parse(JSON.stringify(sellerConnectAccount));

        if (sanitizedSellerConnectAccount && sanitizedSellerConnectAccount?.id) {
          for await (const capability of capabilities) {
            await database.SellerConnectedAccountCapability.create(
              {
                seller_id: seller?.id,
                stripeAccountId: account?.id,
                sellerConnectedAccountId: sanitizedSellerConnectAccount?.id,
                name: capability,
                status: false
              }
            );
          }
        }
      }

      return {
        success: true,
        message: "Payment onboarding successfully.",
      }

    } catch (error) {
      console.error("An error occured while creating connect account: ", error);
      return {
        success: false,
        message: error?.message
      }
    }
  },

  addMoreBankAccountOrCard: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    try {
      const { email } = user;

      const {
        bankCountry,
        currency,
        routingNumber,
        accountNumber,
        transactionMethod,
        cardNumber,
        expMonth,
        expYear,
        cvc,
      } = input;

      const find_seller = await database.Seller.findOne({
        where: {
          email,
        },
      });

      const seller = JSON.parse(JSON.stringify(find_seller));

      if (!seller) {
        return {
          success: false,
          message: "Seller not found!"
        }
      }

      const findSellerConnectedAccount = await database.SellerConnectedAccount.findOne({
        where: {
          seller_id: seller?.id,
        },
      });

      const plainFindSellerConnectedAccount = JSON.parse(JSON.stringify(findSellerConnectedAccount));

      if (!plainFindSellerConnectedAccount) {
        return {
          success: false,
          message: "Seller does not have a connect account!"
        }
      }


      // Validate required fields for card transaction method
      if (transactionMethod === "card") {
        if (!currency) {
          return {
            success: false,
            message: "Currency is required for card transaction method!",
          };
        }
        if (!cardNumber) {
          return {
            success: false,
            message: "Card number is required for card transaction method!",
          };
        }
        if (!expMonth) {
          return {
            success: false,
            message: "Expiration month is required for card transaction method!",
          };
        }
        if (!expYear) {
          return {
            success: false,
            message: "Expiration year is required for card transaction method!",
          };
        }
        if (!cvc) {
          return {
            success: false,
            message: "CVC is required for card transaction method!",
          };
        }
      }


      if (transactionMethod === "bank_account") {
        // Validate required fields for bank account transaction method
        if (!bankCountry) {
          return {
            success: false,
            message: "Bank country is required for bank account transaction method!",
          };
        }
        if (!currency) {
          return {
            success: false,
            message: "Currency is required for bank account transaction method!",
          };
        }
        if (!routingNumber) {
          return {
            success: false,
            message: "Routing number is required for bank account transaction method!",
          };
        }
        if (!accountNumber) {
          return {
            success: false,
            message: "Account number is required for bank account transaction method!",
          };
        }
      }

      let cardToken;
      if (transactionMethod === "card") {
        cardToken = await stripe.tokens.create({
          card: {
            currency: currency,
            number: cardNumber,
            exp_month: expMonth,
            exp_year: expYear,
            cvc: cvc,
          },
        });
      }

      if (transactionMethod === "bank_account") {
        const externalAccount = await stripe.accounts.createExternalAccount(plainFindSellerConnectedAccount?.stripeAccountId, {
          external_account: {
            object: 'bank_account',
            country: bankCountry,
            currency: currency,
            routing_number: routingNumber,
            account_number: accountNumber,
            account_holder_name: plainFindSellerConnectedAccount?.businessName ?? `${plainFindSellerConnectedAccount?.firstName} ${plainFindSellerConnectedAccount?.lastName}`,
            account_holder_type: plainFindSellerConnectedAccount?.businessType,
            metadata: {
              seller_id: seller?.id,
            },
          },
        });
      }

      if (transactionMethod === "card") {
        const externalAccount = await stripe.accounts.createExternalAccount(plainFindSellerConnectedAccount?.stripeAccountId, {
          external_account: cardToken?.id
        });
      }

      return {
        success: true,
        message: "More payout method added successfully."

      }


    } catch (error) {
      console.error("An error occured while adding more external accounts!", error);
      return {
        success: false,
        message: error?.message
      }
    }
  },

  removeConnectAccount: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    try {
      if (user.role !== "admin") return new AuthenticationError("Unauthorized!");

      const { stripeAccountId } = input;
      if (!stripeAccountId)
        return {
          success: false,
          message: "Please provide the account id!"
        }

      const connectAccount = await database.SellerConnectedAccount.findOne({
        where: {
          stripeAccountId,
        },
        raw: true
      })

      if (!connectAccount) {
        return {
          success: false,
          message: "Invalid account id!"
        }
      }

      if (connectAccount.isConnectAccountDeleted) {
        return {
          success: false,
          message: "Account already deleted!"
        }
      }

      const deletedAccount = await stripe.accounts.del(stripeAccountId);

      if (deletedAccount.deleted) {
        return {
          success: true,
          message: "Connect account deleted successfully.",
        };
      } else {
        return {
          success: false,
          message: "Unable to delete the connect account. Please try again.",
        };
      }


    } catch (error) {
      console.error("An error occured while delete connect account!", error);
      return {
        success: false,
        message: error?.message
      }
    }
  },

  sellerWithdrawalFund: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    try {
      let { email } = user;
      const { withdrawAmount, currency, stripeAccountId, bankOrCardId } = input;
      if (!withdrawAmount) {
        return {
          success: false,
          message: "Withdraw amount is required!"
        }
      }

      if (!stripeAccountId) {
        return {
          status: false,
          message: "Stripe account id is required!"
        }
      }

      if (!bankOrCardId) {
        return {
          status: false,
          message: "Bank account id is required!"

        }
      }
      const find_seller = await database.Seller.findOne({
        where: {
          email,
        },
      });

      const seller = JSON.parse(JSON.stringify(find_seller));

      if (!seller) {
        return {
          success: false,
          message: "Seller not found!"
        }
      }

      const withdrawableAmount = await database.OrderItems.findAll({
        attributes: [
          [database.Sequelize.fn("sum", database.Sequelize.col("sellerFinalAmount")), "sellerFinalAmount"]
        ],
        where: {
          seller_id: seller?.id,
          order_status: "delivered",
        }
      });

      const withdrawableAmountInCents = withdrawableAmount[0]?.sellerFinalAmount && typeof withdrawableAmount[0]?.sellerFinalAmount === "number" ? (withdrawableAmount[0]?.sellerFinalAmount) * 100 : 0;

      const withdrawAmountInCents = withdrawAmount * 100;

      if (withdrawAmountInCents > withdrawableAmountInCents) {
        return {
          success: false,
          message: "Insufficient funds!"
        }
      }

      const transferFundsToSeller = await stripe.transfers.create({
        amount: withdrawAmountInCents,
        currency: currency,
        destination: stripeAccountId,
        description: "Transfer to seller's stripe connect account for product sale",
        metadata: {
          seller_id: seller?.id,
        },
      });

      if (transferFundsToSeller && transferFundsToSeller.id) {

        const payoutFundsToSeller = await stripe.payouts.create(
          {
            amount: withdrawAmountInCents,
            currency: currency || "usd",
            destination: bankOrCardId,
            method: "instant", // or 'standard' if available and enabled
            description:
              "Withdraw to seller's personal bank account for product sale",
            metadata: {
              seller_id: seller?.id,
            },
          },
          {
            stripeAccount: stripeAccountId,
          }
        );

        if (payoutFundsToSeller && payoutFundsToSeller?.id) {
          return {
            success: true,
            message: "Withdraw funds to seller's bank account successfully.",
          }
        }
      }
    } catch (error) {
      console.error("An error occcured while seller withdrawing funds", error);
      return {
        success: false,
        message: error?.message
      }
    }
  },
};
