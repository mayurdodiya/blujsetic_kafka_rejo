const { AuthenticationError } = require("apollo-server-express");
const AboutService = require("../../../database/services/about");
module.exports = {
  addAbout: async (root, { input }, { user }) => {
    if (user !== null) {
      const aboutData = await AboutService.add(input);
      return aboutData;
    }
    return new AuthenticationError("Please Provide Token");
  },
  updateAbout: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError(
          "Please Provide Id where you update the about detail"
        );
      }

      const aboutData = await AboutService.update(input);
      return aboutData;
    }
    return new AuthenticationError("Please Provide Token");
  },
  deleteAbout: async (root, { id }, { user }) => {
    if (user !== null) {
      if (!id) {
        return new AuthenticationError(
          "Please Provide Id where you delete the about detail"
        );
      }

      const about = await AboutService.delete(id);

      return about;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
