const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { AuthenticationError } = require("apollo-server-express");

const UserService = require("../../../database/services/user");
const { BioDetail } = require("../../../database/models");
module.exports = {
  addUserBio: async (root, args, { user }) => {
    const {
      user_id,
      marital_status,
      occupation,
      education,
      interest,
      about,
      experience,
      hobbies,
    } = args.input;

    if (user.id) {
      const checkUser = await BioDetail.findOne({
        where: { user_id: user.id },
      });
      // console.log("Check User",checkUser);
      if (checkUser) {
        throw new AuthenticationError("User Bio detail Is already exist...");
      } else {
        let BioDetailData = await BioDetail.create({
          user_id: user.id,
          marital_status,
          occupation,
          education,
          interest,
          about,
          experience,
          hobbies,
        });
        return BioDetailData;
      }
    } else {
      return new AuthenticationError("Please Provide Token");
    }
  },
};
