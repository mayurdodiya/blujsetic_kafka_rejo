const { AuthenticationError } = require("apollo-server-express");
const database = require("../../../database/models");
const elasticClient = require("../../../services/elasticsearch");
module.exports = {
  addStoreActivity: async (root, { input }, { user }) => {
    if (user !== null) {
      const isStoreExist = await database.BusinessInformation.findOne({
        where: {
          id: input.store_id,
        },
      });
      input.userType = user.token_type;
      input.user_id = user.id;
      if (!isStoreExist) return { success: false, message: "Store not found" };
      const storeActivityData = await database.StoreActivity.create(input);
      /* add store activity data into elastic search */
      let elkData = await elasticClient.storeActivities.addStoreActivities({ ...input, id: storeActivityData.id })
      if (!elkData.success) return { success: false, message: elkData.message };
      return { success: true, message: "activity stored", data: [storeActivityData] };
    }
    return new AuthenticationError("Please Provide Token");
  },
  updateStoreActivity: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError(
          "Please Provide Id where you update the storeActivity detail"
        );
      }

      const storeActivityData = await StoreActivityService.update(input);
      return storeActivityData;
    }
    return new AuthenticationError("Please Provide Token");
  },
  deleteStoreActivity: async (root, { id }, { user }) => {
    if (user !== null) {
      if (!id) {
        return new AuthenticationError(
          "Please Provide Id where you delete the storeActivity detail"
        );
      }

      const storeActivity = await StoreActivityService.delete(id);

      return storeActivity;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
