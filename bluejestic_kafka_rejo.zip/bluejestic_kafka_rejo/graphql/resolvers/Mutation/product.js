const { AuthenticationError, UserInputError } = require("apollo-server-express");
const ProductService = require("../../../database/services/product");
const database = require("../../../database/models");
// const { updateOrDeleteServiceOfProduct, findCropImages, findMediaUrlFromId, findMediaUrlFromIds, forAddDataInElasticSearchPlatform } = require("../../../utils/utils");
const { Op } = require("sequelize");
const elasticClient = require("../../../services/elasticsearch/index");
// const { deleteFileFromS3 } = require("../../../middlewares/storeImage");
const ShopifyProductService = require("../../../database/services/shopifyProduct");
const Sequelize = require("sequelize");
const DataTypes = require("sequelize");
const client = require("../../../services/elasticsearch/config/config");
const moment = require("moment");
const redisClient = require("../../../redis/redisClient");
const { default: axios } = require("axios");
const deleteProductCache = require("../../../utils/utils").deleteProductCache;
const { default: slugify } = require("slugify");
const { v4: uuidv4 } = require("uuid");

module.exports = {
  createProduct: async (root, { input }, { user }) => {
    if (!user) {
      return new AuthenticationError("Please Provide Token");
    }

    try {
      let find_color = input?.options?.find((op) => op.name.toLowerCase() === "color");

      let selectedVariant;

      const getSelectedVariant = async (variantArray) => {
        if (variantArray.length === 0) {
          // Handle the case where there are no variants.
          return null;
        }

        const isSamePrice = await variantArray.every((variant, index) => {
          return index === 0 || variant.price === variantArray[0].price;
        });

        if (isSamePrice) {
          // All variants have the same price, return the first one.
          return variantArray[0];
        } else {
          // Find the variant with the cheapest price.
          let cheapestVariant = variantArray[0];
          for await (const variant of variantArray) {
            if (parseFloat(variant.price) < parseFloat(cheapestVariant.price)) {
              cheapestVariant = variant;
            }
          }
          return cheapestVariant;
        }
      };

      if (Boolean(input?.variants?.length)) {
        selectedVariant = await getSelectedVariant(input?.variants);
      }

      const find_category = await database.Category.findOne({
        where: {
          id: Boolean(input?.category?.length) ? input?.category?.[0]?.category_id : 0,
        },
        raw: true,
      });

      const find_subCategory = await database.Subcategory.findOne({
        where: {
          id: Boolean(input?.category?.length) ? input?.category?.[0]?.subCategory_id : 0,
        },
        raw: true,
      });

      const find_childSubcategory = await database.Childsubcategory.findOne({
        where: {
          id: Boolean(input?.category?.length) ? input?.category?.[0]?.childSubCategory_id : 0,
        },
        raw: true,
      });

      let slug = slugify(input?.title, { lower: true, replacement: "-", remove: undefined, strict: true });
      let final_slug;
      let find_unique_user = await database.Product.findOne({
        where: {
          slug: slug,
        },
        // limit: limit,
        // offset: offset,
        raw: true,
      });

      if (!find_unique_user?.slug || find_unique_user?.slug === "") {
        final_slug = slug;
      } else {
        const uniqueId = uuidv4();
        final_slug = `${slug}-${uniqueId}`;
      }

      let productInput = {
        store_id: input?.store_id,
        title: input?.title,
        slug: final_slug,
        description: input?.description,
        isFeature: input?.isFeature,
        status: input?.status,
        isFreeShipping: input?.isFreeShipping,
        condition: input?.condition,
        metaTitle: input?.seo?.metaTitle,
        metaDescription: input?.seo?.metaDescription,
        keywords: input?.seo?.keywords,
        ratio: input?.ratio,
        shipping_method_id: input?.shipping_method_id,
        colorVariant: find_color ? find_color?.data?.length : null,
        dis_price: selectedVariant?.price ? selectedVariant?.price : input?.inventoryPrice?.price,
        dis_listPrice: selectedVariant?.listPrice ? selectedVariant?.listPrice : input?.inventoryPrice?.listPrice,
        brand_id: input?.brand_id,
        category_id: find_category ? input?.category[0]?.category_id : null,
        category: find_category ? find_category?.name : "",
        subCategory_id: find_subCategory ? input?.category[0]?.subCategory_id : null,
        subCategory: find_subCategory ? find_subCategory?.name : "",
        childSubcategory_id: find_childSubcategory ? input?.category[0]?.childSubCategory_id : null,
        childSubcategory: find_childSubcategory ? find_childSubcategory?.name : "",
      };

      const productShippingMethod = await database.ShippingMethod.findByPk(input?.shipping_method_id);
      if (!productShippingMethod) {
        return {
          success: false,
          message: "Product shipping method not found!",
        };
      }

      let product = await ShopifyProductService.add(productInput);
      product = JSON.parse(JSON.stringify(product));
      await deleteProductCache("PRODUCTS");
      await deleteProductCache("ALL_PRODUCTS");

      if (product) {
        let find_store_count = await database.BusinessInformation.findOne({
          where: {
            id: input?.store_id,
          },
          attributes: ["product_count", "id"],
          raw: true,
        });

        console.log("find_store_count", find_store_count);

        let update_store = await database.BusinessInformation.update(
          {
            product_count: find_store_count.product_count + 1,
          },
          {
            where: {
              id: input?.store_id,
            },
          }
        );
      }

      //* elastic search - create product ==============
      let elasticsearchInput = productInput;
      elasticsearchInput["id"] = product.id;
      elasticsearchInput["product_id"] = product.id;
      let productImages = [];
      for (const image_id of input?.images) {
        let find_images = await database.Media.findOne({
          where: {
            id: image_id,
          },
        });
        console.log("find_images+++++++", find_images);
        await productImages.push(find_images.media);
      }
      elasticsearchInput.images = productImages;
      if (find_color) {
        elasticsearchInput.colorVariant = find_color?.data?.length;
      } else {
        elasticsearchInput.colorVariant = null;
      }
      elasticsearchInput.brand_id = input?.brand_id;
      elasticsearchInput.dis_price = selectedVariant ? selectedVariant?.price : input?.inventoryPrice?.price;
      elasticsearchInput.dis_listPrice = selectedVariant ? selectedVariant?.listPrice : input?.inventoryPrice?.listPrice;
      elasticsearchInput.createdAt = moment().toISOString();
      elasticsearchInput.updatedAt = moment().toISOString();

      let data = await elasticClient.product.addProduct({ ...elasticsearchInput, is_deleted: false });
      if (!data.success) return new Error("Elasticsearch - addProduct - " + data.message);

      const indexName = "store";
      const fieldToUpdate = "product_count";
      const increaseValue = 1;
      console.log("follow >>>>>>>>>>>>>>>>> called");
      const {
        hits: { hits },
      } = await client.search({
        index: indexName,
        body: {
          query: {
            bool: {
              must: [
                {
                  match: { id: input?.store_id },
                },
              ],
            },
          },
        },
      });

      if (Boolean(hits?.length)) {
        let data = hits[0];
        const updatedQuantity = data?._source[fieldToUpdate] + increaseValue;
        const update_query = await client.update({
          index: indexName,
          id: data?._id,
          body: {
            doc: {
              [fieldToUpdate]: updatedQuantity,
            },
          },
        });
        console.log("product_count elastic search +++++++++++++++++++++++", update_query);
      }

      // if (update_store) {
      //   console.log("product_count increase successfully ++++++++++++++++++++++++");
      // }
      let storeTypes = ["JOIN_STORES", "SUGGESTED_STORES", "ALL_STORE"];
      process.nextTick(async () => {
        await redisClient.del(`PUBLIC:ALL_STORE`);
        for (let i = 0; i < storeTypes.length; i++) {
          let type = storeTypes[i];
          await redisClient.del(`USER/${user?.id}:${type}`);
        }
      });
      //* elastic search - create product end =================

      let productCategoryResponse;
      if (!product) {
        console.log(">>>>>>>>>>>>2");
        return new Error("Something went wrong");
      } else {
        // let productId = product.id;
        let userId = user.id;
        let productId = product.id;
        console.log(">>>>>>>>>>>>3", input?.category);

        if (input?.size && input?.size?.height && input?.size?.width) {
          await database.ProductImageSize.create({ height: input?.size?.height, width: input?.size?.width, product_id: product?.id });
        }

        for (let i = 0; i < input?.category?.length; i++) {
          const category = input?.category[i];
          let productCategoriesInput = {
            product_id: productId,
            user_id: userId,
            category_id: category.category_id,
            subCategory_id: category.subCategory_id,
            childSubCategory_id: category.childSubCategory_id,
          };
          productCategoryResponse = await database.ProductCategories.create(productCategoriesInput);
          break;
        }
        console.log(">>>>>>>>>>>>4");

        //*  product shipping_commented
        let productShippingDetails = {
          user_id: userId,
          product_id: productId,
          weightValue: input?.shipping?.weight?.value,
          weightUnit: input?.shipping?.weight?.unit,
          length: input?.shipping?.length,
          width: input?.shipping?.width,
          height: input?.shipping?.height,
          unit: input?.shipping?.unit,
        };
        let ProductShippingDetails = await database.ProductShippingDetails.create(productShippingDetails);

        //* Add Inventory

        let productInventoryDetail = {
          price: input?.inventoryPrice?.price,
          listPrice: input?.inventoryPrice?.listPrice,
          quantity: input?.inventoryPrice?.quantity,
          sku: input?.inventoryPrice?.sku,
          product_id: product.id,
        };

        let add_product_inventory = await database.ProductInventory.create(productInventoryDetail);

        if (Boolean(input?.attributes?.length)) {
          for await (const attr of input?.attributes) {
            await database.ProductAttributes.create({ product_id: product.id, type: attr?.type, name: attr?.name, value: attr?.value, user_id: user.id });
          }
        }

        console.log(">>>>>>>>>>>>7");
        // product other attributes
        if (input?.options && input?.options.length > 0) {
          for (const attr of input?.options) {
            let variant_data = await database.Variation.create({ name: attr.name, product_id: product.id });
            let convert_parse = JSON.parse(attr?.data);
            console.log("convert_parse++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", convert_parse);
            if (Boolean(convert_parse?.length)) {
              for await (const val of convert_parse) {
                let variation_option_object = {
                  variation_id: variant_data?.dataValues?.id,
                  value: val?.name ? val?.name : val,
                  ...(val?.colorCode && {
                    colorCode: val?.colorCode,
                  }),
                  product_id: product.id,
                };

                let variation_option = await database.VariationOption.create(variation_option_object);
              }
            }
          }
        }

        if (Boolean(input?.images?.length)) {
          for (const img_id of input?.images) {
            let find_image = await database.Media.findOne({
              where: {
                id: img_id,
              },
            });
            if (find_image) {
              await database.ProductMedia.create({ product_id: product.id, media_id: img_id, src: find_image.media });
            }
          }
        }

        if (Boolean(input?.tags)) {
          for (const tag of input?.tags) {
            await database.ProductTag.create({ tag: tag, product_id: product.id });
          }
        }

        if (Boolean(input?.variants?.length)) {
          for (const attr of input?.variants) {
            let updatedObject = {
              inventory_quantity: attr?.inventory_quantity,
              old_inventory_quantity: attr?.old_inventory_quantity,
              image_id: attr?.image_id,
              isTaxable: attr?.isTaxable,
              grams: attr?.grams,
              price: attr?.price,
              listPrice: attr?.listPrice,
              sku: attr?.sku,
              barcode: attr?.barcode,
              weightValue: attr?.weightValue,
              weightUnit: attr?.weightUnit,
              length: attr?.length,
              width: attr?.width,
              height: attr?.height,
              unit: attr?.unit,
              product_id: product.id,
              position: attr?.position,
              on_hand: attr?.on_hand,
            };

            let product_item_id = await database.ProductItem.create(updatedObject);
            for (const variant of attr?.total_variant) {
              let find_variant_option = await database.VariationOption.findOne({
                where: {
                  value: variant,
                  product_id: product.id,
                },
              });
              if (find_variant_option) {
                await database.ProductConfiguration.create({
                  product_item_id: product_item_id.id,
                  variant_option_id: find_variant_option.id,
                  product_id: product.id,
                });
              }
            }
          }
        }
      }

      // const response = await axios.post(`${process.env.FAST_API_LOCAL}/v1/embed/product`, {
      // const response = await axios.post(`${process.env.FAST_API_STAGE}/v1/embed/product`, {
      //   product_id: product?.id,
      //   product_category_id: productCategoryResponse?.dataValues?.id ?? null,
      // });

      const Payload = {
        product_id: product?.id,
        product_category_id: productCategoryResponse?.dataValues?.id ?? null,
      };

      let config = {
        method: "post",
        maxBodyLength: Infinity,
        // url: `${process.env.FAST_API_STAGE}/v1/embed/product`,
        // url: `${process.env.FAST_API_LOCAL}/v1/embed/product`,
        // url: "http://prodocts-recommendation-stage-svc.bluejestic.svc.cluster.local:5000/v1/embed/product",
        url: "http://34.138.21.186:5000/v1/embed/product",
        headers: {
          "Content-Type": "application/json",
        },
        data: Payload,
      };

      let response = await axios(config);

      return { success: true, message: "Product added successfully", product: {} };
    } catch (error) {
      console.error("An error occured while adding product", error);
      throw new Error("An error occured while adding product");
    }
  },

  updateProduct: async (root, { input }, { user }) => {
    if (!user) {
      return new AuthenticationError("Please Provide Token");
    }

    if (!input.id) {
      return { success: false, message: "Please Provide Product Id" };
    }
    try {
      let product = await database.Product.findOne({
        where: {
          id: Number(input.id),
          is_deleted: false,
        },
      });
      if (!product) {
        return { success: false, message: "Product not found" };
      }

      let find_color = input?.options?.find((op) => op.name.toLowerCase() === "color");

      if (product) {
        let productItems_destroy = await database.ProductItem.destroy({
          where: {
            product_id: product.id,
          },
        });
        console.log("2 >>>>>>>>>>>>>> update");

        let variation_destroy = await database.Variation.destroy({
          where: {
            product_id: product.id,
          },
        });
        console.log("3 >>>>>>>>>>>>>> update");

        let variationOptions_destroy = await database.VariationOption.destroy({
          where: {
            product_id: product.id,
          },
        });
        console.log("4 >>>>>>>>>>>>>> update");

        let productConfigurations_destroy = await database.ProductConfiguration.destroy({
          where: {
            product_id: product.id,
          },
        });
        console.log("5 >>>>>>>>>>>>>> update");

        let productMedia_destroy = await database.ProductMedia.destroy({
          where: {
            product_id: product.id,
          },
        });
        console.log("6 >>>>>>>>>>>>>> update");

        let productInventory_destroy = await database.ProductInventory.destroy({
          where: {
            product_id: product.id,
          },
        });

        console.log("6.5 >>>>>>>>>>>>>> update");

        // let media_destroy = await database.Media.destroy({
        //   where: {
        //     parent_id: product.id,
        //   },
        // });

        if (Boolean(input?.removeImages?.length)) {
          for await (const prd of input?.removeImages) {
            let media_destroy = await database.Media.destroy({
              where: {
                id: prd,
              },
            });
          }
        }

        let size_destroy = await database.ProductImageSize.destroy({
          where: {
            product_id: product.id,
          },
        });
        console.log("7.5 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

        let attributes_destroy = await database.ProductAttributes.destroy({
          where: {
            product_id: product.id,
          },
        });
        console.log("7.6 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

        let tag_destroy = await database.ProductTag.destroy({
          where: {
            product_id: product.id,
          },
        });
        console.log("7.7 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

        let category_destroy = await database.ProductCategories.destroy({
          where: {
            product_id: product.id,
          },
        });
        console.log("7.99 >>>>>>>>>>>>>> add-webhook-in-else-for-update");

        //* ========================================================================================================================================

        let userId = user.id;
        let productId = product.id;
        console.log(">>>>>>>>>>>>3", input?.category);

        let selectedVariant;

        const getSelectedVariant = async (variantArray) => {
          if (variantArray.length === 0) {
            return null;
          }

          const isSamePrice = await variantArray.every((variant, index) => {
            return index === 0 || variant.price === variantArray[0].price;
          });

          if (isSamePrice) {
            return variantArray[0];
          } else {
            let cheapestVariant = variantArray[0];
            for await (const variant of variantArray) {
              if (parseFloat(variant.price) < parseFloat(cheapestVariant.price)) {
                cheapestVariant = variant;
              }
            }
            return cheapestVariant;
          }
        };

        if (Boolean(input?.variants?.length)) {
          selectedVariant = await getSelectedVariant(input?.variants);
        }

        let productInput = {
          store_id: input?.store_id,
          title: input?.title,
          description: input?.description,
          isFeature: input?.isFeature,
          status: input?.status,
          isFreeShipping: input?.isFreeShipping,
          condition: input?.condition,
          tags: input?.tags,
          metaTitle: input?.seo?.metaTitle,
          metaDescription: input?.seo?.metaDescription,
          shipping_method_id: input?.shipping_method_id,
          keywords: input?.seo?.keywords,
          ratio: input?.ratio,
          colorVariant: find_color ? find_color?.data?.length : null,
          dis_price: selectedVariant ? selectedVariant?.price : input?.inventoryPrice?.price,
          dis_listPrice: selectedVariant ? selectedVariant?.listPrice : input?.inventoryPrice?.listPrice,
          brand_id: input?.brand_id,
        };
        console.log("8 >>>>>>>>>>>>>> update");

        const productShippingMethod = await database.ShippingMethod.findByPk(input?.shipping_method_id);
        if (!productShippingMethod) {
          return {
            success: false,
            message: "Product shipping method not found!",
          };
        }

        let response = await database.Product.update(productInput, {
          where: {
            id: product.id,
          },
        });
        await deleteProductCache("PRODUCTS");
        await deleteProductCache("ALL_PRODUCTS");

        let storeTypes = ["JOIN_STORES", "SUGGESTED_STORES", "ALL_STORE"];
        process.nextTick(async () => {
          await redisClient.del(`PUBLIC:ALL_STORE`);
          for (let i = 0; i < storeTypes.length; i++) {
            let type = storeTypes[i];
            await redisClient.del(`USER/${user?.id}:${type}`);
          }
        });

        console.log("9 >>>>>>>>>>>>>> update");

        let elasticsearchInput = productInput;
        let productImages = [];
        for (const image_id of input?.images) {
          let find_images = await database.Media.findOne({
            where: {
              id: image_id,
            },
          });
          // console.log("find_images+++++++", find_images);
          await productImages.push(find_images.media);
        }
        elasticsearchInput.images = productImages;
        elasticsearchInput.brand_id = input?.brand_id;
        if (find_color) {
          elasticsearchInput.colorVariant = find_color?.data?.length;
        } else {
          elasticsearchInput.colorVariant = null;
        }

        elasticsearchInput.dis_price = selectedVariant ? selectedVariant?.price : input?.inventoryPrice?.price;
        elasticsearchInput.dis_listPrice = selectedVariant ? selectedVariant?.listPrice : input?.inventoryPrice?.listPrice;

        const isExists = await client.search({
          index: "products",
          body: {
            query: {
              match: {
                id: product.id,
              },
            },
          },
        });

        if (Boolean(isExists?.hits?.hits?.length) && isExists.hits.hits[0]?._source) {
          elasticsearchInput.createdAt = isExists.hits.hits[0]?._source.createdAt;
        }

        elasticsearchInput.updatedAt = moment().toISOString();

        let data = await elasticClient.product.updateProductById("products", product.id, { ...elasticsearchInput, is_deleted: false });
        if (!data.success) return new Error("Elasticsearch - addProduct - " + data.message);

        if (input?.size && input?.size?.height && input?.size?.width) {
          await database.ProductImageSize.create({ height: input?.size?.height, width: input?.size?.width, product_id: product?.id });
        }

        //* product categories_commented
        let productCategoryResponse;
        if (input?.category && input?.category.length > 0) {
          for (const cat of input?.category) {
            let productCategoriesInput = {
              product_id: productId,
              user_id: userId,
              category_id: cat.category_id,
              subCategory_id: cat.subCategory_id,
              childSubCategory_id: cat.childSubCategory_id,
            };
            productCategoryResponse = await database.ProductCategories.create(productCategoriesInput);
          }
        }
        console.log(">>>>>>>>>>>>4");

        //*  product shipping_commented
        let productShippingDetails = {
          user_id: userId,
          product_id: productId,
          weightValue: input?.shipping?.weight?.value,
          weightUnit: input?.shipping?.weight?.unit,
          length: input?.shipping?.length,
          width: input?.shipping?.width,
          height: input?.shipping?.height,
          unit: input?.shipping?.unit,
        };
        let ProductShippingDetails = await database.ProductShippingDetails.create(productShippingDetails);

        //* Add Inventory

        let productInventoryDetail = {
          price: input?.inventoryPrice?.price,
          listPrice: input?.inventoryPrice?.listPrice,
          quantity: input?.inventoryPrice?.quantity,
          sku: input?.inventoryPrice?.sku,
          product_id: product.id,
        };

        let add_product_inventory = await database.ProductInventory.create(productInventoryDetail);

        if (Boolean(input?.attributes?.length)) {
          for await (const attr of input?.attributes) {
            await database.ProductAttributes.create({ product_id: product.id, type: attr?.type, name: attr?.name, value: attr?.value, user_id: user.id });
          }
        }

        console.log(">>>>>>>>>>>>7");
        // product other attributes
        if (Boolean(input?.options?.length)) {
          for (const attr of input?.options) {
            let variant_data = attr?.data ? await database.Variation.create({ name: attr.name, product_id: product.id }) : null;
            let convert_parse = attr?.data ? JSON.parse(attr?.data) : [];
            // for await (const val of attr?.data) {
            //   let variation_option = await database.VariationOption.create({
            //     variation_id: variant_data?.dataValues?.id,
            //     value: val,
            //     product_id: product.id,
            //   });
            // }
            if (Boolean(convert_parse?.length)) {
              for await (const val of convert_parse) {
                let variation_option_object = {
                  variation_id: variant_data?.dataValues?.id,
                  value: val?.name ? val?.name : val,
                  ...(val?.colorCode && {
                    colorCode: val?.colorCode,
                  }),
                  product_id: product.id,
                };

                let variation_option = await database.VariationOption.create(variation_option_object);
              }
            }
          }
        }

        if (Boolean(input?.images?.length)) {
          for (const img_id of input?.images) {
            let find_image = await database.Media.findOne({
              where: {
                id: img_id,
              },
            });
            if (find_image) {
              await database.ProductMedia.create({ product_id: product.id, media_id: img_id, src: find_image.media });
            }
          }
        }

        if (Boolean(input?.tags)) {
          for (const tag of input?.tags) {
            await database.ProductTag.create({ tag: tag, product_id: product.id });
          }
        }

        if (Boolean(input?.variants?.length)) {
          for (const attr of input?.variants) {
            let updatedObject = {
              inventory_quantity: attr?.inventory_quantity,
              old_inventory_quantity: attr?.old_inventory_quantity,
              image_id: attr?.image_id,
              isTaxable: attr?.isTaxable,
              grams: attr?.grams,
              price: attr?.price,
              list_price: attr?.list_price,
              sku: attr?.sku,
              barcode: attr?.barcode,
              weightValue: attr?.weightValue,
              weightUnit: attr?.weightUnit,
              length: attr?.length,
              width: attr?.width,
              height: attr?.height,
              unit: attr?.unit,
              product_id: product.id,
              position: attr?.position,
            };

            let product_item_id = await database.ProductItem.create(updatedObject);
            for (const variant of attr?.total_variant) {
              let find_variant_option = await database.VariationOption.findOne({
                where: {
                  value: variant,
                  product_id: product.id,
                },
              });
              if (find_variant_option) {
                await database.ProductConfiguration.create({
                  product_item_id: product_item_id.id,
                  variant_option_id: find_variant_option.id,
                  product_id: product.id,
                });
              }
            }
          }
        }

        const Payload = {
          product_id: product?.id,
          product_category_id: productCategoryResponse?.dataValues?.id ?? null,
        };

        let config = {
          method: "post",
          maxBodyLength: Infinity,
          // url: `${process.env.FAST_API_STAGE}/v1/embed/product`,
          url: `${process.env.FAST_API_STAGE}/v1/embed/product`,
          // url: "http://34.138.21.186:5000/v1/embed/product",
          // url: `${process.env.FAST_API_LOCAL}/v1/embed/product`,
          headers: {
            "Content-Type": "application/json",
          },
          data: Payload,
        };

        let response1 = await axios(config);

        //* ========================================================================================================================================
      }

      return { success: true, message: "Product updated successfully", product: {} };
    } catch (error) {
      console.error("An error occured while updatinf the product: ", error);
      throw new Error("An error occured while updatinf the product");
    }
  },

  deleteProduct: async (root, { id }, { user }) => {
    if (user !== null) {
      if (!id) return new UserInputError("Product id is required");
      const product = await database.Product.findOne({ where: { id: id, is_deleted: false } });

      if (!product) {
        return new UserInputError("Product Already Deleted otherwise Product not found");
      }

      if (product) {
        await ProductService.delete(id);
        const isExists = await client.search({
          index: "products",
          body: {
            query: {
              match: {
                id: id,
              },
            },
          },
        });
        await deleteProductCache("PRODUCTS");
        await deleteProductCache("ALL_PRODUCTS");

        if (Boolean(isExists?.hits?.hits?.length) && isExists.hits.hits[0]?._source) {
          let data = await elasticClient.product.updateProductById("products", product.id, { ...isExists.hits.hits[0]._source, is_deleted: true });
          if (!data.success) return new Error("Elasticsearch - addProduct - " + data.message);

          if (isExists.hits.hits[0]?._source?.store_id) {
            const indexName = "store";
            const fieldToUpdate = "product_count";
            const increaseValue = 1;
            console.log("follow >>>>>>>>>>>>>>>>> called");
            const {
              hits: { hits },
            } = await client.search({
              index: indexName,
              body: {
                query: {
                  bool: {
                    must: [
                      {
                        match: { id: isExists.hits.hits[0]?._source?.store_id },
                      },
                    ],
                  },
                },
              },
            });

            if (Boolean(hits?.length)) {
              let data = hits[0];
              const updatedQuantity = data?._source[fieldToUpdate] === 0 ? 0 : data?._source[fieldToUpdate] - increaseValue;
              const update_query = await client.update({
                index: indexName,
                id: data?._id,
                body: {
                  doc: {
                    [fieldToUpdate]: updatedQuantity,
                  },
                },
              });
              console.log("product_count elastic search +++++++++++++++++++++++", update_query);
            }

            // if (update_store) {
            //   console.log("product_count increase successfully ++++++++++++++++++++++++");
            // }
          }
        }

        return { id: product.id };
      }
    }
    // return new AuthenticationError("Please Provide Token");
  },

  assignProduct: async (root, { store_id, product_id }, { user }) => {
    if (user.token_type !== "admin") return new AuthenticationError("Unauthorized");
    const result = await database.Product.update(
      { store_id: store_id },
      {
        where: {
          id: product_id,
        },
      }
    );
    if (!result) {
      return { success: false, message: "something went wrong !" };
    }
    let successed_array = [];
    if (Boolean(product_id?.length)) {
      for (const id of product_id) {
        let data = await elasticClient.product.updateProductById("products", id, { store_id: store_id });
        successed_array.push(data?.success);
      }
    }
    function checkArray(arr) {
      const allTrue = arr.every((value) => value === true);

      if (allTrue) {
        return {
          result: true,
          count: arr.length,
        };
      } else {
        return { result: true, count: arr.length };
      }
    }

    const final = await checkArray(successed_array);
    console.log(final?.count, product_id);

    if (final?.result && final?.count === product_id?.length) {
      return { success: true, message: "Assigned Products" };
    }
    return { success: false, message: "All Product is not assinged" };
  },

  updateBulkProduct: async (root, { input }, { user }) => {
    try {
      // if (user.token_type !== "admin") return new AuthenticationError("Unauthorized");
      // let products = [
      //   {
      //     product_id: 10,
      //     images: [
      //       {
      //         media_id: 37043,
      //         position: 1,
      //       },
      //       {
      //         media_id: 37042,
      //         position: 2,
      //       },
      //       {
      //         media_id: 37041,
      //         position: 3,
      //       },
      //       {
      //         media_id: 37040,
      //         position: 4,
      //       },
      //       {
      //         media_id: 37045,
      //         position: 5,
      //       },
      //       {
      //         media_id: 37044,
      //         position: 6,
      //       },
      //     ],
      //     status: "Draft",
      //     category: [
      //       {
      //         category_id: 0,
      //         subCategory_id: 0,
      //         childSubCategory_id: 0,
      //       },
      //     ],
      //   },
      //   {
      //     product_id: 10,
      //     images: [
      //       {
      //         media_id: 37043,
      //         position: 2,
      //       },
      //       {
      //         media_id: 37042,
      //         position: 3,
      //       },
      //       {
      //         media_id: 37041,
      //         position: 1,
      //       },
      //       {
      //         media_id: 37040,
      //         position: 6,
      //       },
      //       {
      //         media_id: 37045,
      //         position: 4,
      //       },
      //       {
      //         media_id: 37044,
      //         position: 5,
      //       },
      //     ],
      //     status: "Publish",
      //     category: [
      //       {
      //         category_id: 0,
      //         subCategory_id: 0,
      //         childSubCategory_id: 0,
      //       },
      //     ],
      //   },
      // ];

      const products = input?.products;

      console.log("products++++++++++++", input?.products);

      if (product?.shipping_method_id) {
        const result = await database.Product.update(
          { shipping_method_id: product?.status },
          {
            where: {
              id: products.map((i) => i?.id),
            },
          }
        );
      }

      for (let i = 0; i < products.length; i++) {
        const product = products[i];
        //* update product images
        for (let j = 0; j < product.images.length; j++) {
          const image = product.images[j];
          const result = await database.ProductMedia.update(
            { position: image.position },
            {
              where: {
                media_id: image?.media_id,
              },
            }
          );
        }

        //* update status
        if (product?.status) {
          const result = await database.Product.update(
            { status: product?.status },
            {
              where: {
                id: product?.id,
              },
            }
          );
        }

        //* update category

        const find_category = await database.Category.findOne({
          where: {
            id: Boolean(product?.category?.length) ? product?.category?.[0]?.category_id : 0,
          },
          raw: true,
        });

        const find_subCategory = await database.Subcategory.findOne({
          where: {
            id: Boolean(product?.category?.length) ? product?.category?.[0]?.subCategory_id : 0,
          },
          raw: true,
        });

        const find_childSubcategory = await database.Childsubcategory.findOne({
          where: {
            id: Boolean(product?.category?.length) ? product?.category?.[0]?.childSubCategory_id : 0,
          },
          raw: true,
        });
        for (let i = 0; i < product?.category?.length; i++) {
          const category = product.category[i];
          let find_product = await database.ProductCategories.findOne({ where: { product_id: product?.id } });
          if (find_product) {
            const result = await database.ProductCategories.update(
              { category_id: category?.category_id, subCategory_id: category?.subCategory_id, childSubCategory_id: category?.childSubCategory_id },
              {
                where: {
                  product_id: product?.id,
                },
              }
            );
          } else {
            const result = await database.ProductCategories.create({ category_id: category?.category_id, subCategory_id: category?.subCategory_id, childSubCategory_id: category?.childSubCategory_id, product_id: product?.id, user_id: user?.id });
          }
          let data = await elasticClient.product.updateProductById("products", product?.id, {
            category_id: find_category ? product?.category[0]?.category_id : null,
            category: find_category ? find_category?.name : "",
            subCategory_id: find_subCategory ? product?.category[0]?.subCategory_id : null,
            subCategory: find_subCategory ? find_subCategory?.name : "",
            childSubcategory_id: find_childSubcategory ? product?.category[0]?.childSubCategory_id : null,
            childSubcategory: find_childSubcategory ? find_childSubcategory?.name : "",
          });
        }

        //* Update Vendor
        // for (let i = 0; i < product?.store_id?.length; i++) {
        if (product?.store_id) {
          const result = await database.Product.update(
            { store_id: product?.store_id },
            {
              where: {
                id: product?.id,
              },
            }
          );
        }
        // }

        //* update attributes
        if (Boolean(product?.attributes?.length)) {
          await database.ProductAttributes.destroy({ where: { product_id: product?.id, user_id: user?.id } });
        }
        for (let i = 0; i < product?.attributes?.length; i++) {
          const attri = product?.attributes[i];
          // if (attri?.id) {
          //   const result = await database.ProductAttributes.update(
          //     { name: attri?.name, value: attri?.value, product_id: product?.id, user_id: user?.id },
          //     {
          //       where: {
          //         id: attri?.id,
          //       },
          //     }
          //   );
          // } else {
          const result = await database.ProductAttributes.create({ ...attri, product_id: product?.id, user_id: user?.id });
          // }
        }
      }
      return { success: true, message: "Updated successfully" };
    } catch (error) {
      console.log("error+++++++++++++++++++", error);
    }
  },

  updateBulkProductStatusCategory: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please provide the token!");
    if (user.role !== "admin") return new AuthenticationError("Unauthorized!");

    try {
      if (!Array.isArray(input?.product_ids) || !input?.product_ids.length) {
        return {
          success: false,
          message: "Please provide valid product id(s)!"
        }
      }

      for (const product_id of input?.product_ids) {
        let find_product = await database.Product.findOne({
          where: {
            id: product_id
          },
          include: [
            {
              model: database.ProductCategories,
              as: "categories"
            }
          ]
        });

        find_product = JSON.parse(JSON.stringify(find_product));

        if (!find_product) {
          return {
            success: false,
            message: "Product not found!"
          }
        }

        let status = ["Publish", "Draft", "Archieved"];

        if (input?.status) {
          if (!status.includes(input?.status)) {
            return {
              success: false,
              message: "Invalid status provided!"
            }
          } else {
            await database.Product.update({

              status: input?.status
            }, {
              where: {
                id: find_product?.id
              }
            });
          }
        }

        if (input?.category_id && !input?.sub_category_id && !input?.child_sub_category_id) {
          return {
            success: false,
            message: "Please provide all 3 categories!"
          }
        }

        if (input?.category_id && input?.sub_category_id && !input?.child_sub_category_id) {
          return {
            success: false,
            message: "Please provide all 3 categories!"
          }
        }

        if (input?.category_id && input?.sub_category_id && input?.child_sub_category_id) {

          const find_categories = await database.Category.findOne({
            where: {
              ...(input?.category_id && { id: input?.category_id })
            },
            include: [
              {
                model: database.Subcategory,
                as: "subCategory",
                ...(input?.sub_category_id && { id: input?.sub_category_id }),
                include: [
                  {
                    model: database.Childsubcategory,
                    as: "childSubCategory",
                    ...(input?.child_sub_category_id && { id: input?.child_sub_category_id }),
                  }
                ]
              }
            ]
          });


          if (!find_categories) {
            return {
              success: false,
              message: "Please provide valid 3 categories!"
            }
          }

          if (find_product?.categories && Array.isArray(find_product?.categories) && !find_product?.categories.length) {
            await database.ProductCategories.create({
              user_id: user?.id,
              product_id: find_product?.id,
              category_id: input?.category_id,
              subCategory_id: input?.sub_category_id,
              childSubCategory_id: input?.child_sub_category_id,
            });
          } else {
            await database.ProductCategories.update({
              category_id: input?.category_id,
              subCategory_id: input?.sub_category_id,
              childSubCategory_id: input?.child_sub_category_id,
            }, {
              where: {
                product_id: find_product?.id
              }
            });
          }
        }

      }

      return {
        success: true,
        message: "Product(s) updated successfully."
      }

    } catch (error) {
      console.error("An error occured while updating bulk product: ", error);
      return {
        success: false,
        message: "An error occured while updating bulk product!"
      }
    }
  },

  updateBulkProductSeller: async (root, { input }, { user }) => {
    const { product_id, shipping_method_id, status, category_id, subCategory_id, childSubCategory_id } = input;
    try {
      if (product_id?.length <= 0) {
        return { success: false, message: "Please provide product_id" };
      }

      console.log("product_id", product_id, shipping_method_id, status, category_id, subCategory_id, childSubCategory_id);

      const [product_update] = await database.Product.update(
        {
          shipping_method_id: shipping_method_id,
          status: status,
        },
        {
          where: {
            id: {
              [Op.in]: product_id, // Assuming image.media_ids is the array of IDs
            },
          },
        }
      );

      console.log("product_update", product_update);

      if (!product_update) {
        return { success: false, message: "Shipping Mehtod or Status not update" };
      }

      const [product_category_update] = await database.ProductCategories.update(
        {
          category_id: category_id,
          subCategory_id: subCategory_id,
          childSubCategory_id: childSubCategory_id,
        },
        {
          where: {
            product_id: {
              [Op.in]: product_id, // Assuming image.media_ids is the array of IDs
            },
          },
        }
      );

      if (!product_category_update) {
        return { success: false, message: "Category not update" };
      }
      return { success: true, message: "Bulk update successfully" };
    } catch (error) {
      console.log("error=>", error);
    }
  },

  removeBulkProduct: async (root, { input: { product_id } }, { user }) => {
    if (!user) return new AuthenticationError("Please provide the token!");
    if (user.token_type !== "admin") return new AuthenticationError("Unauthorized!");
    try {

      if (!Array.isArray(product_id) || !product_id.length) {
        return {
          success: false,
          message: "Please provide valid Product id(s)!"
        }
      }

      for (let i = 0; i < product_id?.length; i++) {
        let id = product_id[i];
        let product = await database.Product.findOne({ where: { id: id, is_deleted: false } });

        product = JSON.parse(JSON.stringify(product));

        if (!product) {
          return new UserInputError("Product Already Deleted otherwise Product not found");
        }

        if (product) {
          await ProductService.delete(id);
          await deleteProductCache("PRODUCTS");
          await deleteProductCache("ALL_PRODUCTS");
          const indexName = "products"
          const isExists = await client.search({
            index: indexName,
            body: {
              query: {
                match: {
                  id: id,
                },
              },
            },
          });


          if (Boolean(isExists?.hits?.hits?.length) && isExists.hits.hits[0]?._source) {

            const _source = isExists.hits.hits[0]?._source;

            const updatedDocument = {
              ..._source,
              is_deleted: true
            };

            const updateResponse = await client.update({
              index: indexName,
              id: isExists.hits.hits[0]?._id,
              body: {
                doc: updatedDocument,
              },
            });
          }
        }
      }
      return { success: true, message: "Product(s) deleted successfully." };
    } catch (error) {
      console.error("An error occured while deleting product(s): ", error);
      return {
        success: false,
        message: error?.message ?? "An error occured while deleting product(s): "
      }
    }
  },

  updateBulkProductStatus: async (root, { input: { product_id, status } }, { user }) => {
    const status_array = ["Publish", "Draft"];
    console.log("product_id, status++++++++++++++++++++", product_id, status);
    if (user.token_type !== "admin") return new AuthenticationError("Unauthorized");
    if (!status_array.includes(status)) return { success: true, message: "Please Provide Valid Status" };
    for (let i = 0; i < product_id?.length; i++) {
      let id = product_id[i];
      const result = await database.Product.update(
        { status: status },
        {
          where: {
            id: id,
          },
        }
      );

      if (result) {
        const isExists = await client.search({
          index: "products",
          body: {
            query: {
              match: {
                id: id,
              },
            },
          },
        });
        let product;
        if (Boolean(isExists?.hits?.hits?.length) && isExists.hits.hits[0]?._source) {
          product = isExists.hits.hits[0]._source;
          let data = await elasticClient.product.updateProductById("products", id, { ...isExists.hits.hits[0]._source, status: status });
          if (!data.success) return new Error("Elasticsearch - addProduct - " + data.message);
        }

        process.nextTick(async () => {
          let get_product_count = await database.Product.count({
            where: {
              store_id: product?.store_id,
              status: "Publish",
            },
          });
          if (get_product_count === 0) {
            let update = await database.BusinessInformation.update(
              {
                product_count: get_product_count,
                status: "Inactive",
              },
              {
                where: {
                  id: product?.store_id,
                },
              }
            );
            let data = await elasticClient.store.updateStoreById("store", product?.store_id, { status: "Inactive", product_count: get_product_count });
            // if (!data.success) return new Error("Elasticsearch - addProduct - " + data.message);
          } else {
            let update = await database.BusinessInformation.update(
              {
                product_count: get_product_count,
                status: "Active",
              },
              {
                where: {
                  id: product?.store_id,
                },
              }
            );
            let data = await elasticClient.store.updateStoreById("store", product?.store_id, { status: "Active", product_count: get_product_count });
          }
        });
      }
    }
    await deleteProductCache("PRODUCTS");
    await deleteProductCache("ALL_PRODUCTS");
    return { success: true, message: "Status Updated Successfully" };
  },

  postProductForRecommendation: async (root, args, { user }) => {
    try {
      const Payload = {
        ...args,
      };

      const find_prod = await database.Product.findOne({
        where: {
          id: args?.product_id,
        },
        attributes: ["id"],
        raw: true,
      });

      if (find_prod) {
        let config = {
          method: "post",
          maxBodyLength: Infinity,
          // url: "http://prodocts-recommendation-stage-svc.bluejestic.svc.cluster.local:5000/v1/embed/product",
          // url: "http://34.138.21.186:5000/v1/embed/product",
          url: `${process.env.FAST_API_STAGE}/v1/embed/product`,
          headers: {
            "Content-Type": "application/json",
          },
          data: Payload,
        };
        let response = await axios(config);
        console.log("response", JSON.stringify(response?.data));
        if (response?.data?.message) {
          return { success: true, message: response?.data?.message };
        } else {
          return { success: false, message: "Something went wrong!" };
        }
      } else {
        return { success: false, message: "Please Verify product_id" };
      }
    } catch (error) {
      console.log("error", error);
      return { success: false, message: "Something went wrong!" };
    }
  },
};

// createProduct: async (root, { input }, { user }) => {
//   try {
//     // console.log("input>>>>>>>>>>>>>>>>>", input.cropImages);
//     // return
//     if (user !== null) {
//       if (!input?.store_id) {
//         return { success: false, message: "Please provide store id", product: {} };
//       }
//       const store = await database.BusinessInformation.findOne({ where: { id: input?.store_id } });
//       if (!store) {
//         return { success: false, message: "Store not found", product: {} };
//       }
//       // console.log("input>>>>>>>>>>>>>>>>>", input);
//       // add uuid in cropImages
//       // if (input.cropImages.length > 0) {
//       //   for (const cropImage of input.cropImages) {
//       //     const { uuid } = require("uuidv4");
//       //     cropImage["id"] = uuid();
//       //   }
//       // }
//       // Product inputs
//       let productInput = {
//         store_id: input?.store_id,
//         title: input?.title,
//         description: input?.description,
//         price: input?.inventoryPrice?.price,
//         isFeature: input?.isFeaturedPoduct,
//         isActive: input?.isActive,
//         quantity: input?.inventoryPrice?.quantity,
//         listPrice: input?.inventoryPrice?.listPrice,
//         sku: input?.inventoryPrice?.sku,
//         image: input?.image,
//         video: input?.video,
//         isVisible: input?.isVisible,
//         isFreeShipping: input?.isFreeShipping,
//         condition: input?.condition,
//         tags: input?.tags,
//         metaTitle: input?.seo?.metaTitle,
//         metaDescription: input?.seo?.metaDescription,
//         keywords: input?.seo?.keywords,
//         cropImages: input.cropImages,
//         ratio: input?.ratio,
//         size: input?.size,
//       };
//       // console.log("input>>>>>>>>>>>>>>>>>", productInput);
//       let product = await ProductService.add(productInput);
//       product = JSON.parse(JSON.stringify(product));
//       // elastic search - create product
//       let elasticsearchInput = productInput;
//       elasticsearchInput["id"] = product.id;
//       elasticsearchInput["product_id"] = product.id;
//       elasticsearchInput.image ? (elasticsearchInput.image = await findMediaUrlFromIds(elasticsearchInput.image)) : [];
//       elasticsearchInput.cropImages = await findCropImages(elasticsearchInput.cropImages);
//       let data = await elasticClient.product.addProduct({...productInput, is_deleted:false});
//       if (!data.success) return new Error("Elasticsearch - addProduct - " + data.message);
//       if (!product) {
//         console.log(">>>>>>>>>>>>2");
//         return new Error("Something went wrong");
//       } else {
//         let productId = product.id;
//         let userId = user.id;
//         console.log(">>>>>>>>>>>>3");
//         // product categories
//         if (input?.category && input?.category.length > 0)
//           for (const cat of input?.category) {
//             // Poduct categories
//             let productCategoriesInput = {
//               product_id: productId,
//               user_id: userId,
//               category_id: cat.category_id,
//               subCategory_id: cat.subCategory_id,
//               childSubCategory_id: cat.childSubCategory_id,
//             };
//             let productCategories = await database.ProductCategories.create(productCategoriesInput);
//           }
//         console.log(">>>>>>>>>>>>4");
//         // product attributes
//         if (input?.attributes && input?.attributes.length > 0)
//           for (const attr of input?.attributes) {
//             let ProductAttributesInput = {
//               product_id: productId,
//               user_id: userId,
//               name: attr?.name,
//               value: attr?.value,
//             };
//             let ProductAttributes = await database.ProductAttributes.create(ProductAttributesInput);
//           }
//         console.log(">>>>>>>>>>>>5");
//         // product size
//         if (input?.variant?.size && input?.variant?.size.length > 0)
//           for (const sz of input?.variant?.size) {
//             let productSize = {
//               product_id: productId,
//               user_id: userId,
//               size: sz,
//             };
//             let Size = await database.Size.create(productSize);
//           }
//         console.log(">>>>>>>>>>>>6");
//         // product color
//         if (input?.variant?.color && input?.variant?.color.length > 0)
//           for (const clr of input?.variant?.color) {
//             let productColor = {
//               product_id: productId,
//               user_id: userId,
//               name: clr.name,
//               colorCode: clr.colorCode,
//             };
//             let Color = await database.Color.create(productColor);
//           }
//         console.log(">>>>>>>>>>>>7");
//         // product other attributes
//         if (input?.variant?.other && input?.variant?.other.length > 0)
//           for (const attr of input?.variant?.other) {
//             let productAttributes = {
//               product_id: productId,
//               user_id: userId,
//               name: attr.name,
//               data: attr.data,
//             };
//             let ProductOtherInformation = await database.ProductOtherInformations.create(productAttributes);
//           }
//         console.log(">>>>>>>>>>>>9");
//         //  product shipping details
//         let productShippingDetails = {
//           user_id: userId,
//           product_id: productId,
//           weightValue: input?.shipping?.weight?.value,
//           weightUnit: input?.shipping?.weight?.unit,
//           length: input?.shipping?.length,
//           width: input?.shipping?.width,
//           height: input?.shipping?.height,
//           unit: input?.shipping?.unit,
//         };
//         let ProductShippingDetails = await database.ProductShippingDetails.create(productShippingDetails);
//         console.log(">>>>>>>>>>>>8");
//       }
//       let result = {
//         id: product.id,
//         store_id: product.store_id,
//         category_id: product.category_id,
//         delivery_id: product.delivery_id,
//         color_id: product.color_id,
//         size_id: product.size_id,
//         title: product.title,
//         description: product.description,
//         price: product.price,
//         isFeature: product.isFeature,
//         isActive: product.isActive,
//         quantity: product.quantity,
//         listPrice: product.listPrice,
//         sku: product.sku,
//         images: product.image,
//         video: product.video,
//         ratio: product.ratio,
//         size: product.size,
//         // cropImages
//       };
//       return { success: true, message: "Product added successfully", product: result };
//     } else {
//       return new AuthenticationError("Please Provide Token");
//     }
//   } catch (error) {
//     console.log(error);
//   }
// },

// =======================================================================================================================================================================

// updateProduct: async (root, { input }, { user }) => {
//   if (user !== null) {
//     if (!input.id) {
//       return { success: false, message: "Please Provide Product Id" };
//     }
//     let response = await database.Product.findOne({
//       where: {
//         id: Number(input.id),
//         is_deleted: false,
//       },
//     });
//     if (!response) {
//       return { success: false, message: "Product not found" };
//     }
//     // update cropImages with uuid
//     let cropImages = [];

//     let existsCrpImages = response.cropImages;

//     let removeImages = input.removeImages;
//     if (removeImages && removeImages.length > 0) {
//       // get not exists images
//       removeImages = existsCrpImages.filter((image) => removeImages.includes(image.id));
//       let removeImageIds = [
//         ...removeImages.map((image) => image.oldFile),
//         ...removeImages.map((image) => image.croppedFile && image.croppedFile.baseURL),
//       ];
//       console.log("removeImages", removeImageIds);
//       // delete images from media
//       await database.Media.destroy({ where: { id: { [Op.in]: removeImageIds } } });
//     }
//     // Product inputs
//     let productInput = {
//       id: input.id,
//       store_id: input?.store_id,
//       title: input?.title,
//       description: input?.description,
//       price: input?.inventoryPrice?.price,
//       isFeature: input?.isFeaturedPoduct,
//       isActive: input?.isActive,
//       quantity: input?.inventoryPrice?.quantity,
//       listPrice: input?.inventoryPrice?.listPrice,
//       sku: input?.inventoryPrice?.sku,
//       image: input?.image,
//       video: input?.video,
//       isVisible: input?.isVisible,
//       isFreeShipping: input?.isFreeShipping,
//       condition: input?.condition,
//       tags: input?.tags,
//       metaTitle: input?.seo?.metaTitle,
//       metaDescription: input?.seo?.metaDescription,
//       keywords: input?.seo?.keywords,
//       cropImages: input.cropImages,
//       ratio: input?.ratio,
//       size: input?.size,
//     };

//     let product = await ProductService.update(productInput);
//     product = JSON.parse(JSON.stringify(product));
//     product = JSON.parse(JSON.stringify(product));

//     // elastic search - create product
//     let elasticsearchInput = productInput;
//     if (productInput.image) elasticsearchInput.image ? (productInput.image = await findMediaUrlFromIds(productInput.image)) : [];
//     if (productInput.cropImages) elasticsearchInput.cropImages = await findCropImages(productInput.cropImages);
//     console.log("productInputproductInputproductInput ++++++++++ ", JSON.stringify(elasticsearchInput));
//     //  return
//     let data = await elasticClient.product.updateProductById("products", product.id, { ...elasticsearchInput, is_deleted: false });
//     if (!data.success) return new Error("Elasticsearch - addProduct - " + data.message);
//     if (!product) {
//       console.log(">>>>>>>>>>>>2");
//       return { success: false, message: "Something went wrong" };
//     } else {
//       let productId = product.id;
//       let userId = user.id;
//       console.log(">>>>>>>>>>>>3");

//       let updateOrFindQuery = {
//         where: {
//           user_id: user.id,
//           product_id: product.id,
//         },
//       };
//       let isUpdateCategory = await updateOrDeleteServiceOfProduct(
//         database.ProductCategories,
//         input?.category,
//         updateOrFindQuery,
//         userId,
//         productId
//       );
//       if (!isUpdateCategory) {
//         return { success: false, message: "Not able to  Update - Categories" };
//       }

//       console.log(">>>>>>>>>>>>4");

//       // // product attributes
//       let isUpdateAttributes = await updateOrDeleteServiceOfProduct(
//         database.ProductAttributes,
//         input?.attributes,
//         updateOrFindQuery,
//         userId,
//         productId
//       );
//       if (!isUpdateAttributes) {
//         return { success: false, message: "Not able to  Update - Attributes" };
//       }

//       console.log(">>>>>>>>>>>>5");

//       // // product size
//       let isUpdateSize = await updateOrDeleteServiceOfProduct(database.Size, input?.variant?.size, updateOrFindQuery, userId, productId, "size");
//       if (!isUpdateSize) {
//         return { success: false, message: "Not able to  Update - Size" };
//       }
//       console.log(">>>>>>>>>>>>6");

//       // // product color
//       let isUpdateColor = await updateOrDeleteServiceOfProduct(database.Color, input?.variant?.color, updateOrFindQuery, userId, productId);
//       if (!isUpdateColor) {
//         return { success: false, message: "Not able to  Update - Color" };
//       }
//       console.log(">>>>>>>>>>>>7");

//       // // product other attributes
//       let isUpdateOtherInformation = await updateOrDeleteServiceOfProduct(
//         database.ProductOtherInformations,
//         input?.variant?.other,
//         updateOrFindQuery,
//         userId,
//         productId
//       );
//       if (!isUpdateOtherInformation) {
//         return { success: false, message: "Not able to  Update - ProductOtherInformation" };
//       }
//       console.log(">>>>>>>>>>>>9");

//       let productShippingDetails = {
//         weightValue: input?.shipping?.weight?.value,
//         weightUnit: input?.shipping?.weight?.unit,
//         length: input?.shipping?.length,
//         width: input?.shipping?.width,
//         height: input?.shipping?.height,
//         unit: input?.shipping?.unit,
//       };

//       let ProductShippingDetails = await database.ProductShippingDetails.update(productShippingDetails, updateOrFindQuery);
//       console.log(">>>>>>>>>>>>8");
//     }

//     return { success: true, message: "Product updated successfully", product: product };
//   }
//   return new AuthenticationError("Please Provide Token");
// },
