const { AuthenticationError } = require("apollo-server-express");
const CardAndBillingAddressService = require("../../../database/services/cardandbillingaddress");
module.exports = {
  addCardAndBillingAddress: async (root, { input }, { user }) => {
    if (user !== null) {
      let object = {
        user_id: user.id,
        card_number: input.card_number,
        expiry_date: input.expiry_date,
        cvv: input.cvv,
        color: input.color,
        streetAddress: input.streetAddress,
        country: input.country,
        state: input.state,
        city: input.city,
        zipcode: input.zipcode,
        buildingName: input.buildingName,
        number: input.number,
        isDefault: input?.isDefault,
        firstName: input.firstName,
        lastName: input.lastName,
        image : input.image,
        cartType : input.cartType
      };
      const cardDetails = await CardAndBillingAddressService.add(
        object,
        user.id
      );
      return cardDetails;
    }
    return new AuthenticationError("Please Provide Token");
  },

  updateCardAndBillingAddress: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError(
          "Please Provide Id where you update the about detail"
        );
      }

      const cardDetails = await CardAndBillingAddressService.update(
        input,
        user.id
      );
      return cardDetails;
    }
    return new AuthenticationError("Please Provide Token");
  },

  deleteCardAndBillingAddress: async (root, { id }, { user }) => {
    if (user !== null) {
      if (!id) {
        return new AuthenticationError(
          "Please Provide Id where you delete the about detail"
        );
      }

      const cardDetails = await CardAndBillingAddressService.delete(id);

      return cardDetails;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
