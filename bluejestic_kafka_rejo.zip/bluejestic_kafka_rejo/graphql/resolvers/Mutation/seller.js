const jwt = require("jsonwebtoken");
const { AuthenticationError } = require("apollo-server-express");
const fs = require("fs");
const path = require("path");
const UserService = require("../../../database/services/user");
const { Seller, LegalDetails, BusinessInformation } = require("../../../database/models");
const database = require("../../../database/models");
const { validateEmptyFields, validateFields } = require("../../../utils/Validation");
const sendEmail = require("../../../utils/sendMail");
const elasticClient = require("../../../services/elasticsearch");
const config = require("../../../database/config/stripe");
const stripe = require("stripe")(config.stripeSecretKey);
const moment = require("moment");
const { default: slugify } = require("slugify");
const { where, Sequelize } = require("sequelize");
const { raw } = require("express");
const crypto = require("crypto");
const { Op } = require("sequelize");
const bcrypt = require("bcryptjs");

// const { sendMailWithSendGrid } = require("../../../utils/sendMail");
module.exports = {
  //* not used
  registerSeller: async (root, args, context) => {
    const { firstName, lastName, email, confirmEmail, password, confirmPassword, mobileNumber, phoneNumber, ext, accountType, jobTitle, userFor } = args.input;

    let sellerData;
    const CheckEmail = await Seller.findOne({ where: { email } });
    if (CheckEmail && CheckEmail.email == email) {
      return new Error("Email already exists");
    } else {
      if (Object.keys(args.input.businessInformation).length === 0) {
        return new AuthenticationError("Please Provide the Business Information");
      } else {
        if (email != confirmEmail) {
          return new AuthenticationError("Email and Confirm Email does not match");
        } else if (password != confirmPassword) {
          return new AuthenticationError("Password and Confirm Password does not match");
        } else {
          const bcryptPassword = await bcrypt.hash(password, 10);
          sellerData = await database.Seller.create({
            firstName,
            lastName,
            email,
            password: bcryptPassword,
            mobileNumber,
            phoneNumber,
            ext,
            jobTitle,
            accountType,
            userFor,
          });
        }
        let { name, streetAddress, city, state, postalCode } = args.input.businessInformation;

        const fields = ["name", "streetAddress", "city", "state", "postalCode"];

        const data = [name, streetAddress, city, state, postalCode];

        const emptyValidators = validateFields(data, fields);

        if (emptyValidators) {
          return new Error(emptyValidators);
        }

        const businessInformation = args.input.businessInformation;
        businessInformation.seller_id = sellerData.id;
        const businessInformationData = await BusinessInformation.create(businessInformation);
      }
      // console.log("=========================", args.input.legalDetails);
      // if (Object.keys(args.input.legalDetails).length === 0) {
      //   return new AuthenticationError("Please Provide the Legal Detail");
      // } else {
      //   // Empty Fields Validator
      //   let { taxClassification, countryIncorporation } =
      //     args.input.legalDetails;

      //   const fields = ["taxClassification", "countryIncorporation"];

      //   const data = [taxClassification, countryIncorporation];

      //   const emptyValidators = validateFields(data, fields);
      //   if (emptyValidators) {
      //     return new Error(emptyValidators);
      //   }

      //   const legalDetails = args.input.legalDetails;
      //   legalDetails.seller_id = sellerData.id;

      //   const legalDetailsData = await LegalDetails.create(legalDetails);
      // }
    }

    return sellerData;
    // }
  },

  updateSellerDetail: async (root, { input }, { user }) => {
    try {

      const find_seller = await database.Seller.findOne({
        where: {
          id: user?.seller_id
        },
        attributes: ["id"],
        raw: true
      })

      if (!find_seller) {
        return { success: false, message: "Provide valid seller_id" }
      }

      const [update_seller] = await database.Seller.update(
        {
          ...input
        },
        {
          where: {
            id: user?.seller_id
          }
        }
      )

      if (update_seller) {
        return { success: true, message: "Seller Info. update successfully" }
      } {
        return { success: false, message: "Something went wrong" }
      }

    } catch (error) {
      console.log('error', error);

    }
  },

  //* seller onboarding process
  addSellerApprovalDetail: async (root, args, { user }) => {
    if (!user) return new Error("Please login to continue");
    // let {email} = args.input;
    let email = user.email;
    console.log("args+++++++++++++++++++++++++++++++++++++++++++", args);
    const {
      title,
      firstName,
      lastName,
      accountType,
      // email,
      phoneNumber,
      companyLegalName,
      websiteUrl,
      streetAddress,
      state_name,
      city,
      state,
      postalCode,
      productType,
      businessType,
    } = args.input;

    let sellerDetails = {
      firstName,
      lastName,
      accountType,
      email,
      phoneNumber,
    };

    let storeDetials = {
      companyLegalName,
      websiteUrl,
      streetAddress,
      city,
      state,
      state_name,
      postalCode,
      businessType,
      title: title,
      name: companyLegalName,
    };
    try {
      console.log("User", user);
      // sellerDetails.email = email;
      await database.User.update({ becomeSellerStatus: "pending" }, { where: { email } });
      // console.log("args.input", user.email);
      const seller = await database.Seller.findOne({ where: { email } });
      if (seller) return new Error("Seller already exists");
      const sellerApprovalExists = await database.SellerApproval.findOne({ where: { email } });
      if (sellerApprovalExists) return new Error("You have already requested to become a seller");

      // send email to seller
      const emailData = {
        to: email,
        from: process.env.EMAIL_USER,
        subject: "Seller Approval",
        html: `<p>Hi ${firstName ?? ""}${lastName ? " " : ""}${lastName ?? ""},</p>
        <p>Thank you for your interest in becoming a seller on the Bluejestic.com Marketplace. We have received your request and will get back to you shortly.</p>
        <p>Regards,</p>
        <p>Team Bluejestic</p>`,
      };
      await sendEmail(emailData);

      // send email to admin
      const adminEmailData = {
        to: process.env.ADMIN_EMAIL,
        from: process.env.EMAIL_USER,
        subject: "Seller Approval",
        html: `
        <!DOCTYPE html>
        <html>
        <body>
        <p>Hi Admin,</p>
                <p> ${firstName ?? ""}${lastName ? " " : ""}${lastName ?? ""} has requested to become a seller on the Bluejestic.com Marketplace. Please review the request and approve or reject it.</p>
                <a href="https://bluejestic.com/store-confirmation/?status=approved">Approve</a>
                <a href="https://bluejestic.com/store-confirmation/?status=rejected">Reject</a>
                <p>Regards,</p>
                <p>Team Bluejestic</p>
                </body>
                </html>
                `,
      };
      await sendEmail(adminEmailData);

      args.input = { ...args.input, storeDetials, sellerDetails };
      args.input.user_id = user.id;
      args.input.email = email;
      // console.log("args.input", args.input);
      const sellerData = await database.SellerApproval.create(args.input);
      return sellerData;
    } catch (error) {
      return new Error(error);
    }
  },

  //* not used
  sellerSignUp: async (root, args, context) => {
    const { accountType, firstname, lastname, phone, email, password, confirmpassword } = args.input;

    let sellerData;
    const CheckEmail = await Seller.findOne({ where: { email } });
    if (CheckEmail && CheckEmail.email == email) {
      return new Error("Email already exists");
    } else {
      if (password != confirmpassword) {
        return new AuthenticationError("Password and Confirm Password does not match");
      } else {
        const bcryptPassword = await bcrypt.hash(password, 10);
        sellerData = await database.Seller.create({
          firstName: firstname,
          lastName: lastname,
          email,
          password: bcryptPassword,
          mobileNumber: phone,
          accountType,
        });
      }
      let { company, storeName, zipcode, businessURl, businesstype, address, city, state } = args.input;

      const businessInformationData = await BusinessInformation.create({
        name: storeName,
        companyLegalName: company,
        streetAddress: address,
        postalCode: zipcode,
        websiteUrl: businessURl,
        businessType: businesstype,
        city,
        state,
        seller_id: sellerData.id,
      });
    }

    return sellerData;
  },

  //* not used
  sellerLogin: async (root, { email, password }, context) => {
    // const { email, password } = input;

    const seller = await Seller.findOne({ where: { email } });
    if (!seller) return new Error("Seller not found");
    // const isApproved = await database.Seller.findOne({ where: { email, isApprovedByAdmin: true } });
    // if (!isApproved) return new Error("Seller not approved by admin");

    const businessInformation = await BusinessInformation.findOne({
      where: { seller_id: seller?.id },
    });
    const legalDetails = await LegalDetails.findOne({
      where: { seller_id: seller?.id },
    });

    // if (!seller || !businessInformation || !legalDetails) {
    //   return new AuthenticationError("Invalid Credentials");
    // }

    let sellerData = {
      id: seller.id,
      firstName: seller.firstName,
      lastName: seller.lastName,
      email: seller.email,
      mobileNumber: seller.mobileNumber,
      phoneNumber: seller.phoneNumber,
      ext: seller.ext,
      jobTitle: seller.jobTitle,
      isVerify: seller.isVerify,
      businessInformation: businessInformation?.toJSON(),
      legalDetails: legalDetails?.toJSON(),
    };

    if (seller && bcrypt.compareSync(password, seller.password)) {
      const token = jwt.sign({ id: seller.id, type: "seller" }, process.env.JWT_SECRET);
      return { jwt: token, seller: sellerData };
    } else {
      throw new AuthenticationError("Invalid credentials");
    }
  },

  //* update seller detail - not used
  updateSellerDetails: async (root, { input }, { user }) => {
    try {
      if (user !== null) {
        let inputForSeller = {
          firstName: input.firstName,
          lastName: input.lastName,
          email: input.email,
          phoneNumber: input.phoneNumber,
          jobTitle: input.jobTitle,
          aboutUs: input.aboutUs,
          language: input.language,
          dateFormat: input.dateFormat,
          timeZone: input.timeZone,
        };

        let inputForBusinessInformation = {
          name: input.name,
          companyLegalName: input.companyLegalName,
          streetAddress: input.streetAddress,
          city: input.city,
          state: input.state,
          postalCode: input.postalCode,
          websiteUrl: input.websiteUrl,
          isHaveTeam: input.isHaveTeam,
          annualSale: input.annualSale,
          totalEmployees: input.totalEmployees,
          logo: input.logo,
          cover_image: input.cover_image,
          sellerType: input.sellerType,
        };

        let inputForLegalDetails = {
          taxClassification: input.taxClassification,
          countryIncorporation: input.countryIncorporation,
          taxId: input.taxId,
          foundationYear: input.foundationYear,
          estimatedAnnualSale: input.estimatedAnnualSale,
          numberOfEmployees: input.numberOfEmployees,
        };

        // Update the seller
        let [responseOfSeller] = await database.Seller.update(inputForSeller, {
          where: {
            id: Number(user.id),
          },
        });

        // Update the Store
        let [responseOfStore] = await database.BusinessInformation.update(inputForBusinessInformation, {
          where: {
            seller_id: Number(user.id),
          },
        });

        // Update the Company Legal Details
        let [responseOfCompanyLegalDetails] = await database.LegalDetails.update(inputForLegalDetails, {
          where: {
            seller_id: Number(user.id),
          },
        });

        if (responseOfSeller) {
          responseOfSeller = await database.Seller.findOne({
            where: {
              id: Number(user.id),
              // isDeleted: false,
            },
          });
          if (responseOfSeller) {
            return responseOfSeller;
          } else {
            return new Error("Some Error in update data ");
          }
        }
      } else {
        return new AuthenticationError("Please Provide Token");
      }
      return null;
    } catch (error) {
      return new Error(error);
    }
  },

  //*  not used
  updateSeller: async (root, { input }, { user }) => {
    try {
      if (user !== null) {
        let inputForSeller = {
          firstName: input.firstName,
          lastName: input.lastName,
          email: input.email,
          phoneNumber: input.phoneNumber,
          jobTitle: input.jobTitle,
          aboutUs: input.aboutUs,
          language: input.language,
          dateFormat: input.dateFormat,
          timeZone: input.timeZone,
        };

        let inputForBusinessInformation = {
          name: input.name,
          title: input.title,
          companyLegalName: input.companyLegalName,
          streetAddress: input.address,
          city: input.city,
          state: input.state,
          country: input.country,
          postalCode: input.zipcode,
          employmentType: input.employmentType,
          profession: input.profession,
          websiteUrl: input.websiteUrl,
          isHaveTeam: input.isHaveTeam,
          annualSale: input.annualSale,
          totalEmployees: input.totalEmployees,
          logo: input.logo,
          cover_image: input.cover_image,
          sellerType: input.sellerType,
        };
        console.log(inputForBusinessInformation);

        let inputForLegalDetails = {
          taxClassification: input.taxClassification,
          countryIncorporation: input.countryIncorporation,
          taxId: input.taxId,
          foundationYear: input.foundationYear,
          estimatedAnnualSale: input.estimatedAnnualSale,
          numberOfEmployees: input.numberOfEmployees,
        };
        // Update the seller
        let [responseOfSeller] = await database.Seller.update(inputForSeller, {
          where: {
            id: Number(input.id),
          },
        });

        // Update the Store
        let [responseOfStore] = await database.BusinessInformation.update(inputForBusinessInformation, {
          where: {
            seller_id: Number(input.id),
          },
        });

        // Update the Company Legal Details
        let [responseOfCompanyLegalDetails] = await database.LegalDetails.update(inputForLegalDetails, {
          where: {
            seller_id: Number(input.id),
          },
        });

        if (responseOfSeller) {
          responseOfSeller = await database.Seller.findOne({
            where: {
              id: Number(input.id),
              // isDeleted: false,
            },
          });
          if (responseOfSeller) {
            return responseOfSeller;
          } else {
            return new Error("Some Error in update data ");
          }
        }
      } else {
        return new AuthenticationError("Please Provide Token");
      }
      return null;
    } catch (error) {
      return new Error(error);
    }
  },

  sellerOnboarding5Details: async (root, { input }, { user: seller }) => {
    if (!seller) {
      return new AuthenticationError("Please provide token");
    }

    try {
      const stepper = ["personal-information", "business-type", "business-details", "identification-form", "store-availability"];
      // if (seller !== null && seller?.token_type === "seller") {
      // let find_seller = await database.Seller.findOne({
      //   where: {
      //     id: seller?.id,
      //   },
      //   attributes: ["id"],
      // });

      // if (!find_seller) return { success: false, message: "Seller Not found!" };
      // console.log("🚀 ~ sellerOnboarding5Details: ~ seller:");

      if (seller.user_id === null) {
        let find_seller = await database.Seller.findOne({
          where: {
            id: seller?.id,
          },
          attributes: ["id"],
        });

        if (!find_seller) return { success: false, message: "Seller Not found!" };
      }

      const { type } = input;
      if (!type) return { success: false, message: "Please Provide type." };

      const getNextStep = (currentStep) => {
        const currentIndex = stepper.indexOf(currentStep);
        if (currentIndex === -1 || currentIndex === stepper.length - 1) {
          return null;
        }
        return stepper[currentIndex + 1];
      };

      const stepperUpdateCall = async (data) => {
        if (data) {
          let [update_seller] = await database.Seller.update(data, {
            where: {
              id: seller?.id,
            },
          });

          //* update seller by id - elastic search db 
          await elasticClient.sellers.updateSellerById(seller?.id, data);

          if (seller?.user_id) {
            await database.User.update(data, {
              where: {
                id: seller?.user_id,
              },
            });

            //* update user by id - elastic search db 
            await elasticClient.user.updateUserById("user", seller?.user_id, data);
          }
          return update_seller;
        }
      };
      let nextStepper;
      switch (type) {
        case "personal-information":

          if (seller.token_type === "user") {

            const findSeller = await database.Seller.findOne({
              where: {
                [database.Sequelize.Op.or]: [
                  {
                    email: seller?.email,
                  },
                  {
                    user_id: seller?.id
                  }
                ]
              }
            });

            if (findSeller) {
              return {
                success: false,
                message: "Seller already exists with this email or user id"
              }

            }
            const userRegisterAsSeller = await database.Seller.create({
              firstName: seller.firstName,
              lastName: seller.lastName,
              email: seller.email,
              password: seller.password,
              is_user: true,
              user_id: seller.id,
              userName: seller.userName,
              social_type: seller.social_type,
              sellerApprovedStatusNew: null
            });
            seller = await database.Seller.findOne({ where: { id: userRegisterAsSeller?.id }, raw: true });
          }

          let find_personal_information = await database.SellerPersonalInfo.findOne({
            where: {
              seller_id: seller?.id,
            },
            attributes: ["id"],
            raw: true,
          });
          let add_seller_info;
          if (find_personal_information) {
            [add_seller_info] = await database.SellerPersonalInfo.update(input, {
              where: {
                seller_id: seller?.id,
              },
            });
          } else {
            add_seller_info = await database.SellerPersonalInfo.create({
              seller_id: seller?.id,
              ...input,
            });
          }
          if (!add_seller_info) return { success: false, message: "Something went Wrong, Please try agian later!" };
          nextStepper = getNextStep(type);
          await stepperUpdateCall({ currentQueryForVerification: nextStepper ?? "" });
          return { success: true, message: "Personal Information Updated Successfully!" };
        case "business-type":

          if (seller.token_type === "user") {
            seller = await database.Seller.findOne({ where: { user_id: seller.id }, raw: true });
          }

          let find_business_type = await database.SellerBusinessDetail.findOne({
            where: {
              seller_id: seller?.id,
            },
            attributes: ["id"],
            raw: true,
          });
          let add_business_type;
          if (find_business_type) {
            [add_business_type] = await database.SellerBusinessDetail.update(input, {
              where: {
                seller_id: seller?.id,
              },
            });
          } else {
            add_business_type = await database.SellerBusinessDetail.create({
              seller_id: seller?.id,
              ...input,
            });
          }
          if (!add_business_type) return { success: false, message: "Something went Wrong, Please try agian later!" };
          nextStepper = getNextStep(type);
          await stepperUpdateCall({ currentQueryForVerification: nextStepper ? nextStepper : "" });
          return { success: true, message: "Business Type Updated Successfully!" };
        case "business-details":

          if (seller.token_type === "user") {
            seller = await database.Seller.findOne({ where: { user_id: seller.id }, raw: true });
          }

          let find_business_details = await database.SellerBusinessDetail.findOne({
            where: {
              seller_id: seller?.id,
            },
            attributes: ["id"],
            raw: true,
          });
          let add_business_details;
          if (find_business_details) {
            [add_business_details] = await database.SellerBusinessDetail.update(input, {
              where: {
                seller_id: seller?.id,
              },
            });
          } else {
            add_business_details = await database.SellerBusinessDetail.create({
              seller_id: seller?.id,
              ...input,
            });
          }
          if (!add_business_details) return { success: false, message: "Something went Wrong, Please try agian later!" };
          nextStepper = getNextStep(type);
          await stepperUpdateCall({ currentQueryForVerification: nextStepper ? nextStepper : "" });
          return { success: true, message: "Business Details Updated Successfully!" };
        case "identification-form":

          if (seller.token_type === "user") {
            seller = await database.Seller.findOne({ where: { user_id: seller.id }, raw: true });
          }

          let find_identification_form = await database.SellerIdentification.findOne({
            where: {
              seller_id: seller?.id,
            },
            attributes: ["id"],
            raw: true,
          });
          let add_identification_form;
          if (find_identification_form) {
            [add_identification_form] = await database.SellerIdentification.update({
              ...input,
              id_type: "identityDocuments"
            }, {
              where: {
                seller_id: seller?.id,
              },
            });

            [add_seller_document_identification_form] = await database.SellerDocumentsApproval.update({
              seller_id: seller?.id,
              documentType: "identityDocuments",
              documentApprovedStatus: "pending",
              ...input,
            }, {
              where: {
                seller_id: seller?.id
              }
            });


          } else {
            add_identification_form = await database.SellerIdentification.create({
              seller_id: seller?.id,
              id_type: "identityDocuments",
              ...input,
            });

            add_seller_document_identification_form = await database.SellerDocumentsApproval.create({
              seller_id: seller?.id,
              documentType: "identityDocuments",
              documentApprovedStatus: "pending",
              ...input,
            });
          }
          if (!add_identification_form && add_seller_document_identification_form) return { success: false, message: "Something went Wrong, Please try agian later!" };
          nextStepper = getNextStep(type);
          await stepperUpdateCall({ currentQueryForVerification: nextStepper ? nextStepper : "" });
          return { success: true, message: "Identification Form Updated Successfully!" };
        case "store-availability":

          if (seller.token_type === "user") {
            seller = await database.Seller.findOne({ where: { user_id: seller.id }, raw: true });
          }

          let find_store_availability = await database.SellerPersonalInfo.findOne({
            where: {
              seller_id: seller?.id,
            },
            attributes: ["id"],
            raw: true,
          });
          let add_store_info;
          if (find_store_availability) {
            [add_store_info] = await database.SellerPersonalInfo.update(input, {
              where: {
                seller_id: seller?.id,
              },
            });

            // let slug = slugify(input?.store_name, { lower: true, replacement: "" });
            // let final_slug;

            // let find_unique_user = await database.BusinessInformation.findOne({
            //   where: {
            //     slug: slug,
            //   },
            //   attributes: ["id"],
            //   raw: true,
            // });

            // if (find_unique_user) {
            //   const otp = Math.floor(Math.random() * 900) + 100;
            //   final_slug = slug + "-" + otp;
            // } else {
            //   final_slug = slug;
            // }

            // const create_store = await database.BusinessInformation.create({
            //   seller_id: seller?.id,
            //   name: input?.store_name,
            //   slug: final_slug,
            //   status: "Pending",
            // });
          } else {
            add_store_info = await database.SellerPersonalInfo.create({
              seller_id: seller?.id,
              ...input,
            });
          }
          if (!add_store_info) return { success: false, message: "Something went Wrong, Please try agian later!" };
          nextStepper = getNextStep(type);
          await stepperUpdateCall({ currentQueryForVerification: nextStepper ?? "completed", isSellerInfoVerified: true, isDetails5OnboardingCompletedNew: true, sellerApprovedStatusNew: "pending", details5OnboardingCompletedAtNew: new Date(), becomeSellerStatus: "pending" });

          // send email to seller
          const emailData = {
            to: seller.email,
            from: process.env.EMAIL_USER,
            subject: "Seller Approval",
            html: `<p>Hi ${seller?.firstName ?? ""}${seller?.lastName ? " " : ""}${seller?.lastName ?? ""},</p>
        <p>Thank you for your interest in becoming a seller on the Bluejestic.com Marketplace. We have received your request and will get back to you shortly.</p>
        <p>Regards,</p>
        <p>Team Bluejestic</p>`,
          };
          await sendEmail(emailData);

          // send email to admin
          const adminEmailData = {
            to: process.env.ADMIN_EMAIL,
            from: process.env.EMAIL_USER,
            subject: "Seller Approval",
            html: `
        <!DOCTYPE html>
        <html>
        <body>
        <p>Hi Admin,</p>
                <p> ${seller?.firstName ?? ""}${seller?.lastName ? " " : ""}${seller?.lastName ?? ""} has requested to become a seller on the Bluejestic.com Marketplace. Please review the request and approve or reject it.</p>
                <a href="https://bluejestic.com/store-confirmation/?status=approved">Approve</a>
                <a href="https://bluejestic.com/store-confirmation/?status=rejected">Reject</a>
                <p>Regards,</p>
                <p>Team Bluejestic</p>
                </body>
                </html>
                `,
          };
          await sendEmail(adminEmailData);

          return { success: true, message: "Store Availability Updated Successfully!" };
        default:
          return {
            success: false,
            message: "Enter Valid type"
          };
      }
    } catch (error) {
      console.log("error++++++++++++++++++++++++", error);
    }
  },

  directSelleOnboarding5Detail: async (root, { input }, { user: seller }) => {
    try {
      let find_seller = await database.Seller.findOne({
        where: {
          email: input?.businessDetails?.business_email,
        },
        attributes: ["id"],
        raw: true,
      });
      if (find_seller) {
        return ({ success: false, message: 'Seller already exist' })
      } else {
        store_detail = await database.Seller.create({
          email: input?.businessDetails?.business_email,
          firstName: input?.personalInformation?.firstName,
          lasteName: input?.personalInformation?.lasteName,
          phoneNumber: input?.personalInformation?.phone_number
        });
        find_seller = JSON.parse(JSON.stringify(store_detail))
      }
      for (const [tableName, objectData] of Object.entries(input)) {
        console.log('=========', tableName, objectData);
        const storeExists = await database[objectData?.type].create({
          ...objectData,
          seller_id: find_seller?.id
        });
      }
      find_seller = await database.Seller.update(
        {
          "currentQueryForVerification": "completed",
          "isDetails5OnboardingCompletedNew": true,
          "details5OnboardingCompletedAtNew": new Date()
        },
        {
          where: {
            id: find_seller?.id
          }
        }
      );

      const emailData = {
        to: find_seller.email,
        from: process.env.EMAIL_USER,
        subject: "Seller Approval",
        html: `<p>Hi ${find_seller?.firstName ?? ""}${find_seller?.lastName ? " " : ""}${find_seller?.lastName ?? ""},</p>
                <p>Thank you for your interest in becoming a seller on the Bluejestic.com Marketplace. We have received your request and will get back to you shortly.</p>
                <p>Regards,</p>
                <p>Team Bluejestic</p>`,
      };
      await sendEmail(emailData);

      // send email to admin
      const adminEmailData = {
        to: process.env.ADMIN_EMAIL,
        from: process.env.EMAIL_USER,
        subject: "Seller Approval",
        html: `
              <!DOCTYPE html>
              <html>
              <body>
              <p>Hi Admin,</p>
              <p> ${find_seller?.firstName ?? ""}${find_seller?.lastName ? " " : ""}${find_seller?.lastName ?? ""} has requested to become a seller on the Bluejestic.com Marketplace. Please review the request and approve or reject it.</p>
              <a href="https://bluejestic.com/store-confirmation/?status=approved">Approve</a>
              <a href="https://bluejestic.com/store-confirmation/?status=rejected">Reject</a>
              <p>Regards,</p>
              <p>Team Bluejestic</p>
              </body>
              </html>
              `,
      };
      await sendEmail(adminEmailData);
      return { success: true, message: "Form Submitted Successfully" };

    } catch (error) {
      console.log('error ===== >', error);
    }
  },

  checkStoreAvailability: async (root, { store_name }, { user: seller }) => {
    // if (!seller) {
    //   return new AuthenticationError("Please provide token");
    // }
    try {
      // if (seller !== null) {
      const formattedName = store_name.toLowerCase().replace(/\s+/g, "");
      console.log("formattedName", formattedName);
      const storeExists = await database.BusinessInformation.findOne({
        where: Sequelize.where(Sequelize.fn("REPLACE", Sequelize.fn("LOWER", Sequelize.col("name")), " ", ""), formattedName),
      });

      if (storeExists) {
        return { success: false, message: "Storename already exists, Try another name!" };
      }
      return { success: true, message: "Store name is Available!" };
      // } else {
      //   return new AuthenticationError("Please Provide Token");
      // }
    } catch (error) {
      console.log("error", error);
    }
  },

  //* Seller is verified or not
  sellerVerified: async (root, args, { user }) => {
    try {
      if (user !== null) {
        new AuthenticationError("Please Provide Token");
      }
      const { isVerify } = args;
      if (isVerify == undefined) {
        return new Error("Please Provide the isVerify");
      }

      const seller = await database.Seller.update({ isVerify: isVerify }, { where: { id: user.id } });
      console.log("seller", seller);
      if (seller) return await database.Seller.findOne({ where: { id: user.id } });
    } catch (error) {
      return new Error(error);
    }
  },

  //* confirm by bluejestic Admin
  sellerApproval: async (root, args, { user }) => {
    try {
      if (!user) return new AuthenticationError("Please provide token");
      if (user.role !== "admin") return new Error("Unauthorized");
      const { status, email, sellerApprovalNote } = args;

      const seller = await database.Seller.findOne({ where: { email }, raw: true });
      if (!seller) return new Error("Seller not found");

      let validStatus = ["approved", "rejected"];
      if (!validStatus.includes(status)) return new Error("Invalid status");


      if (status === "approved") {
        if (seller.sellerApprovedStatusNew === status) {
          return {
            success: false,
            message: "Seller request already approved"
          };
        }

        // let sellerApproval = await database.SellerApproval.findOne({ where: { email }, raw: true });
        // if (!sellerApproval) return new Error("Seller request not found");
        // let sellerDetails = JSON.parse(sellerApproval.sellerDetails);
        // let storeDetials = JSON.parse(sellerApproval.storeDetials);
        // if (!sellerDetails || !storeDetials) return new Error("Seller details not found");
        // let seller = await database.Seller.findOne({ where: { email } }, { raw: true });
        // if (!seller) seller = await database.Seller.create({ ...sellerDetails, sellerApprovedStatusNew: status });


        let businessInformation = await database.BusinessInformation.findOne({ where: { seller_id: seller.id } }, { raw: true });

        const sellerStoreData = await database.Seller.findOne({
          where: {
            id: seller.id
          },
          attributes: ["id", "user_id", "firstName", "lastName", "phoneNumber", "accountType"],
          include: [
            {
              model: database.SellerPersonalInfo,
              as: "seller_personal_info",
              attributes: ["store_name"]
            },
            {
              model: database.SellerBusinessDetail,
              as: "seller_business_detail",
              attributes: ["business_type", "business_country",  "business_city", "business_state", "business_zip_code", "business_address", "business_email", "business_phone_number", "business_legal_name"]
            },
            // {
            //   model: database.SellerIdentification,
            //   as: "seller_identification",

            // },
          ],
          raw: true,
          nest: true
        });

        let final_slug;
        let slug = slugify(sellerStoreData?.seller_personal_info?.store_name, { lower: true, replacement: "" });

        let find_unique_user = await database.BusinessInformation.findOne({
          where: {
            slug: slug,
          },
          raw: true,
        });

        if (find_unique_user) {
          const otp = Math.floor(Math.random() * 900) + 100;
          final_slug = slug + otp;
        } else {
          final_slug = slug;
        }

        let store_info = {
          // ...storeDetials,
          user_id: sellerStoreData.user_id,
          seller_id: sellerStoreData.id,
          // title: sellerApproval?.title,
          firstName: sellerStoreData?.firstName,
          lastName: sellerStoreData?.lastName,
          // companyEmail: sellerApproval?.email,
          business_type: sellerStoreData?.seller_business_detail?.business_type,
          phoneNumber: sellerStoreData?.seller_business_detail?.business_phone_number,
          accountType: sellerStoreData?.accountType,
          // productType: sellerApproval?.productType,
          companyEmail: sellerStoreData?.seller_business_detail?.business_email,
          name: sellerStoreData?.seller_personal_info?.store_name,
          companyLegalName: sellerStoreData?.seller_business_detail?.business_legal_name,
          city: sellerStoreData?.seller_business_detail?.business_city,
          state: sellerStoreData?.seller_business_detail?.business_state,
          country: sellerStoreData?.seller_business_detail?.business_country,
          // state_name: sellerApproval?.state,
          postalCode: sellerStoreData?.seller_business_detail?.business_zip_code,
          streetAddress: sellerStoreData?.seller_business_detail?.business_address,
          slug: final_slug
        };

        if (!businessInformation) businessInformation = await database.BusinessInformation.create(store_info);
        businessInformation = JSON.parse(JSON.stringify(businessInformation));

        /* elastic search */
        // let storeData = {
        //   seller_id: sellerStoreData.id,
        //   user_id: sellerStoreData.user_id,
        //   id: businessInformation.id,
        //   companyLegalName: sellerStoreData?.seller_personal_info?.store_name,
        //   streetAddress: sellerStoreData?.seller_business_detail?.business_address,
        //   city: sellerStoreData?.seller_business_detail?.business_city,
        //   business_type: sellerStoreData?.seller_business_detail?.business_type,
        //   companyEmail: sellerStoreData?.seller_business_detail?.business_email,
        //   name: sellerStoreData?.seller_personal_info?.store_name,
        //   state: sellerStoreData?.seller_business_detail?.business_state,
        //   postalCode: sellerStoreData?.seller_business_detail?.business_zip_code,
        // };
        await elasticClient.store.createStore(store_info);

        let token;

        if (seller.user_id) {
          token = jwt.sign({ id: seller.user_id, type: "user", user_id: seller.user_id ?? null, seller_id: seller.id ?? null, store_id: businessInformation?.id ?? null, store_slug: businessInformation?.slug ?? null, }, process.env.JWT_SECRET);
        } else {
          token = jwt.sign({ id: seller.id, type: "seller", user_id: seller.user_id ?? null, seller_id: seller.id ?? null, store_id: businessInformation?.id ?? null, store_slug: businessInformation?.slug ?? null, }, process.env.JWT_SECRET);
        }


        if (!seller?.is_user) {
          const generatePassword = async (password) => {
            return await bcrypt.hash(password, 10);
          };

          function generateSecurePassword(length = 16) {
            return crypto.randomBytes(length).toString('base64').slice(0, length);
          }
          const password = generateSecurePassword(12); // Generate a 12-character password
          const bcryptPassword = await generatePassword(password);
          const update_seller = await database.Seller.update(
            {
              password: bcryptPassword
            },
            {
              where: {
                id: seller.id
              }
            })
          const emailData = {
            to: email,
            from: process.env.EMAIL_USER,
            subject: "Your request to become a seller on Bluejestic.com has been approved",
            html: `<p>Hi ${seller?.firstName ?? ""}${seller?.lastName ? " " : ""}${seller?.lastName ? `${seller?.lastName}` : ""},</p>
                <p>Your request to become a seller on Bluejestic.com has been approved.</p>
              <p> Please fill in your store details and start selling.</p>
              <a href="${process.env.FRONTEND_URL}/seller/onboarding?token=${token}">Click here to Filling Required fields </a>
              <p>Regards,</p>
              <p>Team Bluejestic</p>
              your password is: ${password}
              `,
            // <a href="https://bluejestic.com/seller/onboarding?onboard=step1&store_id=${businessInformation.id}&token=${token}">Click here to Filling Required fields </a>
          };
          await sendEmail(emailData);
        } else {
          const emailData = {
            to: email,
            from: process.env.EMAIL_USER,
            subject: "Your request to become a seller on Bluejestic.com has been approved",
            html: `<p>Hi ${seller?.firstName ?? ""}${seller?.lastName ? " " : ""}${seller?.lastName ?? ""},</p>
              <p>Your request to become a seller on Bluejestic.com has been approved.</p>
            <p> Please fill in your store details and start selling.</p>
            <a href="${process.env.FRONTEND_URL}/seller/onboarding?token=${token}">Click here to Filling Required fields </a>
            <p>Regards,</p>
            <p>Team Bluejestic</p>
            `,
            // <a href="https://bluejestic.com/seller/onboarding?onboard=step1&store_id=${businessInformation.id}&token=${token}">Click here to Filling Required fields </a>
          };
          await sendEmail(emailData);
        }

        await database.Seller.update({ isSellerVerify: true, sellerApprovedStatusNew: status, sellerApprovalNote, status_updated_by_new: user?.id, status_updated_at_new: new Date() }, { where: { email } });

        //* update seller by id - elastic search db 
        await elasticClient.sellers.updateSellerById(seller?.id, { isSellerVerify: true, sellerApprovedStatusNew: status, sellerApprovalNote, status_updated_by_new: user?.id, status_updated_at_new: new Date() });

        if (seller.user_id) {
          await database.User.update({ becomeSellerStatus: status, becomeSellerApprovalNote: sellerApprovalNote, isSeller: true }, { where: { id: seller.user_id } });

          //* update user by id - elastic search db 
          await elasticClient.user.updateUserById("user", seller.user_id, { becomeSellerStatus: status, becomeSellerApprovalNote: sellerApprovalNote, isSeller: true });
        }

        // const update = await database.SellerApproval.update({ sellerApprovedStatusNew: status }, { where: { email } });
        if (seller && businessInformation) return { success: true, message: "Seller Approved!" };
      } else {
        if (seller.sellerApprovedStatusNew === status) {
          return {
            success: false,
            message: "Seller request already rejected"
          };
        }
        // await database.SellerApproval.update({ sellerApprovedStatusNew: status }, { where: { email } });
        await database.Seller.update({ sellerApprovedStatusNew: status, sellerApprovalNote, status_updated_by_new: user?.id, status_updated_at_new: new Date() }, { where: { email } });

        //* update seller by id - elastic search db 
        await elasticClient.sellers.updateSellerById(seller?.id, { sellerApprovedStatusNew: status, sellerApprovalNote, status_updated_by_new: user?.id, status_updated_at_new: new Date() });

        if (seller.user_id) {
          await database.User.update({ becomeSellerStatus: status, becomeSellerApprovalNote: sellerApprovalNote, isSeller: false }, { where: { id: seller.user_id } });

          //* update user by id - elastic search db 
          await elasticClient.user.updateUserById("user", seller.user_id, { becomeSellerStatus: status, becomeSellerApprovalNote: sellerApprovalNote, isSeller: false });

        }
        return { success: true, message: "Seller Rejected!" };
      }
      return new Error("Some error occurred");
    } catch (error) {
      console.log(error);
      return new Error(error);
    }
  },

  //* update bank account details of seller for transfer money
  updateBankDetails: async (root, { connect_id }, { user }) => {
    try {
      console.log("connect_id", connect_id);
      //  let data =  await stripe.accounts.createLoginLink(connect_id);
      //  console.log("data", data);
      const accountLink = await stripe.accountLinks.create({
        account: connect_id,
        refresh_url: process.env.BASE_LOCAL_URL,
        return_url: process.env.BASE_LOCAL_URL,
        type: "account_onboarding",
      });
      console.log("accountLink", accountLink);
      return accountLink.url;
    } catch (error) {
      console.log(error);
      return new Error(error);
    }
  },
  /* seller bank account details */
  sendOTPForWithdrawal: async (root, { email }, { user }) => {
    try {
      if (!user) throw new AuthenticationError("Unauthorized");
      if (user.token_type !== "seller") throw new AuthenticationError("Unauthorized");
      const seller = await database.Seller.findOne({
        where: { id: user.id },
        raw: true,
      });
      if (!seller) return { success: false, message: "Seller not found" };
      /* generate 6 digit random otp */
      const otp = Math.floor(100000 + Math.random() * 900000);
      const emailData = {
        to: seller.email,
        from: process.env.EMAIL_USER,
        subject: "Bluejestic - OTP Verification for withdrawal",
        html: `
          <div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
            <div style="margin:50px auto;width:70%;padding:20px 0">
              <div style="border-bottom:1px solid #eee">
                <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Bluejestic</a>
              </div>
              <p style="font-size:1.1em">Hi,</p>
              <p>Thank you for choosing Bluejestic. Use the following OTP to complete your Sign Up procedures. OTP is valid for 5 minutes</p>
              <h2 style="background: #00466a;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">${otp}</h2>
              <p style="font-size:0.9em;">Regards,<br />Bluejestic</p>
              <hr style="border:none;border-top:1px solid #eee" />
            </div>
          </div>
          `,
      };
      let isSend = await sendEmail(emailData);
      if (!isSend) return { success: false, message: "OTP not sent, please try again later" };

      const update = await database.Seller.update(
        { otpForWithdrawal: otp, otpForWithdrawalExpiry: moment().add(5, "minutes").toDate() }, //update
        { where: { id: user.id } } //find
      );
      return { success: true, message: "OTP sent successfully" };
    } catch (error) {
      console.log(error);
      return { success: false, message: error.message };
    }
  },

  sellerOnboard: async (root, { input }, { user: seller }) => {
    // input = {
    //   seller: {
    //     firstName: '',
    //     lastName: '',
    //     profile_image: '',
    //     phoneNumber: '',
    //     is_tax_calculation: true,
    //     is_price_include_tax: true,
    //     tax_categories: ["Digital", "Physical"],
    //   },
    //   sellerIdentification: {
    //     id_type: "tax_document",
    //     document: ""
    //   },
    //   tax_rules: [
    //     {
    //       country: "",
    //       state: "",
    //       rate_percentage: 5,
    //     }
    //   ],
    //   password: {
    //     current_password: "",
    //     new_password: "",
    //   },
    //   store: {
    //     logo_image: '',
    //     banner_image: '',
    //     store_name: '',
    //     companyLegalName: ""
    //   },
    //   business: {
    //     business_address: "",
    //     business_address_detail: "",
    //     business_email: "",
    //     business_city: "",
    //     business_state: "",
    //     business_zip_code: "",
    //     business_country: "",
    //     business_phone_number: "",
    //   }
    // }

    try {
      let notUpdated = []
      for (const [tableName, objectData] of Object.entries(input)) {
        switch (tableName) {
          case 'seller':
            const [update_seller] = await database.Seller.update(
              {
                ...objectData
              },
              {
                where: {
                  id: seller?.seller_id
                }
              })
            if (!update_seller) { notUpdated.push('Seller detail not updated') }
            break;
          case 'sellerIdentification':
            const find_document = await database.SellerIdentification.findOne({
              where: {
                seller_id: seller?.seller_id,
                id_type: "tax_document"
              },
              attributes: ['id'],
              raw: true
            })
            if (find_document) {
              const [update_seller_identification] = await database.SellerIdentification.update(
                {
                  document: objectData?.document,
                },
                {
                  where: {
                    seller_id: seller?.seller_id,
                    id_type: "tax_document"
                  }
                })
              if (!update_seller_identification) { notUpdated.push('Seller Identification not updated') }
            } else {
              await database.SellerIdentification.create(
                {
                  ...objectData,
                  seller_id: seller?.seller_id
                })
            }
            break;
          case 'tax_rules':
            await database.Taxrate.destroy({
              where: {
                seller_id: seller?.seller_id
              }
            });
            for (let i = 0; i < objectData?.length; i++) {
              await database.Taxrate.create(
                {
                  ...objectData,
                  seller_id: seller?.seller_id,
                  store_id: seller?.store_id
                })
            }
            break;
          case 'password':
            let find_seller = await database.Seller.findOne({
              where: {
                id: seller?.seller_id,
              },
              attributes: ["password"],
              raw: true,
            });
            if (bcrypt.compareSync(objectData?.current_password, find_seller?.password)) {
              const bcryptPassword = await bcrypt.hash(objectData?.new_password, 10);
              const [updateOTP] = await database.Seller.update(
                { password: bcryptPassword },
                {
                  where: {
                    id: seller?.seller_id,
                  },
                }
              );
              if (!updateOTP) { notUpdated.push('Password not updated') }
            } else {
              notUpdated.push('Wrong Password Provided')
            }
            break;
          case 'store':
            const [updateStore] = await database.BusinessInformation.update(
              {
                ...objectData
              },
              {
                where: {
                  seller_id: seller?.seller_id,
                },
              }
            );
            if (!updateStore) { notUpdated.push('Store detail not updated') }
            break;
          case 'business':
            const [update_business] = await database.SellerBusinessDetail.update(
              {
                ...objectData
              },
              {
                where: {
                  seller_id: seller?.seller_id,
                },
              }
            );
            if (!update_business) { notUpdated.push('Business detail not updated') }
            break;
          default:
            break;
        }
      }
      if (notUpdated?.length === 0) {
        const [update_seller] = await database.Seller.update(
          {
            isOnboardCompleted: true,
            currentStepForSellerOnboarding: 'completed'
          },
          {
            where: {
              id: seller?.seller_id
            }
          })
        if (Boolean(update_seller)) {
          return { success: true, message: "seller updated successfully", error: notUpdated }
        }
      }
      return { success: false, message: "Something went wrong", error: notUpdated }
    } catch (error) {
      console.log('error===', error);

    }
  },

  /**
   * Calculates and updates the withdrawable amount for a seller based on delivered orders.
   *
   * @param {Object} _ - Unused parameter.
   * @param {Object} args - Unused parameter.
   * @param {Object} context - The context object containing user information.
   * @param {Object} context.user - The authenticated user object.
   * @throws {AuthenticationError} - Throws if the user is not authenticated or if seller_id is not provided.
   * @returns {Object} - Returns an object with success status, message, and the updated withdrawable amount.
   */

}