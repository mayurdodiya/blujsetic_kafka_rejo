const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { AuthenticationError } = require("apollo-server-express");

const AddressService = require("../../../database/services/address");
const { User } = require("../../../database/models");

module.exports = {
  address: async (root, args, { user }) => {
    if (!user)
      return new AuthenticationError(
        "You are not authorized to access this data"
      );

    const {
      address_1,
      address_2,
      city,
      state,
      zip_code,
      country,
      address_for,
    } = args.input;

    let address = await AddressService.add({
      address_1,
      address_2,
      city,
      state,
      zip_code,
      country,
      address_for,
      user_id: user.id,
    });
    return address;
  },

  getAddress: async (root, args, { user }) => {
    // if (!user) {
    //   return new AuthenticationError(
    //     "You are not authorized to access this data"
    //   );
    // }

    let Getaddress = await AddressService.getById(user.id);

    return Getaddress;
  },
};
