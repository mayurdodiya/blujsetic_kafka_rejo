const { AuthenticationError } = require("apollo-server-express");
const PostService = require("../../../database/services/post");
const { handleFileUpload } = require("../../../middlewares/config");
const MediaService = require("../../../database/services/media");
const database = require("../../../database/models");
const elasticClient = require("../../../services/elasticsearch");
const { Op } = require("sequelize");
// const streamToString = (stream) => {
//   const chunks = [];
//   return new Promise((resolve, reject) => {
//     stream.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
//     stream.on("error", (err) => reject(err));
//     stream.on("end", () => resolve(Buffer.concat(chunks)));
//   });
// };
// const File = require("../../../graphql/resolvers/FileModel/filemodel");
module.exports = {
  addPost: async (root, { input }, { user }) => {
    if (user === null) {
      return new AuthenticationError("You are not authorized to access this data");
    } else {
      console.log("input----------------", input);
      if (!input.post_for) {
        return { success: false, message: "Please select post for" };
      }
      if (!["SELLER", "USER", "GROUP"].includes(input.post_for.toUpperCase())) {
        return { success: false, message: "Please select valid post for" };
      }
      if (input.post_for.toUpperCase() == "SELLER") {
        // if (user.token_type !== "seller") return { success: false, message: "Please Provide Seller token" };
        input.seller_id = user.id;
        delete input.user_id;
        // if (!input.store_id) {
        //   return { success: false, message: "Please select store" };
        // }
        const store = await database.BusinessInformation.findOne({ where: { id: user.store_id } });
        if (!store) {
          return { success: false, message: "Please select valid store" };
        }
        input.store_name = store.name;
      } else if (input.post_for.toUpperCase() == "GROUP") {
        if (!input.group_id) {
          return { success: false, message: "Please select group" };
        }
        const store = await database.Group.findOne({ where: { id: input.group_id } });
        if (!store) {
          return { success: false, message: "Please select valid group" };
        }
      } else {
        input.user_id = user.id;
      }
      // if (user.token_type === "user") {
        input.user_id = user.id;
      // }
      // input.user_id =  && user.id;
      input.post_for = input.post_for.toUpperCase();
      console.log("Final Input ", input);
      const Post = PostService.add(input);
      return { success: true, message: "post posted", data: Post };
    }
  },
  sharePost: async (root, { input }, { user }) => {
    if (user != null) {
      if (!input.bookmark_id) {
        // if (!user || !input.product_id || !input.share_post_for || !input.store_name) {
        if (!user || !input.share_post_for) {
          return {
            status: 400,
            success: false,
            message: "Invalid Request",
            data: null,
          };
        }
      }
      let array = ["POST", "USER", "GROUP", "BOOKMARK"];
      if (!array.includes(input.share_post_for.toUpperCase())) {
        return {
          status: 400,
          success: false,
          message: "Invalid Type of share_post_for",
          data: null,
        };
      }
      if (input.share_post_for.toUpperCase() == "BOOKMARK") {
        if (input.bookmark_id) {
          let sharepost = await database.SharePost.findOne({ where: { id: input.bookmark_id } });
          if (sharepost) {
            let update = await database.SharePost.update({ isBookmarked: true }, { where: { id: input.bookmark_id } });
            let elkData = await elasticClient.sharePosts.updateSharePostById(input.bookmark_id, { isBookmarked: true });
            if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");
            return {
              status: 200,
              success: true,
              message: "Post bookmarked successfully",
              data: [sharepost],
            };
          } else {
            return {
              status: 400,
              success: false,
              message: "Please select valid bookmark post",
              data: null,
            };
          }
        } else {
          return {
            status: 400,
            success: false,
            message: "Please select bookmark post",
            data: null,
          };
        }
      }
      if (input.share_post_for.toUpperCase() == "GROUP" && !input.group_id) {
        return {
          status: 400,
          success: false,
          message: "Please select group",
          data: null,
        };
      }
      if (input?.store_name) {
        const store = await database.BusinessInformation.findOne({ where: { name: input?.store_name } });
        if (!store && input?.store_name) {
          return {
            status: 400,
            success: false,
            message: "Error - Store not found",
            data: null,
          };
        }
        input.store_id = store.id;
      }
      if (input?.product_id) {
        const post = await database.Product.findOne({ where: { id: input?.product_id, is_deleted: false } });
        if (!post && input?.product_id) {
          return {
            status: 400,
            success: false,
            message: "Error - Invalid Product Id",
            data: null,
          };
        }
      }
      let get_collection;
      if (input?.collection_id) {
        get_collection = await database.BookmarkCollection.findOne({ where: { id: input?.collection_id }, raw: true });
        // console.log("get_collection+++++++++++++++++++++++++++++++++", get_collection);
        if (!get_collection) {
          return {
            status: 400,
            success: false,
            message: "Error - Invalid Collection Id",
            data: null,
          };
        }
      }
      if (input.share_post_for.toUpperCase() == "GROUP" && input.group_id.length > 0) {
        const group = await database.Group.findOne({ where: { id: input.group_id[0] } });
        if (!group) {
          return {
            status: 400,
            success: false,
            message: "Error - Group not found",
            data: null,
          };
        }
        if (!input?.product_id && !input?.collection_id) {
          return {
            status: 400,
            success: false,
            message: "Error - product_id or collection_id not found",
            data: null,
          };
        }
        let sharePost = [];
        if (Boolean(input.group_id?.length)) {
          for (const group of input.group_id) {
            input.user_id = user.id;
            // input.store_id = store.id;
            input.group_id = group;
            input.share_post_for = input.share_post_for.toUpperCase();
            if (input?.product_id) {
              let find_product = await database.Product.findOne({
                where: {
                  id: input?.product_id,
                },
                raw: true,
              });
              if (find_product?.store_id) {
                // let find_store = await database.BusinessInformation.findOne
                input.store_id = find_product?.store_id;
              }
            }
            const SharePost = await PostService.sharePost(input);
            const shared_post = await database.Post.create({ group_id: group, sharepost_id: SharePost?.id, post_for: "SHAREPOST", user_id: user.id, collection_control: get_collection?.isPrivate ? "private" : "public" });
            let update_sharepost = await database.SharePost.update({ post_id: shared_post?.id }, { where: { post_id: shared_post?.id } });
            sharePost.push(JSON.parse(JSON.stringify(SharePost)));
          }
          console.log("sharePost", sharePost);
          return {
            status: 200,
            success: true,
            message: "Share post successfully",
            data: sharePost,
          };
        }
      }
      input.user_id = user.id;
      // input.store_id = store.id;
      input.share_post_for = input.share_post_for.toUpperCase();
      if (input.share_post_for.toUpperCase() == "POST" && input?.product_id) {
        const SharePost = await PostService.sharePost(input);
        const shared_post = await database.Post.create({ sharepost_id: SharePost?.id, post_for: "SHAREPOST", user_id: user.id });
        let update_sharepost = await database.SharePost.update({ post_id: shared_post?.id }, { where: { id: SharePost?.id } });
      }

      if (input.share_post_for.toUpperCase() == "POST" && input?.collection_id) {
        console.log("get_collection", get_collection);
        const shared_collection = await PostService.sharePost(input);
        const shared = await database.Post.create({ sharepost_id: shared_collection?.id, post_for: "SHAREPOST", user_id: user.id, collection_control: "public" });
        // const shared = await database.Post.create({ sharepost_id: shared_collection?.id, post_for: "SHAREPOST", user_id: user.id, collection_control: get_collection?.isPrivate ? "private" : "public" });
        let update_sharepost = await database.SharePost.update({ post_id: shared?.id }, { where: { id: shared_collection?.id } });
        const updateCollection = await database.BookmarkCollection.update(
          {
            isPrivate: false,
          },
          {
            where: {
              id: get_collection?.id,
            },
          }
        );
      }

      /* add share post in elastic search */
      if (input.image && input.image.length > 0) {
        let mediasData = await database.Media.find({
          where: {
            [Op.in]: input.image,
          },
        });
        let urls = mediasData.map((m) => m.media);
        input.image = urls;
      }
      // let elkData = await elasticClient.sharePosts.addSharePost({ ...input, id: SharePost.id });
      // if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");

      return {
        status: 200,
        success: true,
        message: "Share post successfully",
        // data: [JSON.parse(JSON.stringify(SharePost))],
      };
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  UploadFile: async (_, { file }, { user }) => {
    // const { createReadStream, filename, mimetype, encoding } = await file;
    try {
      if (user == null) {
        return new AuthenticationError("Please Provide Token");
      } else {
        const response = await handleFileUpload(file);

        let type = "image/" + response.Location.split(/\.(?=[^\.]+$)/)[1];
        console.log("ygyiildihfdihuidfxui", type);
        let url = response.Location;
        const media = await MediaService.add({
          parent_id: user.id,
          media: url,
          media_type: type,
        });

        return {
          id: media.id,
          parent_id: media.parent_id,
          media: media.media,
          media_type: media.media_type,
        };
      }
    } catch (error) {
      return new AuthenticationError("Internal server Error");
    }
  },

  updatePost: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError("Please Provide Id where you update the product");
      }
      const isAccessUser = await database.Post.findOne({
        where: { user_id: user.id },
      });

      if (!isAccessUser) return new Error("you haven't access to update");

      const post = await PostService.update(input);
      return post;
    }
    return new AuthenticationError("Please Provide Token");
  },

  deletePost: async (root, { id }, { user }) => {
    if (user !== null) {
      const isExitPost = await database.Post.findOne({
        where: { id },
      });
      if (!isExitPost) return new Error("post not found");
      let userQuery = user.token_type === "user" ? { user_id: user.id } : { seller_id: user.id };
      console.log(userQuery);
      const isAccessUser = await database.Post.findOne({
        where: { id: id, ...userQuery },
        raw: true,
      });
      console.log(isAccessUser);
      if (!isAccessUser) return new Error("you haven't access to delete");
      const post = await PostService.delete(id);

      return { post };
    }
    return new AuthenticationError("Please Provide Token");
  },
  deleteSharePost: async (root, { id }, { user }) => {
    if (user !== null) {
      const isExitPost = await database.SharePost.findOne({
        where: { id },
      });
      if (!isExitPost) return { success: false, message: "Share Post not found", sharePost: -1 };
      const isAccessUser = await database.SharePost.findOne({
        where: { user_id: user.id },
      });

      if (!isAccessUser) return { success: false, message: "you haven't access to delete", sharePost: -1 };

      const post = await PostService.deleteSharePost(id);

      if (post) {
        const isAccessUser = await database.Post.destroy({
          where: { sharepost_id: id },
        });
      }

      return { success: true, message: "SharePost delete successfully", sharePost: post.id };
    }
    return new AuthenticationError("Please Provide Token");
  },
  createPost: async (root, { input }, { user }) => {
    if (user === null) {
      return new AuthenticationError("You are not authorized to access this data");
    } else {
      if (user.id) {
        input.user_id = user.id;
        if (!input.post_for) {
          return new AuthenticationError("post_for is required");
        }
        let post_for = input.post_for.toUpperCase();
        let postTypes = ["USER", "SELLER", "GROUP"];
        if (!postTypes.includes(post_for)) {
          return new AuthenticationError("post_for is invalid");
        }

        if (post_for === "USER") {
          let postInput;
          if (input.media_id) {
            postInput = {
              title: input.title,
              content: input.content,
              user_id: user.id,
              media_id: input.media_id,
              visible_for: input.visible_for,
              post_for: post_for,
            };
          } else {
            postInput = {
              title: input.title,
              content: input.content,
              user_id: user.id,
              visible_for: input.visible_for,
              post_for: post_for,
              media_id: [],
            };
          }
          const result = await PostService.add(postInput);
          return result;
        } else if (post_for === "SELLER") {
          let sellerPostInput;
          if (!input.store_id) {
            return new AuthenticationError("store_id is required");
          }
          if (input.media_id) {
            sellerPostInput = {
              title: input.title,
              content: input.content,
              seller_id: user.id,
              store_id: input.store_id,
              isActive: input.isActive ? input.isActive : false,
              isDraft: input.isDraft ? input.isDraft : false,
              isSchedule: input.isSchedule ? input.isSchedule : false,
              scheduleTime: input.scheduleTime,
              media_id: input.media_id,
              visible_for: input.visible_for,
              post_for: post_for,
            };
          } else {
            sellerPostInput = {
              title: input.title,
              content: input.content,
              seller_id: user.id,
              store_id: input.store_id,
              isActive: input.isActive,
              isDraft: input.isDraft,
              isSchedule: input.isSchedule,
              scheduleTime: input.scheduleTime,
              media_id: [],
              visible_for: input.visible_for,
              post_for: post_for,
            };
          }
          const result = await PostService.add(sellerPostInput);
          return result;
        } else if (post_for === "GROUP") {
          if (!input.group_id) {
            return new AuthenticationError("group_id is required");
          }
          let groupPostInput;

          if (input.media_id) {
            groupPostInput = {
              title: input.title,
              content: input.content,
              user_id: user.id,
              group_id: input.group_id,
              media_id: input.media_id,
              visible_for: input.visible_for,
              post_for: post_for,
            };
          } else {
            groupPostInput = {
              title: input.title,
              content: input.content,
              user_id: user.id,
              group_id: input.group_id,
              media_id: [],
              visible_for: input.visible_for,
              post_for: post_for,
            };
          }
          const result = await PostService.add(groupPostInput);
          return result;
        } else {
          return new AuthenticationError("post_for is invalid");
        }
      }
    }
  },
  updatePosts: async (root, { input }, { user }) => {
    if (user === null) {
      return new AuthenticationError("You are not authorized to access this data");
    } else {
      if (user.id) {
        if (!input.id) {
          return new AuthenticationError("id is required");
        }
        input.user_id = user.id;
        if (!input.post_for) {
          return new AuthenticationError("post_for is required");
        }
        let post_for = input.post_for.toUpperCase();
        let postTypes = ["USER", "SELLER", "GROUP"];
        if (!postTypes.includes(post_for)) {
          return new AuthenticationError("post_for is invalid");
        }

        if (post_for === "USER") {
          let post = await database.Post.findOne({
            where: {
              id: Number(input.id),
              post_for: "USER",
            },
          });

          if (!post) return new Error("post not found");
          const result = await PostService.update(input);
          return result;
        } else if (post_for === "SELLER") {
          let sellerPost = await database.Post.findOne({
            where: {
              id: Number(input.id),
              post_for: "SELLER",
            },
          });

          if (!sellerPost) return new Error("post not found");
          const result = await PostService.update(input);
          return result;
        } else if (post_for === "GROUP") {
          let groupPost = await database.Post.findOne({
            where: {
              id: Number(input.id),
              post_for: "GROUP",
            },
          });

          if (!groupPost) return new Error("post not found");
          const result = await PostService.update(input);
          return result;
        } else {
          return new AuthenticationError("post_for is invalid");
        }
      }
    }
  },
};
