const { AuthenticationError } = require("apollo-server-express");
const database = require("../../../database/models");
module.exports = {
  addUserDevices: async (root, { input }, { user }) => {
    if (user !== null) {
      input.userType = user.token_type;
      input.user_id = user.id;
      console.log(input);
      const UserDevices = await database.UserDevices.create(input);
      return { success: true, message: "activity stored", data: [UserDevices] };
    }
    return new AuthenticationError("Please Provide Token");
  },
  updateUserDevices: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError(
          "Please Provide Id where you update the UserDevices detail"
        );
      }

      const UserDevices = await UserDevicesService.update(input);
      return UserDevices;
    }
    return new AuthenticationError("Please Provide Token");
  },
  deleteUserDevices: async (root, { id }, { user }) => {
    if (user !== null) {
      if (!id) {
        return new AuthenticationError(
          "Please Provide Id where you delete the UserDevices detail"
        );
      }

      const UserDevices = await UserDevicesService.delete(id);

      return UserDevices;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
