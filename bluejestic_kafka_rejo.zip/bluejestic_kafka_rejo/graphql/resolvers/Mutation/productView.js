const { AuthenticationError } = require("apollo-server-express");
const database = require("../../../database/models");
const elasticClient = require("../../../services/elasticsearch");
module.exports = {
  addProductView: async (root, { input }, { user }) => {
    // if (user !== null) {
    const isStoreExist = await database.BusinessInformation.findOne({
      where: {
        id: input.store_id,
      },
    });
    input.userType = user?.token_type ? user.token_type : null;
    input.user_id = user?.id ? user?.id : null;
    if (!isStoreExist) return { success: false, message: "Store not found" };

    let existQuery = {
      where: {
        store_id: input.store_id,
        user_id: input.user_id,
        product_id: input.product_id,
      },
    };

    let existsProductView = await database.ProductView.findOne(existQuery);
    if (existsProductView) return { success: false, message: "Product View already exists" };

    const productViewData = await database.ProductView.create(input);
    /* add store activity data into elastic search */
    let elkData = await elasticClient.productViews.addProductViews({ ...input, id: productViewData.id });
    if (!elkData.success) return { success: false, message: elkData.message };
    return { success: true, message: "activity stored", data: [productViewData] };
    // }
    // return new AuthenticationError("Please Provide Token");
  },
  updateProductView: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError("Please Provide Id where you update the storeActivity detail");
      }

      const productViewData = await ProductViewService.update(input);
      return productViewData;
    }
    return new AuthenticationError("Please Provide Token");
  },
  deleteProductView: async (root, { id }, { user }) => {
    if (user !== null) {
      if (!id) {
        return new AuthenticationError("Please Provide Id where you delete the storeActivity detail");
      }

      const storeActivity = await ProductViewService.delete(id);

      return storeActivity;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
