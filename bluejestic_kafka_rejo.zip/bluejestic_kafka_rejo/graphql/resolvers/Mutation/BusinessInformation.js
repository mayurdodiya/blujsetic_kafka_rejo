const { AuthenticationError } = require("apollo-server-express");
const BusinessInformationService = require("../../../database/services/BusinessInformation");
const database = require("../../../database/models");
const elasticClient = require("../../../services/elasticsearch");
module.exports = {
  addBusinessInformation: async (root, { input }, { user }) => {
    if (user !== null) {
      const BusinessInformation = await BusinessInformationService.add(input);
      return BusinessInformation;
    }
    return new AuthenticationError("Please Provide Token");
  },

  updateBusinessInformation: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError(
          "Please Provide Id where you update the BusinessInformation"
        );
      }
      const BusinessInformation = await BusinessInformationService.update(
        input
      );
      BusinessInformation.logo = input.logo;
      BusinessInformation.cover_image = input.cover_image;
      return BusinessInformation;
    }
    return new AuthenticationError("Please Provide Token");
  },

  updateStoreDetail: async (root, { input }, { user: seller }) => {
    if (!seller) {
      return new AuthenticationError("Please Provide Token");
    }
    if (!input.store_id) {
      return {
        success: false,
        message: "Please Provide Id where you update the BusinessInformation",
      };
    }

    try {
      if (seller?.token_type === "user") {
        seller = await database.Seller.findOne({
          where: { user_id: seller?.id },
        });
      }

      let findBusinessInformationData =
        await database.BusinessInformation.findOne({
          where: { seller_id: seller.id, id: input?.store_id },
        });

      if (findBusinessInformationData.seller_id !== seller?.id) {
        return {
          success: false,
          message: "Invalid request or Store not found.",
        };
      }

      const { type } = input;
      if (!type) return { success: false, message: "Please Provide type." };

      const stepperforOnboaring = [
        "store-logo",
        "cover-image",
        "descriptions",
        "business-preference",
        "upload-legel-documents",
      ];

      const getNextStep = (currentStep) => {
        const currentIndex = stepperforOnboaring.indexOf(currentStep);
        if (
          currentIndex === -1 ||
          currentIndex === stepperforOnboaring.length - 1
        ) {
          return null;
        }
        return stepperforOnboaring[currentIndex + 1];
      };

      const stepperUpdateCall = async (data) => {
        if (data) {
          let [update_seller_info] = await database.Seller.update(data, {
            where: {
              id: seller?.id,
            },
          });

          //* update seller by id - elastic search db
          await elasticClient.sellers.updateSellerById(seller?.id, data);

          if (seller?.user_id) {
            await database.User.update(data, {
              where: {
                id: seller?.user_id,
              },
            });

            //* update user by id - elastic search db
            await elasticClient.user.updateUserById(
              "user",
              seller?.user_id,
              data
            );
          }
          return update_seller_info;
        }
      };

      let nextStepper;

      switch (type) {
        case "store-logo":
          [update_store_info] = await database.BusinessInformation.update(
            { logo_image: input?.logo },
            {
              where: {
                seller_id: seller?.id,
              },
            }
          );
          if (!update_store_info)
            return {
              success: false,
              message: "Something went Wrong, Please try agian later!",
            };

          //* update store by id - elastic search db
          await elasticClient.store.updateStoreById("store", seller?.id, {
            logo_image: input?.logo,
          });

          nextStepper = getNextStep(type);
          await stepperUpdateCall({
            currentStepForSellerOnboarding: nextStepper ?? "",
          });
          return { success: true, message: "Store logo Updated Successfully!" };
        case "cover-image":
          [update_store_info] = await database.BusinessInformation.update(
            { banner_image: input?.cover_image },
            {
              where: {
                seller_id: seller?.id,
              },
            }
          );
          if (!update_store_info)
            return {
              success: false,
              message: "Something went Wrong, Please try agian later!",
            };

          //* update store by id - elastic search db
          await elasticClient.store.updateStoreById("store", seller?.id, {
            banner_image: input?.cover_image,
          });

          nextStepper = getNextStep(type);
          await stepperUpdateCall({
            currentStepForSellerOnboarding: nextStepper ?? "",
          });
          return {
            success: true,
            message: "Cover image Updated Successfully!",
          };
        case "descriptions":
          [update_store_info] = await database.BusinessInformation.update(
            {
              shortDescription: input?.shortDescription,
              longDescription: input?.longDescription,
            },
            {
              where: {
                seller_id: seller?.id,
              },
            }
          );
          if (!update_store_info)
            return {
              success: false,
              message: "Something went Wrong, Please try agian later!",
            };

          //* update store by id - elastic search db
          await elasticClient.store.updateStoreById("store", seller?.id, {
            shortDescription: input?.shortDescription,
            longDescription: input?.longDescription,
          });

          nextStepper = getNextStep(type);
          await stepperUpdateCall({
            currentStepForSellerOnboarding: nextStepper ?? "",
          });
          return {
            success: true,
            message: "Descriptions Updated Successfully!",
          };
        case "business-preference":
          [update_store_info] = await database.BusinessInformation.update(
            {
              isFollow: input?.isFollow,
              isLikeShare: input?.isLikeShare,
              isNotification: input?.isNotification,
              isMessaging: input?.isMessaging,
              isTrends: input?.isTrends,
            },
            {
              where: {
                seller_id: seller?.id,
              },
            }
          );
          if (!update_store_info)
            return {
              success: false,
              message: "Something went Wrong, Please try agian later!",
            };

          //* update store by id - elastic search db
          await elasticClient.store.updateStoreById("store", seller?.id, {
            isFollow: input?.isFollow,
            isLikeShare: input?.isLikeShare,
            isNotification: input?.isNotification,
            isMessaging: input?.isMessaging,
            isTrends: input?.isTrends,
          });

          nextStepper = getNextStep(type);
          await stepperUpdateCall({
            currentStepForSellerOnboarding: nextStepper ?? "",
          });
          return {
            success: true,
            message: "Business preferences Updated Successfully!",
          };
        case "upload-legel-documents":
          [update_store_info] = await database.BusinessInformation.update(
            {
              documents: input?.documents,
            },
            {
              where: {
                seller_id: seller?.id,
              },
            }
          );
          if (!update_store_info)
            return {
              success: false,
              message: "Something went Wrong, Please try agian later!",
            };

          //* update store by id - elastic search db
          await elasticClient.store.updateStoreById("store", seller?.id, {
            documents: input?.documents,
          });

          nextStepper = getNextStep(type);
          await stepperUpdateCall({
            currentStepForSellerOnboarding: nextStepper ?? "completed",
            isOnboardCompleted: true,
            onboardCompletedAt: new Date(),
          });
          return { success: true, message: "Documents Uploaded Successfully!" };
        default:
          return {
            success: false,
            message: "Invalid type",
          };
      }
    } catch (error) {
      console.log("🚀 ~ updateStoreDetail: ~ error:", error);
    }
    // if (seller?.user_id) {
    //   await database.User.update({ isOnboardCompleted: true, onboardCompletedAt: new Date() }, { where: { id: seller?.user_id } });
    // }
    // await database.Seller.update({ isOnboardCompleted: true, onboardCompletedAt: new Date() }, { where: { id: seller?.id } });
    // const BusinessInformation = await BusinessInformationService.update(input);
    // console.log("🚀 ~ updateStoreDetail: ~ BusinessInformation:", BusinessInformation);
    // if (BusinessInformation) {
    //   return {
    //     success: true,
    //     message: "Seller onboarding completed successfully."
    //   }
    // } else {
    //   return {
    //     success: false,
    //     message: "Something went wrong."
    //   }
    // }
    // return BusinessInformation;
    // }
    // return new AuthenticationError("Invalid request");
  },

  updateStoreInfo: async (root, { input }, { user: seller }) => {
    try {
      if (!seller?.store_id) {
        return {
          success: false,
          message: "Please Provide Id where you update the BusinessInformation",
        };
      }

      const [BusinessInformation] = await database.BusinessInformation.update(
        input,
        { where: { id: seller?.store_id } }
      );

      if (BusinessInformation) {
        return { success: true, message: "Updated Successfully" }
      } else {
        return { success: false, message: "Something went wrong" }
      }

      console.log("BusinessInformation=====", BusinessInformation);
    } catch (error) {
      console.log("error", error);
    }
  },

  // deleteBusinessInformationDetail: async (root, { id }, { user }) => {
  //   if (user !== null) {
  //     const BusinessInformation = await BusinessInformationService.delete(id);

  //     return BusinessInformation;
  //   }
  //   return new AuthenticationError("Please Provide Token");
  // },
};
