const { AuthenticationError, UserInputError } = require("apollo-server-express");
const database = require("../../../database/models");

module.exports = {
  addProductBrand: async (root, args, { user }) => {
    // console.log("args++++++++++++++++++", args);

    try {
      if (user !== null) {
        try {
          let find_store = await database.BusinessInformation.findOne({
            where: {
              id: args.store_id,
            },
          });
          if (!find_store) {
            return { success: false, message: "Store not found", brand: null };
          }
          let addProductBrand = await database.ProductBrand.create(args);
          return { success: true, message: "Product added successfully", brand: { name: addProductBrand.name, id: addProductBrand.id } };
        } catch (error) {
          console.error("Server started.", error);
          throw error;
        }
      } else {
        return new AuthenticationError("Please Provide Token");
      }
    } catch (error) {
      console.log("error++++++++++++++++++++++++++++++++++", error);
    }
  },
};
