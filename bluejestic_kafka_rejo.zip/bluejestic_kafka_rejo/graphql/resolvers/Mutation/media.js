const { AuthenticationError } = require("apollo-server-express");
const { Media } = require("../../../database/models");
module.exports = {
  addMedia: async (root, args, { user }) => {
    const {
      owner_id,
      media_setting_id,
      media,
      media_type,
      media_for,
      media_tags,
      meta,
    } = args.input;
    if (user != null) {
      return Media.create({
        parent_id: user.id,
        owner_id,
        media_setting_id,
        media,
        media_type,
        media_for,
        media_tags,
        meta,
      });
    } else {
      return new AuthenticationError("Please provide the token");
    }
  },
  updateMedia: async (root, args, { user }) => {
    const {
      id,
      owner_id,
      media_setting_id,
      media,
      media_type,
      media_for,
      media_tags,
      meta,
    } = args.input;
    if (user != null) {
      if (!id) {
        return "Please Provide ID";
      }
      return Media.create({
        id,
        parent_id: user.id,
        owner_id,
        media_setting_id,
        media,
        media_type,
        media_for,
        media_tags,
        meta,
      });
    } else {
      return new AuthenticationError("Please provide the token");
    }
  },
  deletMedia: async (root, { id }, { user }) => {
    if (user != null) {
      if (!id) {
        return "Please Provide ID";
      }
      await Media.delete(id);
      return "Media is deleted";
    } else {
      return new AuthenticationError("Please provide the token");
    }
  },
};
