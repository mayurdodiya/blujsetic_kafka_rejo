const { AuthenticationError, UserInputError } = require("apollo-server-express");
const database = require("../../../database/models");
const GroupService = require("../../../database/services/group");
const elasticClient = require("../../../services/elasticsearch");
const { default: slugify } = require("slugify");
const redisClient = require("../../../redis/redisClient");
const client = require("../../../services/elasticsearch/config/config");
module.exports = {
  createGroup: async (root, { input }, { user }) => {
    if (user !== null) {
      input.user_id = user.id;
      input.subCategory_id = input.subCategory_id[0];

      let slug = slugify(input?.name, { lower: true, replacement: "" });
      let final_slug;

      let is_exist = await database.Group.findOne({
        where: {
          name: input?.name,
        },
      });

      if (is_exist) {
        return { success: false, message: "Group name already exist" };
      }

      let find_unique_user = await database.Group.findOne({
        where: {
          slug: slug,
        },
        raw: true,
      });

      if (find_unique_user) {
        const otp = Math.floor(Math.random() * 900) + 100;
        final_slug = slug + otp;
      } else {
        final_slug = slug;
      }

      const group = await GroupService.add({ ...input, slug: final_slug, created_by: user?.firstName + " " + user?.lastName, is_deleted: false });
      let storeTypes = ["JOIN_CLUBS", "CLUBS_YOU_MANAGE", "SUGGESTED_CLUBS", "ALL_CLUB"];

      process.nextTick(async () => {
        await redisClient.del(`PUBLIC:ALL_CLUB`);
        for (let i = 0; i < storeTypes.length; i++) {
          let type = storeTypes[i];
          await redisClient.del(`USER/${user?.id}:${type}`);
        }
      });
      /* add group in elastic search */
      // if (input.bannerImage) input.bannerImage = await database.Media.findOne({ where: { id: input.coverImage } }).then((data) => (data?.media ? data?.media : null));
      // if (input.coverImage) input.coverImage = await database.Media.findOne({ where: { id: input.coverImage } }).then((data) => (data?.media ? data?.media : null));

      let elkData = await elasticClient.group.addGroup({ ...input, id: group.id, slug: final_slug, created_by: user?.firstName + " " + user?.lastName, is_deleted: false });
      console.log(elkData);
      if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");

      return group;
    }
    return new AuthenticationError("Please Provide Token");
  },

  updateGroupDetail: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError("Please Provide Id where you update the group");
      }

      let find_name = await database.Group.findOne({
        where: { id: input?.id },
        raw: true,
      });

      if (!find_name) {
        return { success: false, message: "Group name already exist" };
      }

      const group = await GroupService.update(input);
      let storeTypes = ["JOIN_CLUBS", "CLUBS_YOU_MANAGE", "SUGGESTED_CLUBS", "ALL_CLUB"];

      process.nextTick(async () => {
        await redisClient.del(`PUBLIC:ALL_CLUB`);
        for (let i = 0; i < storeTypes.length; i++) {
          let type = storeTypes[i];
          await redisClient.del(`USER/${user?.id}:${type}`);
        }
      });
      /* update group in elastic search */
      // if (input.bannerImage) input.bannerImage = await database.Media.findOne({ where: { id: input.coverImage } }).then((data) => (data?.media ? data?.media : null));
      // if (input.coverImage) input.coverImage = await database.Media.findOne({ where: { id: input.coverImage } }).then((data) => (data?.media ? data?.media : null));
      let elkData = await elasticClient.group.updateGroupById(group.id, { ...input });
      if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");

      return { success: true, message: "Fetch Successfully", slug: group?.slug, id: group?.id };
    }
    return new AuthenticationError("Please Provide Token");
  },

  deleteGroupDetail: async (root, { id }, { user }) => {
    if (user !== null) {
      const group = await GroupService.delete(id, user.id);
      /* delete group in elastic search */
      let elkData = await elasticClient.group.deleteGroup({ id, user_id: user.id });
      if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");
      return group;
    }
    return new AuthenticationError("Please Provide Token");
  },

  removeGroupMember: async (root, args, { user }) => {
    let groupMembers = args?.member_id;
    let club_id = args?.club_id;

    if (user !== null) {
      let find_club = await database.Group.findOne({
        where: {
          id: club_id,
        },
        raw: true,
      });

      if (!find_club) {
        return { success: false, message: "Group Not Found!" };
      }

      let find_admin = await database.JoinGroup.findOne({
        where: {
          group_id: club_id,
          user_id: user?.id,
        },
        raw: true,
      });

      if (!find_admin?.isAdmin) {
        return { success: false, message: "You have not access to remove Members" };
      }

      for (let i = 0; i < groupMembers.length; i++) {
        let member_id = groupMembers[i];
        let remove_member = await database.JoinGroup.destroy({
          where: { user_id: member_id, group_id: club_id },
        });
      }
      return { success: true, message: "Members Remove Successfully" };
    }
    return new AuthenticationError("Please Provide Token");
  },

  deleteGroupsBySlugsForAdmin: async (root, { slugs }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    if (user.role !== "admin") return new AuthenticationError("Unauthorized!");
    try {

      if (!Array.isArray(slugs) || !slugs.length) {
        return {
          success: false,
          message: "Please provide valid group id(s)!"
        }
      }

      for (let i = 0; i < slugs?.length; i++) {
        let slug = slugs[i];
        let group = await database.Group.findOne({ where: { slug: slug, is_deleted: false } });

        group = JSON.parse(JSON.stringify(group));

        if (!group) {
          return new UserInputError("Group Already Deleted otherwise Group not found!");
        }

        if (group) {
          await GroupService.deleteBySlug(slug);
          const indexName = "group"
          const isExists = await client.search({
            index: indexName,
            body: {
              query: {
                bool: {
                  must: [
                      {
                        match: { slug: slug }
                      },
                      {
                        match: { is_deleted: false }
                      }
                    ]
                  }
                }
              },
            });


          if (Boolean(isExists?.hits?.hits?.length) && isExists.hits.hits[0]?._source) {

            const _source = isExists.hits.hits[0]?._source;

            const updatedDocument = {
              ..._source,
              is_deleted: true
            };

            const updateResponse = await client.update({
              index: indexName,
              id: isExists.hits.hits[0]?._id,
              body: {
                doc: updatedDocument,
              },
            });
          }
        }
      }
      return { success: true, message: "Group(s) deleted successfully." };

    } catch (error) {
      console.error("An error occured while deleting the clubs by admin", error);
      throw new Error("An error occured while deleting the clubs by admin");
    }
  },
};
