const database = require("../../../database/models");
const { AuthenticationError, ApolloError } = require("apollo-server-express");
const { auth } = require("../../../database/services/token");
const { likeServiceForValidation } = require("../../../utils/utils");
const elasticClient = require("../../../services/elasticsearch");
const redisClient = require("../../../redis/redisClient");
module.exports = {
  createLike: async (_, { input }, { user }) => {
    try {
      const { parent_id, like_for } = input;
      const token = await auth(user);

      if (token == false) {
        return new AuthenticationError("Please Provide the token");
      }

      const validLike = like_for.toUpperCase();

      console.log(validLike);
      if (!validLike) {
        return new AuthenticationError("Please Provide the like_for");
      }

      const validLikesData = ["POST", "COMMENT", "GROUP", "COMMENTREPLY", "SELLERPOST", "PRODUCT", "SHAREPOST"];
      const isValidMedia = validLikesData.includes(validLike);

      if (isValidMedia == false) {
        return { message: "like_for is not valid" };
      }

      let Input = {};

      let { body, data } = await likeServiceForValidation(validLike, database, parent_id);
      if (!data) {
        return { message: "Invalid Request" };
      }
      Input = body;
      Input["user_id"] = token.id;
      Input["like_for"] = validLike;

      const userLikeDuplicate = await database.Like.findAll({
        where: Input,
      });

      if (userLikeDuplicate.length > 0) {
        return { message: "You already liked this post" };
      }
      const likeData = await database.Like.create(Input);
      /* add like in elastic search */
      let elkBody = {
        id: likeData.id,
        store_id: data.store_id,
        ...Input,
      };
      let elkData = await elasticClient.storeLikes.addStoreLikes(elkBody);
      if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");
      return { message: "Like Created", id: likeData?.id };
    } catch (error) {
      console.log(error);
      return error;
    }
  },

  disLike: async (_, { input }, { user }) => {
    try {
      const { id } = input;
      const token = await auth(user);

      if (token == false) {
        return new AuthenticationError("Please Provide the token");
      }

      const findLike = await database.Like.findOne({
        where: { id: id },
      });

      if (findLike == null) {
        return { message: "Like is not found" };
      } else {
        const deleteLike = await database.Like.destroy({
          where: { id: id, user_id: token.id },
        });
        const user = await database.User.findOne({
          where: { id: token.id },
        });

        /* delete like in elastic search */
        if (findLike.like_for == "SELLERPOST") {
          // let post = await database.Post.findOne({ where: { id: findLike.post_id } });
          let elkData = await elasticClient.storeLikes.deleteStoreLike({ id });
          if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");
          /* dislike using kafka*/
          // await global.kafkaConfig.produce("seller_likes", [{ value: { store_id: post.store_id ? post.store_id : null, data: -1 } }])
          // await global.kafkaConfig.produce("seller_post_likes", [{ value: { data: elkBody, isLike: true } }]);
        }
        return { message: "Like Deleted", user: user };
      }
    } catch (error) {
      return "Internal Sever Error : " + error;
    }
  },

  addStoreLike: async (_, { store_id }, { user }) => {
    try {
      if (!user) return new AuthenticationError("Please Provide the Token");
      let find_store = await database.BusinessInformation.findOne({ where: { id: store_id } });
      if (!find_store) return { success: false, message: "Store Not Found" };
      let find_like = await database.StoreLike.findOne({ where: { store_id: store_id, user_id: user?.id } });
      let storeTypes = ["JOIN_STORES", "SUGGESTED_STORES", "ALL_STORE"];
      process.nextTick(async () => {
        const res35 = await redisClient.del(`PUBLIC:ALL_STORE`);
        for (let i = 0; i < storeTypes.length; i++) {
          let type = storeTypes[i];
          const res35 = await redisClient.del(`USER/${user?.id}:${type}`);
          console.log(res35); // 0
        }
      });
      if (!find_like) {
        let create_like = await database.StoreLike.create({ store_id: store_id, user_id: user?.id });
        return { success: true, message: "Store Like Successfully!" };
      } else {
        let remove_like = await database.StoreLike.destroy({
          where: {
            store_id: Number(store_id),
          },
        });
        return { success: true, message: "Store Unlike Successfully!" };
      }
    } catch (error) {
      console.log("error", error);
    }
  },
};
