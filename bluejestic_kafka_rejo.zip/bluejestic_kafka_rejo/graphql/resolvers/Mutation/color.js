const {AuthenticationError} = require('apollo-server-express')
const ColorService = require('../../../database/services/color')
module.exports = {
addColor : async(root, {input}, {user}) => {
    
    if(user !== null){
        const ColoeData = await ColorService.add(input);
        return ColoeData
    }
    return new AuthenticationError("Please Provide Token")
},
updateColor:async(root, {input}, {user} ) => {
    
    if(user !== null){
        if(!input.id){
            return  new AuthenticationError("Please Provide Id where you update the product")
        }

        const ColorData = await ColorService.update(input)
        return ColorData
    }
    return new AuthenticationError("Please Provide Token")
},
deleteColor:async(root, {id}, {user} ) => {
    
    if(user !== null){
        
        const Color = await ColorService.delete(id)
        
        return Color
    }
    return new AuthenticationError("Please Provide Token")
}
}