const { AuthenticationError } = require("apollo-server-express");
const CreateOrderItemService = require("../../../database/services/createOrderItem");
module.exports = {
  createOrderItem: async (root, { input }, { user }) => {
    if (user !== null) {
      let dummyData = [
        {
          productId: 6,
          quantity: 5,
        },
        { productId: 7, quantity: 3 },
      ];

      const cardDetails = await CreateOrderItemService.add(dummyData, user.id);
      return cardDetails;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
