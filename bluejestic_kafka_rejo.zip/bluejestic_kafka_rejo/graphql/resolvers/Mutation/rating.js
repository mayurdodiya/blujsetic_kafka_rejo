const {AuthenticationError} = require('apollo-server-express')
const RatingService = require('../../../database/services/rating')
module.exports = {
addRating : async(root, {input}, {user}) => {
    
    if(user !== null){
        const RatingData = await RatingService.add(input);
        return RatingData
    }
    return new AuthenticationError("Please Provide Token")
},
updateRating:async(root, {input}, {user} ) => {
    if(user !== null){
        if(!input.id){
            return  new AuthenticationError("Please Provide Id where you update the product")
        }
        const RatingData = await RatingService.update(input)
        return RatingData
    }
    return new AuthenticationError("Please Provide Token")
},
deleteRating:async(root, {id}, {user} ) => {
    
    if(user !== null){        
        const Rating = await RatingService.delete(id)
        return Rating
    }
    return new AuthenticationError("Please Provide Token")
}
}