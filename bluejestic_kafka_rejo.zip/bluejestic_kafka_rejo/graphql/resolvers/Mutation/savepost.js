const { AuthenticationError } = require("apollo-server-express");

const SavePostService = require("../../../database/services/savepost");
const database = require("../../../database/models");
module.exports = {
  createSavePost: async (root, { input }, { user }) => {
    if (user === null) {
      return new AuthenticationError(
        "You are not authorized to access this data"
      );
    } else {
      const savePost = SavePostService.add(input);
      return savePost;
    }
  },
  unSavePost: async (root, { id, post_id }, { user }) => {
    if (user === null) {
      return {
        success: false,
        message: "You are not authorized to access this data"
      }
    } else {
      let where = id ? { id: id, user_id: user.id } : { post_id: post_id, user_id: user.id };
      let post = await database.SavePost.findOne({ where: where })
      if (!post) {
        return { success: false, message: "Post not found" }
      }
      console.log("post.userId !== user.id", post.user_id, user.id);
      if (post.user_id !== user.id) {
        return { success: false, message: "You are not authorized to access this post to unsave" }
      }
      const savePost = SavePostService.delete(where);
      return {
        success: true,
        message: "Post Unsaved"
      }
    }
  },
};
