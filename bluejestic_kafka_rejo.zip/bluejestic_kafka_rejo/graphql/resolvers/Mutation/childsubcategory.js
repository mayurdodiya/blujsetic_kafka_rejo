const { AuthenticationError } = require("apollo-server-express");
const ChildSubCategoryService = require("../../../database/services/childsubcategory");
module.exports = {
  addChildSubCategory: async (root, { name, image_id, banner_id, description, is_deleted = false, category_id, sub_category_id, position }, { user }) => {
    if (user !== null) {
      const subcategory = await ChildSubCategoryService.add({ name, image_id, banner_id, description, is_deleted, category_id, sub_category_id, position });
      return subcategory;
    }
    return new AuthenticationError("Please Provide Token");
  },

  updateChildSubCategory: async (root, args, { user }) => {
    if (user !== null) {
      if (!args?.id) {
        return new AuthenticationError("Please Provide Id where you update the category");
      }
      const category = await ChildSubCategoryService.update({ ...args });
      return category;
    }
    return new AuthenticationError("Please Provide Token");
  },

  deleteChildSubCategory: async (root, { id }, { user }) => {
    if (user !== null) {
      const category = await ChildSubCategoryService.delete(id);

      return category;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
