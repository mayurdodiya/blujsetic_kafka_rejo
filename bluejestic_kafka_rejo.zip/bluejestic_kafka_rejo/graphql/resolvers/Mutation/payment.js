const { AuthenticationError } = require("apollo-server-express");
const { Op, Sequelize } = require("sequelize");
const config = require("../../../database/config/stripe");
const database = require("../../../database/models");
const stripe = require("stripe")(config.stripeSecretKey);
const elasticClient = require("../../../services/elasticsearch");
const { findCropImages } = require("../../../utils/utils");
module.exports = {
  //* For payment verication without usd
  verifyPayment: async (root, { paymentId, order_id }, { user }) => {
    try {
      if (!user) {
        return { success: false, message: "Please Provide Token" };
      }
      // const orderMasters = await database.ConfirmedOrder.findOne({

      const order = await database.OrderMaster.findOne({
        where: {
          userId: user.id,
          paymentId,
          id: order_id,
        },
        include: [
          {
            model: database.OrderItems,
            as: "orderItems",
            attributes: ["id", "orderId", "productId", "quantity"],
          },
        ],
        // raw: true,
        nest: true,
      }).then((data) => data.toJSON());
      if (!order) {
        return { success: false, message: "order not found" };
      }
      const paymentIntentForPayemnt = await stripe.paymentIntents.retrieve(paymentId);
      // console.log("paymentIntentForPayemnt", paymentIntentForPayemnt);
      // console.log("Orderss : ------", order);

      if (paymentIntentForPayemnt.status == "succeeded") {
        /* update productqty and delete cart */
        await Promise.all(
          order.orderItems.map(async (o) => {
            let product = await database.Product.findOne({ where: { id: o.productId, is_deleted: false }, raw: true });
            let elasticPayload = {
              quantity: product.quantity - o.quantity,
            };
            let updateElasticssearchOrder = await elasticClient.product.updateProductById("products", product.id, elasticPayload);
            /** product qty update */
            await database.Product.update({ quantity: Sequelize.literal(`quantity - ${o.quantity}`) }, { where: { id: o.productId } });
            /* cart delete */
            await database.Cart.destroy({ where: { user_id: user.id, parent_id: o.productId } });

            /* order items - payload */
            await database.OrderItems.update(
              {
                paymentStatus: "done",
              },
              { where: { id: o.id } }
            );
          })
        );

        // payment done - database
        let payload = { isPaymentDone: true, paymentStatus: "done", isActive: true };
        const confirmOrder = await database.OrderMaster.update(payload, { where: { id: order.id } });
        let elkData = await elasticClient.order.updateOrderMasterById("order_master", order.id, payload);

        return { success: true, message: "Payment Confirmed" };
      } else {
        return { success: false, message: "Payment Failed" };
      }
    } catch (error) {
      console.log("error", error);
      return { success: false, message: "Somthing Went Wrong" };
    }
  },

  //* For withdraw payment from seller
  withDrawPaymentFromSeller: async (root, args, { user }) => {
    try {
      if (!user) {
        return { success: false, message: "Please Provide Token" };
      }
      if (user.token_type !== "seller") {
        return { success: false, message: "Access Denied" };
      }
      const { amount, accountId } = args;
      const { id } = user;
      const seller = await database.Seller.findOne({ where: { id: id }, raw: true });
      if (!seller) {
        return { success: false, message: "Seller not found" };
      }
      const isOnboardingApproved = await database.Seller.findOne({
        where: { id: id, stripeAccountId: accountId, isPaymentOnboardingCompleted: true },
      });
      if (!isOnboardingApproved) {
        return { success: false, message: "Seller not approved for withdraw money" };
      }

      /* verified OTP */
      if (!seller.otpForWithdrawal) return { success: false, message: "Resend OTP" };
      if (seller.otpForWithdrawal !== args.otp) return { success: false, message: "OTP not verified" };
      if (seller.otpForWithdrawalExpiry < new Date()) return { success: false, message: "OTP expired" };

      /* amount validation */

      let seller_order_amounts = await database.OrderItems.findAll({
        where: {
          seller_id: id,
          //* BALANCE_NOT_FOUND
          // order_status: "delivered",
        },
        attributes: [[Sequelize.fn("sum", Sequelize.col("sellerFinalAmount")), "total"]],
        raw: true,
      });
      if (seller_order_amounts[0]?.total && seller_order_amounts[0]?.total < amount) {
        return { success: false, message: "Insufficient balance" };
      }

      const account = await stripe.accounts.retrieve(accountId);
      console.log("account", account.external_accounts);

      if (amount < 500) {
        return { success: false, message: "Minimum amount should be $500" };
      }

      /* transfer money to seller */
      const transfer = await stripe.transfers.create({
        amount: amount * 100,
        currency: "usd",
        destination: accountId,
        metadata: { seller_id: seller.id },
      });
      console.log("transfertransfer", transfer);
      if (transfer.id) return { success: true, message: "Money transfered to seller", data: { id: transfer.id } };
      else return { success: false, message: "Money not transfered to seller" };
    } catch (error) {
      console.log("error", error);
      return { success: false, message: error.message };
    }
  },

  //* For refund payment to seller
  refundFromSellerToPlatform: async (root, args, { user }) => {
    try {
      if (!user) {
        return { success: false, message: "Please Provide Token" };
      }
      const { amount, orderId } = args;

      let orderItem = await database.OrderItems.findOne({
        where: {
          id: orderId,
          paymentStatus: {
            [Op.or]: ["done", "refunded"],
          },
          // order_status : "returned"
        },
        include: [
          {
            model: database.OrderMaster,
            as: "orderMaster",
            attributes: ["id", "paymentId"],
          },
        ],
        // raw: true,
      });
      console.log("orderItem", JSON.parse(JSON.stringify(orderItem)));
      if (!orderItem) return { success: false, message: "Order not found" };

      if (orderItem.paymentStatus == "refunded") return { success: false, message: "Order already refunded" };

      //* refund from seller to customer
      let refund = await stripe.refunds.create({
        payment_intent: orderItem.orderMaster.paymentId,
        amount: amount * 100,
      });
      console.log("refundrefund", refund);

      /* retrive payment */
      const paymentIntentForPayemnt = await stripe.paymentIntents.retrieve(orderItem.orderMaster.paymentId);

      const charge = await stripe.charges.retrieve(`${refund?.charge}`, {
        stripeAccount: paymentIntentForPayemnt?.charges?.data[0]?.payment_method_details?.card?.wallet?.dynamic_last4,
      });
      let charge_url = charge.receipt_url ? charge.receipt_url : "";

      /* order master - update payment status */
      await database.OrderItems.update({ paymentStatus: "refunded", refund_reciept_url: charge_url }, { where: { id: orderItem.id } });

      if (refund.status == "succeeded") return { success: true, message: "Money refunded  to customer", data: { id: refund.id } };
      else return { success: false, message: "Money not refunded  to customer" };
    } catch (error) {
      console.log("error", error);
      return { success: false, message: error.message };
    }
  },

  //* generate client-secret key for payment
  addPayment: async (root, { amount }, { user }) => {
    if (user !== null) {
      try {
        const user_data = await database.User.findOne({
          where: {
            id: user.id,
          },
          raw: true
        });
        if (user_data) {
          const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY);
          const paymentIntent = await stripe.paymentIntents.create({
            amount: (amount * 100).toFixed(0),
            currency: "usd",
            // customer: user?.id ? String(user?.id) : '',
            // Verify your integration in this guide by including this parameter
            metadata: { integration_check: "accept_a_payment" },
            receipt_email: user_data.email,
            description: "fees",
          });
          if (paymentIntent?.client_secret) {
            return { client_secret: paymentIntent["client_secret"] };
          }
        }
      } catch (err) {
        console.log("err", err);
        return { success: false, message: "Somthing Went Wrong" };
      }
    }
    return new AuthenticationError("Please Provide Token");
  },
};
