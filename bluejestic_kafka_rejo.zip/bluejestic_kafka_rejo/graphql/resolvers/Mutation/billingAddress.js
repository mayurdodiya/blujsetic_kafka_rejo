const { AuthenticationError } = require("apollo-server-express");
const BillingAddressService = require("../../../database/services/billingAddress");
module.exports = {
  addBillingAddress: async (root, { input }, { user }) => {
    if (user !== null) {
      let object = {
        user_id: user.id,
        streetAddress: input.streetAddress,
        city: input.city,
        firstName: input.firstName,
        lastName: input.lastName,
        country: input.country,
        country_name: input.country_name,
        state: input.state,
        state_name: input.state_name,
        number: input.number,
        isDefault: input.isDefault,
        zipcode: input.zipcode,
        buildingName: input.buildingName,
        isPinLocation: input.isPinLocation,
        latitude: input.latitude,
        longitude: input.longitude,
      };
      const cardDetails = await BillingAddressService.add(object, user.id);
      return cardDetails;
    }
    return new AuthenticationError("Please Provide Token");
  },
  updateBillingAddress: async (root, { input }, { user }) => {
    if (user !== null) {
      if (!input.id) {
        return new AuthenticationError("Please Provide Id where you update the about detail");
      }

      const cardDetails = await BillingAddressService.update(input, user.id);
      return cardDetails;
    }
    return new AuthenticationError("Please Provide Token");
  },
  deleteBillingAddress: async (root, { id }, { user }) => {
    if (user !== null) {
      if (!id) {
        return new AuthenticationError("Please Provide Id where you delete the about detail");
      }

      const cardDetails = await BillingAddressService.delete(id);

      return cardDetails;
    }
    return new AuthenticationError("Please Provide Token");
  },
};
