const { 
    getSellerAnalytics,
    getSellerTrafficAndEngagement,
    getCustomersDetails,
    getSellerSalesData,
    getSellerSocialActivity,
    getSellerStoreFollowers,
    getSellerFinances,
    getOrdersAnalysis,
    getSellerSalesDataInsights
} = require("../Query/sellerAnalytics");

module.exports = {
    Mutation: {
    },
    Query: {
        getSellerAnalytics,
        getSellerTrafficAndEngagement,
        getCustomersDetails,
        getSellerSalesData,
        getSellerSocialActivity,
        getSellerStoreFollowers,
        getSellerFinances,
        getOrdersAnalysis,
        getSellerSalesDataInsights
    }
}