const { addOffer, deleteOffer, updateOffer } = require("../Mutation/offer");
const { getAllOffers, getSingleOffer } = require("../Query/offer");
module.exports = {
  Mutation: {
    addOffer,
    deleteOffer,
    updateOffer,
  },
  Query: {
    getAllOffers,
    getSingleOffer,
  },
};
