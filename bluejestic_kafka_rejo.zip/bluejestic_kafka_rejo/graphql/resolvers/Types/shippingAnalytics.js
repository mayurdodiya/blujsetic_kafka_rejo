const { getShippingAnalytics } = require("../Query/shippingAnalytics");

module.exports = {
    Mutation: {
    },
    Query: {
        getShippingAnalytics
    }
}