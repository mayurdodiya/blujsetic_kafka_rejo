const { address, getAddress } = require("../Mutation/address");
// const { address } = require("../Mutation/address");

// const { getSingleUser, getAllUsers} = require('../Query/address');

module.exports = {
  Query: {},
  Mutation: {
    address,
    getAddress,
  },
};
