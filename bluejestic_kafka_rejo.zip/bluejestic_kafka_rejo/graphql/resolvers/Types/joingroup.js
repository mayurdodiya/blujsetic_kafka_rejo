const { joinGroup, leaveGroup } = require("../Mutation/joingroup");
// const { groups, getSingleGroupDetail } = require("../Query/group");

module.exports = {
  Query: {},
  Mutation: {
    joinGroup,
    leaveGroup,
  },
};
