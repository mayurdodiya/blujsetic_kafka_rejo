const { addLegalDetails } = require("../Mutation/LegalDetails");
const {
  getAllLegalDetails,
  getSingleLegalDetails,
} = require("../Query/LegalDetails");

module.exports = {
  Query: {
    getAllLegalDetails,
    getSingleLegalDetails,
  },
  Mutation: {
    addLegalDetails,
  },
};
