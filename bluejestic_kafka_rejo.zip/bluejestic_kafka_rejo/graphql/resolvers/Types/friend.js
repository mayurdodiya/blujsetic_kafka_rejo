const { addFriend, deleteFriend, updateFriend } = require("../Mutation/friend");
const {
  getAllFriend,
  getAllPeople,
  getAllAdminUser,
  getUserDetail,
  getSingleFriend,
  getFriendRequest,
  checkRequestStatus,
  getMyFriends,
  deleteFriendByUserAndFriendId,
  getMutualFollowing,
  getUserFollowers,
  getUserFollowings,
  getSuggestedUsers,
} = require("../Query/friend");
module.exports = {
  Mutation: {
    addFriend,
    deleteFriend,
    updateFriend,
  },
  Query: {
    getAllFriend,
    getAllPeople,
    getAllAdminUser,
    getUserDetail,
    getSingleFriend,
    getFriendRequest,
    checkRequestStatus,
    getMyFriends,
    deleteFriendByUserAndFriendId,
    getMutualFollowing,
    getUserFollowers,
    getUserFollowings,
    getSuggestedUsers,
  },
};
