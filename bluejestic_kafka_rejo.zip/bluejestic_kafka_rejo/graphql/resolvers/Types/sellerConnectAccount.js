const { 
  createSellerConnectAccount, 
  addMoreBankAccountOrCard,
  removeConnectAccount, 
  sellerWithdrawalFund, 
} = require("../Mutation/sellerConnectAccount");

const { capabilitiesActiveLink, 
  getTransactionHistoryOfSeller, 
  getSellerConnectAccountDetails ,
  getTransactionHistoryOfSellerForAdmin
} = require("../Query/sellerConnectAccount");

module.exports = {
  Mutation: {
    createSellerConnectAccount,
    addMoreBankAccountOrCard,
    removeConnectAccount,
    sellerWithdrawalFund,
  },
  Query: {
    capabilitiesActiveLink,
    getTransactionHistoryOfSeller,
    getSellerConnectAccountDetails,
    getTransactionHistoryOfSellerForAdmin
  },
};