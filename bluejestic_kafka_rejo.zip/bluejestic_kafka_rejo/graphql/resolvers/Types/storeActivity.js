const { addStoreActivity } = require("../Mutation/storeActivity");
const { getAllStoreActivities, getAllStoreActivityChartData, getUserDevicesData, storeVisitorsGender, visitorsLocation, getAccountReachedChartData } = require("../Query/storeActivity");
module.exports = {
  Mutation: {
    addStoreActivity
  },
  Query: {
    getAllStoreActivities,
    getAllStoreActivityChartData,
    getUserDevicesData,
    storeVisitorsGender,
    visitorsLocation,
    getAccountReachedChartData
  },
};
