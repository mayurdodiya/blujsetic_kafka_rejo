const { randomArray } = require("../Query/randomArray");
module.exports = {
  Mutation: {},
  Query: { randomArray },
};
