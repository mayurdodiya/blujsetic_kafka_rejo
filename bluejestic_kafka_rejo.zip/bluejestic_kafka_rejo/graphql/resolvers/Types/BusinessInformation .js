const {
  addBusinessInformation,
  updateBusinessInformation,
  updateStoreDetail,
  updateStoreInfo
} = require("../Mutation/BusinessInformation");
const {
  getAllBusinessInformation,
  getSingleBusinessInformation,
  getStoreDetail,
  searchStoressWithElasticSearch
} = require("../Query/BusinessInformation");

module.exports = {
  Query: {
    getAllBusinessInformation,
    getSingleBusinessInformation,
    getStoreDetail,
    searchStoressWithElasticSearch
  },
  Mutation: {
    addBusinessInformation,
    updateBusinessInformation,
    updateStoreDetail,
    updateStoreInfo
  },
};
