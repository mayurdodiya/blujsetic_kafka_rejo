const { addNotification, updateNotification, deleteNotification } = require("../Mutation/notification");
const { getAllNotification, getSingleNotification } = require("../Query/notification");
module.exports = {
  Mutation: {
    addNotification,
    updateNotification,
    deleteNotification
  },
  Query: {
    getAllNotification,
    getSingleNotification
  },
};
