const { addUserDevices } = require("../Mutation/userDevices");
const { getAllUserDevices } = require("../Query/userDevices");
module.exports = {
  Mutation: {
    addUserDevices
  },
  Query: {
    getAllUserDevices
  },
};
