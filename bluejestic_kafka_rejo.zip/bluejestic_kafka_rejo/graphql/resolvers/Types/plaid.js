const { createPlaidLinkToken, getAccessTokenForPlaid } = require("../Mutation/plaid");
module.exports = {
  Mutation: {
    createPlaidLinkToken,
    getAccessTokenForPlaid
  },
  Query: {
  },
};
