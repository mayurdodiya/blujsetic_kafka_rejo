const {addMedia} = require('../Mutation/media')
const {getAllMedia, getSingleMedia} = require('../Query/media')
module.exports = {
  Mutation: {
    addMedia,
  },
  Query: {
    getAllMedia,
    getSingleMedia
    },
};