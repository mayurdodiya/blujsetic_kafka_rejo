const { addBillingAddress, deleteBillingAddress, updateBillingAddress } = require("../Mutation/billingAddress");
const { getAllBillingAddress, getSingleBillingAddress } = require("../Query/billingAddress");
module.exports = {
  Mutation: {
    addBillingAddress,
    deleteBillingAddress,
    updateBillingAddress,
  },
  Query: {
    getAllBillingAddress,
    getSingleBillingAddress,
  },
};
