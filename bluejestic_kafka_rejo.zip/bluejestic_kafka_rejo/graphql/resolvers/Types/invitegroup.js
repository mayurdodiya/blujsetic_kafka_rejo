const {
  inviteGroups,
  acceptInviteGroups,
  cancleInviteGroupRequest,
} = require("../Mutation/invitegroup");
// const { groups, getSingleGroupDetail } = require("../Query/group");

module.exports = {
  Query: {},
  Mutation: {
    inviteGroups,
    acceptInviteGroups,
    cancleInviteGroupRequest,
  },
};
