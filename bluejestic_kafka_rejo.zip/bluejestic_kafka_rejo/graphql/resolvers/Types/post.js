const { addPost, deletePost, updatePost, UploadFile, createPost, updatePosts, sharePost, deleteSharePost } = require("../Mutation/post");
const { getAllPost, getSinglePost, getSavedPost } = require("../Query/post");
module.exports = {
  Mutation: {
    addPost,
    deletePost,
    updatePost,
    UploadFile,
    createPost,
    updatePosts,
    sharePost,
    deleteSharePost,
  },
  Query: {
    getAllPost,
    getSinglePost,
    getSavedPost,
  },
};
