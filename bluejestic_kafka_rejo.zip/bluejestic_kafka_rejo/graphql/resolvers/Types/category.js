const { addCategory, deleteCategoryDetail, updateCategoryDetail, updateCategoryPosition } = require("../Mutation/categories");
const { getAllCategoryDetail, getSingleCategoryDetail, getSingleCategory } = require("../Query/categories");
module.exports = {
  Mutation: {
    addCategory,
    updateCategoryDetail,
    updateCategoryPosition,
    deleteCategoryDetail,
  },
  Query: {
    getAllCategoryDetail,
    getSingleCategoryDetail,
    getSingleCategory,
  },
};
