const { addUserLocationActivity } = require("../Mutation/userLocationActivity");
const { getAllUserLocationHistory } = require("../Query/userLocationActivity");
module.exports = {
  Mutation: {
    addUserLocationActivity
  },
  Query: {
    getAllUserLocationHistory
  },
};
