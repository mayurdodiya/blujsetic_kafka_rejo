const { followStore, unFollowStore } = require("../Mutation/followstore");
const { getAllStoreFollowers,getAllStoreFollowChartData } = require("../Query/followstore");
module.exports = {
  Mutation: { followStore, unFollowStore },
  Query: {
    getAllStoreFollowers,
    getAllStoreFollowChartData
  },
};
