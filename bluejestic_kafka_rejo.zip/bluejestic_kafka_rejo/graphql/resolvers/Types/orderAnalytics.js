const { getOrderAnalyticsForSeller, getOrdersOfSeller } = require("../Query/orderAnalytics");

module.exports = {
    Mutation: {
    },
    Query: {
        getOrderAnalyticsForSeller,
        getOrdersOfSeller       
    }
}