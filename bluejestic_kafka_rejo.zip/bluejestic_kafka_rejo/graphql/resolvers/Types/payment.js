const { withDrawPaymentFromSeller, refundFromSellerToPlatform, addPayment, verifyPayment } = require("../Mutation/payment");
// const { groups, getSingleGroupDetail } = require("../Query/group");

module.exports = {
  Query: {},
  Mutation: {
    withDrawPaymentFromSeller,
    refundFromSellerToPlatform,
    addPayment,
    verifyPayment,
  },
};
