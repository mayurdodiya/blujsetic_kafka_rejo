const {
  addSubCategory,
  deleteSubCategory,
  updateSubCategory,
} = require("../Mutation/subcategory");
const {
  getAllSubCategory,
  getSingleSubCategory,
} = require("../Query/subcategory");
module.exports = {
  Mutation: {
    addSubCategory,
    deleteSubCategory,
    updateSubCategory,
  },
  Query: {
    getAllSubCategory,
    getSingleSubCategory,
  },
};
