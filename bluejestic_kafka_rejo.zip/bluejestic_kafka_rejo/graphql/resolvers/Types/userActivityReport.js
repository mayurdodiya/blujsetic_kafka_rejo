// const { addColor, deleteColor, updateColor } = require("../Mutation/color");
const { getUserActivityReport } = require("../Query/userActivityReport");
module.exports = {
  // Mutation: {},
  Query: {
    getUserActivityReport,
  },
};
