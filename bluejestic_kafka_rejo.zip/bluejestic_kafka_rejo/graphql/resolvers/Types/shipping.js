const { addShipping } = require("../Mutation/Shipping");
const { getAllShipping } = require("../Query/shipping");

module.exports = {
  Query: {
    getAllShipping,
  },
  Mutation: {
    addShipping,
  },
};
