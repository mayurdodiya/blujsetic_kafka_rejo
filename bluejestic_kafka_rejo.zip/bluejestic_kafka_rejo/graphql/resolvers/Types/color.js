const { addColor, deleteColor, updateColor } = require("../Mutation/color");
const { getAllColor, getSingleColor } = require("../Query/color");
module.exports = {
  Mutation: {
    addColor, deleteColor, updateColor 
  },
  Query: {
    getAllColor,
    getSingleColor
  },
};
