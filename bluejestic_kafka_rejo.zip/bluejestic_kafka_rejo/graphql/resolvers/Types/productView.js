const { addProductView } = require("../Mutation/productView");
const {
  getAllProductViews,
  getAllProductViewChartData
} = require("../Query/productView");
module.exports = {
  Mutation: {
    addProductView
  },
  Query: {
    getAllProductViews,
    getAllProductViewChartData
  },
};
