const { addProductBrand } = require("../Mutation/productBrand");
const { getBrandByProductId } = require("../Query/productBrand");

module.exports = {
  Mutation: { addProductBrand },
  Query: { getBrandByProductId },
};
