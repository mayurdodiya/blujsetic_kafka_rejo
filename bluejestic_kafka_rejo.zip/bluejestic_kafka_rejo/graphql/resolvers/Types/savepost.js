const { createSavePost, unSavePost } = require("../Mutation/savepost");
const { getAllSavepost, getSingleSavepost } = require("../Query/savepost");
module.exports = {
  Mutation: {
    createSavePost, unSavePost
  },
  Query: {
    getAllSavepost,
    getSingleSavepost,
  },
};
