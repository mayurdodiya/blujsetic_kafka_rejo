const {  addAbout, deleteAbout, updateAbout } = require("../Mutation/about");
const { getAllAbout, getSingleAbout } = require("../Query/about");
module.exports = {
  Mutation: {
    addAbout, 
    deleteAbout,
    updateAbout
  },
  Query: {
   getAllAbout,
   getSingleAbout
  },
};
