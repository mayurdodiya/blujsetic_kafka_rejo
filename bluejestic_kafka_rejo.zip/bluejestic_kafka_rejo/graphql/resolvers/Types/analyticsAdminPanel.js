const {
  getCustomersAnalytics,
  getDashboardAnalytics,
  getStoresAnalytics,
  getNewStoresApplicationsAnalytics,
  getProductsAnalytics,
  getSalesAnalytics,
  getOrdersAnalytics,
  getCategoriesAnalytics,
  getCategoryDistribution,
  getClubsAnalytics,
  getClubAnalyticsBySlug,
  getAdminDashboardData,
  getUserAnalyticsBySlug,
  getStoresAnalyticsBySlug
} = require("../Query/analyticsAdminPanel");


module.exports = {
  Mutation: {
    },
  Query: {
    getCustomersAnalytics,
    getDashboardAnalytics,
    getStoresAnalytics,
    getNewStoresApplicationsAnalytics,
    getProductsAnalytics,
    getSalesAnalytics,
    getOrdersAnalytics,
    getCategoriesAnalytics,
    getCategoryDistribution,
    getClubsAnalytics,
    getClubAnalyticsBySlug,
    getAdminDashboardData,
    getUserAnalyticsBySlug,
    getStoresAnalyticsBySlug
  },
};
