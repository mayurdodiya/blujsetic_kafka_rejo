const {  addFollowDetail, updateFollowDetail, deleteFollowDetail} = require("../Mutation/follow")
const { getAllFollowDetails, getSingleFollowDetail } = require("../Query/follow")


module.exports = {
    Query:{
    getAllFollowDetails,
    getSingleFollowDetail
    },
    Mutation : {
    addFollowDetail,
    updateFollowDetail,
    deleteFollowDetail
    }
}