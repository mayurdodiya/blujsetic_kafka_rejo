const {
  createSellerPost,
  updateSellerPost,
  deleteSellerPost,
} = require("../Mutation/sellerPost");
const {
  getAllSellerPost,
  getSingleSellerPost,
  getPostByStore,
} = require("../Query/sellerPost");
module.exports = {
  Mutation: {
    createSellerPost,
    updateSellerPost,
    deleteSellerPost,
  },
  Query: {
    getAllSellerPost,
    getSingleSellerPost,
    getPostByStore,
  },
};
