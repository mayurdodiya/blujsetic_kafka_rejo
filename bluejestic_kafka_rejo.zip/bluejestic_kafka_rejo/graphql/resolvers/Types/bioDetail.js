const {addUserBio} = require('../Mutation/biodetail')
const {getAlluserBioDetails, getUserBioDetail} = require('../Query/biodetail')
module.exports = {
  Mutation: {
   addUserBio,
  },
  Query: {
    getAlluserBioDetails,
    getUserBioDetail
    },
};