const { addSize, updateSize, deleteSize } = require("../Mutation/size");
const { getAllSize, getSingleSize } = require("../Query/size");
module.exports = {
  Mutation: {
    addSize, updateSize, deleteSize
  },
  Query: {
    getAllSize,
    getSingleSize
  },
};
