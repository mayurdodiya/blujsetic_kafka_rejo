const { addCardAndBillingAddress, deleteCardAndBillingAddress, updateCardAndBillingAddress } = require("../Mutation/cardandbilllingaddress");
const { getAllCardAndAddress, getSingleCardAndAddress } = require("../Query/cardandaddressdetail");
module.exports = {
  Mutation: {
    addCardAndBillingAddress,
    deleteCardAndBillingAddress,
    updateCardAndBillingAddress,
  },
  Query: {
    getAllCardAndAddress,
    getSingleCardAndAddress,
  },
};
