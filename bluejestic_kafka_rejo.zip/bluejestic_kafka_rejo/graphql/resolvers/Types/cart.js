const { createCart, deleteCart, deleteCartItems, updateCart, insertSelectedCartItems, deleteSelectedCartItems, getSelectedProducts, changeCartItemsStatus } = require("../Mutation/cart");
const { getAllCart, getCartCount, getSingleCart, getSelectedCartItems } = require("../Query/cart");
module.exports = {
  Mutation: {
    createCart,
    deleteCart,
    updateCart,
    deleteCartItems,
    insertSelectedCartItems,
    deleteSelectedCartItems,
    getSelectedProducts,
    changeCartItemsStatus
  },
  Query: {
    getAllCart,
    getCartCount,
    getSingleCart,
    getSelectedCartItems,
  },
};
