const {
  registerSeller,
  addSellerApprovalDetail,
  updateSellerDetail,
  sellerLogin,
  updateSellerDetails,
  updateSeller,
  sellerOnboarding5Details,
  directSelleOnboarding5Detail,
  checkStoreAvailability,
  sellerVerified,
  sellerSignUp,
  sellerApproval,
  updateBankDetails,
  sendOTPForWithdrawal,
  sellerOnboard
} = require("../Mutation/seller");
const { singleSelller, sellerBankOnboardingStatus, sellerConnectAccounts, sellerTransactionHistory, sellerPaymentVerificationPopup, sellerAvailableAmount, getNewStoreApplications, getSingleNewStoreApplication, sellerWithdrawableAmount } = require("../Query/seller");
module.exports = {
  Mutation: {
    registerSeller,
    addSellerApprovalDetail,
    updateSellerDetail,
    sellerLogin,
    updateSellerDetails,
    updateSeller,
    sellerOnboarding5Details,
    directSelleOnboarding5Detail,
    checkStoreAvailability,
    sellerVerified,
    sellerSignUp,
    sellerApproval,
    updateBankDetails,
    sendOTPForWithdrawal,
    sellerOnboard,
  },
  Query: {
    singleSelller,
    sellerBankOnboardingStatus,
    sellerConnectAccounts,
    sellerTransactionHistory,
    sellerPaymentVerificationPopup,
    sellerAvailableAmount,
    getNewStoreApplications,
    getSingleNewStoreApplication,
    sellerWithdrawableAmount
  },
};
