const {
  createGroupPost,
  updateGroupPost,
  deleteGroupPost,
} = require("../Mutation/groupPost");
const { getAllGroupPost } = require("../Query/groupPost");
module.exports = {
  Mutation: {
    createGroupPost,
    updateGroupPost,
    deleteGroupPost,
  },
  Query: {
    getAllGroupPost,
  },
};
