// const { createLiveStream } = require("../Mutation/livestream");
// // const { joinLiveStream } = require("../Mutation/livestream");
// const { quickLiveStream } = require("../Mutation/livestream");
// const { endLiveStream } = require("../Mutation/livestream");

// const { getUpcomingLivestreams } = require("../Query/livestream");

// module.exports = {
//   Mutation: {
//     createLiveStream,
//     // joinLiveStream,
//     quickLiveStream,
//     endLiveStream,
//   },
//   Query: {
//     getUpcomingLivestreams,
//   },
// };
