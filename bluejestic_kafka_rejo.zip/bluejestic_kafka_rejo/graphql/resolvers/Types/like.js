const { createLike, disLike, addStoreLike } = require("../Mutation/like");
const { getAllLikes, getSingleLike, getAllStoreLikesChartData } = require("../Query/like");
module.exports = {
  Query: {
    getAllLikes,
    getSingleLike,
    getAllStoreLikesChartData,
  },
  Mutation: {
    createLike,
    disLike,
    addStoreLike,
  },
};
