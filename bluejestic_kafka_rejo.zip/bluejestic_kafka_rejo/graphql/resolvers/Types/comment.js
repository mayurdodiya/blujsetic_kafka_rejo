const { createComment, createCommentReply } = require("../Mutation/comment");
const { getCommentById, getCommentCount, getAllComments, getAllStoreCommentsChartData } = require("../Query/comment");

module.exports = {
  Query: {
    getCommentById,
    getAllComments,
    getCommentCount,
    getAllStoreCommentsChartData,
  },
  Mutation: {
    createComment,
    createCommentReply,
  },
};
