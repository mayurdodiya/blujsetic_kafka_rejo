const {addRating, deleteRating, updateRating} = require('../Mutation/rating')
const {getAllRating, getSingleRating} = require('../Query/rating')
module.exports = {
  Mutation: {
    addRating,
    updateRating,
    deleteRating
  },
  Query: {
    getAllRating,
    getSingleRating
    },
};