const { createOrderItem } = require("../Mutation/createOrderItem");
// const { createOrderItem } = require("../Query/createOrderItem");
module.exports = {
  Mutation: {
    createOrderItem,
  },
  Query: {},
};
