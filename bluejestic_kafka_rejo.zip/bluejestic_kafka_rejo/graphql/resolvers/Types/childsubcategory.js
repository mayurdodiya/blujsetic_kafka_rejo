const {
  addChildSubCategory,
  deleteChildSubCategory,
  updateChildSubCategory,
} = require("../Mutation/childsubcategory");
const {
  getAllChildSubCategory,
  getSingleChildSubCategory,
} = require("../Query/childsubcategory");
module.exports = {
  Mutation: {
    addChildSubCategory,
    deleteChildSubCategory,
    updateChildSubCategory,
  },
  Query: {
    getAllChildSubCategory,
    getSingleChildSubCategory,
  },
};
