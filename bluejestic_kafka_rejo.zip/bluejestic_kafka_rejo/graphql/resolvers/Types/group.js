const { createGroup, updateGroupDetail, deleteGroupDetail, removeGroupMember, deleteGroupsBySlugsForAdmin } = require("../Mutation/group");
const { groups, groupsRequested, getCacheClub, getClubSlugList, checkMemberStatus, group, groupMedia, searchGroupsWithElasticSearch, getAllClubs, getGroupMember, getSuggestedGroups, getJoinedGroups, getMyGroups, getClubsForAdmin } = require("../Query/group");

module.exports = {
  Query: {
    groups,
    groupsRequested,
    getCacheClub,
    getClubSlugList,
    checkMemberStatus,
    group,
    groupMedia,
    searchGroupsWithElasticSearch,
    getAllClubs,
    getGroupMember,
    getSuggestedGroups,
    getJoinedGroups,
    getMyGroups,
    getClubsForAdmin
  },
  Mutation: {
    createGroup,
    updateGroupDetail,
    deleteGroupDetail,
    removeGroupMember,
    deleteGroupsBySlugsForAdmin
  },
};
