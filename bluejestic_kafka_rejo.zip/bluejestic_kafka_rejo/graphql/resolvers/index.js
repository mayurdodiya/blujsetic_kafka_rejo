const userResolvers = require("./Types/user");
// const postResolvers = require("./post");
const commentResolvers = require("./Types/comment");
const addressType = require("./Types/address");
const bioDetailResolver = require("./Types/bioDetail");
const productResolver = require("./Types/product");
const productBrandResolver = require("./Types/productBrand");
// const liveStreamResolver = require("./Types/livestream");
const colorResolver = require("./Types/color");
const sizeResolver = require("./Types/size");
const storeResolver = require("./Types/store");
const postResolver = require("./Types/post");
const followResolver = require("./Types/follow");
const offerResolver = require("./Types/offer");
const aboutResolver = require("./Types/about");
const cardandbillingaddressResolver = require("./Types/cardandbillingaddress");
const notificationResolver = require("./Types/notification");
const cartResolver = require("./Types/cart");
const ratingResolver = require("./Types/rating");
const bookmarkResolver = require("./Types/bookmark");
const categoryResolver = require("./Types/category");
const groupResolver = require("./Types/group");
const businessInformationResolver = require("./Types/BusinessInformation ");
const legalDetailsResolver = require("./Types/LegalDetails");
const likeResolver = require("./Types/like");
const sellerResolver = require("./Types/seller");
const savepostResolver = require("./Types/savepost");
const sellerPostResolver = require("./Types/sellerPost");
const analyticsResolver = require("./Types/analyticsAdminPanel");
const subCategoryResolver = require("./Types/subcategory");
const childSubCategoryResolver = require("./Types/childsubcategory");
const randomResolver = require("./Types/randomArray");
const friendResolver = require("./Types/friend");
const joinGroupResolver = require("./Types/joingroup");
const inviteGroupResolver = require("./Types/invitegroup");
const groupPostResolver = require("./Types/groupPost");
const followStoreResolver = require("./Types/followstore");
const billingAddressResolver = require("./Types/billingAddress");
const createOrderItem = require("./Types/createOrderItem");
const paymentResolver = require("./Types/payment");
const plaidResolver = require("./Types/plaid");
const orderResolver = require("./Types/order");
const storeActivities = require("./Types/storeActivity");
const userLocationActivity = require("./Types/userLocationActivity");
const userDevicesResolver = require("./Types/userDevices");
const userActivityReport = require("./Types/userActivityReport");
const productViewResolver = require("./Types/productView");
const sellerAnalyticsResolver = require("./Types/sellerAnalytics"); 
const sellerConnectAccountResolver = require("./Types/sellerConnectAccount"); 
const shippingAnalyticsResolver = require("./Types/shippingAnalytics")
const orderAnalyticsResolver = require("./Types/orderAnalytics")
/* Test messages resolver */
module.exports = [
  userResolvers,
  commentResolvers,
  postResolver,
  addressType,
  bioDetailResolver,
  productResolver,
  productBrandResolver,
  // liveStreamResolver,
  colorResolver,
  sizeResolver,
  storeResolver,
  followResolver,
  offerResolver,
  aboutResolver,
  notificationResolver,
  cartResolver,
  ratingResolver,
  bookmarkResolver,
  categoryResolver,
  groupResolver,
  businessInformationResolver,
  legalDetailsResolver,
  likeResolver,
  sellerResolver,
  savepostResolver,
  sellerPostResolver,
  analyticsResolver,
  subCategoryResolver,
  childSubCategoryResolver,
  randomResolver,
  friendResolver,
  joinGroupResolver,
  inviteGroupResolver,
  groupPostResolver,
  followStoreResolver,
  cardandbillingaddressResolver,
  billingAddressResolver,
  createOrderItem,
  paymentResolver,
  plaidResolver,
  orderResolver,
  storeActivities,
  userLocationActivity,
  userActivityReport,
  userDevicesResolver,
  productViewResolver,
  sellerAnalyticsResolver,
  sellerConnectAccountResolver,
  shippingAnalyticsResolver,
  orderAnalyticsResolver
];
