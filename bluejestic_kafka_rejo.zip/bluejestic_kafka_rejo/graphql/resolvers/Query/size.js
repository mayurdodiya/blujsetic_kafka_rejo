const { AuthenticationError } = require("apollo-server-express");

const SizeService = require("../../../database/services/size");
module.exports = {
  getAllSize: async (root, args, { user }) => {
    if (user != null) {
      const allMedia = await SizeService.getAll();
      return allMedia;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getSingleSize: async (_, { id }, { user }) => {
    if (user != null) {
      return SizeService.getById(id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
};
