const { AuthenticationError, UserInputError } = require("apollo-server-express");
const database = require("../../../database/models");
const axios = require("axios");

module.exports = {
  getUpcomingLivestreams: async (root, { store_id }, { user }) => {
    try {
      let find_data = await database.LiveStream.findAll({
        where: {
          store_id: store_id,
          endTime: null,
        },
        attributes: ["meeting_id", "title", "status", "date", "time", "final_date", "uuid", "media_id"],
      });
      let livestream = JSON.parse(JSON.stringify(find_data));
      if (livestream?.length > 0) {
        for (const iterator of livestream) {
          let find_livestream_media = await database.Media.findOne({
            where: {
              id: iterator.media_id,
            },
          });

          iterator.media = find_livestream_media?.media;
        }
      }
      return { success: true, message: "Live Stream Created Successfully", data: livestream };
    } catch (error) {
      console.log("error", error);
    }
  },
};
