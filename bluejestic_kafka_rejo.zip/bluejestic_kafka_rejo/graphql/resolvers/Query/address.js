const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { AuthenticationError } = require("apollo-server-express");

const AddressService = require("../../../database/services/address");
const { User } = require("../../../database/models");

module.exports = {
  //   address: async (root, args, { user }) => {
  //     let address = await AddressService.add({});
  //     return address;
  //   },
};
