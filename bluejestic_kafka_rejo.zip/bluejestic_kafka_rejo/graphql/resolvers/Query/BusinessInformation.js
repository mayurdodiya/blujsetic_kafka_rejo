const { AuthenticationError } = require("apollo-server-express");

const BusinessInformationService = require("../../../database/services/BusinessInformation");
const { stringToUrl } = require("../../../middlewares/utils");
const elasticClient = require("../../../services/elasticsearch");
module.exports = {
  getAllBusinessInformation: async (root, args, { user }) => {
    if (user != null) {
      const allBusinessInformationDetail = await BusinessInformationService.getAll();
      return allBusinessInformationDetail;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
  getSingleBusinessInformation: async (_, { id }, { user }) => {
    if (user != null) {
      return BusinessInformationService.getById(id);
    } else {
      return new AuthenticationError("Please Provide the Token");
    }
  },
  getStoreDetail: async (_, { id }, { user }) => {
    if (user != null) {
      let bi_data = await BusinessInformationService.getById(id);
      bi_data.logo = await stringToUrl(bi_data.logo, bi_data.id);
      bi_data.cover_image = await stringToUrl(bi_data.cover_image, bi_data.id);
      return bi_data;
    } else {
      return new AuthenticationError("Please Provide the Token");
    }
  },
  searchStoressWithElasticSearch: async (root, args, { user }) => {
    console.log("searchStoressWithElasticSearch-callled +++++++++++++++++++++++++++++++++++");

    // if (!user) return new AuthenticationError("Please Provide the token");
    let { search, page, limit, category, subCategory, isCategoryFilter = false } = args;
    let stores = await elasticClient.store.searchStoressWithElasticSearch("stores", { search, page, limit, user_id: user?.id, isCategoryFilter, category, subCategory });
    // console.log("stores", stores);
    if (stores && stores.success === false) {
      return { success: false, message: stores.message, data: [] };
    }
    return { success: true, message: "Data successfully", data: stores.data };
  },
};
