const { AuthenticationError } = require("apollo-server-express");

const OfferService = require("../../../database/services/offer");

module.exports = {
  getAllOffers: async (root, args, { user }) => {
    if (user != null) {
      const Offe = await OfferService.getAll();
      return Offe;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getSingleOffer: async (_, { id }, { user }) => {
    if (user != null) {
      return OfferService.getById(id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
};
