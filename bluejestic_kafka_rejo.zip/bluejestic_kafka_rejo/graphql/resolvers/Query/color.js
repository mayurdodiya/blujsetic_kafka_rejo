
const { AuthenticationError } = require("apollo-server-express");

const ColorService = require("../../../database/services/color");
module.exports = {
   getAllColor:async(root, args, {user})=> {
    if(user != null){
    const allMedia = await ColorService.getAll();
    return allMedia;
    }else{
        return new AuthenticationError('Please Provide the token')
    }
  },
  getSingleColor :async (_, { id }, {user}) =>  {
    if(user != null){
        return ColorService.getById(id)
    }else{
        return new AuthenticationError('Please Provide the token')
    }
},
};