const { AuthenticationError } = require("apollo-server-express");
const stripe = require("stripe")(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2023-08-16",
});
const database = require("../../../database/models");

module.exports = {
    capabilitiesActiveLink: async (root, { input }, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        try {
            const { email } = user;
            const { stripeAccountId } = input;

            let find_seller = await database.Seller.findOne({
                where: { email },
            });
            const seller = JSON.parse(JSON.stringify(find_seller));
            if (!seller) {
                return {
                    success: false,
                    message: "Seller not found!"
                }
            }

            if (!stripeAccountId) {
                return {
                    status: false,
                    message: "stripeAccountId is required!"
                }
            }

            const capablitiesActiveLink = await stripe.accounts.createLoginLink(stripeAccountId);

            if (capablitiesActiveLink && capablitiesActiveLink.url) {
                return {
                    status: true,
                    message: "Capabilities activation link successfully.",
                    url: capablitiesActiveLink?.url,
                }
            }
        } catch (error) {
            console.error("An error occured while generating capabilities activation link: ", error);
            return {
                success: false,
                message: error?.message
              }
        }
    },

    getTransactionHistoryOfSeller: async (root, { input }, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        try {
            let { email } = user;
            let find_seller = await database.Seller.findOne({
                where: { email },
            });
            const seller = JSON.parse(JSON.stringify(find_seller));
            if (!seller) {
                return {
                    success: false,
                    message: "Seller not found!"
                }
            }

            const transactionHistories = await database.SellerPayoutHistory.findAll({
                where: {
                    seller_id: seller?.id
                },
                include: [
                    {
                        model: database.Seller,
                        as: "sellerInfo"
                    }
                ],
                order: [["createdAt", "DESC"]],
                ...(input?.limit && {
                    limit: Number(input?.limit),
                }),
                ...(input?.page && input?.limit && {
                    offset: (Number(input?.page) - 1) * Number(input?.limit)
                })
            });


            return {
                success: true,
                message: "Transaction histories fetched successfully.",
                data: JSON.parse(JSON.stringify(transactionHistories))
            }

        } catch (error) {
            console.error("An error occured while fetching transaction histories!", error);
            throw new Error("An error occured while fetching transaction histories!");
        }
    },

    getTransactionHistoryOfSellerForAdmin: async (root, { input }, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        if (user.role !== "admin") return new AuthenticationError("Unauthorized");
        try {

            const transactionHistories = await database.SellerPayoutHistory.findAll({
                include: [
                    {
                        model: database.Seller,
                        as: "sellerInfo"
                    }
                ],
                order: [["createdAt", "DESC"]],
                ...(input?.limit && {
                    limit: Number(input?.limit),
                }),
                ...(input?.page && input?.limit && {
                    offset: (Number(input?.page) - 1) * Number(input?.limit)
                })
            });


            return {
                success: true,
                message: "Transaction histories for admin fetched successfully.",
                data: JSON.parse(JSON.stringify(transactionHistories))
            }

        } catch (error) {
            console.error("An error occured while fetching transaction histories for admin!", error);
            throw new Error("An error occured while fetching transaction histries for admin!");
        }
    },
    
    getSellerConnectAccountDetails: async (root, { input }, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        try {
            const { email } = user;

            const find_seller = await database.Seller.findOne({
                where: {
                    email,
                },
            });

            const seller = JSON.parse(JSON.stringify(find_seller));

            if (!seller) {
                return {
                    success: false,
                    message: "Seller not found!"
                }
            }
              
            const sellerConnectedAccount = await database.SellerConnectedAccount.findOne({
                where: {
                    seller_id: seller?.id,
                },
                include: [
                    {
                        model: database.SellerConnectedAccountCapability,
                        as: "seller_connected_account_capabilities",
                    },
                    {
                        model: database.SellerBankAccounts,
                        as: "seller_bank_accounts_info",
                    },
                ]
            });

            const sellerConnectedAccountPlain = JSON.parse(JSON.stringify(sellerConnectedAccount));
            console.log("🚀 ~ file: sellerConnectAccount.js:283 ~ sellerConnectedAccountPlain:", sellerConnectedAccountPlain)

            return {
                success: true,
                message: "Seller connect account details fetched successfully.",
                data: sellerConnectedAccountPlain
            }

        } catch (error) {
            console.error("An error occcured while fetching seller connect account details: ", error);
            throw new Error("An error occcured while fetching seller connect account details");
        }
    },
};
