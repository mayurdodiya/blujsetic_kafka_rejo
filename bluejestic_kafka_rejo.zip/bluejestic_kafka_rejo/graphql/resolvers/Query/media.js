const { AuthenticationError } = require("apollo-server-express");

const UserService = require("../../../database/services/user");
const { Media } = require("../../../database/models");
const user = require("./user");
module.exports = {
  getAllMedia: async (root, args, { user }) => {
    if (user != null) {
      const allMedia = await Media.findAll();
      return allMedia;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getSingleMedia: async (_, { id }, { user }) => {
    if (user != null) {
      return Media.findByPk(id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
};
