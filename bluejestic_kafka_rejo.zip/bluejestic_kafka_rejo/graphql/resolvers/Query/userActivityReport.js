const { Op } = require("sequelize");
const database = require("../../../database/models");
const moment = require("moment");
const elasticClient = require("../../../services/elasticsearch");
const { AuthenticationError } = require("apollo-server-express");

module.exports = {
  getUserActivityReport: async (root, args, { user }) => {
    try {
      let { start_date, end_date, time_interval } = args;
      if (!user && user?.token_type !== "user") {
        return new AuthenticationError("Please Provide the token");
      }
      let data = await elasticClient.order.getDatewiseUserActivityReport(start_date, end_date, time_interval, user?.id);
      return { success: true, message: "Data successfully", data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  getUserActivitsyReport: async (root, args, { user }) => {
    if (user != null) {
      const get_post_count = await database.Post.count({ where: { user_id: user?.id } });
      const get_like_count = await database.Like.count({ where: { user_id: user?.id } });

      const currentDate = moment();

      const currentMonthStartDate = currentDate.clone().startOf("month");
      const currentMonthEndDate = currentDate.clone().endOf("month");
      const lastMonthStartDate = currentDate.clone().subtract(1, "months").startOf("month");
      const lastMonthEndDate = currentDate.clone().subtract(1, "months").endOf("month");
      const currentMonthCountPromise = await database.Post.count({ where: { createdAt: { [Op.between]: [currentMonthStartDate.toDate(), currentMonthEndDate.toDate()] } } });
      const lastMonthCountPromise = await database.Post.count({ where: { createdAt: { [Op.between]: [lastMonthStartDate.toDate(), lastMonthEndDate.toDate()] } } });

      const currentMonthLikeCountPromise = await database.Like.count({ where: { createdAt: { [Op.between]: [currentMonthStartDate.toDate(), currentMonthEndDate.toDate()] } } });
      const lastMonthLikeCountPromise = await database.Like.count({ where: { createdAt: { [Op.between]: [lastMonthStartDate.toDate(), lastMonthEndDate.toDate()] } } });

      let percentageChange = 0;
      if (lastMonthLikeCountPromise !== 0) {
        percentageChange = ((currentMonthLikeCountPromise - lastMonthLikeCountPromise) / lastMonthLikeCountPromise) * 100;
      }

      const countDifference = await (currentMonthCountPromise - lastMonthCountPromise);
      return { success: true, message: "fetched all user location activities", data: { post_count: get_post_count, like_count: get_like_count, post_diff: countDifference, like_diff: percentageChange } };
    } else {
      return { success: false, message: "Please Provide Token" };
    }
  },
};

// const { Op } = require("sequelize");
// const database = require("../../../database/models");
// const moment = require("moment");

// module.exports = {
//   getUserActivityReport: async (root, args, { user }) => {
//     if (user != null) {
//       const get_post_count = await database.Post.count({ where: { user_id: user?.id } });
//       const get_like_count = await database.Like.count({ where: { user_id: user?.id } });

//       const startDate = moment().startOf("month").toDate();
//       const endDate = moment().endOf("month").toDate();

//       const post_diff = await database.Post.count({ where: { createdAt: { [Op.between]: [startDate, endDate] } } });

//       console.log("post_diff+++++++++++++++++++++++++++++++++++", JSON.parse(JSON.stringify(post_diff)));

//       return { success: true, message: "fetched all user location activities", data: { post_count: get_post_count, like_count: get_like_count, post_diff: post_diff } };
//     } else {
//       return { success: false, message: "Please Provide Token" };
//     }
//   },
// };
