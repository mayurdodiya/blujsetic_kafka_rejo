const { AuthenticationError } = require("apollo-server-express");
const { Op } = require("sequelize");
const database = require("../../../database/models");
const FollowStoreService = require("../../../database/services/followstore");
const FriendService = require("../../../database/services/friend");
const elasticClient = require("../../../services/elasticsearch");
module.exports = {
  getAllStoreFollowers: async (root, { id }, { user }) => {
    if (user != null) {
      let followerList = [];
      let followers = await FollowStoreService.getAll(id);
      followers = JSON.parse(JSON.stringify(followers));
      for await (const res of followers) {
        const friend = await database.Friend.findAll({
          where: {
            user_id: Number(user.id),
            friend_id: Number(res.user_id),
          },
          raw: true,
        });
        res.user.isFriendForFriendStatus = friend.length > 0 ? friend[0].isFriend : false;
        res.user.isActiveForFriendStatus = friend.length > 0 ? friend[0].isActive : false;
      }

      if (followers) {
        for (const follower of followers) {
          //  user followers count
          let userFollowers = await FriendService.getMyFollowing(follower.user.id);

          let user = follower.user ? follower.user : [];
          user.follower_count = userFollowers.length;
          user.profileUrl = user.profileAvtar
            ? await database.Media.findOne({
                where: { id: Number(user.profileAvtar[0]) },
              }).then((res) => res.media)
            : "";
          followerList.push(user);
        }
      }
      return followerList;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
  getAllStoreFollowChartData: async (root, args, { user }) => {
    try {
      let { start_date, end_date, time_interval, time_zone } = args;
      if (!user || !user?.store_id  ) {
        return new AuthenticationError("Please Provide the token");
      }
      let data = await elasticClient.storeFollowers.getAllStoreFollowChartData({ store_id: user?.store_id, start_date, end_date, time_interval, time_zone });
      console.log("data", data);
      return { success: true, message: "Data successfully", data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },
};
