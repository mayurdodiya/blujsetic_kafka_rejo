const { AuthenticationError } = require("apollo-server-express");

const NotificationService = require("../../../database/services/notification");
module.exports = {
  getAllNotification: async (root, args, { user }) => {
    if (user != null) {
      const allNotification = await NotificationService.getAll();
      return allNotification;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getSingleNotification: async (_, { id }, { user }) => {
    if (user != null) {
      return NotificationService.getById(id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
};
