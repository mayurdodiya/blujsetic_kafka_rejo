const { AuthenticationError } = require("apollo-server-express");

const PostService = require("../../../database/services/post");
const database = require("../../../database/models");
const { Op, where } = require("sequelize");
const FriendService = require("../../../database/services/friend");
const FollowStoreService = require("../../../database/services/followstore");
const { sharePostsForFeed } = require("../../../utils/utils");

module.exports = {
  getAllPost: async (root, { group_id, myPost, user_id, page, limit }, { user }) => {
    try {
      console.log("getAllPost-callled +++++++++++++++++++++++++++++++++++");
      if (limit && page) {
        var offset = (parseInt(page) - 1) * limit;
        limit = parseInt(limit);
      }
      let userId = user?.id;
      let allPost = [];
      let sharePosts = [];
      let result = [];
      let sameGroupIds = [];
      let friendIds = [];
      let storeIds = [];
      let postWhere = {};

      if (!user) {
        if (user_id && page >= 2) {
          return {
            success: false,
            message: "Post fetched successfully",
            data: [],
            currentPage: page,
            totalPost: 100,
          };
        } else if (page >= 4) {
          return {
            success: false,
            message: "Post fetched successfully",
            data: [],
            currentPage: page,
            totalPost: 100,
          };
        }
      }

      //! Get All Posts/ feed API starts now

      if (group_id) {
        //* find All posts using group id
        postWhere = {
          [Op.or]: [{ [Op.and]: [{ group_id: { [Op.eq]: group_id } }, { group_id: { [Op.ne]: null } }] }],
        };
        let post = await database.Post.findAll({
          where: postWhere,
          limit: limit,
          offset: offset,
          order: [
            [{ model: database.Comment, as: "comments" }, "createdAt", "ASC"],
            [{ model: database.Like, as: "likes" }, "createdAt", "ASC"],
            [{ model: database.SharePost, as: "sharePosts" }, { model: database.Product, as: "products" }, { model: database.ProductMedia, as: "images" }, "position", "ASC"],
            [
              { model: database.SharePost, as: "sharePosts" },
              { model: database.BookmarkCollection, as: "collection" },
              { model: database.Bookmark, as: "bookmark_product" },
              { model: database.Product, as: "bookmark" },
              { model: database.ProductMedia, as: "images" },
              "position",
              "ASC",
            ],
            ["createdAt", "DESC"],
          ],
          include: [
            {
              model: database.SavePost,
              as: "savedPost",
              required: false,
              ...(userId && {
                user_id: userId,
              }),
            },
            {
              model: database.SharePost,
              as: "sharePosts",
              include: [
                {
                  model: database.Product,
                  as: "products",
                  include: [
                    {
                      model: database.BusinessInformation,
                      as: "store",
                      attributes: ["id", "logo_image", "banner_image", "name", "product_count", "slug"],
                    },
                    {
                      model: database.Like,
                      as: "likes",
                      attributes: ["id"],
                    },
                    {
                      model: database.ProductMedia,
                      as: "images",
                      attributes: ["id", "src", "media_id", "position"],
                    },
                    {
                      model: database.Bookmark,
                      as: "bookmark",
                      attributes: ["id", "product_id", "collection_id"],
                      include: [
                        {
                          model: database.BookmarkCollection,
                          as: "collection",
                          attributes: ["id", "name", "user_id", "isPrivate", "slug"],
                        },
                      ],
                    },
                    {
                      model: database.Comment,
                      as: "comments",
                    },
                    {
                      model: database.Like,
                      as: "productLikes",
                      include: [
                        {
                          model: database.User,
                          as: "user",
                        },
                      ],
                    },
                  ],
                },
                {
                  model: database.BookmarkCollection,
                  as: "collection",
                  attributes: ["id", "name", "user_id", "slug", "isPrivate"],
                  include: [
                    {
                      model: database.User,
                      as: "user",
                      attributes: ["userName"],
                    },
                    {
                      model: database.Bookmark,
                      as: "bookmark_product",
                      attributes: ["product_id", "collection_id"],
                      include: [
                        {
                          model: database.Product,
                          as: "bookmark",
                          attributes: ["id", "title", "dis_price", "dis_listPrice"],
                          include: [
                            {
                              model: database.ProductMedia,
                              as: "images",
                              attributes: ["id", "src", "media_id", "position"],
                              // order: [
                              //   [
                              //     {
                              //       model: database.ProductMedia,
                              //       as: "images",
                              //     },
                              //     "position",
                              //     "ASC",
                              //   ],
                              // ],
                            },
                          ],
                        },
                      ],
                    },
                    {
                      model: database.BookmarkCollectionLikes,
                      as: "likes",
                      attributes: ["user_id"],
                      include: [
                        {
                          model: database.User,
                          as: "like_user",
                          attributes: ["id", "firstName", "lastName", "profileAvtar"],
                        },
                      ],
                    },
                  ],
                },
                {
                  model: database.Like,
                  as: "likes",
                  include: [
                    {
                      model: database.User,
                      as: "user",
                      attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "userName"],
                    },
                  ],
                },
                {
                  model: database.Comment,
                  as: "comments",
                  include: [
                    {
                      model: database.User,
                      as: "user",
                      attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "userName"],
                    },
                    {
                      model: database.CommentReply,
                      as: "commentReply",
                      // attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "userName"],
                      include: [
                        {
                          model: database.User,
                          as: "user",
                          attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "userName"],
                        },
                        {
                          model: database.Like,
                          as: "commentReplyLike",
                          include: [
                            {
                              model: database.User,
                              as: "user",
                              attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "userName"],
                            },
                          ],
                        },
                      ],
                    },
                    {
                      model: database.Like,
                      as: "likes",
                      include: [
                        {
                          model: database.User,
                          as: "user",
                          attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "userName"],
                        },
                      ],
                    },
                  ],
                },
                {
                  model: database.User,
                  as: "user",
                  attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "userName"],
                },
              ],
            },
            {
              model: database.Comment,
              as: "comments",
            },
            {
              model: database.Like,
              as: "likes",
              include: [
                {
                  model: database.User,
                  as: "user",
                  attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "userName"],
                },
              ],
            },
            {
              model: database.Group,
              as: "group",
              include: [
                {
                  model: database.User,
                  as: "user",
                  attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "userName"],
                },
              ],
            },
          ],
        });
        allPost.push(...post);
      } else {
        if (userId) {
          //* collect friends ids for get friends
          const friends = await database.Friend.findAll({
            where: {
              user_id: user.id,
              isFriend: true,
            },
          });
          friends.forEach((friend) => {
            friendIds.push(friend.dataValues.friend_id);
          });

          //* collect group ids for get groups follows
          const sameGroup = await database.JoinGroup.findAll({
            where: {
              user_id: user.id,
            },
          });
          sameGroup.forEach((group) => {
            sameGroupIds.push(group.dataValues.group_id);
          });

          //* collect store ids for get store follows
          const store = await database.FollowStore.findAll({
            where: userId ? { user_id: userId } : {},
          });
          storeIds = store.map((store) => store.dataValues.store_id);
        }

        //* get users posts by id
        if (user_id) {
          postWhere = {
            user_id: user_id,
            post_for: { [Op.in]: ["USER", "SHAREPOST"] },
          };
          let post = await database.Post.findAll({
            //* deep order sorting
            limit: limit,
            offset: offset,
            order: [
              [{ model: database.Comment, as: "comments" }, "createdAt", "ASC"],
              [{ model: database.Like, as: "likes" }, "createdAt", "ASC"],
              [{ model: database.SharePost, as: "sharePosts" }, { model: database.Product, as: "products" }, { model: database.ProductMedia, as: "images" }, "position", "ASC"],
              [
                { model: database.SharePost, as: "sharePosts" },
                { model: database.BookmarkCollection, as: "collection" },
                { model: database.Bookmark, as: "bookmark_product" },
                { model: database.Product, as: "bookmark" },
                { model: database.ProductMedia, as: "images" },
                "position",
                "ASC",
              ],
              ["createdAt", "DESC"],
            ],
            where: postWhere,
            include: [
              {
                model: database.SavePost,
                as: "savedPost",
                required: false,
                attributes: ["id"],
                where: {
                  user_id: user_id,
                },
              },
              {
                model: database.SharePost,
                as: "sharePosts",
                include: [
                  {
                    model: database.Product,
                    as: "products",
                    include: [
                      {
                        model: database.BusinessInformation,
                        as: "store",
                      },
                      {
                        model: database.ProductMedia,
                        as: "images",
                        attributes: ["id", "src", "media_id", "position"],
                      },
                      {
                        model: database.Like,
                        as: "likes",
                        attributes: ["id"],
                      },
                      {
                        model: database.Bookmark,
                        as: "bookmark",
                        include: [
                          {
                            model: database.BookmarkCollection,
                            as: "collection",
                            attributes: ["id", "name", "user_id", "isPrivate", "slug"],
                          },
                        ],
                      },
                      {
                        model: database.Comment,
                        as: "comments",
                      },
                      {
                        model: database.Like,
                        as: "productLikes",
                        include: [
                          {
                            model: database.User,
                            as: "user",
                          },
                        ],
                      },
                    ],
                  },
                  {
                    model: database.BookmarkCollection,
                    as: "collection",
                    attributes: ["id", "name", "user_id", "slug", "isPrivate"],
                    include: [
                      {
                        model: database.User,
                        as: "user",
                        attributes: ["userName"],
                      },
                      {
                        model: database.Bookmark,
                        as: "bookmark_product",
                        attributes: ["product_id", "collection_id"],
                        include: [
                          {
                            model: database.Product,
                            as: "bookmark",
                            attributes: ["id", "title", "dis_price", "dis_listPrice", "slug"],
                            include: [
                              {
                                model: database.ProductMedia,
                                as: "images",
                                attributes: ["id", "src", "media_id", "position"],
                              },
                            ],
                          },
                        ],
                      },
                      {
                        model: database.BookmarkCollectionLikes,
                        as: "likes",
                        attributes: ["user_id"],
                        include: [
                          {
                            model: database.User,
                            as: "like_user",
                            attributes: ["id", "firstName", "lastName", "profileAvtar"],
                          },
                        ],
                      },
                    ],
                  },
                  {
                    model: database.Like,
                    as: "likes",
                    attributes: ["id"],
                  },
                  {
                    model: database.User,
                    as: "user",
                  },
                ],
              },
              {
                model: database.Comment,
                as: "comments",
              },
              {
                model: database.Like,
                as: "likes",
                include: [
                  {
                    model: database.User,
                    as: "user",
                  },
                ],
              },
              {
                model: database.Group,
                as: "group",
              },
            ],
            nest: true,
          });
          allPost.push(...post);
        } else {
          //* Get MAIN feed
          console.log("dasdasdasdasdasd", [userId, ...friendIds]);

          postWhere = {
            [Op.or]: [
              userId ? { user_id: userId, post_for: "USER" } : { post_for: "USER" },
              {
                post_for: "USER",
                user_id: {
                  [Op.in]: friendIds,
                },
              },
              {
                post_for: "GROUP",
                group_id: {
                  [Op.in]: sameGroupIds,
                },
              },
              {
                post_for: "SELLER",
                store_id: {
                  [Op.in]: storeIds,
                },
              },
              //* share post where clause
              // user_id
              //   ? {
              //       user_id: user_id,
              //       post_for: "SHAREPOST",
              //       // user_id: {
              //       //   [Op.in]: friendIds,
              //       // },
              //     }
              //   : {
              //       post_for: "SHAREPOST",
              //       // user_id: {
              //       //   [Op.in]: [userId, ...friendIds],
              //       // },
              //     },
              user_id
                ? {
                    user_id: user_id,
                    post_for: "SHAREPOST",
                    // user_id: {
                    //   [Op.in]: friendIds,
                    // },
                  }
                : userId
                ? {
                    post_for: "SHAREPOST",
                    collection_control: {
                      [Op.not]: ["private"],
                    },
                    user_id: {
                      [Op.in]: [userId, ...friendIds],
                    },
                  }
                : {
                    post_for: "SHAREPOST",
                    collection_control: {
                      [Op.not]: ["private", "public"],
                    },
                    // user_id: {
                    //   [Op.in]: [userId, ...friendIds],
                    // },
                  },
              user_id
                ? {}
                : userId
                ? {
                    post_for: "SHAREPOST",
                    collection_control: "private",
                    user_id: {
                      [Op.in]: [userId, ...friendIds],
                    },
                  }
                : {},
            ],
          };

          //*  get feed posts
          let post = await database.Post.findAll({
            order: [
              [{ model: database.Comment, as: "comments" }, "createdAt", "ASC"],
              [{ model: database.Like, as: "likes" }, "createdAt", "ASC"],
              [{ model: database.SharePost, as: "sharePosts" }, { model: database.Product, as: "products" }, { model: database.ProductMedia, as: "images" }, "position", "ASC"],
              [
                { model: database.SharePost, as: "sharePosts" },
                { model: database.BookmarkCollection, as: "collection" },
                { model: database.Bookmark, as: "bookmark_product" },
                { model: database.Product, as: "bookmark" },
                { model: database.ProductMedia, as: "images" },
                "position",
                "ASC",
              ],
              ["createdAt", "DESC"],
            ],
            where: postWhere,
            //* Pagination
            limit: limit,
            offset: offset,
            include: [
              //* where cluase for share posts */
              {
                model: database.SavePost,
                as: "savedPost",
                required: false,
                ...(userId && {
                  user_id: userId,
                }),
              },
              {
                model: database.SharePost,
                as: "sharePosts",
                include: [
                  {
                    model: database.Product,
                    as: "products",
                    include: [
                      {
                        model: database.BusinessInformation,
                        as: "store",
                      },
                      {
                        model: database.ProductMedia,
                        as: "images",
                        attributes: ["id", "src", "media_id", "position"],
                      },
                      {
                        model: database.Like,
                        as: "likes",
                        attributes: ["id"],
                      },
                      {
                        model: database.Bookmark,
                        as: "bookmark",
                        include: [
                          {
                            model: database.BookmarkCollection,
                            as: "collection",
                            attributes: ["id", "name", "user_id", "isPrivate", "slug"],
                          },
                        ],
                      },
                      {
                        model: database.Comment,
                        as: "comments",
                      },
                      {
                        model: database.Like,
                        as: "productLikes",
                        include: [
                          {
                            model: database.User,
                            as: "user",
                          },
                        ],
                      },
                    ],
                  },
                  {
                    model: database.BookmarkCollection,
                    as: "collection",
                    attributes: ["id", "name", "user_id", "slug", "isPrivate"],
                    include: [
                      {
                        model: database.User,
                        as: "user",
                        attributes: ["userName"],
                      },
                      {
                        model: database.Bookmark,
                        as: "bookmark_product",
                        attributes: ["product_id", "collection_id"],
                        include: [
                          {
                            model: database.Product,
                            as: "bookmark",
                            attributes: ["id", "title", "dis_price", "dis_listPrice", "slug"],
                            include: [
                              {
                                model: database.ProductMedia,
                                as: "images",
                                attributes: ["id", "src", "media_id", "position"],
                              },
                            ],
                          },
                        ],
                      },
                      {
                        model: database.BookmarkCollectionLikes,
                        as: "likes",
                        attributes: ["user_id"],
                        include: [
                          {
                            model: database.User,
                            as: "like_user",
                            attributes: ["id", "firstName", "lastName", "profileAvtar"],
                          },
                        ],
                      },
                    ],
                  },
                  {
                    model: database.Like,
                    as: "likes",
                    attributes: ["id"],
                  },
                  {
                    model: database.User,
                    as: "user",
                  },
                ],
              },
              {
                model: database.Comment,
                as: "comments",
              },
              {
                model: database.Like,
                as: "likes",
                include: [
                  {
                    model: database.User,
                    as: "user",
                  },
                ],
              },
              {
                model: database.Group,
                as: "group",
              },
            ],
            nest: true,
          });
          allPost.push(...post);
        }
      }
      console.log("allPost++++++++++++", allPost[1]?.sharePosts);

      //* This loops helps to add new fields and some oprations
      for (let i = 0; i < allPost?.length; i++) {
        let post = allPost[i];
        post = await sharePostsForFeed(post);
        let postUser;
        let mediaIds = [];
        if (!post?.dataValues) {
          mediaIds = post?.media_id ? post?.media_id : [];
        } else {
          mediaIds = post.dataValues.media_id ? post.dataValues.media_id : [];
        }
        //* find posts images
        const medias = await database.Media.findAll({
          where: {
            id: {
              [Op.in]: mediaIds,
            },
          },
        });

        let mediasData = medias.map((media) => {
          return { ...media?.dataValues, url: media?.dataValues?.media };
        });
        //* get Friend Status
        // let isActiveForFriendStatus, isFriendForFriendStatus;
        // if (userId) {
        //   let friendStatus = await checkStatusesForFriend(userId, post.user_id);
        //   isActiveForFriendStatus = friendStatus.isActiveForFriendStatus;
        //   isFriendForFriendStatus = friendStatus.isFriendForFriendStatus;
        // }
        let Users = null;
        //* Working on post user response
        if (post?.user_id) {
          postUser = await database.User.findOne({ where: { id: post.user_id }, raw: true });
          // profileAvtar = await database.Media.findOne({
          //   where: { id: postUser?.profileAvtar },
          // });
          // profileCoverImage = await database.Media.findOne({
          //   where: { id: postUser?.profileCoverImage },
          // });
          // user Followers
          // var userFollowers = await FriendService.getMyFriends(postUser.id);

          // user Following

          // var userFollowings = await FriendService.getMyFollowing(postUser.id);
          Users = {
            id: post?.user?.id || postUser?.id,
            firstName: post?.user?.firstName || postUser?.firstName,
            lastName: post?.user?.lastName || postUser?.lastName,
            logo_image: postUser?.logo_image,
            banner_image: postUser?.banner_image,
            // profileImage: {
            //   url: profileAvtar ? profileAvtar?.dataValues?.media : profileAvtar,
            //   alternativeText: "",
            // },
            // coverImage: {
            //   url: profileCoverImage ? profileCoverImage?.dataValues?.media : profileCoverImage,
            //   alternativeText: "",
            // },
            userName: post?.user?.userName || postUser?.userName,
            // isActiveForFriendStatus: isActiveForFriendStatus,
            // isFriendForFriendStatus: isFriendForFriendStatus,
            // followers: userFollowers,
            // followings: userFollowings,
          };
        }
        //* Working on post products response
        if (post?.products && post?.products.productComments) {
          post.comments = post.products.productComments;
        }
        if (post?.products && post?.products.productLikes) {
          post.likes = post.products.productLikes;
        }
        if (post?.collection && post?.collection?.mainLike) {
          post.likes = post?.collection.mainLike;
        }
        console.log(`post >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> ${i}`, post?.id);
        post.comment_count = post ? (post?.products ? (post?.products?.comments?.length > 0 ? post?.products?.comments?.length : 0) : post?.comments?.length > 0 ? post?.comments?.length : 0) : 0;

        //* Working on post likes response
        if (Boolean(post.likes.length)) {
          post.like_count = post.likes.length || 0;
          // let n = 3;
          // if (Boolean(post.likes.length)) {
          // for (let i = 0; i < post.likes.length; i++) {
          //   if (i == n - 1) break;
          //   let user = post.likes[i].user;
          //   if (user) {
          //     let user_profileUrl = await database.Media.findOne({
          //       where: { id: Number(user?.profileAvtar[0]) },
          //     });
          //     user.profileUrl = user_profileUrl ? user_profileUrl?.media : "";
          //     let user_profileCoverImageUrl = await database.Media.findOne({
          //       where: { id: Number(user?.profileCoverImage[0]) },
          //     });
          //     user.profileCoverImageUrl = user_profileCoverImageUrl ? user_profileCoverImageUrl?.media : "";
          //   }
          // }
          // }
        }

        //* STORE DETAIL - START */
        if (post?.store_id != null || post?.store_id != undefined) {
          let store = await database.BusinessInformation.findOne({
            where: { id: post?.store_id },
            include: [
              {
                model: database.Product,
                as: "products",
              },
            ],
          });
          // console.log("store?.logo++++++++++++++++++++++", store?.logo);
          // if (store?.logo?.length > 0) {
          //   let logo = await database.Media.findOne({
          //     where: {
          //       id: Number(store.logo[0]),
          //     },
          //     raw: true,
          //   });
          //   if (logo) {
          //     store.logo = [logo?.media];
          //   } else {
          //     store.logo = "";
          //   }
          // }
          // console.log("store?.logo++++++++++++++++++++++", store?.cover_image);
          // if (store?.cover_image?.length > 0 && store?.cover_image[0] !== "") {
          //   let cover_image = await database.Media.findOne({
          //     where: {
          //       id: Number(store.cover_image[0]),
          //     },
          //     raw: true,
          //   });
          //   if (cover_image) {
          //     store.cover_image = [cover_image.media];
          //   } else {
          //     store.cover_image = "";
          //   }
          // }

          // if (Boolean(store?.products?.length)) {
          // for (const product of store.products) {
          //   store.isFollow = false;
          //   if (userId) {
          //     const followStores = await FollowStoreService.getById(store.id, user.id);
          //     store.isFollow = followStores ? true : false;
          //   }
          //   let followStore = await FollowStoreService.getAll(store.id);
          //   for (const item of followStore) {
          //     if (item?.user?.profileUrl != null) {
          //       let profileAvtar = (item.user.profileAvtar = await database.Media.findOne({
          //         where: {
          //           id: item.user.profileAvtar ? item.user.profileAvtar[0] : 0,
          //         },
          //       }).then((res) => res.media));
          //       item.user.profileUrl = profileAvtar ? profileAvtar?.media : "";
          //     } else {
          //       item.user.profileUrl = "";
          //     }

          //     if (item?.user?.profileCoverImage != null) {
          //       let profileCoverImage = await database.Media.findOne({
          //         where: {
          //           id: item.user.profileCoverImage[0],
          //         },
          //       });
          //       item.user.profileCoverImage = profileCoverImage ? profileCoverImage?.media : "";
          //     } else {
          //       item.user.profileCoverImage = "";
          //     }
          //   }

          //   let updated_follow_store = JSON.parse(JSON.stringify(followStore));
          //   if (updated_follow_store?.length > 0) {
          //     for (let item of updated_follow_store) {
          //       if (item?.user?.profileUrl) {
          //         let profileUrl = await database.Media.findOne({
          //           where: {
          //             id: item.user.profileAvtar ? item.user.profileAvtar[0] : 0,
          //           },
          //           raw: true,
          //         });
          //         item.user.profileUrl = profileUrl ? profileUrl?.media : "";
          //       } else {
          //         item.user.profileUrl = "";
          //       }
          //     }
          //     store.followers = updated_follow_store;
          //   }
          // }
          post.store = store;
          // }
        }
        //* GROUP DETAILS  */
        if (post.group_id && post.group_id !== null) {
          let find_group = await database.Group.findOne({
            where: {
              id: post?.group_id,
            },
            raw: true,
          });
          let group_post_data = {
            id: find_group?.id,
            name: find_group?.name,
            slug: find_group?.slug,
          };
          post.group = group_post_data;
        }

        // if (post.group && post.group !== null) {
        //   if (post?.group?.bannerImage) {
        //     let bannerImage = await database.Media.findOne({
        //       where: { id: Number(post.group.bannerImage) },
        //       raw: true,
        //     });
        //     post.group.bannerImage = bannerImage ? bannerImage?.media : "";
        //   } else {
        //     post.group.bannerImage = "";
        //   }

        //   if (post?.group?.coverImage) {
        //     let coverImage = await database.Media.findOne({
        //       where: { id: Number(post.group.coverImage) },
        //       raw: true,
        //     });
        //     post.group.coverImage = coverImage ? coverImage?.media : "";
        //   } else {
        //     post.group.coverImage = "";
        //   }
        // }

        let isBookmark = false;
        let bookmark_id;
        if (post?.products?.id) {
          if (user?.id) {
            let bookmarkData = await database.Bookmark.findOne({
              where: {
                user_id: user.id,
                product_id: post?.products.id,
              },
              raw: true,
            });

            bookmark_id = bookmarkData ? bookmarkData?.id : null;
            isBookmark = bookmarkData ? true : false;
          }
        }

        //*  FINAL RESULT - START
        let resultObject = {
          id: post.id,
          title: "",
          media_type: post?.media_type,
          isShare: post.isShare,
          isBookmarked: isBookmark,
          bookmark_id: bookmark_id,
          content: post.content,
          savedPost: post?.savedPost,
          owner_id: post.owner_id,
          post_for: post.post_for,
          store_id: post.store_id,
          store_name: post.store_name,
          user: Users ? Users : null,
          store: post.store,
          comments: post.comments,
          comment_count: post.comment_count,
          likes: post.likes,
          medias: mediasData,
          createdAt: post.createdAt,
          product: post?.products,
          collection: post?.collection,
          group: post?.group,
        };
        result.push(resultObject);
      }

      //* Arranging the post according to the date wise
      function arrangedPost(arr) {
        let result = arr.sort((a, b) => {
          return new Date(b.createdAt) - new Date(a.createdAt);
        });
        return result;
      }
      result = arrangedPost(result);
      return {
        success: true,
        message: "Post fetched successfully",
        data: result,
        currentPage: page,
        totalPost: await database.Post.count({
          where: postWhere,
        }),
      };
    } catch (err) {
      console.log("erre", err);
      return new Error(err.message);
    }
  },

  getSinglePost: async (_, { post_id }, { user }) => {
    // if (user != null) {

    try {
      let userId = user?.id;
      const post = await PostService.getById(post_id);
      console.log("postpostpostpost", JSON.parse(JSON.stringify(post)));

      // =============================================================================== //

      async function checkStatusesForFriend(userId, friendId) {
        console.log("userId", userId);
        console.log("friendId", friendId);
        let friend;
        if (userId) {
          friend = await database.Friend.findOne({
            where: {
              user_id: userId,
              friend_id: friendId,
            },
          });
        } else {
          friend = await database.Friend.findOne({
            where: {
              friend_id: friendId,
            },
          });
        }

        if (friend) {
          return {
            isActiveForFriendStatus: friend?.isActive || false,
            isFriendForFriendStatus: friend?.isFriend || false,
          };
        } else {
          return {
            isActiveForFriendStatus: false,
            isFriendForFriendStatus: false,
          };
        }
      }
      // for (let i = 0; i < allPost?.length; i++) {
      //   const post = allPost[i];
      // return null
      let postUser;
      let mediaIds = [];

      if (!post.dataValues) {
        mediaIds = post.media_id ? post.media_id : [];
        postUser = user?.id ? await database.User.findOne({ where: { id: user?.id } }) : null;
      } else {
        mediaIds = post.dataValues.media_id ? post.dataValues.media_id : [];
      }
      const medias = await database.Media.findAll({
        where: {
          id: {
            [Op.in]: mediaIds,
          },
        },
      });

      let mediasData = medias.map((media) => {
        return { ...media?.dataValues, url: media?.dataValues?.media };
      });
      let profileAvtar;
      let profileCoverImage;
      if (post.user != undefined) {
        // profileAvtar = post?.user?.profileAvtar
        //   ? await database.Media.findOne({
        //       where: { id: post?.user?.profileAvtar },
        //     })
        //   : "";
        // profileCoverImage = post?.user?.profileCoverImage
        //   ? await database.Media.findOne({
        //       where: { id: post?.user?.profileCoverImage },
        //     })
        //   : null;
        // user Followers
        var userFollowers = await FriendService.getMyFriends(post.user.id);

        // user Following

        var userFollowings = await FriendService.getMyFollowing(post.user.id);
      } else {
        // profileAvtar = postUser?.profileAvtar
        //   ? await database.Media.findOne({
        //       where: { id: postUser.profileAvtar },
        //     })
        //   : null;
        // profileCoverImage = postUser?.profileCoverImage
        //   ? await database.Media.findOne({
        //       where: { id: postUser?.profileCoverImage },
        //     })
        //   : null;
      }
      // console.log("post.user", post);
      // Friend Status
      let { isActiveForFriendStatus, isFriendForFriendStatus } = await checkStatusesForFriend(userId, post.user_id);

      // User Include Object - START
      if (post?.user == undefined) {
        postUser = user?.id ? await database.User.findOne({ where: { id: user?.id }, raw: true }) : null;
      }
      let Users = {
        id: post?.user?.id || postUser?.id,
        username: "",
        firstName: post?.user?.firstName || postUser?.firstName,
        lastName: post?.user?.lastName || postUser?.lastName,
        address: "",
        about: "",
        country: "",
        state: "",
        friends: {
          id: null,
        },
        logo_image: post?.user?.logo_image,
        banner_image: post?.user?.banner_image,
        // profileImage: {
        //   url: profileAvtar ? profileAvtar?.dataValues?.media : profileAvtar,
        //   alternativeText: "",
        // },
        // coverImage: {
        //   url: profileCoverImage ? profileCoverImage?.dataValues?.media : profileCoverImage,
        //   alternativeText: "",
        // },
        isActiveForFriendStatus: isActiveForFriendStatus,
        isFriendForFriendStatus: isFriendForFriendStatus,
        followers: userFollowers,
        followings: userFollowings,
      };
      // console.log("post.comments", post.comments, "\n", "post.likes", post.likes);

      // User Populate for Like - START
      if (post.likes) {
        for (const Like of post.likes) {
          let user = Like.user;

          // comment user follower

          const commentUserFollowers = await FriendService.getMyFriends(user?.id);

          user.followers = commentUserFollowers;
          // comment user following
          const commentUserFollowing = await FriendService.getMyFollowing(user?.id);
          console.log("commentUserFollowing", commentUserFollowing, commentUserFollowers);
          user.followings = commentUserFollowing;
          // User friend status
          let { isActiveForFriendStatus, isFriendForFriendStatus } = await checkStatusesForFriend(userId, user.id);

          user.isActiveForFriendStatus = isActiveForFriendStatus;
          user.isFriendForFriendStatus = isFriendForFriendStatus;

          // if (user) {
          //   user.profileUrl = user?.profileAvtar[0]
          //     ? await database.Media.findOne({
          //         where: { id: Number(user?.profileAvtar[0]) },
          //       }).then((res) => {
          //         return res.media;
          //       })
          //     : null;
          //   user.profileCoverImageUrl = user?.profileCoverImage[0]
          //     ? await database.Media.findOne({
          //         where: { id: Number(user?.profileCoverImage[0]) },
          //       }).then((res) => {
          //         return res.media;
          //       })
          //     : null;
          // }
          // user.profileAvtar = ["123"];
        }
      }

      /* STORE DETAIL - START */
      if (post?.store_id != null || post?.store_id != undefined) {
        let store = await database.BusinessInformation.findOne({
          where: { id: post?.store_id },
          include: [
            {
              model: database.Product,
              as: "products",
            },
          ],
        });
        console.log("store+++++++++++++++++++++++++++", JSON.parse(JSON.stringify(store)));
        // return
        /* STORE DETAIL - START */

        // let logo = await database.Media.findAll({
        //   where: {
        //     id: {
        //       [Op.in]: store.logo,
        //     },
        //   },
        // });
        // store.logo = logo.map((media) => media?.dataValues?.media);
        // // console.log("store.logo", logo);
        // let cover_image = await database.Media.findAll({
        //   where: {
        //     id: {
        //       [Op.in]: store.cover_image,
        //     },
        //   },
        // });
        // store.cover_image = cover_image.map((media) => media?.dataValues?.media);
        // console.log("store.cover_image", cover_image);

        // for (const product of store?.products) {
        //   // Images Ids and createurl link
        //   let images = [];
        //   console.log("product+++++++++++++++++++++++++++++++++++++++++++", product);
        //   // if (product.image !== null) {
        //   //   // convert in array
        //   //   images = await database.Media.findAll({
        //   //     where: {
        //   //       id: {
        //   //         [Op.in]: product.image,
        //   //       },
        //   //     },
        //   //     raw: true,
        //   //   });
        //   //   product.image = images.map((media) => {
        //   //     return media?.dataValues?.media;
        //   //   });
        //   // } else {
        //   //   product.image = [];
        //   // }

        //   // IsStoreFollow or not
        //   const followStores = await FollowStoreService.getById(store.id, user?.id);
        //   store.isFollow = followStores ? true : false;

        //   let followStore = await FollowStoreService.getAll(store.id);
        //   for (const item of followStore) {
        //     console.log(item.user.profileAvtar);
        //     if (item.user.profileAvtar != null) {
        //       console.log(1111111111111111111111111);
        //     } else {
        //       console.log(2222222222222222222222222);
        //     }

        //     item.user.profileUrl != null
        //       ? (item.user.profileAvtar = await database.Media.findOne({
        //           where: {
        //             id: item.user.profileAvtar ? item.user.profileAvtar[0] : 0,
        //           },
        //         }).then((res) => res.media))
        //       : "";
        //     item.user.profileCoverImage != null
        //       ? (item.user.profileCoverImageUrl = await database.Media.findOne({
        //           where: {
        //             id: item.user.profileCoverImage[0],
        //           },
        //         }).then((res) => {
        //           return res.media;
        //         }))
        //       : "";
        //   }

        //   for (let item of JSON.parse(JSON.stringify(followStore))) {
        //     item.user.profileUrl = await database.Media.findOne({
        //       where: {
        //         id: item.user.profileAvtar ? item.user.profileAvtar[0] : 0,
        //       },
        //     }).then((res) => {
        //       console.log("res", res.dataValues);
        //       return res.dataValues.media;
        //     });
        //   }
        //   store.followers = JSON.parse(JSON.stringify(followStore));
        // }
        post.store = store;
        /* STORE DETAIL - END */
      }
      /* STORE DETAIL - END */
      /* GROUP DETAILS  */
      if (post.group && post.group !== null) {
        // banner image of group
        // post.group.bannerImage = await database.Media.findOne({
        //   where: { id: Number(post.group.bannerImage) },
        // }).then((res) => res?.media || "");
        // // cover image of group
        // post.group.coverImage = await database.Media.findOne({
        //   where: { id: Number(post.group.coverImage) },
        // }).then((res) => res?.media || "");

        let { isActiveForFriendStatus, isFriendForFriendStatus } = await checkStatusesForFriend(user?.id, post.group.user.id);

        // set the friend statues
        post.group.user.isActiveForFriendStatus = isActiveForFriendStatus;
        post.group.user.isFriendForFriendStatus = isFriendForFriendStatus;

        // Find Admins
        const groupAdmins = await database.JoinGroup.findAll({
          where: {
            group_id: post.group.id,
            isAdmin: true,
          },
          include: [
            {
              model: database.User,
              as: "members",
            },
          ],
        });

        // Find Group Members
        const groupMembers = await database.JoinGroup.findAll({
          where: {
            group_id: post.group.id,
          },
          include: [
            {
              model: database.User,
              as: "members",
            },
          ],
        });
        console.log("MEMBERS", JSON.parse(JSON.stringify(groupMembers)));

        // Find Exist User
        const groupUser = await database.JoinGroup.findOne({
          where: {
            user_id: user.id,
            group_id: post.group.id,
          },
        });
        // Is exist or not
        post.group.isExist = groupUser ? true : false;

        // get admin list
        let adminPayload = [];

        for (let i = 0; i < groupAdmins?.length; i++) {
          const admin = groupAdmins[i];

          // set the friends status of Admins
          let { isActiveForFriendStatus, isFriendForFriendStatus } = await checkStatusesForFriend(user.id, admin.members.id);

          admin.members.isActiveForFriendStatus = isActiveForFriendStatus;
          admin.members.isFriendForFriendStatus = isFriendForFriendStatus;

          // set the profile image of admin of group
          // admin.members.profileAvtar =
          //   admin?.members?.profileAvtar != null
          //     ? await database.Media.findOne({
          //         where: { id: Number(admin?.members?.profileAvtar[0]) },
          //       }).then((res) => res?.media || "")
          //     : "";

          // set the cover image of admin of group
          // admin.members.profileCoverImage =
          //   admin?.members?.profileCoverImage != null
          //     ? await database.Media.findOne({
          //         where: { id: Number(admin?.members?.profileCoverImage[0]) },
          //       }).then((res) => res?.media || "")
          //     : "";
          const loginUserFriends = (
            await database.Friend.findAll({
              where: {
                user_id: user.id,
                isFriend: true,
              },
              raw: true,
            })
          ).map((friend) => friend.friend_id);
          const memberFriends = (
            await database.Friend.findAll({
              where: {
                user_id: admin.members.id,
                isFriend: true,
              },
              raw: true,
            })
          ).map((friend) => friend.friend_id);
          adminPayload.push(admin.members);
          const mutualFriends = loginUserFriends.filter((friend) => memberFriends.includes(friend));
          admin.members.mutualFriends = mutualFriends;
        }

        post.group.admins = adminPayload;
        // get member list
        let membersPayload = [];

        for (let i = 0; i < groupMembers?.length; i++) {
          const admin = groupMembers[i];

          // set the friends status of Admins
          let { isActiveForFriendStatus, isFriendForFriendStatus } = await checkStatusesForFriend(user.id, admin.members.id);

          admin.members.isActiveForFriendStatus = isActiveForFriendStatus;
          admin.members.isFriendForFriendStatus = isFriendForFriendStatus;

          // set the profile image of members of group
          // admin.members.profileAvtar =
          //   admin?.members?.profileAvtar != null
          //     ? await database.Media.findOne({
          //         where: { id: Number(admin?.members?.profileAvtar[0]) },
          //       }).then((res) => res?.media || "")
          //     : "";

          // set the cover image of members of group
          // admin.members.profileCoverImage =
          //   admin?.members?.profileCoverImage[0] != null
          //     ? await database.Media.findOne({
          //         where: { id: Number(admin?.members?.profileCoverImage[0]) },
          //       }).then((res) => res?.media || "")
          //     : "";
          membersPayload.push(admin.members);
          // mutual friends
          const loginUserFriends = (
            await database.Friend.findAll({
              where: {
                user_id: user.id,
                isFriend: true,
              },
              raw: true,
            })
          ).map((friend) => friend.friend_id);
          const memberFriends = (
            await database.Friend.findAll({
              where: {
                user_id: admin.members.id,
                isFriend: true,
              },
              raw: true,
            })
          ).map((friend) => friend.friend_id);
          const mutualFriends = loginUserFriends.filter((friend) => memberFriends.includes(friend));
          admin.members.mutualFriends = mutualFriends;
        }
        post.group.members = membersPayload;
      }

      // User Include Object - END
      //  FINAL RESULT - START
      let resultObject = {
        id: post.id,
        title: "",
        isShare: post.isShare,
        isBookmarked: post.isBookmarked ? post.isBookmarked : false,
        content: post.content,
        owner_id: post.owner_id,
        post_for: post.post_for,
        store_id: post.store_id,
        store_name: post.store_name,
        user: Users,
        store: post.store,
        comments: post.comments,
        comment_count: post?.comments?.length || 0,
        likes: post.likes,
        medias: mediasData,
        createdAt: post.createdAt,
        product: post?.products,
        group: post?.group,
      };
      return resultObject;
    } catch (error) {
      console.log("errorfhbsudfksldfgbuegbydbugyl", error);
    }

    // =============================================================================== //

    // } else {
    //   return new AuthenticationError("Please Provide the token");
    // }
  },

  getSavedPost: async (_, { page, limit }, { user }) => {
    try {
      if (!user) throw new AuthenticationError("Unauthorized");

      if (limit && page) {
        var offset = (parseInt(page) - 1) * limit;
        limit = parseInt(limit);
      }

      const get_saved_post = await database.SavePost.findAll({
        where: { user_id: user?.id },
        limit: limit,
        offset: offset,
        include: [
          {
            model: database.Post,
            as: "post",
            include: [
              {
                model: database.Comment,
                as: "comments",
              },
              {
                model: database.Like,
                as: "likes",
                attributes: ["id"],
              },
            ],
          },
        ],
      });

      let sorted = JSON.parse(JSON.stringify(get_saved_post));
      const all_post = [];

      for (const post of sorted) {
        let find_post_image = "";
        if (Boolean(post?.post?.media_id?.length)) {
          let n = post?.post?.media_id?.length;
          if (Boolean(post?.post?.media_id?.length)) {
            for (let i = 0; i < n; i++) {
              const product = post?.post?.media_id[i];
              find_post_image = await database.Media.findOne({
                where: {
                  id: product,
                },
              });
            }
          }
        }
        if (post) {
          all_post.push({ title: post?.post?.title, content: post?.post?.content, image: find_post_image.media, likes: post?.post?.likes?.length, comments: post?.post?.comments?.length });
          // all_post.push({ post_id: post?.id, post: { ...post?.post, title: post?.post?.title, content: post?.post?.content, image: find_post_image.media, likes: post?.likes?.length } });
        }
      }

      return { success: true, message: "Saved Product fetch", data: all_post };
    } catch (err) {
      console.log("erre", err);
      return new Error(err.message);
    }
  },
};
