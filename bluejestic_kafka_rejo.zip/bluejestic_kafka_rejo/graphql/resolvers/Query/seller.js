const { AuthenticationError } = require("apollo-server-express");
const database = require("../../../database/models");
const { Op, Sequelize } = require("sequelize");
const sendEmail = require("../../../utils/sendMail");
module.exports = {
  singleSelller: async (root, args, { user }) => {
    const seller = await database.Seller.findOne({
      where: { id: args.id },
      include: [
        {
          model: database.BusinessInformation,
          as: "personalInformation",
        },
      ],
    });
    return seller;
  },

  /* seller bank onboarding status */
  sellerBankOnboardingStatus: async (root, args, { user }) => {
    try {
      if (!user) throw new AuthenticationError("Unauthorized");
      if (user.token_type !== "seller") throw new AuthenticationError("Unauthorized");
      const seller = await database.Seller.findOne({
        where: { id: user.id },
      });
      if (!seller) return { success: false, message: "Seller not found" };
      return {
        success: true,
        message: "Seller bank onboarding status",
        data: {
          isPaymentOnboardingCompleted: seller.isPaymentOnboardingCompleted,
          accountId: seller.stripeAccountId,
          details_submitted: seller.details_submitted,
          isPopup: seller.isPopup,
        },
      };
    } catch (error) {
      console.log(error);
      return { success: false, message: error.message };
    }
  },

  /* seller bank account details */
  sellerConnectAccounts: async (root, args, { user }) => {
    try {
      if (!user) throw new AuthenticationError("Unauthorized");
      if (user.token_type !== "seller") throw new AuthenticationError("Unauthorized");
      const seller = await database.Seller.findOne({
        where: { id: user.id },
      });
      if (!seller) return { success: false, message: "Seller not found" };
      const sellerBankAccounts = await database.SellerBankAccounts.findAll({
        where: { seller_id: user.id },
        order: [["createdAt", "DESC"]],
        raw: true,
      });
      return { success: true, message: "Seller bank onboarding status", data: sellerBankAccounts };
    } catch (error) {
      console.log(error);
      return { success: false, message: error.message };
    }
  },

  /* seller transaction history */
  sellerTransactionHistory: async (root, args, { user }) => {
    try {
      if (!user) throw new AuthenticationError("Unauthorized");
      if (user.token_type !== "seller") throw new AuthenticationError("Unauthorized");
      const seller = await database.Seller.findOne({
        where: { id: user.id },
      });
      if (!seller) return { success: false, message: "Seller not found" };
      const sellerTransactionHistory = await database.SellerTansactionHistory.findAll({
        where: { seller_id: user.id },
        raw: true,
      });
      return { success: true, message: "seller transaction history ", data: sellerTransactionHistory };
    } catch (error) {
      console.log(error);
      return { success: false, message: error.message };
    }
  },

  sellerPaymentVerificationPopup: async (root, args, { user }) => {
    try {
      if (!user) throw new AuthenticationError("Unauthorized");
      if (user.token_type !== "seller") throw new AuthenticationError("Unauthorized");
      const seller = await database.Seller.findOne({
        where: { id: user.id },
      });
      if (!seller) return { success: false, message: "Seller not found" };
      const update = await database.Seller.update(
        { isPopup: args.isPopup }, //update
        { where: { id: user.id } } //find
      );
      return { success: true, message: "seller transaction history " };
    } catch (error) {
      console.log(error);
      return { success: false, message: error.message };
    }
  },

  sellerAvailableAmount: async (root, args, { user }) => {
    try {
      if (!user) throw new AuthenticationError("Unauthorized");
      if (user.token_type !== "seller") throw new AuthenticationError("Unauthorized");
      const seller = await database.Seller.findOne({
        where: { id: user.id },
      });
      if (!seller) return { success: false, message: "Seller not found" };
      /* find upcoming amount */
      const upcoming_amount =
        (
          await database.OrderItems.findAll({
            where: {
              seller_id: user.id,
              order_status: {
                [Op.in]: ["callProcess", "pending", "processing", "approved"],
              },
            },
            attributes: [[Sequelize.fn("sum", Sequelize.col("sellerFinalAmount")), "upcoming_amount"]],
            group: ["sellerFinalAmount"],
            raw: true,
          })
        )[0]?.upcoming_amount || 0;

      /* find total amount */
      const final_amount =
        (
          await database.OrderItems.findAll({
            where: {
              seller_id: user.id,
              order_status: "delivered",
            },
            attributes: [[Sequelize.fn("sum", Sequelize.col("sellerFinalAmount")), "final_amount"]],
            group: ["sellerFinalAmount"],
            raw: true,
          })
        )[0]?.final_amount || 0;
      return {
        success: true,
        message: "Seller available amount",
        data: {
          upcoming_amount: upcoming_amount,
          final_amount: final_amount,
        },
      };
    } catch (error) {
      console.log(error);
      return { success: false, message: error.message };
    }
  },
  
  getNewStoreApplications: async (root, args, { user }) => {
    const {page, limit} = args;
    if (!user) return new AuthenticationError("Please provide token");
    if (user.role !== "admin") return new AuthenticationError("Unautorized");

    try {
      const newStoreApplications = await database.Seller.findAndCountAll({
        include: [
          {
            model: database.SellerPersonalInfo,
            as: "seller_personal_info",
            attributes: ["store_name"],
            include: [
              {
                model: database.Category,
                as: "product_category_details",
                attributes: ["id", "name"],
              }
            ]
          },
          {
            model: database.SellerBusinessDetail,
            as: "seller_business_detail",
            attributes: ["business_email", "business_address"]
          },
          {
            model: database.SellerDocumentsApproval,
            as: "seller_documents_info",
            attributes: ["id", "documentType", "documentName", "document", "documentApprovedStatus"]
          }
        ],
        attributes: ["id", "firstName", "lastName", "email", "sellerApprovedStatusNew", "details5OnboardingCompletedAtNew", "phoneNumber", "createdAt"],
        order: [["createdAt", "DESC"]],
        ...(limit ? { limit: Number(limit) } : {}),
        ...(page && limit ? { offset: (Number(page) - 1) * Number(limit) } : {}),
      });
      return {
        success: true,
        message: "New store applications retrieved successfully.",
        data: JSON.parse(JSON.stringify(newStoreApplications))
      }

    } catch (error) {
      console.error("🚀 ~ getNewStoreApplications: ~ error:", error);
      return {
        success: false,
        message: "An error occurred while retrieving new store applications. Please try again later.",
        data: []
      }
    }

  },

  getSingleNewStoreApplication: async (root, args, { user }) => {
    if (!user) return new AuthenticationError("Please provide token");
    if (user.role !== "admin") return new AuthenticationError("Unautorized");

    const { id } = args;
    try {
      const singleNewStoreApplication = await database.Seller.findOne({
        include: [
          {
            model: database.SellerPersonalInfo,
            as: "seller_personal_info",
            attributes: ["store_name"],
            include: [
              {
                model: database.Category,
                as: "product_category_details",
                attributes: ["id", "name"],
              }
            ]
          },
          {
            model: database.SellerBusinessDetail,
            as: "seller_business_detail",
            attributes: ["business_email", "business_address"]
          },
          {
            model: database.SellerDocumentsApproval,
            as: "seller_documents_info",
             attributes: ["id", "documentType", "documentName", "document", "documentApprovedStatus"]
          }
        ],
        attributes: ["id", "firstName", "lastName", "email", "sellerApprovedStatusNew", "details5OnboardingCompletedAtNew", "phoneNumber"],
        where: {
          ...(id && { id }),
        },
      });

      if (singleNewStoreApplication) {
        return {
          success: true,
          message: "New store application retrieved successfully.",
          data: JSON.parse(JSON.stringify(singleNewStoreApplication))
        }
      }

    } catch (error) {
      console.error("🚀 ~ getSingleNewStoreApplication: ~ error:", error);
      return {
        success: false,
        message: "An error occurred while retrieving new store applications. Please try again later.",
        data: []
      }
    }

  },

  sellerWithdrawableAmount: async (_, { }, { user }) => {
    try {
      if (!user) throw new AuthenticationError("Please provide the token");
      const { email } = user;

      const find_seller = await database.Seller.findOne({
        where: {
          email,
        },
      });

      const seller = JSON.parse(JSON.stringify(find_seller));

      if (!seller) {
        return {
          success: false,
          message: "Seller not found!"
        }
      }

      const withdrawableAmount = await database.OrderItems.findAll({
        attributes: [
          [Sequelize.fn("sum", Sequelize.col("sellerFinalAmount")), "sellerFinalAmount"]
        ],
        where: {
          seller_id: seller?.id,
          order_status: "delivered",
        }
      });

      const sellerFinalAmountFromDB = JSON.parse(JSON.stringify(withdrawableAmount))[0].sellerFinalAmount;

      return {
        success: true,
        message: "Seller withdrawable amount fetched successfully",
        withdrawableAmount: sellerFinalAmountFromDB && typeof sellerFinalAmountFromDB === "number" ? sellerFinalAmountFromDB : 0,
      }
      
    } catch (error) {
      console.error("Error getting seller withdrawable amount: ", error);
      throw new Error("Error getting seller withdrawable amount!");
    }
  }

};


