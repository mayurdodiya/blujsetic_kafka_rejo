const { AuthenticationError } = require("apollo-server-express");
const database = require("../../../database/models");
const elasticClient = require("../../../services/elasticsearch");
module.exports = {
  getAllLikes: async (root, args, { user }) => {
    if (user != null) {
      const allLikes = await database.Like.findAll({
        include: [
          {
            model: database.User,
            as: "user",
          },
        ],
      });
      return allLikes;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
  getAllStoreLikesChartData: async (root, args, { user }) => {
    try {
      let { like_for, start_date, end_date, time_interval, time_zone } = args;
      if (!user || !user?.store_id  ) {
        return new AuthenticationError("Please Provide the token");
      }
      let data = await elasticClient.storeLikes.getAllStoreLikesChartData({ store_id: user?.store_id, like_for, start_date, end_date, time_interval, time_zone });
      // console.log("data", data);
      return { success: true, message: "Data successfully", data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  getSingleLike: async (root, args, { user }) => {
    if (user != null) {
      let parent_id = args?.parent_id;
      let like_for = args?.like_for;

      let isLike = false;
      let like_id;

      let find_product_like = await database.Like.findOne({
        where: {
          id: parent_id,
          like_for: like_for,
          user_id: user?.id,
        },
        raw: true,
      });
      if (find_product_like) {
        isLike = true;
        like_id = find_product_like?.id;
      }
      return {
        data: {
          isLike: isLike,
          like_id,
        },
        success: true,
        message: "Like Data Fetch Successfully",
      };
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
};
