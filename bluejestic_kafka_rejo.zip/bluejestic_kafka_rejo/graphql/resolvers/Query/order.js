const { AuthenticationError } = require("apollo-server-express");
const DB = require("../../../database/models");
const { Op } = require("sequelize");
const elasticClient = require("../../../services/elasticsearch");
const { default: axios } = require("axios");
const moment = require("moment");
const countries = require("i18n-iso-countries");
countries.registerLocale(require("i18n-iso-countries/langs/en.json"));
module.exports = {
  getAllOrders: async (root, { store_id = null, order_status, order, search = '', page, limit, startDate, endDate, isBuyAgainOrder }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    try {
      let field = store_id ? "store_id" : "user_id";
      let order_by = order || "";

      let offset;
      if (page && limit) {
        offset = (parseInt(page) - 1) * parseInt(limit);
        limit = parseInt(limit);
      }

      let formattedStartDate, formattedEndDate;
      if (startDate && endDate) { 
        formattedStartDate = moment(startDate).startOf("day").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
        formattedEndDate = moment(endDate).endOf("day").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
      }

      let order_data = ["createdAt", "DESC"];
      let product_data = [{ model: DB.Product, as: "product" }, "title", "ASC"];
      if (order_by === "Date Created") {
        order_data = ["createdAt", "DESC"];
      } else if (order_by === "A-Z") {
        // product_data = [{ model: DB.Product, as: "product" }, "title", "ASC"];
      } else if (order_by === "Z-A") {
        // product_data = [{ model: DB.Product, as: "product" }, "title", "DESC"];
      }

      let filteredSearch;
      if (search) {
        filteredSearch = search.replace(/[#\$]/g, "");
      }

      const isStatusSearched = ["N/A", "in_transit", "delivered", "error", "unknown", "N/A", "delivered_to_service_point", "pending", "cancelled", "returned", "confirmed"].includes(filteredSearch);

      const allOrders = await DB.OrderItems.findAll({
        where: {
          // ...(user?.token_type === "user" ? { user_id: user?.id } : { store_id: user?.id }),
          [field]: store_id ? store_id : user?.id,
          ...(order_status && order_status.length && { order_status: order_status }),
          ...(formattedStartDate && formattedEndDate && {
            createdAt: {
              [DB.Sequelize.Op.between]: [formattedStartDate, formattedEndDate],
            }
          }),
          ...(isBuyAgainOrder !== undefined && isBuyAgainOrder !== null && {
            isBuyAgainOrder: isBuyAgainOrder
          }),
          ...(filteredSearch && !isNaN(filteredSearch) && {
            [DB.Sequelize.Op.or]: [
               {
                totalAmount: {
                  [DB.Sequelize.Op.eq]: parseFloat(filteredSearch),
                }
              },
              {
                id: {
                  [DB.Sequelize.Op.eq]: parseInt(filteredSearch),
                }
              }
            ]
          }),
          ...(isStatusSearched && { order_status: { [DB.Sequelize.Op.iLike]: `%${filteredSearch}%` } }) 
        },
        include: [
          {
            model: DB.BillingAddresses,
            as: "shipping_data",
          },
          {
            model: DB.Product,
            as: "product",
            attributes: ["id", "store_id", "title", "dis_listPrice", "dis_price", "slug"],
            ...(filteredSearch && isNaN(filteredSearch) && !isStatusSearched && {
              where: {
                title: {
                  [DB.Sequelize.Op.iLike]: `%${filteredSearch}%`,
                },
              },
            }),
            include: [
              // {
              //   model: DB.Variation,
              //   as: "options",
              //   attributes: ["name"],
              //   include: [{ model: DB.VariationOption, as: "data", attributes: ["value", "colorCode"] }],
              // },
              {
                model: DB.ProductItem,
                as: "variant",
                attributes: ["id", "title", "price", "listPrice", "sku", "barcode", "inventory_quantity", "old_inventory_quantity", "isTaxable", "image_id", "height", "width", "length", "weightValue", "weightUnit"],
                include: [
                  // {
                  //   model: DB.ProductConfiguration,
                  //   as: "total_variant",
                  //   attributes: ["id", "variant_option_id"],
                  //   include: [
                  //     {
                  //       model: DB.VariationOption,
                  //       as: "variant_option",
                  //       attributes: ["value", "variation_id", "colorCode"],
                  //     },
                  //   ],
                  // },
                  {
                    model: DB.Media,
                    as: "image",
                    attributes: ["media"],
                  },
                ],
              },
              {
                model: DB.ProductMedia,
                as: "images",
                attributes: ["src", "media_id"],
              },
              {
                model: DB.BusinessInformation,
                as: "store",
              },
            ],
          },
          {
            model: DB.OrderMaster,
            as: "orderMaster",
            include: [
              {
                model: DB.BillingAddresses,
                as: "shipping_detail",
              }
            ]
          },
          {
            model: DB.User,
            as: "customer",
            attributes: ["id", "firstName", "lastName", "logo_image", "banner_image"],
          },
        ],
        ...(limit && { limit: limit }),
        ...(offset && { offset: offset }),
        order: [order_data],
      });

      const sanitizedAllOrders = JSON.parse(JSON.stringify(allOrders));

      // Check if it's an array
      if (!Array.isArray(sanitizedAllOrders)) {
        return [];
      }
      // console.log("🚀 ~ file: order.js:167 ~ sanitizedAllOrders:", sanitizedAllOrders)
      
      sanitizedAllOrders.forEach((order) => {
        order.store_details = order?.product?.store 
      });


      return sanitizedAllOrders;

    } catch (error) {
      console.error("An error occured while fetching all the orders for summary: ", error);
      return {
        success: false,
        message: "An error occured while fetching all the orders for summary"
      };
    }
  },

  getShipDetail: async (root, { input }, { user }) => {
    let { products } = input;
    // try {
    //   let total_weigh = 0;
    //   for (const p of products) {
    //     if (!p.productId || !p.quantity) {
    //       return { success: false, message: "Please Provide Valid Products" };
    //     }

    //     let single_product = await DB.Product.findOne({
    //       where: {
    //         id: p.productId,
    //         is_deleted: false,
    //       },
    //       attributes: ["id"],
    //       include: [
    //         {
    //           model: DB.ProductItem,
    //           as: "variant",
    //           ...(p?.variant_id && {
    //             where: {
    //               id: p?.variant_id,
    //             },
    //           }),
    //           attributes: ["id", "sku", "inventory_quantity", "old_inventory_quantity", "isTaxable", "height", "width", "length", "weightValue", "weightUnit"],
    //         },
    //         {
    //           model: DB.ProductShippingDetails,
    //           as: "shipping",
    //         },
    //       ],
    //     });
    //     let product = JSON.parse(JSON.stringify(single_product));

    //     console.log("fasdfasfdsasafsdafsd++++++++++++++++++++", product);

    //     function convertWeight(weightUnit_converFrom, weightUnit_converTo, weightValue) {
    //       const conversionRates = {
    //         kg: {
    //           kg: 1,
    //           g: 1000,
    //           lb: 2.20462,
    //           oz: 35.274,
    //         },
    //         g: {
    //           kg: 0.001,
    //           g: 1,
    //           lb: 0.00220462,
    //           oz: 0.035274,
    //         },
    //         lb: {
    //           kg: 0.453592,
    //           g: 453.592,
    //           lb: 1,
    //           oz: 16,
    //         },
    //         oz: {
    //           kg: 0.0283495,
    //           g: 28.3495,
    //           lb: 0.0625,
    //           oz: 1,
    //         },
    //       };

    //       if (!conversionRates[weightUnit_converFrom] || !conversionRates[weightUnit_converFrom][weightUnit_converTo]) {
    //         throw new Error("Invalid weight units provided for conversion.");
    //       }

    //       const convertedValue = weightValue * conversionRates[weightUnit_converFrom][weightUnit_converTo];
    //       return convertedValue;
    //     }

    //     if (product?.variant) {
    //       const weightValue = Number(product?.variant?.weightValue);
    //       const convertedValue = convertWeight(product?.variant?.weightUnit, "kg", weightValue);
    //       console.log("convertedValue", convertedValue);

    //       total_weigh = total_weigh + convertedValue;
    //     }
    //   }

    //   console.log("total_weigh+++++++++++++++++++++++++++", total_weigh);

    //   const data = {
    //     carrier_ids: ["se-5264045"],
    //     from_country_code: "US",
    //     from_postal_code: "78756",
    //     to_country_code: "US",
    //     to_postal_code: "91521",
    //     weight: {
    //       value: 1,
    //       unit: "pound",
    //     },
    //     dimensions: {
    //       length: 2,
    //       width: 1,
    //       height: 2,
    //       unit: "inch",
    //     },
    //   };

    //   // let config = {
    //   //   method: "post",
    //   //   maxBodyLength: Infinity,
    //   //   url: "https://api.shipengine.com/v1/rates/estimate",
    //   //   headers: {
    //   //     "Content-Type": "application/json",
    //   //     "API-Key": process.env.SHIPENGINE_API_KEY,
    //   //   },
    //   //   data: data,
    //   // };

    //   // let response = await axios(config);
    //   // let final;
    //   // [final] = response.data.filter((item) => item.service_code === process.env.SHIPENGINE_SERVICE_CODE);
    //   // let charges = final.shipping_amount.amount + final.insurance_amount.amount + final.confirmation_amount.amount + final.other_amount.amount;
    //   // return { data: final, charges };
    // } catch (error) {
    //   console.log("Ship Enginge - INTERNAL SERVER ERROR  : \n", error);
    //   return { success: false, message: error.message };
    // }

    // ================================= SHIP CHARGE AS OLD ADMIN PANEL DESIGN ===================================

    // let orderShipTotal = []
    // try {
    //   for (const p of products) {
    //     if (!p.productId || !p.quantity) {
    //       return { success: false, message: "Please Provide Valid Products" };
    //     }
    //     let single_product = await DB.Product.findOne({
    //       where: {
    //         id: p.productId,
    //         is_deleted: false,
    //       },
    //       include: [
    //         {
    //           model: DB.ProductItem,
    //           as: "variant",
    //           ...(p?.variant_id && {
    //             where: {
    //               id: p?.variant_id,
    //             },
    //           }),
    //           attributes: ["id", "title", "price", "listPrice", "sku", "barcode", "inventory_quantity", "old_inventory_quantity", "isTaxable", "image_id", "height", "width", "length", "weightValue", "weightUnit"],
    //           include: [
    //             {
    //               model: DB.ProductConfiguration,
    //               as: "total_variant",
    //               attributes: ["id", "variant_option_id"],
    //               include: [
    //                 {
    //                   model: DB.VariationOption,
    //                   as: "variant_option",
    //                   attributes: ["value", "variation_id", "colorCode"],
    //                 },
    //               ],
    //             },
    //             {
    //               model: DB.Media,
    //               as: "image",
    //               attributes: ["media"],
    //             },
    //           ],
    //         },
    //         {
    //           model: DB.ProductShippingDetails,
    //           as: "shipping",
    //         },
    //         {
    //           model: DB.Variation,
    //           as: "options",
    //           attributes: ["name"],
    //           include: [{ model: DB.VariationOption, as: "data", attributes: ["value", "colorCode"] }],
    //         },
    //         {
    //           model: DB.ProductMedia,
    //           as: "images",
    //           attributes: ["src", "media_id"],
    //         },
    //         {
    //           model: DB.ProductTag,
    //           as: "tags",
    //           attributes: ["tag"],
    //         },
    //         {
    //           model: DB.ProductCategories,
    //           as: "categories",
    //           attributes: ["category_id", "subCategory_id", "childSubCategory_id"],
    //           include: [
    //             {
    //               model: DB.Category,
    //               as: "category",
    //             },
    //             {
    //               model: DB.Subcategory,
    //               as: "subCategory",
    //             },
    //             {
    //               model: DB.Childsubcategory,
    //               as: "childSubCategory",
    //             },
    //           ],
    //         },
    //         {
    //           model: DB.ProductInventory,
    //           as: "inventoryPrice",
    //           attributes: ["price", "listPrice", "quantity", "sku"],
    //         },
    //         {
    //           model: DB.ProductAttributes,
    //           as: "attributes",
    //           attributes: ["name", "value"],
    //         },
    //         {
    //           model: DB.ProductImageSize,
    //           as: "size",
    //         },
    //         {
    //           model: DB.BusinessInformation,
    //           as: "store",
    //           attributes: ["id", "name", "logo"],
    //           include: [{
    //             model: DB.StoreDetail,
    //             as: "store_detail"
    //           }]
    //         },
    //       ],
    //       // raw: true,
    //     });
    //     let product = JSON.parse(JSON.stringify(single_product));

    //     console.log("fasdfasfdsasafsdafsd++++++++++++++++++++", product);

    //     let totalAmount = Number(product?.variant ? product?.variant?.price : product?.inventoryPrice?.price) * p.quantity;

    //     let orderShipCalculation = {
    //       store_id: product?.store.id,
    //       store_name: product?.store?.name,
    //       store_detail: {
    //         min_amount: product?.store?.store_detail?.min_amount,
    //         flat_rate: product?.store?.store_detail?.flat_rate,
    //         is_FreeShipping: product?.store?.store_detail?.is_FreeShipping,
    //         is_minimum_purchase_amount: product?.store?.store_detail?.is_minimum_purchase_amount,
    //         is_flat_rate: product?.store?.store_detail?.is_flat_rate,
    //       },
    //       isShopifyProduct: product?.shopify_product_id === "" || !product?.shopify_product_id ? false : true,
    //       totalAmount: totalAmount,
    //       ship_charge: 0,
    //       user_id: user.id,
    //     }

    //     orderShipTotal.push(orderShipCalculation)
    //   }
    //   const groupedByStore = orderShipTotal.reduce((acc, item) => {
    //     if (!acc[item.store_id]) {
    //       acc[item.store_id] = { store_id: item.store_id, totalAmount: 0 };
    //     }
    //     acc[item.store_id].totalAmount += item.totalAmount;
    //     acc[item.store_id].store_detail = item.store_detail;
    //     acc[item.store_id].isShopifyProduct = item.isShopifyProduct;
    //     acc[item.store_id].store_name = item.store_name;
    //     return acc;
    //   }, {});

    //   const shipResult = Object.values(groupedByStore);

    //   const calculateShipping = (stores) => {
    //     return stores.map((store) => {
    //       const { store_detail, totalAmount } = store;

    //       let ship_charge = 0;

    //       if (store_detail.is_FreeShipping) {
    //         ship_charge = 0;
    //       } else if (store_detail.is_flat_rate) {
    //         ship_charge = store_detail.flat_rate;
    //       } else if (store_detail.is_minimum_purchase_amount) {
    //         ship_charge = totalAmount < store_detail.min_amount ? store_detail.flat_rate : 0;
    //       }

    //       return { ...store, ship_charge };
    //     });
    //   };

    //   const updatedStores = await calculateShipping(shipResult);

    //   return { success: true, message: "Data Fetch Successfully!", data: updatedStores }
    // } catch (error) {
    //   console.log(error);

    // }

    // let productArray = {
    //   // "productId": 12209,
    //   // "quantity": 1,
    //   // "variant_id": 141630,
    //   // "store_id": 337,
    //   // "service_code": "ups_ground"
    //   "productId": 17280,
    //   "quantity": 1,
    //   "variant_id": 174661,
    //   "store_id": 1
    // }

    let orderItemArray = []
    for (let i = 0; i < products.length; i++) {
      const productArray = products[i]

      let single_product = await DB.Product.findOne({
        where: {
          id: productArray.productId,
          is_deleted: false,
        },
        include: [
          {
            model: DB.ProductItem,
            as: "variant",
            ...(productArray?.variant_id && {
              where: {
                id: productArray?.variant_id,
              },
            }),
            attributes: ["id", "title", "price", "listPrice", "sku", "barcode", "inventory_quantity", "old_inventory_quantity", "isTaxable", "image_id", "height", "width", "length", "weightValue", "weightUnit", "product_id"],
          },
          {
            model: DB.ProductShippingDetails,
            as: "shipping",
          },
          {
            model: DB.ShippingMethod,
            as: "shipping_method",
          },
          {
            model: DB.ProductInventory,
            as: "inventoryPrice",
            attributes: ["price", "listPrice", "quantity", "sku"],
          },
          {
            model: DB.BusinessInformation,
            as: "store",
            attributes: ["id", "name", "logo", "city", "state", "state_name", "country", "postalCode"],
            include: [{
              model: DB.StoreDetail,
              as: "store_detail"
            }]
          },
        ],
        // raw: true,
      });
      let product = JSON.parse(JSON.stringify(single_product))

      console.log('prodasdasdasdsdduct', product);

      if (product?.shopify_product_id === "" || !product?.shopify_product_id) {
        // general Product
        if (product?.shipping_method?.is_free_delivery) {
          orderItemArray.push({ success: true, message: "Fetch Successfully", isShopifyProduct: false, ship_charge: 0, is_free_delivery: true, product_id: product?.id })
          // return { success: true, message: "Fetch Successfully", isShopifyProduct: false, ship_charge: 0, is_free_delivery: true }
        } else {
          const shipping = await DB.BillingAddresses.findOne({
            where: {
              isDefault: true,
              user_id: user?.id,
            },
            raw: true,
          });

          let ProductShippingDetails;
          // console.log("o?.variant_id++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", general_prd?.variant_id);
          if (product?.variant?.id) {
            ProductShippingDetails = await DB.ProductItem.findOne({ where: { id: product?.variant?.id }, raw: true });
          } else {
            ProductShippingDetails = await DB.ProductShippingDetails.findOne({ where: { product_id: product.id }, raw: true });
          }

          if (!ProductShippingDetails) {
            orderItemArray.push({ success: false, message: "Product has not Shipping Details", product_id: product?.id })
            // return { success: false, message: "Product has not Shipping Details" }
          }
          console.log('ProductShippingDetails', ProductShippingDetails);

          const getISO2FromCountryName = (countryName) => {
            const iso2 = countries.getAlpha2Code(countryName, 'en');
            return iso2 || 'Country not found';
          };

            
          const shopifyPayload = {
            "carrier_ids": [
              process.env.SHIPENGINE_CARIRER_ID
            ],
            "from_country_code": getISO2FromCountryName(product?.store?.country),
            "from_postal_code": product?.store?.postalCode,
            "from_city_locality": product?.store?.city,
            "from_state_province": product?.store?.state,
            "to_country_code": shipping?.country,
            "to_postal_code": shipping?.zipcode,
            "to_city_locality": shipping?.city,
            "to_state_province": shipping?.state,
            "weight": {
              "value": ProductShippingDetails.weightValue,
              "unit": "pound",
            },
            "dimensions": {
              "length": ProductShippingDetails.length,
              "width": ProductShippingDetails.width,
              "height": ProductShippingDetails.height,
              "unit": "inch",
            }
          }
          console.log('shopifyPayload', shopifyPayload);

          try {
            const baseURL = 'https://api.shipengine.com/v1';
            const headers = {
              'API-Key': process.env.SHIPENGINE_API_KEY,
              'Content-Type': 'application/json'
            };
            const response = await axios.post(`${baseURL}/rates/estimate`, shopifyPayload, { headers });
            console.log('asdsdbfdsfhdbfhjsdbfdaddsa', response.data);
            if (response.data[0]?.error_messages?.length > 0) {
              orderItemArray.push({ success: false, message: "You can not purchase this item", isShopifyProduct: false, data: response.data || [], product_id: product?.id })
            } else {
              orderItemArray.push({ success: true, message: "Product detail fetch successfully!", isShopifyProduct: false, data: response.data || [], product_id: product?.id })
            }
            // return { success: true, message: "Product detail fetch successfully!", isShopifyProduct: false, data: response.data || [] }
          } catch (error) {
            console.log('error', error);
          }
        }
      } else {
        // Shopify Product
        if (product?.store?.store_detail) {
          if (product?.store?.store_detail?.is_FreeShipping) {
            orderItemArray.push({
              success: true, message: "Ship Charge Fetched Successfully", isShopifyProduct: true, is_free_delivery: true, product_id: product?.id
            })
            // return ({
            //   success: true, message: "Ship Charge Fetched Successfully", isShopifyProduct: true, is_free_delivery: true, ship_charge: updatedStores[0]?.ship_charge
            // })
          } else {
            let totalAmount = Number(product?.variant ? product?.variant?.price : product?.inventoryPrice?.price) * productArray.quantity;
            let orderShipCalculation = {
              store_id: product?.store.id,
              store_name: product?.store?.name,
              store_detail: {
                min_amount: product?.store?.store_detail?.min_amount,
                flat_rate: product?.store?.store_detail?.flat_rate,
                is_FreeShipping: product?.store?.store_detail?.is_FreeShipping,
                is_minimum_purchase_amount: product?.store?.store_detail?.is_minimum_purchase_amount,
                is_flat_rate: product?.store?.store_detail?.is_flat_rate,
              },
              isShopifyProduct: product?.shopify_product_id === "" || !product?.shopify_product_id ? false : true,
              totalAmount: totalAmount,
              ship_charge: 0,
              user_id: user.id,
            }

            const groupedByStore = [orderShipCalculation].reduce((acc, item) => {
              if (!acc[item.store_id]) {
                acc[item.store_id] = { store_id: item.store_id, totalAmount: 0 };
              }
              acc[item.store_id].totalAmount += item.totalAmount;
              acc[item.store_id].store_detail = item.store_detail;
              acc[item.store_id].isShopifyProduct = item.isShopifyProduct;
              acc[item.store_id].store_name = item.store_name;
              return acc;
            }, {});

            const shipResult = Object.values(groupedByStore);

            const calculateShipping = (stores) => {
              return stores.map((store) => {
                const { store_detail, totalAmount } = store;

                let ship_charge = 0;

                if (store_detail.is_FreeShipping) {
                  ship_charge = 0;
                } else if (store_detail.is_flat_rate) {
                  ship_charge = store_detail.flat_rate;
                } else if (store_detail.is_minimum_purchase_amount) {
                  ship_charge = totalAmount < store_detail.min_amount ? store_detail.flat_rate : 0;
                }

                return { ...store, ship_charge };
              });
            };

            const updatedStores = await calculateShipping(shipResult);
            // return ({
            //   success: true, message: "Ship Charge Fetched Successfully", isShopifyProduct: true, ship_charge: updatedStores[0]?.ship_charge, is_free_delivery: false
            // })
            orderItemArray.push({
              success: true, message: "Ship Charge Fetched Successfully", isShopifyProduct: true, ship_charge: updatedStores[0]?.ship_charge, is_free_delivery: false, product_id: product?.id
            })

          }
        } else {
          // return ({ success: false, message: "Ship Detail not provided for this Product" })
          orderItemArray.push({ success: false, message: "Ship Detail not provided for this Product", product_id: product?.id })
        }
      }
    }
    return orderItemArray
  },

  getOrderForAdmin: async (root, { store_id, order_status, order, search, page, limit, slug, order_item_id = null }, { user }) => {
    try {
      if (!user) return new AuthenticationError("Please provide tokrn");
      if (user.token_type !== "admin") return new AuthenticationError("Unauthorized");

      let offset;
      if (limit && page) {
        offset = (parseInt(page) - 1) * limit;
        limit = parseInt(limit);
      }

      let order_data = [["createdAt", "DESC"]];
      if (order) {
        if (order === "Default Sort") {
          order_data = [["createdAt", "DESC"]];
        } else if (order === "Newest") {
          order_data = [["createdAt", "DESC"]];
        } else if (order === "Oldest") {
          order_data = [["createdAt", "ASC"]];
        } else if (order === "Highest Total") {
          order_data = [["totalAmount", "DESC"]];
        } else if (order === "Lowest Total") {
          order_data = [["totalAmount", "ASC"]];
        }
      }


      const { rows, count } = await DB.OrderItems.findAndCountAll({
        where: {
          ...(order_item_id && { id: order_item_id }),
          ...(order_status && {
            order_status: order_status,
          }),
        },
        include: [
          {
            model: DB.Product,
            as: "product",
            attributes: ["id", "store_id", "title", "dis_listPrice", "dis_price"],
            ...(search && {
              where: {
                title: {
                  [DB.Sequelize.Op.iLike]: `%${search}%`,
                },
              },
            }),
            include: [
              {
                model: DB.ProductItem,
                as: "variant",
                attributes: ["id", "title", "price", "listPrice", "sku", "barcode", "inventory_quantity", "old_inventory_quantity", "isTaxable", "image_id", "height", "width", "length", "weightValue", "weightUnit"],
                include: [
                  {
                    model: DB.Media,
                    as: "image",
                    attributes: ["media"],
                  },
                ],
              },
              {
                model: DB.ProductMedia,
                as: "images",
                attributes: ["src", "media_id"],
              },
              {
                model: DB.BusinessInformation,
                as: "store",
              },
            ],
          },
          {
            model: DB.OrderMaster,
            as: "orderMaster",
            include: [
              {
                model: DB.BillingAddresses,
                as: "shipping_detail",
              }
            ],
          },
          {
            model: DB.User,
            as: "customer",
            attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "email"],
          },
        ],
        ...(order_data && { order: order_data }),
        ...(limit && page && { limit: limit }),
        ...(limit && page && { offset: offset }),
        distinct: true,
        col: "id"
      });

      return { success: true, message: "Fetched Orders Successfully.", data: rows, total: count };
    } catch (error) {
      console.error("An error occured while fetching orders: ", error);
      return {
        success: false,
        message: "An error occured while fetching orders!",
        data: null,
        total: null
      }
    }
  },

  getSingleOrder: async (root, { order_master_id, order_item_id = null, user_id }, { user }) => {
    try {
      let userId;
      if (user?.token_type === "admin") {
        userId = user_id
      } else {
        userId = user?.id
      }

      console.log('userId', order_master_id, order_item_id, userId);

      if (user != null) {
        const confirm_orders = await DB.OrderMaster.findOne({
          where: {
            id: order_master_id,
            user_id: userId,
          },
          include: [
            {
              model: DB.BillingAddresses,
              as: "shipping_detail",
            },
            {
              model: DB.OrderItems,
              as: "orderItems",
              where: {
                ...(order_item_id && {
                  id: order_item_id,
                }),
              },
              include: [
                {
                  model: DB.BillingAddresses,
                  as: "shipping_data",
                },
                {
                  model: DB.Product,
                  as: "product",
                  attributes: ["id", "store_id", "title", "dis_listPrice", "dis_price", "slug"],
                  include: [
                    {
                      model: DB.ProductItem,
                      as: "variant",
                      attributes: ["id", "title", "price", "listPrice", "sku", "barcode", "inventory_quantity", "old_inventory_quantity", "isTaxable", "image_id", "height", "width", "length", "weightValue", "weightUnit"],
                      include: [
                        {
                          model: DB.Media,
                          as: "image",
                          attributes: ["media"],
                        },
                      ],
                    },
                    {
                      model: DB.ProductMedia,
                      as: "images",
                      attributes: ["src", "media_id"],
                    },
                    {
                      model: DB.BusinessInformation,
                      as: "store",
                    },
                  ],
                },
              ],
            },
          ],
        });
        if (confirm_orders) {
          return { success: true, message: "Fetch Order successfully", data: confirm_orders };
        } else {
          return { success: false, message: "Order not Found", data: confirm_orders };
        }
      } else {
        return new AuthenticationError("Please Provide the token");
      }
    } catch (error) {
      console.log('error', error);
    }
  },

  getSingleOrderForAdmin: async (root, { order_item_id }, { user }) => {
    try {
      if (user.token_type !== "admin") return new AuthenticationError("Unauthorized");

      const order_detail = await DB.OrderItems.findOne({
        where: {
          id: order_item_id,
        },
        attributes: ["id", "variant_id"],
        raw: true,
      });

      if (!order_detail) return { success: true, message: "Order Not Found" };

      const confirm_orders = await DB.OrderItems.findOne({
        where: {
          id: order_detail?.id,
        },
        include: [
          {
            model: DB.Product,
            as: "product",
            attributes: ["id", "store_id", "title", "dis_listPrice", "dis_price"],
            include: [
              {
                model: DB.ProductItem,
                as: "variant",
                attributes: ["id", "title", "price", "listPrice", "sku", "barcode", "inventory_quantity", "old_inventory_quantity", "isTaxable", "image_id", "height", "width", "length", "weightValue", "weightUnit"],
                ...(order_detail?.variant_id && {
                  where: {
                    id: order_detail?.variant_id,
                  },
                }),
                include: [
                  {
                    model: DB.ProductConfiguration,
                    as: "total_variant",
                    attributes: ["id", "variant_option_id"],
                    include: [
                      {
                        model: DB.VariationOption,
                        as: "variant_option",
                        attributes: ["value", "variation_id", "colorCode"],
                        include: [{ model: DB.Variation, as: "data", attributes: ["name"] }],
                      },
                    ],
                  },
                  {
                    model: DB.Media,
                    as: "image",
                    attributes: ["media"],
                  },
                ],
              },
              {
                model: DB.ProductMedia,
                as: "images",
                attributes: ["src", "media_id"],
              },
              {
                model: DB.BusinessInformation,
                as: "store",
              },
            ],
          },
          {
            model: DB.OrderMaster,
            as: "orderMaster",
            include: [
              {
                model: DB.BillingAddresses,
                as: "shipping_detail",
                attributes: ["streetAddress", "city", "state", "country", "zipcode", "buildingName"],
              },
            ],
          },
          {
            model: DB.User,
            as: "customer",
            attributes: ["id", "firstName", "lastName", "logo_image", "banner_image"],
          },
        ],
      });

      return { success: true, message: "Fetch Order successfully", data: confirm_orders };
    } catch (error) {
      console.log("error", error);
    }
  },

  getOrderMetrics: async (root, args, { user }) => {
    try {
      let { store_id } = args;
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }
      let metrics = await elasticClient.order.getOrdersMetrics("order_items", store_id);
      // let metrics = await elasticClient.order.getOrdersMetrics("orders", store_id);
      const { aggregations } = metrics;
      if (!aggregations) return { success: false, message: "No data found" };

      const { pending_orders, shipped_orders, dispatched_orders, total_orders } = aggregations;
      let data = {
        new_orders: pending_orders.doc_count,
        // shipped_orders: shipped_orders.doc_count,
        // dispatched_orders: dispatched_orders.doc_count,
        pending_shipment_orders: shipped_orders.doc_count + dispatched_orders.doc_count,
        total_orders: total_orders.value,
      };
      return { success: true, message: "Data successfully", data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  getDateWiseOrderRevenue: async (root, args, { user }) => {
    try {
      let { start_date, end_date, time_interval, time_zone } = args;
      if (!user || !user?.store_id) {
        return new AuthenticationError("Please Provide the token");
      }
      let data = await elasticClient.order.getDateWiseOrderRevenue("orders", { store_id: user?.store_id, start_date, end_date, time_interval, time_zone });
      return { success: true, message: "Data successfully", data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  getUserOrderAnalysis: async (root, args, { user }) => {
    try {
      let { user_id, start_date, end_date, time_interval, time_zone } = args;
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }
      let data = await elasticClient.order.getDateWiseUserOrderAnalysis("order_master", { user_id, start_date, end_date, time_interval, time_zone });
      console.log("jainam jainam+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", data);
      return { success: true, message: "Data successfully", data: data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  getUserOrderCountStats: async (root, args, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    try {
      let data = await elasticClient.order.getUserOrderCountStatsElastic("order_master", { user_id: user?.id });
      return { success: true, message: "Data successfully", data };
    } catch (error) {
      console.error("An error occured while fetching orders stats for summary", error);
      return {
        success: false,
        message: error?.message || "Something went wrong",
      }
    }
  },

  getOrderCategorySummary: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    try {

      let startDate, endDate;
      if (input && input?.startDate && input?.endDate) {
        startDate = moment(input?.startDate).startOf("day").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
        endDate = moment(input?.endDate).endOf("day").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
      }

      let get_order_statistics = await DB.OrderItems.findAll({
        where: {
          user_id: user?.id,
          ...(startDate && endDate && {
            createdAt: {
              [DB.Sequelize.Op.between]: [startDate, endDate],
            }
          })
        },
        attributes: ["product_id", "totalAmount", "createdAt"],
        include: [
          {
            model: DB.Product,
            as: "product",
            attributes: ["id"],
            include: [
              {
                model: DB.ProductCategories,
                as: "categories",
                attributes: ["childSubCategory_id"],
              },
            ],
          },
        ],
      });


      let data = JSON.parse(JSON.stringify(get_order_statistics));
      const childSubCategoryClothArray = [84, 85, 88, 89, 91, 95, 96, 98, 99, 100, 101, 102, 103, 104, 105, 107, 109, 110, 112, 114, 115, 116, 117, 119, 120, 121, 123, 124, 125, 146, 148, 149, 150, 151, 152];

      const childSubCategoryShoesArray = [106, 118];

      const childSubCategoryJewelleryArray = [48, 49, 50, 51, 52, 54, 56, 57, 58, 59, 60, 86, 147, 153];

      const filteredOrders = data && data.length && data
      .map((order) => {
        const category = order?.product?.categories && order?.product?.categories?.length && order?.product?.categories.find((cat) => {
          return childSubCategoryJewelleryArray.includes(cat.childSubCategory_id) || childSubCategoryShoesArray.includes(cat.childSubCategory_id) || childSubCategoryClothArray.includes(cat.childSubCategory_id);
        });
        
        if (category) {
          if (childSubCategoryJewelleryArray.includes(category.childSubCategory_id)) {
              return { ...order, categoryType: "jewellery" };
            } else if (childSubCategoryShoesArray.includes(category.childSubCategory_id)) {
              return { ...order, categoryType: "shoes" };
            } else if (childSubCategoryClothArray.includes(category.childSubCategory_id)) {
              return { ...order, categoryType: "cloth" };
            }
          }
          
          return null;
        })
        .filter(Boolean);


      let clothSum = 0;
      let jewellerySum = 0;
      let shoesSum = 0;
      
      // Iterate through the CategoryArray to calculate sums
      filteredOrders.forEach((item) => {
        switch (item?.categoryType) {
          case "cloth":
            clothSum += item?.totalAmount;
            break;
          case "jewellery":
            jewellerySum += item?.totalAmount;
            break;
          case "shoes":
            shoesSum += item?.totalAmount;
            break;
            default:
              console.log("Invalid category type");
              break;
            }
          });

      let total_category_revenue = clothSum + jewellerySum + shoesSum;

      let jewellery_percentage = total_category_revenue ? (jewellerySum / total_category_revenue) * 100 : 0;
      let cloth_percentage = total_category_revenue ? (clothSum / total_category_revenue) * 100 : 0;
      let shoes_percentage = total_category_revenue ? (shoesSum / total_category_revenue) * 100 : 0;

      return {
        success: true,
        message: "Fetched user's category wise order's amount stats successfully.",
        data: {
          jewellery: { jewellerySum, jewellery_percentage },
          cloth: { clothSum, cloth_percentage },
          shoes: { shoesSum, shoes_percentage },
        },
      };
    } catch (error) {
      console.error("An error occured while fetching user's category wise order's amount stats: ", error);
      return {
        success: false,
        message: error?.message || "An error occured while fetching user's category wise order's amount stats",
      }
    }
  },

  /* Seller Earning */
  getDateWiseOrderEarnings: async (root, args, { user }) => {
    try {
      let { start_date, end_date, time_interval, time_zone } = args;
      if (!user || !user?.store_id) {
        return new AuthenticationError("Please Provide the token");
      }
      let data = await elasticClient.order.getDateWiseOrderEarnings("order_items", { store_id: user?.store_id, start_date, end_date, time_interval, time_zone });
      return { success: true, message: "Data successfully", data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  getAverageOrderValueAndOrdersMetrtics: async (root, args, { user }) => {
    try {
      let { start_date, end_date, time_interval, time_zone } = args;
      if (!user || !user?.store_id) {
        return new AuthenticationError("Please Provide the token");
      }
      let data = await elasticClient.order.getAverageOrderValueAndOrdersMetrtics("orders", {
        store_id: user?.store_id,
        start_date,
        end_date,
        time_interval,
        time_zone,
      });
      return { success: true, message: "Data successfully", data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  getAllOrdersDataWithCustomerDetails: async (root, args, { user }) => {
    try {
      let { store_id, user_id } = args;
      if (!store_id && !user_id) return { success: false, message: "Please provide user_id or store_id" };

      if (!user || !user?.store_id) {
        return new AuthenticationError("Please Provide the token");
      }
      let response = await elasticClient.order.getAllOrdersDataWithCustomerDetails({ store_id: user?.store_id, user_id });
      return { success: true, message: "Data successfully", data: response.data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  getAllOrdersHistory: async (root, args, { user }) => {
    try {
      let { store_id, start_date, end_date, user_id } = args;
      if (!store_id) return { success: false, message: "Please provide store_id" };

      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }
      let response = await elasticClient.order.getAllOrdersHistory({ user_id, store_id, start_date, end_date });
      return { success: true, message: "Data successfully", data: response.data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  getAllUsersOrdersDetails: async (root, { status }, { user }) => {
    if (!user) {
      return new AuthenticationError("Please Provide the token");
    }

    console.log("fsadfdsafsafsafafsafafssafafafsafa++++++++++++++++++++++++++++++");
    try {
      let user_order = await DB.OrderItems.findAll({
        where: {
          user_id: user.id,
          ...(status.trim() !== "" && {
            order_status: status,
          }),
        },
        include: [
          {
            model: DB.Product,
            as: "product",
          },
          {
            model: DB.BillingAddresses,
            as: "shipping_data",
            attributes: ["streetAddress", "city", "state", "country", "zipcode", "buildingName"],
          },
          {
            model: DB.OrderMaster,
            as: "orderMaster",
            attributes: ["order_id"],
          },
        ],
      });
      let result = [];

      console.log("fsadfasdfsadfdsafs+++++++++++++++++++++++++++++++++++++++++++++++++++++++", JSON.stringify(user_order));
      let order_detail = JSON.parse(JSON.stringify(user_order));

      for (const order of order_detail) {
        let orderStatus = "";
        switch (order?.order_status) {
          case "in_transit":
            orderStatus = "In Tarnsit";
            break;
          case "delivered":
            orderStatus = "Delivered";
            break;
          case "pending":
            orderStatus = "Pending";
            break;
          case "cancelled":
            orderStatus = "Cancelled";
            break;
          case "returned":
            orderStatus = "Returned";
            break;
          default:
            order?.order_status;
            break;
        }

        // let product = order.product;
        // let imageIds = product.cropImages.map(({ croppedFile }) => croppedFile.baseURL);
        // product.image = JSON.parse(
        //   JSON.stringify(
        //     await DB.Media.findAll({
        //       where: {
        //         id: imageIds,
        //       },
        //     })
        //   )
        // ).map((image) => image.media);
        // let product_obj = {
        //   // ...order,
        //   generate_id: order?.orderMaster?.order_id,
        //   shipping: order?.shipping_data,
        //   id: order.id,
        //   title: product.title,
        //   price: product.price,
        //   image: product.image,
        //   quantity: order.quantity,
        //   orderDate: order.createdAt,
        //   order_status: orderStatus,
        // };
        order.order_status = orderStatus;
        // result.push(product_obj);
      }

      console.log("result+++++++++++++++++++++++++++++++++", user_order);

      return { success: true, message: "Data successfully", data: user_order };
    } catch (error) {
      console.log("result+++++++++++++++++++++++++++++++++=============================", error);
      return new AuthenticationError(error.message);
    }
  },

  getAllSellerOrderDetails: async (root, { status }, { user }) => {
    if (!user) {
      return new AuthenticationError("Please Provide the token");
    }
    try {
      let find_seller = DB.BusinessInformation.findOne({
        where: {
          id: user.id,
        },
      });

      if (!find_seller) {
        return new Error("Seller does not exist");
      }

      let user_order = await DB.OrderItems.findAll({
        where: {
          seller_id: user.id,
        },
        attributes: ["id", "quantity", "createdAt", "totalAmount", "order_status"],
        include: [
          {
            model: DB.Product,
            as: "product",
            attributes: ["title", "price", "cropImages"],
          },
          {
            model: DB.User,
            as: "customer",
            attributes: ["firstName", "lastName", "profileAvtar", "userName"],
          },
          {
            model: DB.OrderMaster,
            as: "orderMaster",
            attributes: ["order_id"],
          },
        ],
      });
      let result = [];

      for (const order of JSON.parse(JSON.stringify(user_order))) {
        let orderStatus = "";
        let orderData = order;
        switch (order?.order_status) {
          case "in_transit":
            orderStatus = "In Tarnsit";
            break;
          case "delivered":
            orderStatus = "Delivered";
            break;
          case "pending":
            orderStatus = "Pending";
            break;
          case "cancelled":
            orderStatus = "Cancelled";
            break;
          case "returned":
            orderStatus = "Returned";
            break;
          default:
            order?.order_status;
            break;
        }
        let imageIds = orderData.product.cropImages.slice(0, 1).map(({ croppedFile }) => croppedFile.baseURL);
        let product_image = JSON.parse(
          JSON.stringify(
            await DB.Media.findOne({
              where: {
                id: imageIds,
              },
            })
          )
        );

        let datata = await DB.Media.findOne({
          where: {
            id: {
              [Op.in]: orderData.customer.profileAvtar,
            },
          },
        });

        let product_obj = {
          customer: {
            ...orderData.customer,
            profileAvtar: datata.media,
          },
          product: {
            title: orderData.product.title,
            image: product_image.media,
          },
          order_detail: {
            generate_id: orderData?.orderMaster?.order_id,
            id: orderData.id,
            quantity: orderData.quantity,
            orderDate: orderData.createdAt,
            totalAmount: orderData?.totalAmount,
            order_status: orderStatus,
          },
        };
        result.push(product_obj);
      }

      return { success: true, message: "Data successfully", data: result };
    } catch (error) {
      return new AuthenticationError(error.message);
    }
  },

  getOrderDetails: async (root, args, { user }) => {
    try {
      let { id } = args;
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }
      let response = await elasticClient.order.getOrderDetails({ id });
      return { success: true, message: "Data successfully", data: response.data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  getOrderCustomerActivity: async (root, args, { user }) => {
    try {
      let { store_id, start_date, end_date, time_interval, time_zone } = args;
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }
      let data = await elasticClient.order.getOrderCustomerActivity({ store_id, start_date, end_date, time_interval, time_zone }, "orders");
      if (!data || !data.success) return new Error(data?.message || "Something went wrong");
      return data;
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  getRepeatCustomers: async (root, args, { user }) => {
    try {
      let { store_id, start_date, end_date, time_interval, time_zone } = args;
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }
      let data = await elasticClient.order.getRepeatCustomers({ store_id, start_date, end_date, time_interval, time_zone }, "order_items");
      if (!data || !data.success) return new Error(data?.message || "Something went wrong");
      return data;
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  storeCustomersGender: async (root, args, { user }) => {
    try {
      let { store_id, start_date, end_date, time_interval, time_zone } = args;
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }
      let elkData = await elasticClient.order.storeCustomersGender({ store_id, start_date, end_date, time_interval, time_zone });
      if (!elkData.success) return elkData;
      return elkData;
    } catch (error) {
      return { success: false, message: error.message };
    }
  },

  storeCustomersAgeRatio: async (root, args, { user }) => {
    try {
      let { store_id, start_date, end_date, time_interval, time_zone } = args;
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }
      let elkData = await elasticClient.order.storeCustomersAgeRatio({ store_id, start_date, end_date, time_interval, time_zone });
      if (!elkData.success) return elkData;
      return elkData;
    } catch (error) {
      return { success: false, message: error.message };
    }
  },

  storeCustomersAgeBarChart: async (root, args, { user }) => {
    try {
      let { store_id, start_date, end_date, time_interval, time_zone } = args;
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }
      let elkData = await elasticClient.order.storeCustomersAgeBarChart({ store_id, start_date, end_date, time_interval, time_zone });
      if (!elkData.success) return elkData;
      return elkData;
    } catch (error) {
      return { success: false, message: error.message };
    }
  },

  getCustomerAnalyticsChart: async (root, args, { user }) => {
    try {
      let { store_id, start_date, end_date, time_interval, time_zone } = args;
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }
      let data = await elasticClient.order.getCustomerAnalyticsChart("orders", { store_id, start_date, end_date, time_interval, time_zone });
      return { success: true, message: "Data successfully", data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  customersLocation: async (root, args, { user }) => {
    try {
      let { store_id, filter } = args;
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }
      let elkData = await elasticClient.order.customersLocation({ store_id, filter });
      if (!elkData.success) return elkData;
      return elkData;
    } catch (error) {
      return { success: false, message: error.message };
    }
  },

  customersLocationBySales: async (root, args, { user }) => {
    try {
      let { filter } = args;
      if (!user || !user?.store_id) {
        return new AuthenticationError("Please Provide the token");
      }
      let elkData = await elasticClient.order.customersLocationBySales({ store_id: user?.store_id, filter });
      if (!elkData.success) return elkData;
      return elkData;
    } catch (error) {
      return { success: false, message: error.message };
    }
  },

  customersCategoryBySales: async (root, args, { user }) => {
    try {
      let { store_id, filter } = args;
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }
      let elkData = await elasticClient.order.customersCategoryBySales({ store_id, filter });
      if (!elkData.success) return elkData;
      return elkData;
    } catch (error) {
      return { success: false, message: error.message };
    }
  },

  getRateEstimate: async (root, { input }, { user }) => {
    let { product_data } = input;
    console.log('product_data', product_data);

    try {
      // let shipmentCharges = await estimatedShippingCharges(sellerChargesDetails);
      if (user !== null) {
        const shipping = await DB.BillingAddresses.findOne({
          where: {
            isDefault: true,
            user_id: user?.id,
          },
          raw: true,
        });
        console.log('shipping', shipping);

        if (shipping) {
          let orderItems = []
          for (const p of product_data) {
            if (!p.product_id || !p.quantity) {
              return { success: false, message: "Please Provide Valid Products" };
            }
            let single_product = await DB.Product.findOne({
              where: {
                id: p.product_id,
                is_deleted: false,
              },
              include: [
                {
                  model: DB.ProductItem,
                  as: "variant",
                  ...(p?.variant_id && {
                    where: {
                      id: p?.variant_id,
                    },
                  }),
                  attributes: ["id", "title", "price", "listPrice", "sku", "barcode", "inventory_quantity", "old_inventory_quantity", "isTaxable", "image_id", "height", "width", "length", "weightValue", "weightUnit"],
                  include: [
                    {
                      model: DB.ProductConfiguration,
                      as: "total_variant",
                      attributes: ["id", "variant_option_id"],
                      include: [
                        {
                          model: DB.VariationOption,
                          as: "variant_option",
                          attributes: ["value", "variation_id", "colorCode"],
                        },
                      ],
                    },
                    {
                      model: DB.Media,
                      as: "image",
                      attributes: ["media"],
                    },
                  ],
                },
                {
                  model: DB.ProductShippingDetails,
                  as: "shipping",
                },
                // {
                //   model: DB.Variation,
                //   as: "options",
                //   attributes: ["name"],
                //   include: [{ model: DB.VariationOption, as: "data", attributes: ["value", "colorCode"] }],
                // },
                {
                  model: DB.ProductInventory,
                  as: "inventoryPrice",
                  attributes: ["price", "listPrice", "quantity", "sku"],
                },
                {
                  model: DB.BusinessInformation,
                  as: "store",
                  attributes: ["id", "name", "logo_image", "banner_image"],
                },
              ],
              // raw: true,
            });
            let product = JSON.parse(JSON.stringify(single_product));

            if (product) {
              let ProductShippingDetails;
              if (p?.variant_id) {
                ProductShippingDetails = await DB.ProductItem.findOne({ where: { id: p?.variant_id }, raw: true });
              } else {
                ProductShippingDetails = await DB.ProductShippingDetails.findOne({ where: { product_id: p?.product }, raw: true });
              }
              function convertWeight(weightUnit_converFrom, weightUnit_converTo, weightValue) {
                const conversionRates = {
                  kg: {
                    kg: 1,
                    g: 1000,
                    lb: 2.20462,
                    oz: 35.274,
                  },
                  g: {
                    kg: 0.001,
                    g: 1,
                    lb: 0.00220462,
                    oz: 0.035274,
                  },
                  lb: {
                    kg: 0.453592,
                    g: 453.592,
                    lb: 1,
                    oz: 16,
                  },
                  oz: {
                    kg: 0.0283495,
                    g: 28.3495,
                    lb: 0.0625,
                    oz: 1,
                  },
                };

                if (!conversionRates[weightUnit_converFrom] || !conversionRates[weightUnit_converFrom][weightUnit_converTo]) {
                  throw new Error("Invalid weight units provided for conversion.");
                }

                const convertedValue = weightValue * conversionRates[weightUnit_converFrom][weightUnit_converTo];
                return convertedValue;
              }

              let convertedValue = 0
              if (single_product?.variant) {
                const weightValue = Number(ProductShippingDetails?.weightValue);
                console.log('ProductShippingDetails========', weightValue);
                convertedValue = convertWeight(ProductShippingDetails?.weightUnit, "lb", weightValue);
              }
              console.log('convertedValue', convertedValue);

              if (ProductShippingDetails) {
                orderItems.push({
                  weightValue: convertedValue > 0 ? convertedValue * p?.quantity : 0,
                  length: ProductShippingDetails?.length ? parseFloat(ProductShippingDetails.length) : 0,
                  width: ProductShippingDetails?.width ? parseFloat(ProductShippingDetails.width) : 0,
                  height: ProductShippingDetails?.height ? parseFloat(ProductShippingDetails.height) : 0,
                  // ...(ProductShippingDetails?.weightValue && { weightValue: parseFloat(ProductShippingDetails.weightValue), }),
                  // ...(ProductShippingDetails?.length && { length: ProductShippingDetails.length }),
                  // ...(ProductShippingDetails?.width && { width: ProductShippingDetails.width }),
                  // ...(ProductShippingDetails?.height && { height: ProductShippingDetails.height }),
                })

              }
            }
          }
          const data = orderItems;
          console.log('dasdasdasdasdasdasdasd', data);

          const result = data.reduce((acc, item) => {
            acc.length = Math.max(acc.length, item.length);
            acc.width = Math.max(acc.width, item.width);
            acc.height = Math.max(acc.height, item.height);
            acc.weightValue += item.weightValue;
            return acc;
          }, { weightValue: 0, length: 0, width: 0, height: 0 });


          const ratePayload = {
            "carrier_ids": [
              "se-5264045"
            ],
            "from_country_code": "US",
            "from_postal_code": shipping?.zipcode,
            "to_country_code": "US",
            "to_postal_code": "91521",
            "weight": {
              "value": result?.weightValue,
              "unit": "pound"
            },
            "dimensions": {
              "length": result?.length,
              "width": result?.width,
              "height": result?.height,
              "unit": "inch"
            }
          }

          try {
            let config = {
              method: "post",
              maxBodyLength: Infinity,
              url: "https://api.shipengine.com/v1/rates/estimate",
              headers: {
                "Content-Type": "application/json",
                "API-Key": process.env.SHIPENGINE_API_KEY,
              },
              data: ratePayload,
            };


            let response = await axios(config);
            const rates = response.data

            const groupedRates = rates.reduce((acc, rate) => {
              if (!acc[rate.delivery_days]) acc[rate.delivery_days] = [];
              acc[rate.delivery_days].push(rate);
              return acc;
            }, {});

            const minShippingRates = Object.values(groupedRates)
              .map(group => group.sort((a, b) => a.shipping_amount.amount - b.shipping_amount.amount)[0]);

            const lowestShippingAmounts = minShippingRates
              .sort((a, b) => a.shipping_amount.amount - b.shipping_amount.amount)
              .slice(0, 3);

            // rate_type: 'check',
            // carrier_id: 'se-5264045',
            // shipping_amount: { currency: 'usd', amount: 157.07 },
            // insurance_amount: { currency: 'usd', amount: 0 },
            // confirmation_amount: { currency: 'usd', amount: 0 },
            // other_amount: { currency: 'usd', amount: 25.9 },
            // requested_comparison_amount: { currency: 'usd', amount: 0 },
            // rate_details: [ [Object], [Object], [Object] ],
            // zone: null,
            // package_type: null,
            // delivery_days: 1,
            // guaranteed_service: true,
            // estimated_delivery_date: '2024-11-08T23:00:00Z',
            // carrier_delivery_days: 'Tomorrow by 11:00 PM',
            // ship_date: '2024-11-07T00:00:00Z',
            // negotiated_rate: false,
            // service_type: 'UPS Next Day Air Saver®',
            // service_code: 'ups_next_day_air_saver',
            // trackable: true,
            // carrier_code: 'ups',
            // carrier_nickname: 'ShipEngine Test Account - UPS',
            // carrier_friendly_name: 'UPS',
            // validation_status: 'unknown',
            // warning_messages: [],
            // error_messages: []

            console.log('lowestShippingAmounts', lowestShippingAmounts);
            return { success: true, message: "Fetch successfully", data: lowestShippingAmounts }
          } catch (error) {
            console.log("Ship Enginge - INTERNAL SERVER ERROR  : \n", error);
          }
          console.log(result);
          console.log('orderItems', orderItems);
        } else {
          return { success: false, message: "Please add Shpping Address or Make it default", data: lowestShippingAmounts }
        }
      }
    } catch (error) {
      console.log(error);
    }
  },

  getUSPSServices: async (root, args, { user }) => {
    // try {
    //   const baseURL = "https://api.shipengine.com/v1";

    //   const headers = {
    //     "API-Key": process.env.SHIPENGINE_API_KEY,
    //     "Content-Type": "application/json",
    //   };

    //   const carriersResponse = await axios.get(`${baseURL}/carriers`, {
    //     headers: headers,
    //   });

    //   const uspsCarrier = carriersResponse.data.carriers.find(
    //     (carrier) => carrier.carrier_code === "stamps_com"
    //   );

    //   if (!uspsCarrier) {
    //     throw new Error("USPS carrier not found");
    //   }

    //   const servicesResponse = await axios.get(
    //     `${baseURL}/carriers/${uspsCarrier.carrier_id}/services`,
    //     {
    //       headers: headers,
    //     }
    //   );

    //   console.log("servicesResponse", servicesResponse.data.services);

    //   // for (let i = 0; i < servicesResponse.data.services.length; i++) {
    //   //   let service = servicesResponse.data.services[i];
    //   //   const create_service = await DB.DeliveryServices.create({
    //   //     carrier_id: service.carrier_id,
    //   //     carrier_code: service.carrier_code,
    //   //     service_code: service.service_code,
    //   //     name: service.name,
    //   //     is_domestic: service.domestic,
    //   //     is_international: service.international,
    //   //     is_multi_package_supported: service.is_multi_package_supported,
    //   //   });
    //   //   console.log("create_services", create_service);
    //   // }


    // } catch (error) {
    //   console.error("Error in getUSPSServices:", error);
    //   throw new ApolloError("Failed to fetch USPS services");
    // }
    // try {
    //   const baseURL = 'https://api.shipengine.com/v1';
    //   const headers = {
    //     'API-Key': process.env.SHIPENGINE_API_KEY,
    //     'Content-Type': 'application/json'
    //   };

    //   const fromAddress = {
    //     name: "Sender Name",
    //     address_line1: "123 Main St",
    //     city_locality: "Austin",
    //     state_province: "TX",
    //     postal_code: "78701",
    //     country_code: "US",
    //     phone: "512-555-5555"
    //   };

    //   const toAddress = {
    //     name: "Recipient Name",
    //     address_line1: "456 Oak St",
    //     city_locality: "Los Angeles",
    //     state_province: "CA",
    //     postal_code: "90001",
    //     country_code: "US"
    //   };

    //   const packageDetails = {
    //     weight: {
    //       value: 1.5,
    //       unit: "pound"
    //     },
    //     dimensions: {
    //       length: 12,
    //       width: 8,
    //       height: 6,
    //       unit: "inch"
    //     }
    //   };

    //   const payload = {
    //     shipment: {
    //       service_code: 'usps_priority_mail',
    //       ship_to: toAddress,
    //       ship_from: fromAddress,
    //       packages: [packageDetails]
    //     }
    //   };

    //   const response = await axios.post(`${baseURL}/labels`, payload, { headers });

    //   console.log('response========', response.data);

    // } catch (error) {
    //   console.log('error =====>>', error);
    // }


    try {
      const get_delivery_method = await DB.DeliveryServices.findAll({
        where: {
          is_active: true
        },
        raw: true
      })

      return { success: true, message: "Services Fetch Successfully", data: get_delivery_method }
    } catch (error) {
      console.log('error', error);

    }
  },

  getUSPSDeliveryTime: async (root, args, { user }) => {

    const fromAddress = {
      name: "Sender Name",
      address_line1: "123 Main St",
      city_locality: "Austin",
      state_province: "TX",
      postal_code: "78701",
      country_code: "US"
    };

    const toAddress = {
      name: "Recipient Name",
      address_line1: "456 Oak St",
      city_locality: "Los Angeles",
      state_province: "CA",
      postal_code: "90001",
      country_code: "US"
    };

    const packageDetails = {
      weight: {
        value: 1.5,
        unit: "pound"
      },
      dimensions: {
        length: 12,
        width: 8,
        height: 6,
        unit: "inch"
      }
    };

    try {
      const baseURL = 'https://api.shipengine.com/v1';
      const headers = {
        'API-Key': process.env.SHIPENGINE_API_KEY,
        'Content-Type': 'application/json'
      };

      const payload = {
        rate_options: {
          carrier_ids: [process.env.SHIPENGINE_CARRIER_ID]
        },
        shipment: {
          validate_address: 'no_validation',
          ship_to: toAddress,
          ship_from: fromAddress,
          packages: [packageDetails]
        }
      };

      const response = await axios.post(`${baseURL}/rates`, payload, { headers });

      const rates = response.data.rate_response.rates;
      return rates.map(rate => ({
        serviceCode: rate.service_code,
        serviceName: rate.service_type,
        estimatedDeliveryDate: rate.estimated_delivery_date,
        deliveryDays: rate.delivery_days
      }));
    } catch (error) {
      console.error('Error fetching USPS delivery time:', error.message);
      throw error;
    }
  },

  getShippingMethod: async (root, { store_id }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");

    let seller_id = user?.seller_id

    try {
      if (user?.token_type === "admin") {
        if (!store_id) {
          return { success: false, message: "store_id is mandatory!" }
        }
        const find_seller = await DB.BusinessInformation.findOne({
          where: {
            id: store_id
          },
          raw: true
        })
        seller_id = find_seller?.seller_id
      } else {
        seller_id = user.seller_id
      }

      const get_seller = await DB.ShippingMethod.findAll({
        where: {
          seller_id: seller_id,
          is_deleted: false
        },
        raw: true
      })
      return { success: true, message: "Shipping Method fetched Successfully!", data: get_seller }
    } catch (error) {
      console.error("Erro while fetching shipping method", error);
      throw new Error("An error occurred while fetching shipping method");
    }
  },

  getDeliveryServicesForFixedType: async (root, { }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    try {
      const servicesResponse = await axios.get("https://api.shipengine.com/v1/carriers", {
        headers: {
          "API-Key": process.env.SHIPENGINE_API_KEY
        }
      });
      let countryServicesRes = [];

      if (servicesResponse.status === 200) {
        servicesResponse?.data?.carriers?.map(item => item?.services?.map(item => countryServicesRes.push(item)));
      }

      return {
        success: true,
        message: "Delivery services fetched successfully.",
        data: countryServicesRes
      }
    } catch (error) {
      console.error("Error while fetching delivery services:", error);
      throw new Error("An error occurred while fetching delivery services");
    }
  }
};
