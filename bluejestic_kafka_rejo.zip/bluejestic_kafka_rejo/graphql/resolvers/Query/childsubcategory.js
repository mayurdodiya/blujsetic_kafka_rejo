const { AuthenticationError } = require("apollo-server-express");

const ChildSubCategoryService = require("../../../database/services/childsubcategory");

module.exports = {
  getAllChildSubCategory: async (root, args, { user }) => {
    if (user != null) {
      const allCategory = await ChildSubCategoryService.getAll();
      return allCategory;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
  getSingleChildSubCategory: async (_, { id }, { user }) => {
    if (user != null) {
      return ChildSubCategoryService.getById(id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
};
