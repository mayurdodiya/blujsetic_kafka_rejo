const { AuthenticationError } = require("apollo-server-express");
const database = require("../../../database/models");
const ProductService = require("../../../database/services/product");
const FollowStoreService = require("../../../database/services/followstore");
const { findCropImages } = require("../../../utils/utils");
const { Op, Sequelize, literal } = require("sequelize");
const { stringToUrl, mediaWithUrlAndnId } = require("../../../middlewares/utils");
const elasticClient = require("../../../services/elasticsearch");
const slugify = require("slugify");
const { v4: uuidv4 } = require("uuid");
const client = require("../../../services/elasticsearch/config/config");
const { default: axios } = require("axios");
const redisClient = require("../../../redis/redisClient");


module.exports = {
  // getAllProducts: async (root, args, { user }) => {
  //   try {
  //     // if (user != null) {
  //     let order = ["ASC", "DESC"];
  //     let order_by, order_type;
  //     if (args.sort) {
  //       if (!args.sort.includes(":")) {
  //         return new Error("Invalid Sort Format");
  //       }
  //       order_by = args.sort.split(":")[0];
  //       order_type = args.sort.split(":")[1];
  //       if (!order.includes(order_type)) {
  //         return new AuthenticationError("Please Provide Valid Sort Order");
  //       }
  //     }
  //     let allProduct;
  //     let obj = {};
  //     if (args.category) {
  //       let category = await database.Category.findOne({ where: { name: args.category } });
  //       if (category) obj = { ...obj, category_id: String(category.id) };
  //     }
  //     if (args.subCategory) {
  //       let subCategory = await database.Subcategory.findOne({ where: { name: args.subCategory, category_id: obj.category_id } });
  //       if (subCategory) obj = { ...obj, subCategory_id: String(subCategory.id) };
  //     }
  //     if (args.childSubCategory || args.childSubCategory == "") {
  //       let childSubCategory = await database.Childsubcategory.findOne({
  //         where: { [Op.and]: { name: args.childSubCategory, category_id: Number(obj.category_id), sub_category_id: Number(obj.subCategory_id) } },
  //         raw: true,
  //       });
  //       if (childSubCategory) obj = { ...obj, childSubCategory_id: String(childSubCategory?.id) };
  //     }
  //     if (Object.values(obj).length > 0) {
  //       let productIDs = await database.ProductCategories.findAll({
  //         where: obj,
  //         raw: true,
  //         attributes: ["product_id"],
  //       });
  //       // unique product ids
  //       productIDs = [...new Set(productIDs.map((item) => item.product_id))];
  //       args.where = {
  //         ...args.where,
  //         id: productIDs,
  //       };
  //     }
  //     let categoriesWhere = {
  //       model: database.ProductCategories,
  //       as: "categories",
  //       include: [
  //         {
  //           model: database.Category,
  //           as: "category",
  //         },
  //         {
  //           model: database.Subcategory,
  //           as: "subCategory",
  //         },
  //         {
  //           model: database.Childsubcategory,
  //           as: "childSubCategory",
  //         },
  //       ],
  //     };
  //     args.where = { ...args.where, is_deleted: false };
  //     console.log("args.where", args.where);
  //     // return
  //     allProduct = await database.Product.findAll({
  //       where: args.where || {},
  //       limit: args.limit,
  //       order: [[order_by || "createdAt", order_type || "ASC"]],
  //       include: [
  //         {
  //           model: database.ProductShippingDetails,
  //           as: "shipping",
  //         },
  //         {
  //           model: database.ProductSEO,
  //           as: "productSEO",
  //         },
  //         {
  //           model: database.ProductOtherInformations,
  //           as: "other",
  //         },
  //         {
  //           model: database.Color,
  //           as: "colors",
  //         },
  //         {
  //           model: database.Size,
  //           as: "sizes",
  //         },
  //         {
  //           model: database.ProductAttributes,
  //           as: "attributes",
  //         },
  //         /* category filter */
  //         categoriesWhere,
  //       ],
  //     });

  //     for (const product of allProduct) {
  //       // for crop images
  //       if (product.cropImages && product.cropImages.length > 0) {
  //         product.cropImages = product.cropImages.map((file) => {
  //           file.mediaId = file.oldFile;
  //           file.croppedFile.mediaId = file.croppedFile.baseURL;
  //           return file;
  //         });
  //         product.cropImages = await findCropImages(product.cropImages);
  //         product.image = product.cropImages.map(({ croppedFile }) => {
  //           return { url: croppedFile.baseURL };
  //         });
  //       }
  //       /* share count */
  //       product.shareCount = await database.SharePost.count({
  //         where: { product_id: product.id },
  //       });

  //       /* like count */
  //       product.likeCount = await database.Like.count({
  //         where: { product_id: product.id },
  //       });
  //       /* comment count */
  //       product.commentCount = await database.Comment.count({
  //         where: { product_id: product.id },
  //       });
  //       /* customers */
  //       let orders = [
  //         ...new Set(
  //           (
  //             await database.ConfirmedOrder.findAll({
  //               where: {
  //                 productId: {
  //                   [Op.contains]: [product.id],
  //                 },
  //                 isPaymentDone: true,
  //               },
  //               attributes: ["userId"],
  //               raw: true,
  //             })
  //           ).map(({ userId }) => userId)
  //         ),
  //       ];

  //       /* customers count */
  //       product.customersCount = orders.length;

  //       /*customers -  users */
  //       product.customers = await database.User.findAll({
  //         where: {
  //           id: orders,
  //         },
  //         limit: 3,
  //         attributes: ["id", "firstName", "lastName", "profileAvtar"],
  //         raw: true,
  //       });

  //       if (user?.id) {
  //         let find_bookmark_bool = await database.Bookmark.findOne({
  //           where: {
  //             product_id: product.id,
  //             user_id: user.id,
  //           },
  //         });
  //         product.isBookMarked = find_bookmark_bool ? true : false;
  //         product.bookmark_id = find_bookmark_bool ? find_bookmark_bool?.id : null;
  //       }

  //       for (let i = 0; i < product.customers.length; i++) {
  //         const user = product.customers[i];
  //         user.profileAvtar = (
  //           await database.Media.findAll({
  //             where: {
  //               id: {
  //                 [Op.in]: user.profileAvtar,
  //               },
  //             },
  //             raw: true,
  //           })
  //         ).map(({ media }) => media);
  //       }
  //       console.log("orders", 1111111, product.customers);
  //     }
  //     return allProduct;
  //     // } else {
  //     //   return new AuthenticationError("Please Provide the token");
  //     // }
  //   } catch (error) {
  //     console.log("error", error);
  //     throw error;
  //   }
  // },

  getAllProducts: async (root, args, { user }) => {
    try {
      let imagelimit = args?.imagelimit ? args?.imagelimit : null;
      let order = ["ASC", "DESC"];
      let order_by, order_type;

      if (args?.limit && args?.page) {
        var offset = (parseInt(args?.page) - 1) * args.limit;
        args.limit = parseInt(args.limit);
      }
      if (args.sort) {
        if (!args.sort.includes(":")) {
          return new Error("Invalid Sort Format");
        }
        order_by = args.sort.split(":")[0];
        order_type = args.sort.split(":")[1];
        if (!order.includes(order_type)) {
          return new AuthenticationError("Please Provide Valid Sort Order");
        }
      }
      if (args?.minPrice && args?.maxPrice) {
        args.where = {
          ...(args?.minPrice &&
            args?.maxPrice && {
            price: {
              [Op.and]: [literal(`CAST(dis_price AS DECIMAL) >= ${args?.minPrice}`), literal(`CAST(dis_price AS DECIMAL) <= ${args?.maxPrice}`)],
            },
          }),
        };
      }
      let allProduct;
      let obj = {};
      if (args?.category) {
        let category = await database.Category.findOne({ where: { name: args?.category } });
        let category_data = JSON.parse(JSON.stringify(category));
        if (category_data) obj = { ...obj, category_id: String(category_data.id) };
      }
      if (args?.subCategory) {
        let subCategory = await database.Subcategory.findOne({ where: { name: args?.subCategory, category_id: Number(obj?.category_id), is_deleted: false } });
        let subcategory_data = JSON.parse(JSON.stringify(subCategory));
        // if (subCategory) obj = { ...obj, subCategory_id: String(subCategory.id) };
        if (subcategory_data) obj = { ...obj, subCategory_id: String(subcategory_data.id) };
      }
      if (args?.childSubCategory) {
        let childSubCategory = await database.Childsubcategory.findOne({
          where: { [Op.and]: { slug: args?.childSubCategory, category_id: Number(obj.category_id), sub_category_id: Number(obj.subCategory_id) } },
        });
        let childSubCategory_data = JSON.parse(JSON.stringify(childSubCategory));
        if (childSubCategory_data) obj = { ...obj, childSubCategory_id: String(childSubCategory_data?.id) };
      }

      // const redisKey = `ALL_PRODUCTS:${args.category}:${args.subCategory}:${args.childSubCategory}:${parseInt(args.page)}:${parseInt(args.limit)}`;

      if (Object.values(obj).length > 0) {
        let productIDs = await database.ProductCategories.findAll({
          where: obj,
          raw: true,
          attributes: ["product_id"],
        });
        // unique product ids
        productIDs = [...new Set(productIDs.map((item) => item.product_id))];
        args.where = {
          ...args.where,
          // ...(productIDs?.length > 0 && {
          id: productIDs,
          // }),
        };
      }
      args.where = { ...args.where, is_deleted: false };
      if (args?.isShopifyProduct) {
        args.where = {
          ...args.where,
          shopify_product_id: {
            [Sequelize.Op.not]: null,
          },
        };
      }
      if (args?.store_id) {
        args.where = {
          ...args.where,
          store_id: args.store_id,
        };
      }
      args.where = { ...args.where, is_deleted: false };

      // Check if products are there in redis or not 
      // const products = await redisClient.get(redisKey);
      // if (products) {
      //   return { success: true, message: "Product Data Fetched Successfully", data: JSON.parse(products) };
      // }

      let get_allProduct = await database.Product.findAll({
        where: args.where,
        // where: { id: [1068, 1069, 1070, 1071, 1072, 1073, 1074, 1075, 1076, 1077, 1078, 1079, 1080, 1081, 1082, 1083, 1084, 1085], is_deleted: false },
        limit: args?.limit ? args?.limit : 10,
        offset: offset ? offset : 0,
        attributes: {
          include: [
            [Sequelize.literal('(SELECT COUNT(*) FROM "Likes" AS "variants" WHERE "product_id" = "Product"."id")'), "like_count"],
            [Sequelize.literal('(SELECT COUNT(*) FROM "Comments" AS "variants" WHERE "product_id" = "Product"."id")'), "comment_count"],
            [Sequelize.literal('(SELECT COUNT(*) FROM "SharePosts" AS "variants" WHERE "product_id" = "Product"."id")'), "sharepost_count"],
            [Sequelize.literal('(SELECT COUNT(*) FROM "ProductItems" AS "variants" WHERE "product_id" = "Product"."id")'), "total_variants"],
            [Sequelize.literal('(SELECT SUM("inventory_quantity") FROM "ProductItems" AS "variants" WHERE "product_id" = "Product"."id")'), "total_inventory_quantity"],
          ],
        },
        include: [
          {
            model: database.ProductMedia,
            as: "images",
            separate: true, // Load separately to avoid conflict
            ...(imagelimit && {
              limit: imagelimit,
            }),
            attributes: ["src"],
            order: [["position", "ASC"]],
          },
          {
            model: database.ProductInventory,
            as: "inventoryPrice",
            attributes: ["price", "listPrice", "quantity", "sku"],
          },
          {
            model: database.Bookmark,
            as: "bookmark",
            attributes: ["id", "collection_id"],
            include: [
              {
                model: database.BookmarkCollection,
                as: "collection",
                attributes: ["id", "name", "user_id", "isPrivate"],
              },
            ],
          },
          {
            model: database.Like,
            as: "likes",
            required: false,
            where: {
              ...(user?.id && {
                user_id: user?.id,
              }),
            },
            // include: [
            //   {
            //     model: database.User,
            //     as: "user",
            //   },
            // ],
          },
        ],
        order: [
          args?.order === "like_count" ? [[Sequelize.literal("like_count"), "DESC"]] : [["createdAt", "DESC"]],
          // [
          //   {
          //     model: database.ProductMedia,
          //     as: "images",
          //   },
          //   "position",
          //   "ASC",
          // ],
        ],
      });


      // let get_allProduct = [];

      // let find_prod = await database.Product.findAll({
      //   attributes: {
      //     include: [
      //       [Sequelize.literal('(SELECT COUNT(*) FROM "Likes" AS "variants" WHERE "product_id" = "Product"."id")'), "like_count"],
      //       [Sequelize.literal('(SELECT COUNT(*) FROM "Comments" AS "variants" WHERE "product_id" = "Product"."id")'), "comment_count"],
      //       [Sequelize.literal('(SELECT COUNT(*) FROM "SharePosts" AS "variants" WHERE "product_id" = "Product"."id")'), "sharepost_count"],
      //       [Sequelize.literal('(SELECT COUNT(*) FROM "ProductItems" AS "variants" WHERE "product_id" = "Product"."id")'), "total_variants"],
      //       [Sequelize.literal('(SELECT SUM("inventory_quantity") FROM "ProductItems" AS "variants" WHERE "product_id" = "Product"."id")'), "total_inventory_quantity"],
      //     ],
      //   },
      //   where: {
      //     store_id: 300,
      //   },
      //   // group: ["Product.id"],
      //   order: [[Sequelize.literal("like_count"), "ASC"]],
      // });

      // console.log("find_prod+++++++++++++++++++++++", find_prod);

      let all_product = await JSON.parse(JSON.stringify(get_allProduct));
      // await redisClient.set(redisKey, JSON.stringify(all_product), 'EX', 3600 * 1);
      // let updated_products = await all_product?.map((prd) => {
      //   return {
      //     ...prd,
      //     like_count: prd?.like_count,
      //     comment_count: prd?.comment_count,
      //     sharepost_count: prd?.sharepost_count,
      //     total_variants: prd?.total_variants,
      //     total_inventory_quantity: prd?.total_inventory_quantity,
      //   };
      // });
      // return updated_products;

      let total_count = await database.Product.count({
        where: args.where,
      });

      return { success: true, message: "Product fetch successfully", data: all_product, total: total_count };
    } catch (error) {
      console.log("error", error);
      throw error;
    }
  },

  getAllProductByLike: async (root, args, { user }) => {
    try {
      if (args?.limit && args?.page) {
        var offset = (parseInt(args?.page) - 1) * args.limit;
        args.limit = parseInt(args.limit);
      }
      const topProducts = await database.Product.findAll({
        include: [
          {
            model: database.Like,
            as: "productLikes",
            attributes: [],
            required: false,
            // where: {
            //   ...(user?.id && {
            //     user_id: user?.id,
            //   }),
            // },
          },
          {
            model: database.ProductMedia,
            as: "images",
            // separate: true,
            ...(true && {
              limit: 1,
            }),
            attributes: ["src"],
            order: [["position", "ASC"]],
          },
        ],
        where: {
          is_deleted: false,
          status: "Publish",
        },
        attributes: ["id", "title", "dis_price", "dis_listPrice", "slug", [Sequelize.fn("COUNT", Sequelize.col("productLikes.product_id")), "like_count"]],
        // attributes: ["id", "title", "dis_price", "dis_listPrice", "slug", [Sequelize.cast(Sequelize.fn("COUNT", Sequelize.col("productLikes.product_id")), "integer"), "likeCount"]],
        group: ["Product.id"],
        order: [[Sequelize.fn("COUNT", Sequelize.col("productLikes.product_id")), "DESC"]],
        limit: args?.limit ? args?.limit : 10,
        offset: offset ? offset : 0,
        subQuery: false,
      });

      console.log("topProducts++++++++++++++++++++++++++", JSON.parse(JSON.stringify(topProducts)));

      return { success: true, message: "Product fetched successfully", data: JSON.parse(JSON.stringify(topProducts)) };
    } catch (error) {
      console.error("Error fetching all the product ", error);
      return {
        success: false,
        message: error?.message ?? ""
      }
    }
  },

  getProductImages: async (root, { product_id }, { user }) => {
    try {
      // const get_product_images = await database.ProductMedia.findAll({
      //   where: {
      //     product_id: product_id,
      //   },
      //   attributes: ["src", "position"],
      //   order: [["position", "ASC"]],
      //   raw: true,
      // });

      let get_allProduct = await database.Product.findOne({
        where: {
          id: product_id,
        },
        include: [
          {
            model: database.ProductMedia,
            as: "images",
            attributes: ["src", "position"],
          },
        ],
        order: [
          [
            {
              model: database.ProductMedia,
              as: "images",
            },
            "position",
            "ASC",
          ],
        ],
      });

      return {
        success: true,
        message: "Fetch Successfully",
        data: get_allProduct,
      };
    } catch (error) {
      console.log("error", error);
    }
  },

  getAllProductByStore: async (root, args, { user }) => {
    let offset, limit;
    if (args?.limit && args?.page) {
      limit = parseInt(args?.limit);
      offset = (parseInt(args?.page) - 1) * limit;
    }
    let order = args?.order ? args?.order : "";

    let isUnassigned = args?.isUnassigned ? true : false;
    let search = args?.search;
    let status = args?.status;
    const categoryIds = args?.category ? args?.category : [];
    const subCategoryIds = args?.subCategory ? args?.subCategory : [];
    const childSubCategoryIds = args?.childSubCategory ? args?.childSubCategory : [];

    // Key to get all the products
    // let redisKey = `PRODUCTS:store_id=${args?.store_id || ''}:minPrice=${args?.minPrice}:maxPrice=${args?.maxPrice}:page=${parseInt(args?.page)}:limit=${parseInt(args.limit)}`;
    // if (status && status !== "") {
    //   redisKey = `PRODUCTS:store_id=${args?.store_id || ''}:minPrice=${args?.minPrice}:maxPrice=${args?.maxPrice}:status=${status}:page=${parseInt(args?.page)}:limit=${parseInt(args.limit)}`;
    // }
    // if (search && search !== "") {
    //   redisKey = `PRODUCTS:store_id=${args?.store_id || ''}:minPrice=${args?.minPrice}:maxPrice=${args?.maxPrice}:search=${search}:page=${parseInt(args?.page)}:limit=${parseInt(args.limit)}`;
    // }


    let order_data = ["createdAt", "ASC"];
    if (order === "Date Created") {
      order_data = ["createdAt", "DESC"];
    } else if (order === "A-Z") {
      order_data = ["title", "ASC"];
    } else if (order === "Z-A") {
      order_data = ["title", "DESC"];
    }

    let product_filter = Op.or;
    let prodcut_data = [];
    if (categoryIds?.length > 0 && subCategoryIds?.length === 0 && childSubCategoryIds?.length === 0) {
      product_filter = Op.or;
      prodcut_data = [{ category_id: categoryIds }, { subCategory_id: subCategoryIds }, { childSubCategory_id: childSubCategoryIds }];
    } else if (categoryIds?.length > 0 && subCategoryIds?.length > 0 && childSubCategoryIds?.length === 0) {
      product_filter = Op.and;
      prodcut_data = [{ category_id: categoryIds }, { subCategory_id: subCategoryIds }];
    } else if (categoryIds?.length > 0 && subCategoryIds?.length > 0 && childSubCategoryIds?.length > 0) {
      product_filter = Op.and;
      prodcut_data = [{ category_id: categoryIds }, { subCategory_id: subCategoryIds }, { childSubCategory_id: childSubCategoryIds }];
    }

    try {
      // let total_count = await database.Product.count({
      //   where: {
      //     ...(user?.token_type !== "admin" && {
      //       status: "Publish",
      //     }),
      //     ...(args?.store_id &&
      //       !isUnassigned && {
      //       store_id: args.store_id,
      //     }),
      //     ...(isUnassigned && {
      //       store_id: null,
      //     }),
      //     ...(status && {
      //       status: status,
      //     }),
      //     ...(search && {
      //       title: {
      //         [Op.iLike]: `%${search}%`,
      //       },
      //     }), 
      //     ...(args?.minPrice &&
      //       args?.maxPrice && {
      //         dis_price: {
      //         [Op.and]: [literal(`CAST(dis_price AS DECIMAL) >= ${args?.minPrice}`), literal(`CAST(dis_price AS DECIMAL) <= ${args?.maxPrice}`)],
      //       },
      //     }),
      //     is_deleted: false,
      //   },
      //   // include: [
      //   //   {
      //   //     model: database.ProductCategories,
      //   //     as: "categories",
      //   //     ...((categoryIds?.length > 0 || subCategoryIds?.length > 0 || childSubCategoryIds?.length > 0) && {
      //   //       where: {
      //   //         [product_filter]: prodcut_data,
      //   //       },
      //   //     }),
      //   //     attributes: ["id", "category_id", "subCategory_id", "childSubCategory_id"],
      //   //     include: [
      //   //       {
      //   //         model: database.Category,
      //   //         as: "category",
      //   //       },
      //   //       {
      //   //         model: database.Subcategory,
      //   //         as: "subCategory",
      //   //       },
      //   //       {
      //   //         model: database.Childsubcategory,
      //   //         as: "childSubCategory",
      //   //       },
      //   //     ],
      //   //   },
      //   // ],
      // });

      // let getProductData = await redisClient.get(redisKey);
      // // Check if data is Cached
      // if (getProductData) {
        //   return { success: true, message: "Product Data Fetched Successfully", data: JSON.parse(getProductData), total: total_count };
      // }
      
      let get_allProduct = await database.Product.findAndCountAll({
        where: {
          ...(user?.token_type !== "admin" && {
            status: "Publish",
          }),
          ...(args?.store_id &&
            !isUnassigned && {
            store_id: args.store_id,
          }),
          ...(isUnassigned && {
            store_id: null,
          }),
          ...(status && {
            status: status,
          }),
          ...(search && {
            title: {
              [Op.iLike]: `%${search}%`,
            },
          }),
          ...(args?.minPrice &&
            args?.maxPrice && {
            dis_price: {
              [Op.and]: [literal(`CAST(dis_price AS DECIMAL) >= ${args?.minPrice}`), literal(`CAST(dis_price AS DECIMAL) <= ${args?.maxPrice}`)],
            },
          }),
          is_deleted: false,
        },
        attributes: {
          include: [
            [Sequelize.literal('(SELECT COUNT(*) FROM "Likes" AS "variants" WHERE "product_id" = "Product"."id")'), "like_count"],
            [Sequelize.literal('(SELECT COUNT(*) FROM "Comments" AS "variants" WHERE "product_id" = "Product"."id")'), "comment_count"],
            [Sequelize.literal('(SELECT COUNT(*) FROM "SharePosts" AS "variants" WHERE "product_id" = "Product"."id")'), "sharepost_count"],
            [Sequelize.literal('(SELECT COUNT(*) FROM "ProductItems" AS "variants" WHERE "product_id" = "Product"."id")'), "total_variants"],
            [Sequelize.literal('(SELECT SUM("inventory_quantity") FROM "ProductItems" AS "variants" WHERE "product_id" = "Product"."id")'), "total_variants_inventory_quantity"],
            [Sequelize.literal('(SELECT quantity::TEXT FROM "ProductInventories" AS "variants" WHERE "product_id" = "Product"."id")'), "total_inventory_quantity"],
            [Sequelize.literal(`(SELECT SUM(quantity)::TEXT FROM "OrderItems" AS "variants" WHERE "product_id" = "Product"."id" AND "order_status" = 'delivered')`), "total_sold"],
          ],
        },
        include: [
          // {
          //   model: database.ProductItem,
          //   as: "variants",
          //   attributes: ["id", "sku", "inventory_quantity"],
          // },
          // {
          //   model: database.Variation,
          //   as: "options",
          //   attributes: ["id", "name"],
          //   // where: {
          //   //   name: {
          //   //     [Op.iLike]: "%color%",
          //   //   },
          //   // },
          //   include: [
          //     {
          //       model: database.VariationOption,
          //       as: "data",
          //       attributes: ["id", "value", "colorCode"],
          //     },
          //   ],
          // },
          // ...((categoryIds?.length > 0 || subCategoryIds?.length > 0 || childSubCategoryIds?.length > 0) && {
          // {
          //   model: database.ProductCategories,
          //   as: "categories",
          //   ...((categoryIds?.length > 0 || subCategoryIds?.length > 0 || childSubCategoryIds?.length > 0) && {
          //     where: {
          //       [database.Sequelize.Op.or]: [{ category_id: categoryIds }, { subCategory_id: subCategoryIds }, { childSubCategory_id: childSubCategoryIds }],
          //     },
          //   }),
          // },
          {
            model: database.ProductCategories,
            as: "categories",
            ...((categoryIds?.length > 0 || subCategoryIds?.length > 0 || childSubCategoryIds?.length > 0) && {
              where: {
                [product_filter]: prodcut_data,
              },
            }),
            attributes: ["id", "category_id", "subCategory_id", "childSubCategory_id"],
            include: [
              {
                model: database.Category,
                as: "category",
              },
              {
                model: database.Subcategory,
                as: "subCategory",
              },
              {
                model: database.Childsubcategory,
                as: "childSubCategory",
              },
            ],
          },
          {
            model: database.Like,
            as: "likes",
            required: false,
            where: {
              ...(user?.id && {
                user_id: user?.id,
              }),
            },
            // include: [
            //   {
            //     model: database.User,
            //     as: "user",
            //   },
            // ],
          },
          {
            model: database.BusinessInformation,
            as: "store",
          },
          {
            model: database.ProductAttributes,
            as: "attributes",
            attributes: ["id", "name", "value", "type"],
          },
          {
            model: database.ProductMedia,
            as: "images",
            attributes: ["src", "media_id", "id", "position"],
          },
          {
            model: database.ProductInventory,
            as: "inventoryPrice",
            attributes: ["price", "listPrice", "quantity", "sku"],
          },
          {
            model: database.Bookmark,
            as: "bookmark",
            attributes: ["id", "collection_id"],
            include: [
              {
                model: database.BookmarkCollection,
                as: "collection",
                attributes: ["id", "name", "user_id", "isPrivate"],
              },
            ],
          },
        ],
        ...(args.limit && args.page && { limit: limit }),
        ...(args.page && args.limit && { offset: offset }),
        // limit: args?.limit ? args?.limit : 10,
        // offset: offset ? offset : 0,
        order: [
          order_data,
          [
            {
              model: database.ProductMedia,
              as: "images",
            },
            "position",
            "ASC",
          ],
        ],
        distinct: true,
        col: "id"
      });

      get_allProduct = JSON.parse(JSON.stringify(get_allProduct));


      // let all_product = await JSON.parse(JSON.stringify(get_allProduct));
      // await redisClient.set(redisKey, JSON.stringify(all_product), 'EX', 3600 * 1);

      // let total_count = await database.Product.count({
      //         where: {
      //           ...(user?.token_type !== "admin" && {
      //             status: "Publish",
      //           }),
      //           ...(args?.store_id &&
      //             !isUnassigned && {
      //             store_id: args.store_id,
      //           }),
      //           ...(isUnassigned && {
      //             store_id: null,
      //           }),
      //           ...(status !== "" && {
      //             status: status,
      //           }),
      //           title: {
      //             [database.Sequelize.Op.iLike]: `%${search}%`,
      //           },
      //           ...(args?.minPrice &&
      //             args?.maxPrice && {
      //             price: {
      //               [Op.and]: [literal(`CAST(dis_price AS DECIMAL) >= ${args?.minPrice}`), literal(`CAST(dis_price AS DECIMAL) <= ${args?.maxPrice}`)],
      //             },
      //           }),
      //           is_deleted: false,
      //         },
      //         // include: [
      //         //   {
      //         //     model: database.ProductCategories,
      //         //     as: "categories",
      //         //     ...((categoryIds?.length > 0 || subCategoryIds?.length > 0 || childSubCategoryIds?.length > 0) && {
      //         //       where: {
      //         //         [product_filter]: prodcut_data,
      //         //       },
      //         //     }),
      //         //     attributes: ["id", "category_id", "subCategory_id", "childSubCategory_id"],
      //         //     include: [
      //         //       {
      //         //         model: database.Category,
      //         //         as: "category",
      //         //       },
      //         //       {
      //         //         model: database.Subcategory,
      //         //         as: "subCategory",
      //         //       },
      //         //       {
      //         //         model: database.Childsubcategory,
      //         //         as: "childSubCategory",
      //         //       },
      //         //     ],
      //         //   },
      //         // ],
      //       }); 


      // let updated_products = await all_product?.map((prd) => {
      //   return {
      //     ...prd,
      //     like_count: prd?.like_count,
      //     comment_count: prd?.comment_count,
      //     sharepost_count: prd?.sharepost_count,
      //     total_variants: prd?.total_variants,
      //     total_inventory_quantity: prd?.total_inventory_quantity,
      //   };
      // });
      return { success: true, message: "Fetched products for sore Successfully", data: get_allProduct?.rows, total: get_allProduct?.count };
    } catch (error) {
      console.error("Error while fetching the products for store: ", error);
      return { success: false, message: error?.message ?? "Error while fetching the products for store"};
    }
  },

  getSingleProductById: async (root, args, { user }) => {
    try {
      const isExistProduct = await database.Product.findOne({
        where: {
          id: args.id,
          is_deleted: false,
        },
      });

      console.log("dasdasdasdasd====================================", JSON.parse(JSON.stringify(isExistProduct)), args.id);

      if (!isExistProduct) {
        return new Error("Product Not Found");
      } else {
        let get_allProduct = await database.Product.findOne({
          where: {
            id: args.id,
          },
          attributes: {
            include: [
              [Sequelize.literal('(SELECT COUNT(*) FROM "Likes" AS "variants" WHERE "product_id" = "Product"."id")'), "like_count"],
              [Sequelize.literal('(SELECT COUNT(*) FROM "Comments" AS "variants" WHERE "product_id" = "Product"."id")'), "comment_count"],
              [Sequelize.literal('(SELECT COUNT(*) FROM "SharePosts" AS "variants" WHERE "product_id" = "Product"."id")'), "sharepost_count"],
            ],
          },
          include: [
            {
              model: database.UserReviewsOnProducts,
              as: "userReviews",
              include: [
                {
                  model: database.User,
                  as: "user_details"
                },
                {
                  model: database.UserReviewsOnProductsMedias,
                  as: "userReviewsOnProductsMedias",
                }
              ]
            },
            {
              model: database.UserFeedbacksOnProducts,
              as: "userFeedbacks",
              include: [
                {
                  model: database.User,
                  as: "user_details"
                }
            ]
            },
            {
              model: database.ProductItem,
              as: "variants",
              attributes: ["id", "title", "price", "sku", "barcode", "inventory_quantity", "old_inventory_quantity", "isTaxable", "image_id"],
              include: [
                {
                  model: database.ProductConfiguration,
                  as: "total_variant",
                  attributes: ["variant_option_id"],
                  include: [
                    {
                      model: database.VariationOption,
                      as: "variant_option",
                      attributes: ["value", "variation_id", "colorCode"],
                    },
                  ],
                },
                {
                  model: database.Media,
                  as: "image",
                  attributes: ["media"],
                },
              ],
            },
            {
              model: database.ProductShippingDetails,
              as: "shipping",
            },
            {
              model: database.Variation,
              as: "options",
              attributes: ["name"],
              include: [{ model: database.VariationOption, as: "data", attributes: ["value", "colorCode"] }],
            },
            {
              model: database.ProductMedia,
              as: "images",
              attributes: ["src", "media_id"],
            },
            {
              model: database.ProductTag,
              as: "tags",
              attributes: ["tag"],
            },
            {
              model: database.ProductCategories,
              as: "categories",
              attributes: ["category_id", "subCategory_id", "childSubCategory_id"],
              include: [
                {
                  model: database.Category,
                  as: "category",
                },
                {
                  model: database.Subcategory,
                  as: "subCategory",
                },
                {
                  model: database.Childsubcategory,
                  as: "childSubCategory",
                },
              ],
            },
            {
              model: database.ProductInventory,
              as: "inventoryPrice",
              attributes: ["price", "listPrice", "quantity", "sku"],
            },
            {
              model: database.ProductAttributes,
              as: "attributes",
              attributes: ["id", "name", "value", "type"],
            },
            {
              model: database.ProductImageSize,
              as: "size",
            },
          ],
        });

        let updated_product = {
          ...get_allProduct.dataValues,
          like_count: get_allProduct?.dataValues?.like_count,
          comment_count: get_allProduct?.dataValues?.comment_count,
          sharepost_count: get_allProduct?.dataValues?.sharepost_count,
        };
        return updated_product;
      }
    } catch (error) {
      console.log(error);
    }
  },


  getProductReviewsBySlug: async (root, { input }, { user }) => {
    try {
      const isExistProduct = await database.Product.findOne({
        where: {
          slug: input?.slug,
          is_deleted: false,
        },
      });

      if (!isExistProduct) {
        return new Error("Product Not Found");
      } else {

        let order_data = [["createdAt", "DESC"]];
        if (input?.order) {
          if (input?.order === "New to old") {
            order_data = [["createdAt", "DESC"]];
          } else if (input?.order === "Old to new") {
            order_data = [["createdAt", "ASC"]];
          }
        }
        let getSingleProductReviews = await database.Product.findOne({
          where: {
            slug: input?.slug,
            is_deleted: false,
          },
          include: [
            {
              model: database.UserReviewsOnProducts,
              as: "userReviews",
              ...(input?.rating && { where : { overAllRating: input?.rating  }}),
              include: [
                {
                  model: database.User,
                  as: "user_details"
                },
                {
                  model: database.UserReviewsOnProductsMedias,
                  as: "userReviewsOnProductsMedias",
                }
              ],
              separate: true,
              order: order_data
            },
          ],
        });

        getSingleProductReviews = JSON.parse(JSON.stringify(getSingleProductReviews));

        return {
          success: true,
          message: "Product reviews fetched successfully.",
          data: getSingleProductReviews
        }


      }
    } catch (error) {
      console.error("An error occured while fetching product reviews: ", error);
      return {
        success: false,
        message: "An error occured while fetching product reviews: "
      }
    }
  },

  searchProducts: async (root, args, { user }) => {
    if (user != null) {
      let order = ["ASC", "DESC"];
      let order_by, order_type;
      if (args.sort) {
        if (!args.sort.includes(":")) {
          return new Error("Invalid Sort Format");
        }
        order_by = args.sort.split(":")[0];
        order_type = args.sort.split(":")[1];
        if (!order.includes(order_type)) {
          return new AuthenticationError("Please Provide Valid Sort Order");
        }
      }
      let allProduct;

      if (args.category) {
        let obj = {};
        let category = await database.Category.findAll({
          where: {
            name: {
              [Op.iRegexp]: args.category,
            },
          },
        });
        if (category)
          obj = {
            ...obj,
            category_id: category.map((item) => item.id),
          };
        let subCategory = await database.Subcategory.findAll({
          where: {
            name: {
              [Op.iRegexp]: args.category,
            },
          },
        });
        if (subCategory) obj = { ...obj, subCategory_id: subCategory.map((item) => item.id) };
        let childSubCategory = await database.Childsubcategory.findAll({
          where: {
            name: {
              [Op.iRegexp]: args.category,
            },
          },
        });
        if (childSubCategory) obj = { ...obj, childSubCategory_id: childSubCategory.map((item) => item.id) };
        let data = Object.keys(obj).map((key) => ({ [key]: obj[key] }));
        let productIDs = await database.ProductCategories.findAll({
          where: {
            [Op.or]: data,
          },
          raw: true,
          attributes: ["product_id"],
        });
        // unique product ids
        productIDs = [...new Set(productIDs.map((item) => item.product_id))];
        args.where = { ...args.where, id: productIDs };
        console.log("obj", 1111, obj);
      }
      if (args.search) {
        args.where = {
          ...args.where,
          [Op.or]: [{ title: { [Op.iRegexp]: args.search } }],
        };
      }
      args.where = { ...args.where, is_deleted: false };
      allProduct = await database.Product.findAll({
        where: args.where || {},
        limit: args.limit,
        order: [[order_by || "createdAt", order_type || "ASC"]],
        include: [
          {
            model: database.ProductShippingDetails,
            as: "shipping",
          },
          {
            model: database.ProductOtherInformations,
            as: "other",
          },
          {
            model: database.Color,
            as: "colors",
          },
          {
            model: database.Size,
            as: "sizes",
          },
          {
            model: database.ProductAttributes,
            as: "attributes",
          },
          {
            model: database.ProductCategories,
            as: "categories",
            include: [
              {
                model: database.Category,
                as: "category",
              },
              {
                model: database.Subcategory,
                as: "subCategory",
              },
              {
                model: database.Childsubcategory,
                as: "childSubCategory",
              },
            ],
          },
          {
            model: database.Comment,
            as: "productComments",
            // where: { comment_for: "product" },
            include: [
              {
                model: database.User,
                as: "user",
              },
            ],
          },
        ],
      });

      for (const product of allProduct) {
        // Images Ids and createurl link
        let images = [];
        let video = [];
        if (product.image !== null) {
          // convert in array
          images = product.image;
          video = product.video;
          // check is array or not
          if (Array.isArray(images)) {
            if (images.length === 0) {
              product.image = [];
              product.filterImage = [];
            } else {
              let validImage = await stringToUrl(images, product.id);
              product.image = validImage ? validImage : [];
            }
          }

          video = product.video;
          // check video
          if (Array.isArray(video)) {
            if (video.length === 0) {
              product.video = [];
            } else {
              let validVideo = await stringToUrl(video, product.id);
              product.video = validVideo ? validVideo : [];
            }
          }
        } else {
          product.video = [];
        }
      }
      return allProduct;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getSingleProduct: async (_, { slug }, { user }) => {
    try {
      const isExistProduct = await database.Product.findOne({
        where: {
          slug: slug,
          is_deleted: false,
        },
      });

      console.log("getSingleProduct++++++++++", isExistProduct);

      if (isExistProduct === null) {
        return new Error("Product Not Found");
      } else {
        let get_allProduct = await database.Product.findOne({
          where: {
            slug: slug,
          },
          attributes: {
            include: [
              [Sequelize.literal('(SELECT COUNT(*) FROM "Likes" AS "variants" WHERE "product_id" = "Product"."id")'), "like_count"],
              [Sequelize.literal('(SELECT COUNT(*) FROM "Comments" AS "variants" WHERE "product_id" = "Product"."id")'), "comment_count"],
              [Sequelize.literal('(SELECT COUNT(*) FROM "SharePosts" AS "variants" WHERE "product_id" = "Product"."id")'), "sharepost_count"],
            ],
          },
          include: [
            {
              model: database.UserReviewsOnProducts,
              as: "userReviews",
              include: [
                {
                  model: database.User,
                  as: "user_details"
                },
                {
                  model: database.UserReviewsOnProductsMedias,
                  as: "userReviewsOnProductsMedias",
                }
              ]
            },
            {
              model: database.UserFeedbacksOnProducts,
              as: "userFeedbacks",
              include: [
                {
                    model: database.User,
                    as: "user_details"
                }
              ]
            },
            {
              model: database.ProductItem,
              as: "variants",
              attributes: ["id", "title", "price", "listPrice", "sku", "barcode", "inventory_quantity", "old_inventory_quantity", "isTaxable", "image_id", "height", "width", "length", "weightValue", "weightUnit"],
              include: [
                {
                  model: database.ProductConfiguration,
                  as: "total_variant",
                  attributes: ["id", "variant_option_id"],
                  include: [
                    {
                      model: database.VariationOption,
                      as: "variant_option",
                      attributes: ["value", "variation_id", "colorCode"],
                    },
                  ],
                },
                {
                  model: database.Media,
                  as: "image",
                  attributes: ["media"],
                },
              ],
            },
            {
              model: database.ProductShippingDetails,
              as: "shipping",
            },
            {
              model: database.Variation,
              as: "options",
              attributes: ["name"],
              include: [{ model: database.VariationOption, as: "data", attributes: ["value", "colorCode"] }],
            },
            {
              model: database.ProductMedia,
              as: "images",
              attributes: ["src", "media_id"],
            },
            {
              model: database.ProductTag,
              as: "tags",
              attributes: ["tag"],
            },
            {
              model: database.ProductCategories,
              as: "categories",
              attributes: ["category_id", "subCategory_id", "childSubCategory_id"],
              include: [
                {
                  model: database.Category,
                  as: "category",
                },
                {
                  model: database.Subcategory,
                  as: "subCategory",
                },
                {
                  model: database.Childsubcategory,
                  as: "childSubCategory",
                },
              ],
            },
            {
              model: database.ProductInventory,
              as: "inventoryPrice",
              attributes: ["price", "listPrice", "quantity", "sku"],
            },
            {
              model: database.ProductAttributes,
              as: "attributes",
              attributes: ["id", "name", "value", "type"],
            },
            {
              model: database.ProductImageSize,
              as: "size",
            },
            {
              model: database.BusinessInformation,
              as: "store",
            },
            {
              model: database.Bookmark,
              as: "bookmark",
              attributes: ["id", "collection_id"],
              include: [
                {
                  model: database.BookmarkCollection,
                  as: "collection",
                  attributes: ["id", "name", "user_id", "isPrivate"],
                },
              ],
            },
          ],
          order: [
            [
              {
                model: database.ProductMedia,
                as: "images",
              },
              "position",
              "ASC",
            ],
          ],
        });
        let data = {
          ...get_allProduct.dataValues,
          like_count: get_allProduct?.dataValues?.like_count,
          comment_count: get_allProduct?.dataValues?.comment_count,
          sharepost_count: get_allProduct?.dataValues?.sharepost_count,
        };
        return data;
      }
    } catch (error) {
      console.log(error);
    }
  },

  getFeatureProduct: async (root, { store_id }, { user }) => {
    if (user != null) {
      let allProduct;
      // get categories data
      allProduct = await database.Product.findAll({
        where: { isFeature: true, isVisible: true, store_id, is_deleted: false },
        limit: 5,
        attributes: [
          "id",
          "title",
          "description",
          "image",
          "cropImages",
          "price",
          "listPrice",
          [
            Sequelize.literal(`(
              case when (select 1 from "Products" p,"Likes" l  where  p.id="Product"."id" and p.id =l.product_id and l.user_id = ${user.id} limit 1) = 1 then true else false end
              )`),
            "likeStatus",
          ],
        ],
      });
      allProduct = JSON.parse(JSON.stringify(allProduct));
      for await (const product of allProduct) {
        //   // crop images
        if (product.cropImages && product.cropImages.length > 0) product.cropImages = await findCropImages(product.cropImages);
        product.image = product.cropImages.map(({ croppedFile }) => croppedFile.baseURL);
      }
      return allProduct;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getAllProductsByIds: async (root, { input }, { user }) => {
    if (user != null) {
      let allProduct;
      // get categories data
      let ids = input.products.map((item) => item.productId);
      if (ids.length === 0) {
        return {
          success: false,
          message: "Inavalid Expression",
          data: [],
        };
      }
      allProduct = await ProductService.getAllById(ids);

      for (const product of allProduct) {
        // Images Ids and createurl link
        let images = [];
        if (product.image !== null) {
          // convert in array
          if (product.image.includes("{") && product.image.includes("}")) {
            images = JSON.parse(product.image.replace(/{/g, "[").replace(/}/g, "]"));
            // check is array or not
            if (Array.isArray(images)) {
              if (images.length === 0) {
                product.image = [];
              } else {
                let validImage = await stringToUrl(images, product.id);
                product.image = validImage ? images : [];
              }
            }
          }
        } else {
          product.image = [];
        }
      }
      return {
        success: true,
        message: "Success",
        data: allProduct,
      };
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getProductMetrics: async (root, args, { user }) => {
    try {
      // let { store_id } = args;
      if (!user || !user?.store_id) {
        return new AuthenticationError("Please provide Valid Token.");
      }
      let metrics = await elasticClient.product.getInventoryMetrics("products", { store_id: user?.store_id });
      if (metrics && metrics.success === false) {
        return { success: false, message: "Data not found", data: [] };
      }
      return { success: true, message: "Data successfully", data: metrics.data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  getOrderSales: async (root, args, { user }) => {
    try {
      if (!user || !user?.store_id) {
        return new AuthenticationError("Please provide Valid Token.");
      }
      let metrics = await elasticClient.product.getOrderSales("order_master", { store_id: user?.store_id });
      console.log('metricsdasdadadas', metrics);

      if (metrics && metrics.success === false) {
        return { success: false, message: "Data not found", data: [] };
      }
      return { success: true, message: "Data fetch successfully", data: metrics?.data };

    } catch (error) {
      console.log(error);

    }
  },

  getRevenueOverview: async (root, args, { user }) => { },

  getProductSoldAndShipped: async (root, args, { user }) => {
    try {
      let { store_id, start_date, end_date } = args;
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }
      let metrics = await elasticClient.product.getProductSoldAndShippedMetrics("products", { store_id, start_date, end_date });
      if (metrics && metrics.success === false) {
        return { success: false, message: "Data not found", data: [] };
      }
      return { success: true, message: "Data successfully", data: metrics.data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  getTopSellingProducts: async (root, args, { user }) => {
    if (!user || !user?.store_id) return new AuthenticationError("Please Provide the token");
    // let { store_id } = args;
    let products = await elasticClient.product.searchTopSellingProducts("products", { store_id: user?.store_id });
    if (products && products.success === false) {
      return { success: false, message: "Data not found", data: [] };
    }
    console.log("products", products.data[0]);
    return { success: true, message: "Data successfully", data: products.data };
  },

  getProductStockReport: async (root, args, { user }) => {
    if (!user || !user?.store_id) return new AuthenticationError("Please Provide the token");
    let { stock_status } = args;

    let products = await elasticClient.product.productStockFilter("products", { store_id: user?.store_id, stock_status });
    console.log("products", products);
    if (products && products.success === false) {
      return { success: false, message: products.message, data: [] };
    }
    // console.log("Productss", products);
    return { success: true, message: "Data successfully", data: products.data };
  },

  searchProductsWithElasticSearch: async (root, args, { user }) => {
    // if (!user) return new AuthenticationError("Please Provide the token");
    try {
      let { search, page, limit, minPrice, maxPrice } = args;
      console.log("searchProductsWithElasticSearch-callled +++++++++++++++++++++++++++++++++++");
      let products = await elasticClient.product.searchProductsWithElasticSearch("products", { search, page, limit, user_id: user?.id, minPrice, maxPrice });
      // return;
      if (products && products.success === false) {
        return { success: false, message: products.message, data: [] };
      }
      return { success: true, message: "Data successfully", data: products.data };
    } catch (error) {
      console.log(error);
    }
  },

  globalSearchWithElasticSearch: async (root, args, { user }) => {
    // if (!user) return new AuthenticationError("Please Provide the token");
    let { search, page, limit } = args;

    try {
      console.log("globalSearchWithElasticSearch-callled +++++++++++++++++++++++++++++++++++");
      let products = await elasticClient.product.globalSearchWithElasticSearch("products", { search, page, limit, user_id: user?.id });
      if (products && products.success === false) {
        return { success: false, message: products.message, data: [] };
      }
      return { success: true, message: "Data successfully", data: products.data };
    } catch (error) {
      console.log("error++++++++++++++++++++++", error);
    }
  },

  getAllSaveProductMetrics: async (root, args, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    let { store_id, start_date, end_date, time_interval, time_zone } = args;
    let products = await elasticClient.sharePosts.getAllSaveProductMetrics({ store_id, start_date, end_date, time_interval, time_zone });
    if (products && products.success === false) {
      return { success: false, message: products.message, data: [] };
    }
    return products;
  },

  getAllShareProductMetrics: async (root, args, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    let { store_id, start_date, end_date, time_interval, time_zone } = args;
    let products = await elasticClient.sharePosts.getAllShareProductMetrics({ store_id, start_date, end_date, time_interval, time_zone });
    if (products && products.success === false) {
      return { success: false, message: products.message, data: [] };
    }
    return products;
  },

  getProductSingleLike: async (root, { slug }, { user }) => {
    try {
      let isExist = false;

      const find_product = await database.Product.findOne({
        where: {
          slug: slug,
        },
        raw: true,
      });

      if (!find_product) return { success: false, message: "Product not found!" };

      const product_id = find_product?.id;

      if (product_id && user?.id) {
        const isLikeStore = await database.Like.findOne({
          where: {
            product_id: Number(product_id),
            user_id: Number(user?.id),
            like_for: "PRODUCT",
          },
          raw: true,
        });
        console.log("isLikeStore+++++++", isLikeStore);
        if (isLikeStore) {
          isExist = true;
        }
        return { success: true, message: "Fetch Successfully", isLike: isExist, like_id: isLikeStore?.id };
      } else {
        new AuthenticationError("Error in store id or user id");
      }
      return null;
    } catch (error) {
      console.log("ERRRRRRRRRR", error);
    }
  },

  addProductCall: async (root, args, { user }) => { },

  getProductTraction: async (root, args, { user }) => {
    try {
      // let { store_id, start_date, end_date, time_interval, time_zone } = args;

      let product_id = args?.product_id;
      let start_date = args?.start_date;
      let end_date = args?.end_date;
      let time_interval = args?.time_interval;
      let time_zone = args?.time_zone;

      // if (!user) {
      //   return new AuthenticationError("Please Provide the token");
      // }
      let data = await elasticClient.product.getProductTractionElasticSearch("product-views", { product_id, start_date, end_date, time_interval, time_zone });
      return { success: true, message: "Data successfully", data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },

  getAllProductByCategory: async (root, { category_id, subCategory_id, childSubCategory_id, limit, page }, { user }) => {
    try {
      if (limit && page) {
        var offset = (parseInt(page) - 1) * limit;
        limit = parseInt(limit);
      }
      const find_array = [];
      for (let i = 0; i < childSubCategory_id?.length; i++) {
        let child_cat_array = childSubCategory_id[i];
        let find_product = await database.ProductCategories.findAll({
          where: {
            // ...(category_id && {
            //   category_id: category_id,
            // }),
            // ...(subCategory_id && {
            //   subCategory_id: subCategory_id,
            // }),
            ...(child_cat_array && {
              childSubCategory_id: {
                [Op.in]: child_cat_array,
              },
            }),
          },
          attributes: ["id", "childSubCategory_id"],
          limit: limit,
          offset: offset,
          include: [
            {
              model: database.Childsubcategory,
              as: "childSubCategory",
              attributes: ["id", "name", "media", "banner_media"],
            },
            {
              model: database.Product,
              as: "product_data",
              where: {
                is_deleted: false,
              },
              // attributes: {
              //   include: [
              //     [Sequelize.literal('(SELECT COUNT(*) FROM "Likes" AS "variants" WHERE "product_id" = "product_data"."id")'), "like_count"],
              //     [Sequelize.literal('(SELECT COUNT(*) FROM "Comments" AS "variants" WHERE "product_id" = "product_data"."id")'), "comment_count"],
              //     [Sequelize.literal('(SELECT COUNT(*) FROM "SharePosts" AS "variants" WHERE "product_id" = "product_data"."id")'), "sharepost_count"],
              //     [Sequelize.literal('(SELECT COUNT(*) FROM "ProductItems" AS "variants" WHERE "product_id" = "product_data"."id")'), "total_variants"],
              //     [Sequelize.literal('(SELECT SUM("inventory_quantity") FROM "ProductItems" AS "variants" WHERE "product_id" = "product_data"."id")'), "total_inventory_quantity"],
              //   ],
              // },
              include: [
                {
                  model: database.ProductMedia,
                  as: "images",
                  limit: 1,
                  attributes: ["src"],
                },
                // {
                //   model: database.ProductInventory,
                //   as: "inventoryPrice",
                //   attributes: ["price", "listPrice", "quantity", "sku"],
                // },
                // {
                //   model: database.Like,
                //   as: "likes",
                //   attributes: ["id"],
                // },
                // {
                //   model: database.Bookmark,
                //   as: "bookmark",
                //   attributes: ["id", "collection_id"],
                //   include: [
                //     {
                //       model: database.BookmarkCollection,
                //       as: "collection",
                //       attributes: ["id", "name", "user_id", "isPrivate", "slug"],
                //     },
                //   ],
                // },
              ],
            },
          ],
        });
        let final_products = JSON.parse(JSON.stringify(find_product));

        let find_count = await database.ProductCategories.count({
          where: {
            ...(child_cat_array && {
              childSubCategory_id: {
                [Op.in]: child_cat_array,
              },
            }),
          },
        });
        find_array.push({ products: final_products, total_count: find_count });
      }

      // console.log("find_array++++++++++++++++", find_array[0]?.products[0]);

      return { success: true, message: "Product Fetch Successfully!", data: find_array };
    } catch (error) {
      console.log("error >>>>>>>>>>>>>>>>>>>>", error);
    }
  },

  verifyProduct: async (root, { slug, page, limit }, { user }) => {
    try {
      const verify_product = await database.Product.findOne({
        where: {
          slug: slug,
        },
        attributes: ["id"],
        raw: true,
      });
      if (verify_product) {
        return { success: true, message: "Product Fetch Successfully!" };
      }
      return { success: false, message: "Product not Found!" };
    } catch (error) {
      console.log(error);
    }
    //* script start

    // if (limit && page) {
    //   var offset = (parseInt(page) - 1) * limit;
    //   limit = parseInt(limit);
    // }

    // const find_product = await database.Product.findAll({
    //   limit: limit,
    //   offset: offset,
    //   where: {
    //     store_id: 351,
    //   },
    //   order: [["id", "DESC"]],
    //   attributes: ["id", "title", "slug"],
    //   raw: true,
    // });

    // // console.log('find_product=================', find_product);

    // // return

    // for (let i = 0; i < find_product?.length; i++) {
    //   let product = find_product[i];
    //   // if (!product?.slug) {
    //   let slug = slugify(product?.title, { lower: true, replacement: "-", remove: undefined, strict: true });
    //   let final_slug;

    //   let find_unique_user = await database.Product.findOne({
    //     where: {
    //       slug: slug,
    //     },
    //     // limit: limit,
    //     // offset: offset,
    //     raw: true,
    //   });

    //   if (!find_unique_user?.slug || find_unique_user?.slug === "") {
    //     final_slug = slug;
    //   } else {
    //     const uniqueId = uuidv4();
    //     final_slug = `${slug}-${uniqueId}`;
    //   }

    //   let [update] = await database.Product.update(
    //     {
    //       slug: final_slug,
    //     },
    //     {
    //       where: {
    //         id: product?.id,
    //       },
    //     }
    //   );

    //   const isExists = await client.search({
    //     index: "products",
    //     body: {
    //       query: {
    //         match: {
    //           id: product?.id,
    //         },
    //       },
    //     },
    //   });

    //   if (isExists?.hits?.hits?.[0]?._source) {
    //     let data = await elasticClient.product.updateProductById("products", product?.id, { ...isExists.hits.hits[0]._source, slug: final_slug });
    //     // if (!data.success) return new Error("Elasticsearch - addProduct - " + data.message);
    //   }

    //   if (Boolean(update)) {
    //     console.log(`>>+++++++ ${i + 1}, ${product?.id} +++++++<<`, product?.title, "===>", final_slug);
    //   }

    //   // return

    //   // } else {
    //   //   console.log("SLug Already Added  +++++++++++++++++++", `${product?.id} ++++ ${product?.slug}`);
    //   // }
    // }

    // const title = "Yeehaw Pink Bikini by Baha Ranch Western Wear";
  },

  getLikeByProduct: async (root, { product_id }, { user }) => {
    try {
      const get_like = await database.Like.findOne({
        where: {
          user_id: user?.id,
          product_id: product_id,
          like_for: "PRODUCT",
        },
        raw: true,
      });
      // console.log("get_like+++++++++++++++", get_like);
      return { success: true, message: "Fetch Like Succesfullly", data: { id: get_like?.id } };
    } catch (error) {
      console.log(error);
    }
  },

  getProductRecommendation: async (root, { type }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");

    const find_user = await database.User.findOne({
      where: {
        id: user?.id
      },
      attributes: ['id'],
      raw: true
    })
    if (!find_user) { return new AuthenticationError("User Not Found!"); }

    const Payload = {
      user_id: find_user?.id
    }

    try {
      let config = {
        method: "post",
        maxBodyLength: Infinity,
        url: "http://prodocts-recommendation-stage-svc.bluejestic.svc.cluster.local:5000/v1/userfeed/separate-recommendation",
        // url: "http://34.138.21.186:5000/v1/userfeed/separate-recommendation",
        headers: {
          "Content-Type": "application/json",
        },
        data: Payload,
      };

      let response = await axios(config);
      console.log('response', JSON.stringify(response?.data));
      let product_array = []

      switch (type) {
        case "recent_views":
          product_array = response?.data?.recent_views?.recommendations?.map((p) => { return p?.product_id })
          break;
        case "shopping_trend":
          product_array = response?.data?.shopping_trend?.recommendations?.map((p) => p?.product_id)
          break;
        case "collections":
          product_array = response?.data?.collections?.recommendations?.map((p) => p?.product_id)
          break;
        case "likes":
          product_array = response?.data?.likes?.recommendations?.map((p) => p?.product_id)
          break;
        default:
          break;
      }

      let get_allProduct = await database.Product.findAll({
        where: {
          id: {
            [Op.in]: product_array
          }
        },
        // attributes: {
        //   include: [
        //     [Sequelize.literal('(SELECT COUNT(*) FROM "Likes" AS "variants" WHERE "product_id" = "Product"."id")'), "like_count"],
        //     [Sequelize.literal('(SELECT COUNT(*) FROM "Comments" AS "variants" WHERE "product_id" = "Product"."id")'), "comment_count"],
        //     [Sequelize.literal('(SELECT COUNT(*) FROM "SharePosts" AS "variants" WHERE "product_id" = "Product"."id")'), "sharepost_count"],
        //     [Sequelize.literal('(SELECT COUNT(*) FROM "ProductItems" AS "variants" WHERE "product_id" = "Product"."id")'), "total_variants"],
        //     [Sequelize.literal('(SELECT SUM("inventory_quantity") FROM "ProductItems" AS "variants" WHERE "product_id" = "Product"."id")'), "total_inventory_quantity"],
        //   ],
        // },
        include: [
          {
            model: database.ProductMedia,
            as: "images",
            attributes: ["src"],
          },
          {
            model: database.ProductInventory,
            as: "inventoryPrice",
            attributes: ["price", "listPrice", "quantity", "sku"],
          },
          {
            model: database.Like,
            as: "likes",
            required: false,
            where: {
              ...(user?.id && {
                user_id: user?.id,
              }),
            },
          },
          {
            model: database.Bookmark,
            as: "bookmark",
            attributes: ["id", "collection_id"],
            include: [
              {
                model: database.BookmarkCollection,
                as: "collection",
                attributes: ["id", "name", "user_id", "isPrivate"],
              },
            ],
          },
        ],
        order: [["createdAt", "DESC"]],
      });

      let all_product = await JSON.parse(JSON.stringify(get_allProduct));

      let updated_products = await all_product?.map((prd) => {
        return {
          ...prd,
          like_count: prd?.like_count,
          comment_count: prd?.comment_count,
          sharepost_count: prd?.sharepost_count,
          total_variants: prd?.total_variants,
          total_inventory_quantity: prd?.total_inventory_quantity,
        };
      });
      return { success: true, message: 'Fetch Successfully', data: updated_products };

    } catch (error) {
      console.log("=================>", error);
    }

  },


  getMinMaxAvgPriceOfProducts: async (root, { input }, { user }) => {
    try {
      let response, prices, responseData;

      if (input && input.store_slug) {
        let find_store = await database.BusinessInformation.findOne({
          where: {
            slug: input?.store_slug,
          },
          attributes: ["id"],
          raw: true
        });
        if (!find_store) {
          return {
            success: false,
            message: "Store not found!"
          }
        }
        response = await database.Product.findAll({
          where: {
            store_id: find_store?.id
          }
        });

        responseData = JSON.parse(JSON.stringify(response));
        prices = responseData?.map((item) => item?.dis_price ?? "0.00");

      } else if (
        input &&
        (input.category || input.subCategory || input.childSubCategory)
      ) {
        let find_category, find_sub_category, find_child_sub_category;
        if (input?.category) {
          find_category = await database.Category.findOne({
            where: {
              slug: input?.category,
            },
            attributes: ["id"],
            raw: true
          });
        }
        if (input?.subCategory) {
          find_sub_category = await database.Subcategory.findOne({
            where: {
              slug: input?.subCategory,
            },
            attributes: ["id"],
            raw: true
          });
        }
        if (input?.childSubCategory) {
          find_child_sub_category = await database.Childsubcategory.findOne({
            where: {
              slug: input?.childSubCategory,
            },
            attributes: ["id"],
            raw: true
          });
        }
        response = await database.ProductCategories.findAll({ 
          where: {
            ...(find_category && find_category?.id && { category_id: find_category?.id }),
            ...(find_sub_category && find_sub_category?.id && {
              subCategory_id: find_sub_category?.id,
            }),
            ...(find_child_sub_category && find_child_sub_category?.id && {
              childSubCategory_id: find_child_sub_category?.id,
            }),
          },
          include: [
            {
              model: database.Product,
              as: "product_data",
              where: {
                status: "Publish",
              },
              attributes: ["id", "dis_price"],
            },
          ],
        });
        responseData = JSON.parse(JSON.stringify(response));
        prices = responseData?.map(
          (item) => item?.product_data?.dis_price ?? "0.00"
        );
      } else {
        response = await database.Product.findAll({
          where: {
            status: "Publish",
          },
          attributes: ["id", "dis_price"],
        });
        responseData = JSON.parse(JSON.stringify(response));
        prices = responseData?.map((item) => item?.dis_price ?? "0.00");
      }

      if (responseData?.length === 0) {
        return {
          success: true,
          message: "No Products found!",
          data: {
            minPrice: null,
            maxPrice: null,
            avgPrice: null,
          },
        };
      }

      const minPrice = Math.round(Math.min(...prices));
      const maxPrice = Math.round(Math.max(...prices));
      const avgPrice = parseFloat(
        (
          prices.reduce((acc, curr) => acc + Number(curr), 0) / prices.length
        ).toFixed(2)
      );

      return {
        success: true,
        message: "Price stats Fetch Successfully",
        data: {
          minPrice,
          maxPrice,
          avgPrice,
        },
      };
    } catch (error) {
      console.error(
        "An Error occured while fetching minimum, maximum and average price of products.",
        error
      );
      throw new Error(
        "An Error occured while fetching minimum, maximum and average price of products."
      );
    }
  },

  /**
   * Gets the analytics of a seller's products.
   * @param {object} root - The root of the GraphQL query
   * @param {object} args - The arguments of the GraphQL query
   * @param {object} context - The context of the GraphQL query
   * @param {object} info - The info of the GraphQL query
   * @returns {object} - An object containing the analytics of the seller's products
   * @throws {Error} - If an error occurs while fetching the analytics
   */
  getAllProductsOfSeller: async (root, { }, { user }) => {
    try {

      const store_id = user?.store_id;

      if (!store_id) {
        return new AuthenticationError("Please Provide the Sotre Id");
      }

      const [
        totalProducts,
        percentageChangeInTotalProducts,
        productsRevenue,
        percentageChangeInProductsRevenue,
        topSelling,
        percentageChangeInTopSellingProducts,
        totalActiveProducts,
        outOfStock
      ] = await Promise.all([
        database.Product.count({
          where: {
            store_id: store_id,
            is_deleted: false,
            isActive: true
          },
        }),
        database.Product.count({
          where: {
            store_id: store_id,
            isActive: true,
            is_deleted: false,
            createdAt: {
              [Op.lt]: new Date(new Date() - 30 * 24 * 60 * 60 * 1000),
            },
          },
        }),
        database.OrderItems.sum('sellerFinalAmount', {
          where: {
            store_id: store_id,
          },
        }),
        database.OrderItems.sum('sellerFinalAmount', {
          where: {
            store_id: store_id,
            createdAt: {
              [Op.lt]: new Date(new Date() - 30 * 24 * 60 * 60 * 1000),
            },
          },
        }),
        database.OrderItems.count({
          where: {
            store_id,
          },
          distinct: true,
          col: 'product_id',
        }),
        database.OrderItems.count({
          where: {
            store_id: store_id,
            createdAt: {
              [Op.lt]: new Date(new Date() - 30 * 24 * 60 * 60 * 1000),
            },
          },
          distinct: true,
          col: 'product_id',
        }),
        database.Product.count({
          where: {
            store_id: store_id,
            is_deleted: false,
            isActive: true
          },
        }),
        client.count({
          index: "order_items",
          body: {
            query: {
              bool: {
                must: [
                  { match: { store_id: store_id } },
                  { match: { quantity: 0 } },                  
                ]
              }
            }
          }
        })
      ]);

      return {
        success: true,
        message: "Products Data Fetched Successfully",
        data: {
          totalProducts,
          percentageChangeInTotalProducts: percentageChangeInTotalProducts === 0
            ? 0
            : ((totalProducts - percentageChangeInTotalProducts) / percentageChangeInTotalProducts) * 100,
          productsRevenue,
          percentageChangeInProductsRevenue: percentageChangeInProductsRevenue === 0 || percentageChangeInProductsRevenue === productsRevenue
            ? 0
            : ((productsRevenue - percentageChangeInProductsRevenue) / percentageChangeInProductsRevenue) * 100,
          topSelling: topSelling,
          percentageChangeInTopSellingProducts: percentageChangeInTopSellingProducts === 0 || percentageChangeInTopSellingProducts === topSelling
            ? 0
            : ((topSelling - percentageChangeInTopSellingProducts) / percentageChangeInTopSellingProducts) * 100,
          totalActiveProducts,
          outOfStock: outOfStock.count
        }
      }

    } catch (error) {
      throw new Error("Error getting products of seller: " + error);
    }
  },
};

// let get_allProduct = await database.Product.findAll({
//   where: { is_deleted: false },
//   attributes: {
//     include: [
//       [Sequelize.literal('(SELECT COUNT(*) FROM "Likes" AS "variants" WHERE "product_id" = "Product"."id")'), "like_count"],
//       [Sequelize.literal('(SELECT COUNT(*) FROM "Comments" AS "variants" WHERE "product_id" = "Product"."id")'), "comment_count"],
//       [Sequelize.literal('(SELECT COUNT(*) FROM "SharePosts" AS "variants" WHERE "product_id" = "Product"."id")'), "sharepost_count"],
//     ],
//   },
//   include: [
//     {
//       model: database.ProductItem,
//       as: "variants",
//       attributes: ["id", "title", "price", "sku", "barcode", "inventory_quantity", "old_inventory_quantity", "isTaxable", "image_id"],
//       include: [
//         {
//           model: database.ProductConfiguration,
//           as: "total_variant",
//           attributes: ["id", "variant_option_id"],
//           include: [
//             {
//               model: database.VariationOption,
//               as: "variant_option",
//               attributes: ["id", "value", "variation_id"],
//             },
//           ],
//         },
//         {
//           model: database.Media,
//           as: "image",
//           attributes: ["media"],
//         },
//       ],
//     },
//     {
//       model: database.ProductShippingDetails,
//       as: "shipping",
//     },
//     {
//       model: database.Variation,
//       as: "options",
//       attributes: ["id", "name"],
//       include: [{ model: database.VariationOption, as: "data", attributes: ["id", "value", "colorCode"] }],
//     },
//     {
//       model: database.ProductMedia,
//       as: "images",
//       attributes: ["id", "src", "media_id"],
//     },
//     {
//       model: database.ProductTag,
//       as: "tags",
//       attributes: ["id", "tag"],
//     },
//     {
//       model: database.ProductCategories,
//       as: "categories",
//       attributes: ["id", "category_id", "subCategory_id", "childSubCategory_id"],
//       include: [
//         {
//           model: database.Category,
//           as: "category",
//         },
//         {
//           model: database.Subcategory,
//           as: "subCategory",
//         },
//         {
//           model: database.Childsubcategory,
//           as: "childSubCategory",
//         },
//       ],
//     },
//     {
//       model: database.ProductInventory,
//       as: "inventoryPrice",
//       attributes: ["id", "price", "listPrice", "quantity", "sku"],
//     },
//     {
//       model: database.ProductAttributes,
//       as: "attributes",
//       attributes: ["id", "name", "value", "type"],
//     },
//     {
//       model: database.ProductImageSize,
//       as: "size",
//       // attributes: ["id"],
//     },
//   ],
// });
