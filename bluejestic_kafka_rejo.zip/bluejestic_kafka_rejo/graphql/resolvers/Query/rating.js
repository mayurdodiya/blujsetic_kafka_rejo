const { AuthenticationError } = require("apollo-server-express");

const RatingService = require("../../../database/services/rating");
module.exports = {
  getAllRating: async (root, args, { user }) => {
    if (user != null) {
      const allRating = await RatingService.getAll();
      return allRating;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getSingleRating: async (_, { id }, { user }) => {
    if (user != null) {
      return RatingService.getById(id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
};
