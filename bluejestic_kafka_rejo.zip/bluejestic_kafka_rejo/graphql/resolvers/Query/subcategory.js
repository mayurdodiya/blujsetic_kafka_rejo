const { AuthenticationError } = require("apollo-server-express");

const SubCategoryService = require("../../../database/services/subcategory");

module.exports = {
  getAllSubCategory: async (root, args, { user }) => {
    if (user != null) {
      const allCategory = await SubCategoryService.getAll();
      return allCategory;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getSingleSubCategory: async (_, { id }, { user }) => {
    if (user != null) {
      return SubCategoryService.getById(id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
};
