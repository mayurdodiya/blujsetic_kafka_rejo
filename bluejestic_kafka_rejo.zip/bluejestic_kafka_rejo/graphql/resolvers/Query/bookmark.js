const { AuthenticationError } = require("apollo-server-express");
const database = require("../../../database/models");
const { Op, Sequelize, where } = require("sequelize");
const FollowStoreService = require("../../../database/services/followstore");
const BookmarkService = require("../../../database/services/bookmark");
const FriendService = require("../../../database/services/friend");
const { findCropImages } = require("../../../utils/utils");

module.exports = {
  getAllBookmark: async (root, { slug, limit, page, user_slug }, { user }) => {
    // if (!user) return new AuthenticationError("Please Provide the token");
    let where = {};
    if (limit && page) {
      var offset = (parseInt(page) - 1) * limit;
      limit = parseInt(limit);
    }

    if (slug) {
      if (user_slug) {
        const find_user = await database.User.findOne({
          where: {
            userName: user_slug,
          },
          attributes: ["id"],
          raw: true,
        });

        if (!find_user) {
          return { success: false, message: "User not Found!" };
        }

        const find_collection = await database.BookmarkCollection.findOne({
          where: {
            slug: slug,
            user_id: find_user?.id,
          },
        });

        if (!find_collection) {
          return { success: false, message: "Collection not Found" };
        }

        if (find_collection?.isPrivate) {
          if (user?.id !== find_collection?.user_id) {
            return { success: false, message: "You have not Permission to Access this Collection." };
          }
        }

        let collections = JSON.parse(JSON.stringify(find_collection));

        const user_id = find_user?.id;

        const friend = await database.Friend.findOne({
          where: {
            user_id: user?.id,
            friend_id: user_id,
          },
          raw: true,
        });

        const find_shared_people = await database.BookmarkCollectionSharedPeople.findOne({
          where: {
            collection_id: collections?.id,
            user_id: find_user?.id,
            friend_id: user?.id,
          },
          raw: true,
        });

        const find_bookmark_collection_follow = await database.BookmarkCollectionFollow.findOne({
          where: {
            collection_id: collections?.id,
            user_id: user?.id,
          },
          raw: true,
        });

        const find_post = await database.SharePost.findOne({
          where: {
            collection_id: find_collection?.id,
            user_id: user?.id,
          },
          attributes: ["id"],
          raw: true,
        });

        if ((friend && friend?.isActive && friend?.isFriend) || user_id === user?.id || find_shared_people || find_bookmark_collection_follow || find_post) {
          where = { ...where, collection_id: find_collection?.id };
        }
      } else {
        const find_collection = await database.BookmarkCollection.findOne({
          where: {
            slug: slug,
            user_id: user?.id,
          },
          raw: true,
        });

        if (!find_collection) {
          return { success: false, message: "Collection not Found" };
        }

        if (find_collection?.isPrivate) {
          if (user?.id !== find_collection?.user_id) {
            return { success: false, message: "You have not Permission to Access this Collection." };
          }
        }

        where = { ...where, collection_id: find_collection?.id };
      }
    } else {
      if (user?.id) {
        where = { ...where, user_id: user?.id };
      }
    }

    try {
      let bookmark = await database.Bookmark.findAll({
        where,
        limit: limit,
        offset: offset,
        include: [
          {
            model: database.Product,
            as: "products",
            attributes: [
              "id",
              "title",
              "slug",
              "dis_price",
              "dis_listPrice",
              [Sequelize.literal('(SELECT COUNT(*) FROM "Likes" AS "variants" WHERE "product_id" = "products"."id")'), "like_count"],
              [Sequelize.literal('(SELECT COUNT(*) FROM "Comments" AS "variants" WHERE "product_id" = "products"."id")'), "comment_count"],
              [Sequelize.literal('(SELECT COUNT(*) FROM "SharePosts" AS "variants" WHERE "product_id" = "products"."id")'), "sharepost_count"],
              [Sequelize.literal('(SELECT COUNT(*) FROM "ProductItems" AS "variants" WHERE "product_id" = "products"."id")'), "total_variants"],
              [Sequelize.literal('(SELECT SUM("inventory_quantity") FROM "ProductItems" AS "variants" WHERE "product_id" = "products"."id")'), "total_inventory_quantity"],
            ],
            include: [
              {
                model: database.ProductMedia,
                as: "images",
                limit: 1,
                // required: false,
                attributes: ["src"],
              },
              {
                model: database.Bookmark,
                as: "bookmark",
                attributes: ["id", "collection_id"],
                include: [
                  {
                    model: database.BookmarkCollection,
                    as: "collection",
                    attributes: ["id", "name", "user_id", "isPrivate", "slug"],
                  },
                ],
              },
            ],
            // required: false
          },
        ],
      });

      let total_count = await database.Bookmark.count({ where });

      bookmark = JSON.parse(JSON.stringify(bookmark));
      // console.log("bookmark++++++++++++++++++++++++++", bookmark);
      // let bookmark_array = [];
      // for (const b of bookmark) {
      //   let products = b.products;
      //   if (user) {
      //     let find_product_like = await database.Like.findOne({
      //       where: {
      //         user_id: user?.id,
      //         product_id: products?.id,
      //       },
      //       raw: true,
      //     });

      //     if (find_product_like) {
      //       products.likes = {
      //         id: find_product_like?.id,
      //       };
      //     } else {
      //       products.likes = {
      //         id: null,
      //       };
      //     }
      //   } else {
      //     products.likes = {
      //       id: null,
      //     };
      //   }
      //   bookmark_array.push(products);
      // }
      return { success: true, message: "fetch successfully", data: bookmark, total: total_count };
    } catch (error) {
      console.log("errorfsudfbuhasbfhubsfub", error);
    }
  },

  getBookmarkCollections: async (root, { isPrivate }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    // let is_filter = isPrivate ? true : false;
    let get_collections = await database.BookmarkCollection.findAll({
      where: {
        user_id: user.id,
        is_deleted: false,
        ...(isPrivate && { isPrivate: isPrivate }),
      },
      include: [
        {
          model: database.BookmarkCollectionLikes,
          as: "likes",
        },
      ],
      order: [["createdAt", "DESC"]],
    });
    let collections = JSON.parse(JSON.stringify(get_collections));

    if (Boolean(collections?.length)) {
      for (const iterator of collections) {
        let find_bookmark_product = await database.Bookmark.findAll({
          where: {
            collection_id: iterator.id,
          },
          raw: true,
        });
        let allProduct = [];
        if (Boolean(find_bookmark_product?.length)) {
          for (const product of find_bookmark_product) {
            let find_prd = await database.Product.findOne({
              where: {
                id: product.product_id,
              },
              include: [
                {
                  model: database.ProductMedia,
                  as: "images",
                  attributes: ["id", "src", "media_id"],
                },
              ],
              // raw: true,
            });

            allProduct.push(JSON.parse(JSON.stringify(find_prd)));
          }
        }
        let image = [];
        let n = 4;
        for (let i = 0; i < allProduct.length; i++) {
          if (i == n - 1) break;
          const product = allProduct[i];
          if (Boolean(product.images.length)) {
            let cropImages = Boolean(product.images?.length) ? product.images[0]?.src : null;
            if (cropImages) image.push(cropImages);
          }
        }
        console.log("allProduct.likes.length++++++++++++++++++++", iterator?.likes?.length);
        let like_lenght;
        iterator.product_images = image;
        iterator.product_count = allProduct?.length;
        iterator.likes = iterator?.likes?.length;
        if (!isPrivate) {
          let find_user = await database.User.findOne({
            where: {
              id: user?.id,
            },
            attributes: ["firstName", "lastName", "profileAvtar", "userName", "logo_image"],
            raw: true,
          });
          if (find_user) {
            // let find_user_profileAvtar = await database.Media.findOne({
            //   where: {
            //     id: find_user?.profileAvtar[0],
            //   },
            //   raw: true,
            // });

            let user = {
              firstName: find_user?.firstName,
              lastName: find_user?.lastName,
              logo_image: find_user?.logo_image,
              // profileAvtar: find_user_profileAvtar?.media,
              userName: find_user?.userName,
            };
            iterator.user = user;
          }
        }
      }
    }
    return collections;
  },

  getSingleBookmark: async (_, { id }, { user }) => {
    if (user != null) {
      return BookmarkService.getById(id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getCollectionSingleLike: async (_, { slug, user_slug }, { user }) => {
    // if (!user) return new AuthenticationError("Please Provide the token");

    try {
      let isExist = false;
      let isPrivate = false;
      let isFollow = false;

      if (user_slug) {
        const find_user = await database.User.findOne({
          where: {
            userName: user_slug,
          },
          attributes: ["id"],
          raw: true,
        });

        if (!find_user) {
          return { success: false, message: "User not Found!" };
        }

        const find_collection = await database.BookmarkCollection.findOne({
          where: {
            slug: slug,
            user_id: find_user?.id,
          },
        });

        if (!find_collection) {
          return { success: false, message: "Collection not Found" };
        }

        if (find_collection?.isPrivate) {
          if (user?.id !== find_collection?.user_id) {
            return { success: false, message: "You have not Permission to Access this Collection." };
          }
        }

        let collections = JSON.parse(JSON.stringify(find_collection));

        const user_id = find_user?.id;

        const friend = await database.Friend.findOne({
          where: {
            user_id: user?.id,
            friend_id: user_id,
          },
          raw: true,
        });

        const find_shared_people = await database.BookmarkCollectionSharedPeople.findOne({
          where: {
            collection_id: collections?.id,
            user_id: user?.id,
            friend_id: find_user?.id,
          },
          raw: true,
        });

        const find_bookmark_collection_follow = await database.BookmarkCollectionFollow.findOne({
          where: {
            collection_id: collections?.id,
            user_id: user?.id,
          },
          raw: true,
        });

        const find_post = await database.SharePost.findOne({
          where: {
            collection_id: find_collection?.id,
            user_id: user?.id,
          },
          attributes: ["id"],
          raw: true,
        });

        if ((friend && friend?.isActive && friend?.isFriend) || user_id === user?.id || find_shared_people || find_bookmark_collection_follow || find_post) {
          const isLikeStore = await database.BookmarkCollectionLikes.findOne({
            where: {
              collection_id: Number(collections?.id),
              user_id: Number(user?.id),
            },
          });
          if (isLikeStore) {
            isExist = true;
          }

          const get_collection = await database.BookmarkCollection.findOne({ where: { id: collections?.id }, raw: true });
          if (get_collection) {
            isPrivate = get_collection?.isPrivate;
          }
          const is_follow = await database.BookmarkCollectionFollow.findOne({ where: { collection_id: collections?.id, user_id: user?.id }, raw: true });
          if (is_follow) {
            isFollow = true;
          }
        }

        console.log('{ success: true, message: "Data successfully", isLike: isExist, isPrivate: isPrivate, isFollow: isFollow }', { success: true, message: "Data successfully", isLike: isExist, isPrivate: isPrivate, isFollow: isFollow });

        return { success: true, message: "Data successfully", isLike: isExist, isPrivate: isPrivate, isFollow: isFollow };
      } else {
        let find = await database.BookmarkCollection.findOne({
          where: {
            slug: slug,
            user_id: user?.id,
          },
          raw: true,
        });

        if (!find) {
          return { success: false, message: "Collection not Found" };
        }

        if (find?.id && user?.id) {
          const isLikeStore = await database.BookmarkCollectionLikes.findOne({
            where: {
              collection_id: Number(find?.id),
              user_id: Number(user?.id),
            },
          });
          if (isLikeStore) {
            isExist = true;
          }

          const get_collection = await database.BookmarkCollection.findOne({ where: { id: find?.id }, raw: true });
          if (get_collection) {
            isPrivate = get_collection?.isPrivate;
          }
          const is_follow = await database.BookmarkCollectionFollow.findOne({ where: { collection_id: find?.id, user_id: user?.id }, raw: true });
          if (is_follow) {
            isFollow = true;
          }
        } else {
          new AuthenticationError("Error in store id or user id");
        }
        return { success: true, message: "Data successfully", isLike: isExist, isPrivate: isPrivate, isFollow: isFollow };
      }
    } catch (error) {
      console.log("ERRRRRRRRRR", error);
    }
  },

  // getCollectionSingleLike: async (_, { slug, user_slug }, { user }) => {
  //   try {
  //     let isExist = false;
  //     let isPrivate = false;
  //     let isFollow = false;
  //     let find_user;
  //     if (user_slug) {
  //       find_user = await database.User.findOne({
  //         where: {
  //           userName: user_slug,
  //         },
  //         attributes: ["id"],
  //         raw: true,
  //       });

  //       if (!find_user) {
  //         return { success: false, message: "User not Found!" };
  //       }
  //     }

  //     let find = await database.BookmarkCollection.findOne({
  //       where: {
  //         slug: slug,
  //         user_id: find_user ? find_user?.id : user?.id,
  //       },
  //       raw: true,
  //     });

  //     if (!find) {
  //       return { success: false, message: "Collection not Found" };
  //     }

  //     if (find?.isPrivate) {
  //       let find_friend = await database.Friend.findOne({
  //         where: {
  //           user_id: user?.id,
  //           friend_id: find?.user_id,
  //         },
  //       });
  //       if (!find_friend) {
  //         return { success: false, message: "You do not have access this collection" };
  //       }
  //     }

  //     console.log("find?.id++++++++++++++++++++++++++++++++++++++++++++++", find?.id, user?.id);

  //     if (find?.id && user?.id) {
  //       const isLikeStore = await database.BookmarkCollectionLikes.findOne({
  //         where: {
  //           collection_id: Number(find?.id),
  //           user_id: Number(user?.id),
  //         },
  //       });
  //       if (isLikeStore) {
  //         isExist = true;
  //       }

  //       const get_collection = await database.BookmarkCollection.findOne({ where: { id: find?.id }, raw: true });
  //       if (get_collection) {
  //         isPrivate = get_collection?.isPrivate;
  //       }
  //       const is_follow = await database.BookmarkCollectionFollow.findOne({ where: { collection_id: find?.id, user_id: user?.id }, raw: true });
  //       if (is_follow) {
  //         isFollow = true;
  //       }
  //     } else {
  //       new AuthenticationError("Error in store id or user id");
  //     }
  //     return { success: true, message: "Data successfully", isLike: isExist, isPrivate: isPrivate, isFollow: isFollow };
  //   } catch (error) {
  //     console.log("ERRRRRRRRRR", error);
  //   }
  // },

  getSingleCollection: async (_, { slug, user_slug }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    if (user_slug) {
      try {
        const find_user = await database.User.findOne({
          where: {
            userName: user_slug,
          },
          attributes: ["id"],
          raw: true,
        });

        if (!find_user) {
          return { success: false, message: "User not Found!" };
        }

        const user_id = find_user?.id;

        const find_collection = await database.BookmarkCollection.findOne({
          where: {
            slug: slug,
            user_id: find_user?.id,
          },
          include: [
            {
              model: database.BookmarkCollectionLikes,
              as: "likes",
            },
            {
              model: database.User,
              as: "user",
              attributes: ["id", "firstName", "lastName", "profileAvtar", "userName", "logo_image"],
            },
          ],
        });

        if (!find_collection) {
          return { success: false, message: "Collection not Found" };
        }

        // if (find_collection?.isPrivate) {
        //   if (user?.id !== find_collection?.user_id) {
        //     return { success: false, message: "You have not Permission to Access this Collection." };
        //   }
        // }

        let collections = JSON.parse(JSON.stringify(find_collection));

        const friend = await database.Friend.findOne({
          where: {
            user_id: user?.id,
            friend_id: user_id,
          },
          raw: true,
        });

        const find_shared_people = await database.BookmarkCollectionSharedPeople.findOne({
          where: {
            collection_id: collections?.id,
            user_id: find_user?.id,
            friend_id: user?.id,
          },
          raw: true,
        });

        const find_bookmark_collection_follow = await database.BookmarkCollectionFollow.findOne({
          where: {
            collection_id: collections?.id,
            user_id: user?.id,
          },
          raw: true,
        });

        const find_post = await database.SharePost.findOne({
          where: {
            collection_id: find_collection?.id,
            user_id: user?.id,
          },
          attributes: ["id"],
          raw: true,
        });

        if ((friend && friend?.isActive && friend?.isFriend) || user_id === user?.id || find_shared_people || find_bookmark_collection_follow || find_post) {
          let iterator = collections;
          iterator.likes = iterator?.likes?.length;
          let find_user = collections?.user;
          if (find_user) {
            let user = {
              id: find_user?.id,
              firstName: find_user?.firstName,
              lastName: find_user?.lastName,
              logo_image: find_user?.logo_image,
              userName: find_user?.userName,
            };
            iterator.user = user;
          }

          let find_bookmark_product = await database.Bookmark.findAll({
            where: {
              collection_id: collections.id,
            },
            limit: 3,
            raw: true,
          });

          let allProduct = [];
          let image = [];

          if (Boolean(find_bookmark_product?.length)) {
            for (const product of find_bookmark_product) {
              let find_prd = await database.Product.findOne({
                where: {
                  id: product.product_id,
                },
                include: [
                  {
                    model: database.ProductMedia,
                    as: "images",
                    attributes: ["id", "src", "media_id"],
                  },
                ],
              });

              allProduct.push(JSON.parse(JSON.stringify(find_prd)));
            }
            let n = 4;
            for (let i = 0; i < allProduct.length; i++) {
              if (i == n - 1) break;
              const product = allProduct[i];
              if (Boolean(product.images.length)) {
                let cropImages = Boolean(product.images?.length) ? product.images[0]?.src : null;
                if (cropImages) image.push(cropImages);
              }
            }
          }

          iterator.product_images = image;
          const get_product_count = await database.Bookmark.count({ where: { collection_id: iterator?.id, user_id: collections?.user_id } });
          iterator.product_count = get_product_count || 0;
          return { success: true, message: "Fetch collection successfully!", data: iterator };
        }

        return { success: false, message: "You have not Permission to Access this Collection..." };
      } catch (error) {
        console.log("ERRRRRRRRRR", error);
      }
    } else {
      try {
        const find_collection = await database.BookmarkCollection.findOne({
          where: {
            slug: slug,
            user_id: user?.id,
          },
          include: [
            {
              model: database.BookmarkCollectionLikes,
              as: "likes",
            },
            {
              model: database.User,
              as: "user",
              attributes: ["id", "firstName", "lastName", "profileAvtar", "userName", "logo_image"],
            },
          ],
        });

        if (!find_collection) {
          return { success: false, message: "Collection not Found" };
        }
        let collections = JSON.parse(JSON.stringify(find_collection));
        if (collections) {
          if (collections?.isPrivate) {
            if (user?.id !== collections?.user_id) {
              return { success: false, message: "You have not Permission to Access this Collection." };
            }
          }

          let iterator = collections;
          iterator.likes = iterator?.likes?.length;
          let find_user = collections?.user;
          if (find_user) {
            let user = {
              id: find_user?.id,
              firstName: find_user?.firstName,
              lastName: find_user?.lastName,
              logo_image: find_user?.logo_image,
              userName: find_user?.userName,
            };
            iterator.user = user;
          }

          let find_bookmark_product = await database.Bookmark.findAll({
            where: {
              collection_id: collections.id,
            },
            limit: 3,
            raw: true,
          });

          let allProduct = [];
          let image = [];

          if (Boolean(find_bookmark_product?.length)) {
            for (const product of find_bookmark_product) {
              let find_prd = await database.Product.findOne({
                where: {
                  id: product.product_id,
                },
                include: [
                  {
                    model: database.ProductMedia,
                    as: "images",
                    attributes: ["id", "src", "media_id"],
                  },
                ],
              });

              allProduct.push(JSON.parse(JSON.stringify(find_prd)));
            }
            let n = 4;
            for (let i = 0; i < allProduct.length; i++) {
              if (i == n - 1) break;
              const product = allProduct[i];
              if (Boolean(product.images.length)) {
                let cropImages = Boolean(product.images?.length) ? product.images[0]?.src : null;
                if (cropImages) image.push(cropImages);
              }
            }
          }
          iterator.product_images = image;
          const get_product_count = await database.Bookmark.count({ where: { collection_id: iterator?.id, user_id: collections?.user_id } });
          iterator.product_count = get_product_count || 0;
          return { success: true, message: "Fetch collection successfully!", data: iterator };
        } else {
          new AuthenticationError("Error in store id or user id");
        }
        return { success: true, message: "Data successfully" };
      } catch (error) {
        console.log("ERRRRRRRRRR", error);
      }
    }
  },

  getSinglePublicCollection: async (_, { slug, user_slug }, { user }) => {
    if (user_slug) {
      try {
        const find_user = await database.User.findOne({
          where: {
            userName: user_slug,
          },
          attributes: ["id"],
          raw: true,
        });

        let provided_user_id = user?.id;

        if (find_user?.id === 163) {
          provided_user_id = find_user?.id
          // return { success: true, message: "", data: {} };
        } else {
          if (!user) return new AuthenticationError("Please Provide the token");
        }

        if (!find_user) {
          return { success: false, message: "User not Found!" };
        }

        const user_id = find_user?.id;

        const find_collection = await database.BookmarkCollection.findOne({
          where: {
            slug: slug,
            user_id: find_user?.id,
          },
          include: [
            {
              model: database.BookmarkCollectionLikes,
              as: "likes",
            },
            {
              model: database.User,
              as: "user",
              attributes: ["id", "firstName", "lastName", "profileAvtar", "userName", "logo_image"],
            },
          ],
        });

        if (!find_collection) {
          return { success: false, message: "Collection not Found" };
        }

        if (find_collection?.isPrivate) {
          if (provided_user_id !== find_collection?.user_id) {
            return { success: false, message: "You have not Permission to Access this Collection." };
          }
        }

        let collections = JSON.parse(JSON.stringify(find_collection));

        const friend = await database.Friend.findOne({
          where: {
            user_id: provided_user_id,
            friend_id: user_id,
          },
          raw: true,
        });

        const find_shared_people = await database.BookmarkCollectionSharedPeople.findOne({
          where: {
            collection_id: collections?.id,
            user_id: find_user?.id,
            friend_id: provided_user_id,
          },
          raw: true,
        });

        const find_bookmark_collection_follow = await database.BookmarkCollectionFollow.findOne({
          where: {
            collection_id: collections?.id,
            user_id: provided_user_id,
          },
          raw: true,
        });

        const find_post = await database.SharePost.findOne({
          where: {
            collection_id: find_collection?.id,
            user_id: provided_user_id,
          },
          attributes: ["id"],
          raw: true,
        });

        if ((friend && friend?.isActive && friend?.isFriend) || user_id === provided_user_id || find_shared_people || find_bookmark_collection_follow || find_post) {
          let iterator = collections;
          iterator.likes = iterator?.likes?.length;
          let find_user = collections?.user;
          if (find_user) {
            let user = {
              id: find_user?.id,
              firstName: find_user?.firstName,
              lastName: find_user?.lastName,
              logo_image: find_user?.logo_image,
              userName: find_user?.userName,
            };
            iterator.user = user;
          }

          let find_bookmark_product = await database.Bookmark.findAll({
            where: {
              collection_id: collections.id,
            },
            limit: 3,
            raw: true,
          });

          let allProduct = [];
          let image = [];

          if (Boolean(find_bookmark_product?.length)) {
            for (const product of find_bookmark_product) {
              let find_prd = await database.Product.findOne({
                where: {
                  id: product.product_id,
                },
                include: [
                  {
                    model: database.ProductMedia,
                    as: "images",
                    attributes: ["id", "src", "media_id"],
                  },
                ],
              });

              allProduct.push(JSON.parse(JSON.stringify(find_prd)));
            }
            let n = 4;
            for (let i = 0; i < allProduct.length; i++) {
              if (i == n - 1) break;
              const product = allProduct[i];
              if (Boolean(product.images.length)) {
                let cropImages = Boolean(product.images?.length) ? product.images[0]?.src : null;
                if (cropImages) image.push(cropImages);
              }
            }
          }

          iterator.product_images = image;
          const get_product_count = await database.Bookmark.count({ where: { collection_id: iterator?.id, user_id: collections?.user_id } });
          iterator.product_count = get_product_count || 0;
          return { success: true, message: "Fetch collection successfully!", data: iterator };
        }

        return { success: false, message: "You have not Permission to Access this Collection..." };
      } catch (error) {
        console.log("ERRRRRRRRRR", error);
      }
    } else {
      if (!user) return new AuthenticationError("Please Provide the token");
      try {
        const find_collection = await database.BookmarkCollection.findOne({
          where: {
            slug: slug,
            user_id: user?.id,
          },
          include: [
            {
              model: database.BookmarkCollectionLikes,
              as: "likes",
            },
            {
              model: database.User,
              as: "user",
              attributes: ["id", "firstName", "lastName", "profileAvtar", "userName", "logo_image"],
            },
          ],
        });

        if (!find_collection) {
          return { success: false, message: "Collection not Found" };
        }
        let collections = JSON.parse(JSON.stringify(find_collection));
        if (collections) {
          if (collections?.isPrivate) {
            if (user?.id !== collections?.user_id) {
              return { success: false, message: "You have not Permission to Access this Collection." };
            }
          }

          let iterator = collections;
          iterator.likes = iterator?.likes?.length;
          let find_user = collections?.user;
          if (find_user) {
            let user = {
              id: find_user?.id,
              firstName: find_user?.firstName,
              lastName: find_user?.lastName,
              logo_image: find_user?.logo_image,
              userName: find_user?.userName,
            };
            iterator.user = user;
          }

          let find_bookmark_product = await database.Bookmark.findAll({
            where: {
              collection_id: collections.id,
            },
            limit: 3,
            raw: true,
          });

          let allProduct = [];
          let image = [];

          if (Boolean(find_bookmark_product?.length)) {
            for (const product of find_bookmark_product) {
              let find_prd = await database.Product.findOne({
                where: {
                  id: product.product_id,
                },
                include: [
                  {
                    model: database.ProductMedia,
                    as: "images",
                    attributes: ["id", "src", "media_id"],
                  },
                ],
              });

              allProduct.push(JSON.parse(JSON.stringify(find_prd)));
            }
            let n = 4;
            for (let i = 0; i < allProduct.length; i++) {
              if (i == n - 1) break;
              const product = allProduct[i];
              if (Boolean(product.images.length)) {
                let cropImages = Boolean(product.images?.length) ? product.images[0]?.src : null;
                if (cropImages) image.push(cropImages);
              }
            }
          }
          iterator.product_images = image;
          const get_product_count = await database.Bookmark.count({ where: { collection_id: iterator?.id, user_id: collections?.user_id } });
          iterator.product_count = get_product_count || 0;
          return { success: true, message: "Fetch collection successfully!", data: iterator };
        } else {
          new AuthenticationError("Error in store id or user id");
        }
        return { success: true, message: "Data successfully" };
      } catch (error) {
        console.log("ERRRRRRRRRR", error);
      }
    }
  },

  getJewelryCollection: async (_, { slug, type }) => {
    // if (!user) return new AuthenticationError("Please Provide the token");
    let colection_for = type === "for_banner" ? "for_banner" : "for_shop_by_collections";
    let isPrivate = false;
    let user = {
      id: 163,
    };

    let get_collections = await database.BookmarkCollection.findAll({
      where: {
        user_id: user.id,
        is_deleted: false,
        isPrivate: false,
        colection_for: colection_for,
      },
      include: [
        {
          model: database.BookmarkCollectionLikes,
          as: "likes",
        },
      ],
      order: [["position", "ASC"]],
    });
    let collections = JSON.parse(JSON.stringify(get_collections));

    if (Boolean(collections?.length)) {
      for (const iterator of collections) {
        let find_bookmark_product = await database.Bookmark.findAll({
          where: {
            collection_id: iterator.id,
          },
          limit: 1,
          raw: true,
        });

        let allProduct = [];
        if (Boolean(find_bookmark_product?.length)) {
          for (const product of find_bookmark_product) {
            let find_prd = await database.Product.findOne({
              where: {
                id: product.product_id,
              },
              include: [
                {
                  model: database.ProductMedia,
                  as: "images",
                  attributes: ["id", "src", "media_id"],
                },
              ],
              // raw: true,
            });

            allProduct.push(JSON.parse(JSON.stringify(find_prd)));
          }
        }
        let image = [];
        let n = 4;
        for (let i = 0; i < allProduct.length; i++) {
          if (i == n - 1) break;
          const product = allProduct[i];
          if (Boolean(product.images.length)) {
            let cropImages = Boolean(product.images?.length) ? product.images[0]?.src : null;
            if (cropImages) image.push(cropImages);
          }
        }
        console.log("allProduct.likes.length++++++++++++++++++++", iterator?.likes?.length);
        let like_lenght;
        iterator.product_images = image;
        iterator.product_count = allProduct?.length;
        iterator.likes = iterator?.likes?.length;
        if (!isPrivate) {
          let find_user = await database.User.findOne({
            where: {
              id: user?.id,
            },
            attributes: ["firstName", "lastName", "profileAvtar", "userName"],
            raw: true,
          });
          if (find_user) {
            let find_user_profileAvtar = await database.Media.findOne({
              where: {
                id: find_user?.profileAvtar[0],
              },
              raw: true,
            });

            let user = {
              firstName: find_user?.firstName,
              lastName: find_user?.lastName,
              profileAvtar: find_user_profileAvtar?.media,
              userName: find_user?.userName,
            };
            iterator.user = user;
          }
        }
      }
    }
    return collections;
  },

  getSharedCollection: async (_, { slug, user_slug }, { user }) => {
    try {
      if (!user) return new AuthenticationError("Please Provide the token");
      const find_share_collection = await database.BookmarkCollectionSharedPeople.findAll({
        where: {
          friend_id: user?.id,
        },
        include: [
          {
            model: database.BookmarkCollection,
            as: "collection_data",
            attributes: ["id", "name", "is_deleted", "isPrivate", "slug"],
            include: [
              {
                model: database.User,
                as: "user",
                attributes: ["id", "firstName", "lastName", "profileAvtar", "userName", "logo_image"],
              },
              {
                model: database.BookmarkCollectionLikes,
                as: "likes",
              },
            ],
          },
          {
            model: database.User,
            as: "user_data",
            attributes: ["id", "firstName", "lastName", "userName", "logo_image"],
          },
        ],
      });

      const collections = JSON.parse(JSON.stringify(find_share_collection));

      if (collections) {
        for (const iterator of collections) {
          iterator.id = iterator?.collection_data?.id;
          iterator.name = iterator?.collection_data?.name;
          iterator.slug = iterator?.collection_data?.slug;
          iterator.isPrivate = iterator?.collection_data?.isPrivate;
          let find_bookmark_product = await database.Bookmark.findAll({
            where: {
              collection_id: iterator?.collection_data?.id,
            },
            raw: true,
          });
          let allProduct = [];
          if (Boolean(find_bookmark_product?.length)) {
            for (const product of find_bookmark_product) {
              let find_prd = await database.Product.findOne({
                where: {
                  id: product.product_id,
                },
                include: [
                  {
                    model: database.ProductMedia,
                    as: "images",
                    attributes: ["id", "src", "media_id"],
                  },
                ],
                // raw: true,
              });

              allProduct.push(JSON.parse(JSON.stringify(find_prd)));
            }
          }
          let image = [];
          let n = 4;
          for (let i = 0; i < allProduct.length; i++) {
            if (i == n - 1) break;
            const product = allProduct[i];
            if (Boolean(product.images.length)) {
              let cropImages = Boolean(product.images?.length) ? product.images[0]?.src : null;
              if (cropImages) image.push(cropImages);
            }
          }
          console.log("allProduct.likes.length++++++++++++++++++++", iterator?.likes?.length);
          let like_lenght;
          iterator.product_images = image;
          iterator.product_count = allProduct?.length;
          iterator.likes = iterator?.collection_data?.likes?.length;
          // if (!isPrivate) {
          let find_user = await database.User.findOne({
            where: {
              id: user?.id,
            },
            attributes: ["id", "firstName", "lastName", "profileAvtar", "userName", "logo_image"],
            raw: true,
          });
          if (find_user) {
            // let find_user_profileAvtar = await database.Media.findOne({
            //   where: {
            //     id: find_user?.profileAvtar[0],
            //   },
            //   raw: true,
            // });

            let user = {
              id: iterator?.collection_data?.user?.id,
              firstName: iterator?.collection_data?.user?.firstName,
              lastName: iterator?.collection_data?.user?.lastName,
              logo_image: iterator?.collection_data?.user?.logo_image,
              // profileAvtar: find_user_profileAvtar?.media,
              userName: iterator?.collection_data?.user?.userName,
            };
            iterator.user = user;
          }
          // }
        }

        console.log("collections+++++++++++++", collections);
        return collections;
      }
    } catch (error) {
      console.log("error", error);
    }
  },

  getFollowedCollection: async (_, { slug, user_slug }, { user }) => {
    try {
      if (!user) return new AuthenticationError("Please Provide the token");
      const find_share_collection = await database.BookmarkCollectionFollow.findAll({
        where: {
          user_id: user?.id,
        },
        include: [
          {
            model: database.BookmarkCollection,
            as: "followed_collection_data",
            attributes: ["id", "name", "is_deleted", "isPrivate", "slug"],
            include: [
              {
                model: database.User,
                as: "user",
                attributes: ["id", "firstName", "lastName", "profileAvtar", "userName", "logo_image"],
              },
              {
                model: database.BookmarkCollectionLikes,
                as: "likes",
              },
            ],
          },
          {
            model: database.User,
            as: "followed_user_data",
            attributes: ["id", "firstName", "lastName", "userName", "logo_image"],
          },
        ],
      });

      const collections = JSON.parse(JSON.stringify(find_share_collection));

      if (collections) {
        for (const iterator of collections) {
          iterator.id = iterator?.followed_collection_data?.id;
          iterator.name = iterator?.followed_collection_data?.name;
          iterator.slug = iterator?.followed_collection_data?.slug;
          iterator.isPrivate = iterator?.followed_collection_data?.isPrivate;
          let find_bookmark_product = await database.Bookmark.findAll({
            where: {
              collection_id: iterator?.followed_collection_data?.id,
            },
            raw: true,
          });
          let allProduct = [];
          if (Boolean(find_bookmark_product?.length)) {
            for (const product of find_bookmark_product) {
              let find_prd = await database.Product.findOne({
                where: {
                  id: product.product_id,
                },
                include: [
                  {
                    model: database.ProductMedia,
                    as: "images",
                    attributes: ["id", "src", "media_id"],
                  },
                ],
                // raw: true,
              });

              allProduct.push(JSON.parse(JSON.stringify(find_prd)));
            }
          }
          let image = [];
          let n = 4;
          for (let i = 0; i < allProduct.length; i++) {
            if (i == n - 1) break;
            const product = allProduct[i];
            if (Boolean(product.images.length)) {
              let cropImages = Boolean(product.images?.length) ? product.images[0]?.src : null;
              if (cropImages) image.push(cropImages);
            }
          }
          console.log("allProduct.likes.length++++++++++++++++++++", iterator?.likes?.length);
          let like_lenght;
          iterator.product_images = image;
          iterator.product_count = allProduct?.length;
          iterator.likes = iterator?.followed_collection_data?.likes?.length;
          // if (!isPrivate) {
          let find_user = await database.User.findOne({
            where: {
              id: user?.id,
            },
            attributes: ["id", "firstName", "lastName", "profileAvtar", "userName", "logo_image"],
            raw: true,
          });
          if (find_user) {
            // let find_user_profileAvtar = await database.Media.findOne({
            //   where: {
            //     id: find_user?.profileAvtar[0],
            //   },
            //   raw: true,
            // });

            let user = {
              id: iterator?.followed_collection_data?.user?.id,
              firstName: iterator?.followed_collection_data?.user?.firstName,
              lastName: iterator?.followed_collection_data?.user?.lastName,
              logo_image: iterator?.followed_collection_data?.user?.logo_image,
              // profileAvtar: find_user_profileAvtar?.media,
              userName: iterator?.followed_collection_data?.user?.userName,
            };
            iterator.user = user;
          }
          // }
        }

        console.log("collections+++++++++++++", collections);
        return collections;
      }
    } catch (error) {
      console.log("error", error);
    }
  },
};
