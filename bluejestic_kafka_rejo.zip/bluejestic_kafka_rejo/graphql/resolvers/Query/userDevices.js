
const database = require("../../../database/models");
module.exports = {
    getAllUserDevices: async (root, args, { user }) => {
        if (user != null) {
            const userDevices = await database.UserDevices.findAll({ where: { user_id: user.id } });
            return { success: true, message: "fetched all user location activities", data: userDevices };
        } else {
            return { success: false, message: "Please Provide Token" }
        }
    },
};