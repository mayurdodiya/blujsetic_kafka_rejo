const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const { AuthenticationError } = require("apollo-server-express");

const UserService = require("../../../database/services/user");
const { BioDetail } = require("../../../database/models");
module.exports = {
  getAlluserBioDetails: async (root, args, context) => {
    const userData = await BioDetail.findAll();
    return userData;
  },

  getUserBioDetail: async (_, { id }, context) => {
    return BioDetail.findByPk(id);
  },
};
