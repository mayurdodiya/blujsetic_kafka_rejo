
const database = require("../../../database/models");
const elasticClient = require("../../../services/elasticsearch");

module.exports = {
    getAllProductViews: async (root, args, { user }) => {
        if (user != null) {
            let { store_id } = args
            const allProductViews = await database.ProductView.findAll({ where: { store_id } });
            return { success: true, message: "fetched all store activities", data: allProductViews };
        } else {
            return { success: false, message: "Please Provide Token" }
        }
    },
    getAllProductViewChartData: async (root, args, { user }) => {
        try {
            let { store_id, start_date, end_date, time_interval, time_zone } = args
            if (!user) {
                return new AuthenticationError("Please Provide the token");
            }
            let data = await elasticClient.productViews.getAllProductViewChartData({ store_id, start_date, end_date, time_interval, time_zone });
            console.log("data", data);
            return { success: true, message: "Data successfully", data }
        } catch (error) {
            console.log(error.message);
            console.log("error", error.stack);
        }
    }
};