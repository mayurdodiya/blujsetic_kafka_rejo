const database = require("../../../database/models");
const elasticClient = require("../../../services/elasticsearch");

module.exports = {
  getAllStoreActivities: async (root, args, { user }) => {
    if (user != null) {
      let { store_id } = args;
      const allStoreActivities = await database.StoreActivity.findAll({ where: { store_id } });
      return { success: true, message: "fetched all store activities", data: allStoreActivities };
    } else {
      return { success: false, message: "Please Provide Token" };
    }
  },
  getAllStoreActivityChartData: async (root, args, { user }) => {
    try {
      let { start_date, end_date, time_interval, time_zone } = args;
      if (!user || !user?.store_id  ) {
        return new AuthenticationError("Please Provide the token");
      }
      let data = await elasticClient.storeActivities.getAllStoreActivityChartData({ store_id: user?.store_id, start_date, end_date, time_interval, time_zone });
      console.log("data", data);
      return { success: true, message: "Data successfully", data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },
  getAccountReachedChartData: async (root, args, { user }) => {
    try {
      let { start_date, end_date, time_interval, time_zone } = args;
      if (!user || !user?.store_id  ) {
        return new AuthenticationError("Please Provide the token");
      }
      let data = await elasticClient.storeActivities.getAllStoreActivityChartData({ store_id: user?.store_id, start_date, end_date, time_interval, time_zone });
      console.log("data", data);
      return { success: true, message: "Data successfully", data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },
  getUserDevicesData: async (root, args, { user }) => {
    try {
      let { store_id, start_date, end_date, time_interval, time_zone } = args;
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }
      let elkData = await elasticClient.storeActivities.getUserDevicesData({ store_id, start_date, end_date, time_interval, time_zone });
      if (!elkData.success) return elkData;
      return elkData;
    } catch (error) {
      return { success: false, message: error.message };
    }
  },
  storeVisitorsGender: async (root, args, { user }) => {
    console.log("ndkjasbdhjbasdhjbasdhjasdhjasdhjasdhjasdhj++++++++++++++++++++++++++++++++++++++++", user);
    try {
      let { start_date, end_date, time_interval, time_zone } = args;
      if (!user || !user?.store_id  ) {
        return new AuthenticationError("Please Provide the token");
      }
      let elkData = await elasticClient.storeActivities.storeVisitorsGender({ store_id: user?.store_id, start_date, end_date, time_interval, time_zone });
      if (!elkData.success) return elkData;
      return elkData;
    } catch (error) {
      return { success: false, message: error.message };
    }
  },
  visitorsLocation: async (root, args, { user }) => {
    try {
      let { store_id, filter } = args;
      if (!user || !user?.store_id  ) {
        return new AuthenticationError("Please Provide the token");
      }
      let elkData = await elasticClient.storeActivities.visitorsLocation({ store_id: user?.store_id, filter });
      if (!elkData.success) return elkData;
      return elkData;
    } catch (error) {
      return { success: false, message: error.message };
    }
  },
};
