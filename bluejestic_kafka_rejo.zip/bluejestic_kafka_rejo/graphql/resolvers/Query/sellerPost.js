const { AuthenticationError } = require("apollo-server-express");
const database = require("../../../database/models");
const SellerPostService = require("../../../database/services/sellerPost");
const { Op } = require("sequelize");

const {
  stringToUrl,
  stringToUrlWithId,
} = require("../../../middlewares/utils");
module.exports = {
  getAllSellerPost: async (root, args, { user }) => {
    if (user != null) {
      let result = [];
      // const allPostResponse = await PostService.getAll();

      let criteria = {};
      if (args.seller_id) {
        criteria = {
          order: [["createdAt", "DESC"]],
          where: { seller_id: args.seller_id, post_for: "SELLER" },
        };
      } else {
        criteria = {
          order: [["createdAt", "DESC"]],
          where: { post_for: "SELLER" },
        };
      }     
      let allPost = await database.Post.findAll(criteria);
      for (let i = 0; i < allPost.length; i++) {
        const sellerPost = JSON.parse(JSON.stringify(allPost[i]));
        const sellerPostImage = allPost[i].media_id;
        const post = allPost[i];
        if (sellerPostImage) {
          const medias = await database.Media.findAll({
            where: {
              id: {
                [Op.in]: post?.media_id || [],
              },
            },
          });
          post.medias = medias.map((media) => {
            return { ...media.dataValues, url: media.dataValues.media };
          });
        }
        let payload = {
          ...sellerPost,
        };
        result.push(payload);
      }
      return result;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getSingleSellerPost: async (_, { id }, { user }) => {
    if (user != null) {
      return SellerPostService.getById(id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getPostByStore: async (root, args, { user }) => {
    if (user != null) {
      let result = [];
      // const allPostResponse = await PostService.getAll();
      let criteria = {};
      if (args.store_id) {
        criteria = {
          order: [["createdAt", "DESC"]],
          where: { store_id: args.store_id },
        };
      } else {
        criteria = {
          order: [["createdAt", "DESC"]],
        };
      }
      let allPost = await database.SellerPost.findAll();

      for (let i = 0; i < allPost.length; i++) {
        const sellerPost = JSON.parse(JSON.stringify(allPost[i]));
        const sellerPostImage = allPost[i].image;
        // const sellerPostVideo = allPost[i].video;
        const image = await stringToUrlWithId(sellerPostImage);
        // const video = await stringToUrlWithId(sellerPostVideo);
        let payload = {
          ...sellerPost,
          image: image,
          // video: video,
        };
        result.push(payload);
      }
      return result;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
};
