module.exports = {
  randomArray: async (root, { input }, { user }) => {
    return { array: [...Array(6)].map((e) => ~~(Math.random() * 99)) };
  },
};
