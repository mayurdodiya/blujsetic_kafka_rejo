const { AuthenticationError } = require("apollo-server-express");

const SavePostService = require("../../../database/services/savepost");
const database = require("../../../database/models");
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
module.exports = {
  getAllSavepost: async (root, args, { user }) => {
    if (user != null) {
      const allSavePost = await SavePostService.getAll({ user_id: user.id });
      // console.log("allSavePost", JSON.parse(JSON.stringify(allSavePost)));
      for await (const item of allSavePost) {
        let medias = await database.Media.findAll({
          where: {
            id: { [Op.in]: item.post.media_id }
          },
        });
        medias = JSON.parse(JSON.stringify(medias))
        let mediasData = medias.map((media) => {
          return { ...media, url: media?.media };
        });
        item.post.medias = mediasData ? mediasData : [];
      }
      return allSavePost;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getSingleSavepost: async (_, { id }, { user }) => {
    if (user != null) {
      return SavePostService.getById(id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
};
