const { AuthenticationError } = require("apollo-server-express");
const database = require("../../../database/models");
const StoreService = require("../../../database/services/store");
const FollowStoreService = require("../../../database/services/followstore");
const { stringToUrl } = require("../../../middlewares/utils");
const { Op, Sequelize, where, json } = require("sequelize");
const moment = require("moment");
const FriendService = require("../../../database/services/friend");
const elasticClient = require("../../../services/elasticsearch");
const storeActivity = require("../../../services/elasticsearch/storeActivity/storeActivity");
const { checkStatusesForFriend } = require("../../../utils/utils");
const redisClient = require("../../../redis/redisClient");
const async = require("async");
const { default: slugify } = require("slugify");
const csvWriter = require("csv-writer").createObjectCsvWriter;

let q = async.queue(function ({ user, include, database_type, type, redisIndex }, callback) {
  process.nextTick(async () => {
    let get_stores_count;
    let res18;
    let where = {};
    where = {
      product_count: {
        [Op.gt]: 0,
      },
      status: "Active",
    };

    get_stores_count = await database.BusinessInformation.count({
      where: where,
    });

    res18 = await redisClient.llen(redisIndex);

    console.log("get_stores_count, res18 .>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>++++++++++++++", res18, get_stores_count);
    if (res18 !== get_stores_count) {
      // let redis_list_name = (user?.id && type === "ALL_STORE") || !user?.id ? "PUBLIC:ALL_STORES" : `USER/${user?.id}:${type}`;
      // console.log("redis_list_name++++++++++++++++++++++++++", redis_list_name);
      const res45 = await redisClient.del(redisIndex);
      try {
        let get_stores = await database.BusinessInformation.findAll({
          where: where,
          attributes: ["id", "name", "slug", "logo_image", "banner_image", "product_count", "createdAt"],
          include: include,
          order: [["name", "ASC"]],
          // raw: true,
        });

        let stores = JSON.parse(JSON.stringify(get_stores));
        let storesArray = [];
        // console.log("fucntion-called++++++++++++++++++++++++++", stores);
        for (const store of stores) {
          let followers_count = await database.FollowStore.count({
            where: {
              store_id: Number(store.id),
            },
          });
          store.followers_count = followers_count;

          let like_count = await database.StoreLike.count({
            where: {
              store_id: store.id,
            },
          });
          store.like_count = like_count;

          // let start_date = moment().subtract(30, "days").toISOString();
          // let end_date = moment().toISOString();
          // let data = await storeActivity.getAllStoreActivityChartData({ store_id: store.id, start_date, end_date });
          // store.total_visitors = data?.current_total_user_reached_count;
          // store.past_visitors = data?.previous_total_user_reached_count_percentage;

          if (user?.id) {
            let isFollow = await database.FollowStore.findOne({
              where: {
                store_id: store.id,
                user_id: Number(user.id),
              },
            });
            store.isFollow = isFollow ? true : false;

            let isLike = await database.StoreLike.findOne({
              where: {
                store_id: store.id,
                user_id: Number(user.id),
              },
            });
            store.isLike = isLike ? true : false;
          } else {
            store.isLike = false;
            store.isFollow = false;
          }

          let find_product = await database.Product.findAll({
            where: {
              store_id: store.id,
            },
            limit: 5,
            attributes: ["id"],
            raw: true,
          });

          let n = find_product ? find_product?.length : 0;
          if (Boolean(find_product.length)) {
            let image = [];
            for (let i = 0; i < n; i++) {
              if (i === 5) break;
              const product = find_product[i];
              let find_product_images = await database.ProductMedia.findOne({
                where: {
                  product_id: product.id,
                },
                order: [["createdAt", "DESC"]],
                attributes: ["src"],
                raw: true,
              });
              if (find_product_images) {
                image.push(find_product_images.src);
              }
            }
            store.product_images = image;
          }
          if (database_type === "redis") {
            let add_data = await redisClient.lpush(redisIndex, JSON.stringify(store));
            console.log("adding data in Redis >>>>>>>>>>>>>>>>>>>>", add_data);
          } else {
            storesArray.push(store);
            console.log("not adding into DB pushing for response >>>>>>>>>>>>>>>>>>>>");
          }
        }
        callback();
        // await getStoreDetails(get_stores, "redis", redis_list_name, user);
      } catch (e) {
        console.log("sdfasdfdsfafdasfafdasfdasf >>>>>>>>>>", e);
      }
    }
  });
}, 1);

q.drain(function () {
  console.log("All tasks have been processed");
});

const userQueues = new Map();

function handleRequest(requestData) {
  return new Promise((resolve, reject) => {
    if (!userQueues.has(requestData?.user?.id)) {
      userQueues.set(
        requestData?.user?.id,
        async.queue((taskData, callback) => {
          // Removed async keyword here
          // Process the task here
          processRequest(taskData)
            .then((result) => {
              // console.log("result+++++++++++++", result);
              callback(null, result);
            })
            .catch((error) => callback(error));
        })
      );
    }

    userQueues.get(requestData?.user?.id).push(requestData, (error, result) => {
      if (error) {
        console.log("error ======================================", error);
        reject(error);
      } else {
        resolve(result);
      }
    });
  });
}

async function processRequest({ user, include, database_type, type, redisIndex }) {
  process.nextTick(async () => {
    let get_stores_count;
    let res18;
    let where = {};
    // "JOIN_STORES"
    // "SUGGESTED_STORES"
    // "ALL_STORE"
    switch (type) {
      case "JOIN_STORES":
        where = {
          product_count: {
            [Op.gt]: 0,
          },
          status: "Active",
        };
        // where = {
        //   id: {
        //     [Op.in]: Sequelize.literal(`
        //     (SELECT DISTINCT "store_id"
        //      FROM "Products"
        //      WHERE "status" = 'Publish')
        //   `),
        //   },
        //   status: "Active",
        // };
        get_stores_count = await database.BusinessInformation.count({
          where: where,
          include: [
            {
              model: database.FollowStore,
              as: "follow_store",
              where: {
                user_id: user?.id,
              },
            },
          ],
        });
        include = [
          {
            model: database.FollowStore,
            as: "follow_store",
            where: {
              user_id: user?.id,
            },
          },
        ];
        res18 = await redisClient.llen(redisIndex);
        break;
      case "SUGGESTED_STORES":
        let storeJoinedIds = await database.FollowStore.findAll({
          where: {
            user_id: user?.id,
          },
          raw: true,
        });
        let only_id = storeJoinedIds.map((store) => store.store_id);
        console.log("only_id+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", only_id);
        where = {
          product_count: {
            [Op.gt]: 0,
          },
          id: { [Op.not]: only_id },
          status: "Active",
        };
        get_stores_count = await database.BusinessInformation.count({
          where: where,
        });
        res18 = await redisClient.llen(redisIndex);
        break;
      case "ALL_STORE":
        where = {
          product_count: {
            [Op.gt]: 0,
          },
          status: "Active",
        };
        // where = {
        //   id: {
        //     [Op.in]: Sequelize.literal(`
        //     (SELECT DISTINCT "store_id"
        //      FROM "Products"
        //      WHERE "status" = 'Publish')
        //   `),
        //   },
        //   status: "Active",
        // };
        get_stores_count = await database.BusinessInformation.count({
          where: where,
        });
        res18 = await redisClient.llen(redisIndex);
        break;
      default:
        break;
    }

    if (res18 !== get_stores_count) {
      // let redis_list_name = (user?.id && type === "ALL_STORE") || !user?.id ? "PUBLIC:ALL_STORES" : `USER/${user?.id}:${type}`;
      // console.log("redis_list_name++++++++++++++++++++++++++", redis_list_name);
      const res45 = await redisClient.del(redisIndex);
      try {
        let get_stores = await database.BusinessInformation.findAll({
          where: where,
          attributes: ["id", "name", "slug", "logo_image", "banner_image", "product_count", "createdAt"],
          include: include,
          order: [["name", "ASC"]],
          // raw: true,
        });

        let stores = JSON.parse(JSON.stringify(get_stores));
        let storesArray = [];
        // console.log("fucntion-called++++++++++++++++++++++++++", stores);
        for (const store of stores) {
          let followers_count = await database.FollowStore.count({
            where: {
              store_id: Number(store.id),
            },
          });
          store.followers_count = followers_count;

          let like_count = await database.StoreLike.count({
            where: {
              store_id: store.id,
            },
          });
          store.like_count = like_count;

          // let start_date = moment().subtract(30, "days").toISOString();
          // let end_date = moment().toISOString();
          // let data = await storeActivity.getAllStoreActivityChartData({ store_id: store.id, start_date, end_date });
          // store.total_visitors = data?.current_total_user_reached_count;
          // store.past_visitors = data?.previous_total_user_reached_count_percentage;

          if (user?.id) {
            let isFollow = await database.FollowStore.findOne({
              where: {
                store_id: store.id,
                user_id: Number(user.id),
              },
            });
            store.isFollow = isFollow ? true : false;

            let isLike = await database.StoreLike.findOne({
              where: {
                store_id: store.id,
                user_id: Number(user.id),
              },
            });
            store.isLike = isLike ? true : false;
          } else {
            store.isLike = false;
            store.isFollow = false;
          }

          let find_product = await database.Product.findAll({
            where: {
              store_id: store.id,
            },
            limit: 5,
            attributes: ["id"],
            raw: true,
          });

          let n = find_product ? find_product?.length : 0;
          if (Boolean(find_product.length)) {
            let image = [];
            for (let i = 0; i < n; i++) {
              if (i === 5) break;
              const product = find_product[i];
              let find_product_images = await database.ProductMedia.findOne({
                where: {
                  product_id: product.id,
                },
                order: [["createdAt", "DESC"]],
                attributes: ["src"],
                raw: true,
              });
              if (find_product_images) {
                image.push(find_product_images.src);
              }
            }
            store.product_images = image;
          }
          if (database_type === "redis") {
            let add_data = await redisClient.lpush(redisIndex, JSON.stringify(store));
            console.log("adding data in Redis >>>>>>>>>>>>>>>>>>>>", add_data);
          } else {
            storesArray.push(store);
            console.log("not adding into DB pushing for response >>>>>>>>>>>>>>>>>>>>");
          }
        }
        return;
      } catch (e) {
        console.log("sdfasdfdsfafdasfafdasfdasf >>>>>>>>>>", e);
      }
    }
  });
}

module.exports = {
  getStores: async (root, args, { user }) => {
  //   try {
  //     const user_pk = user?.token_type === "admin" ? args?.user_id : user?.id;
  //     if (user?.token_type === "admin" && !args?.user_id) {
  //       return { success: false, message: "User id is Mandatory." };
  //     }

  //     let { search, page = 1, limit = 10, type } = args;
  //     if (limit && page) {
  //       var offset = (parseInt(page) - 1) * limit;
  //       limit = parseInt(limit);
  //     }
  //     let include = [];
  //     let where = {};
  //     let searchKeyword = args?.search ? args?.search : "";
  //     const getProducts = await database.BusinessInformation.findAndCountAll({
  //       where,
  //       include,
  //       order: [["name", "ASC"]],
  //       limit,
  //       offset,
  //       attributes: ["id", "name", "slug", "logo_image", "banner_image", "product_count", "createdAt"],
  //     });

  //     const allstores = JSON.parse(JSON.stringify(getProducts.rows));
  //     let storesA = [];

  //     let redisKey = `USER:${args?.type}:PAGE:${args.page}:LIMIT:${args.limit}`;

  //     // let getSotredData = await redisClient.get(redisKey);
      
  //     // if (getSotredData) {
  //     //   return { success: true, message: "Product Data Fetched Successfully", data: JSON.parse(getSotredData)};
  //     // }
            
  //     for (const store of allstores) {
  //       let followers_count = await database.FollowStore.count({
  //         where: {
  //           store_id: Number(store.id),
  //         },
  //       });
  //       store.followers_count = followers_count;

  //       let like_count = await database.StoreLike.count({
  //         where: {
  //           store_id: store.id,
  //         },
  //       });
  //       store.like_count = like_count;

  //       if (user_pk) {
  //         let isFollow = await database.FollowStore.findOne({
  //           where: {
  //             store_id: store.id,
  //             user_id: Number(user_pk),
  //           },
  //         });
  //         store.isFollow = isFollow ? true : false;

  //         let isLike = await database.StoreLike.findOne({
  //           where: {
  //             store_id: store.id,
  //             user_id: Number(user_pk),
  //           },
  //         });
  //         store.isLike = isLike ? true : false;
  //       } else {
  //         store.isLike = false;
  //         store.isFollow = false;
  //       }

  //       let find_product = await database.Product.findAll({
  //         where: {
  //           store_id: store.id,
  //         },
  //         limit: 5,
  //         attributes: ["id"],
  //         raw: true,
  //       });

  //       let n = find_product ? find_product?.length : 0;
  //       if (Boolean(find_product.length)) {
  //         let image = [];
  //         for (let i = 0; i < n; i++) {
  //           if (i === 5) break;
  //           const product = find_product[i];
  //           let find_product_images = await database.ProductMedia.findOne({
  //             where: {
  //               product_id: product.id,
  //             },
  //             order: [["createdAt", "DESC"]],
  //             attributes: ["src"],
  //             raw: true,
  //           });
  //           if (find_product_images) {
  //             image.push(find_product_images.src);
  //           }
  //         }
  //         store.product_images = image;
  //       } 
  //       storesA.push(store);
  //     }

  //     // await redisClient.set(redisKey, JSON.stringify(storesA), 'EX', 3600 * 24 * 1);

  //     const types = ["JOIN_STORES", "SUGGESTED_STORES", "ALL_STORE"];

  //     if (!types.includes(type)) {
  //       return { success: false, message: "Wrong type Provided.", data: { stores: storesArray } };
  //     }

  //     if (!types.includes(type)) {
  //       return { success: false, message: "Wrong type Provided.", data: { stores: storesArray } };
  //     }

  //     let storeB = [];
  //     if (user_pk) {
  //       console.log("<<<<<<<<<<<<<<<<<<< Called with token >>>>>>>>>>>>>>>");

  //       switch (type) {
  //         case "JOIN_STORES":
  //           where = {
  //             product_count: {
  //               [Op.gt]: 0,
  //             },
  //             status: "Active",
  //           };
  //           include = [
  //             {
  //               model: database.FollowStore,
  //               as: "follow_store",
  //               where: {
  //                 user_id: user_pk,
  //               },
  //             },
  //           ];
  //           get_stores_count = await database.BusinessInformation.count({
  //             where: where,
  //             include: include,
  //           });
  //           redisIndex = `JOIN_STORES`;
  //           // res18 = await redisClient.llen(redisIndex);
  //           // res18 = await redisClient.lrange(`USER/${user?.id}:${type}`, startIndex, endIndex);
  //           let join_store = await redisClient.get(redisIndex);
  //           let def = await JSON.parse(join_store);
  //           res18 = def.length;
  //           break;
  //         case "SUGGESTED_STORES":
  //           let storeJoinedIds = await database.FollowStore.findAll({
  //             where: {
  //               user_id: user_pk,
  //             },
  //             raw: true,
  //           });
  //           let only_id = storeJoinedIds.map((store) => store.store_id);
  //           where = {
  //             product_count: {
  //               [Op.gt]: 0,
  //             },
  //             id: { [Op.not]: only_id },
  //             status: "Active",
  //           };
  //           get_stores_count = await database.BusinessInformation.count({
  //             where: where,
  //           });
  //           redisIndex = `SUGGESTED_STORES`;
  //           // res18 = await redisClient.llen(redisIndex);
  //           let suggested_stores = await redisClient.get(redisIndex);
  //           let abc = await JSON.parse(suggested_stores);
  //           res18 = abc.length;
  //           break;
  //         case "ALL_STORE":
  //           where = {
  //             product_count: {
  //               [Op.gt]: 0,
  //             },
  //             status: "Active",
  //           };
  //           where = searchKeyword
  //             ? {
  //               ...where,
  //               [Op.or]: [
  //                 {
  //                   name: { [Op.iLike]: `%${searchKeyword}%` },
  //                 },
  //               ],
  //             }
  //             : where;
  //           get_stores_count = await database.BusinessInformation.count({
  //           where
  //           });
  //           // storeB = await redisClient.get(redisKey);
  //           break;
  //         default:
  //           break;
  //       }
  //     }
  //     // else {
  //     //   console.log("<<<<<<<<<<<<<<<<<<< Called Without with token >>>>>>>>>>>>>>>");
  //     //   where = {
  //     //     product_count: {
  //     //       [Op.gt]: 0,
  //     //     },
  //     //     status: "Active",
  //     //   };
  //     //   where = searchKeyword
  //     //     ? {
  //     //       ...where,
  //     //       [Op.or]: [
  //     //         {
  //     //           name: { [Op.iLike]: `%${searchKeyword}%` },
  //     //         },
  //     //       ],
  //     //     }
  //     //     : where;
  //     //   get_stores_count = await database.BusinessInformation.count({
  //     //     where: where,
  //     //   });
  //     //   redisIndex = `PUBLIC:ALL_STORE`;
  //     //   const res18 = await redisClient.llen(redisIndex);
  //     //   console.log("res18++++++++++++++++++++++++++++++++++", res18);
  //     //   await chooseDatabase(res18, get_stores_count, redisIndex, where);
  //     //   q.push(
  //     //     {
  //     //       user: user,
  //     //       include: include,
  //     //       database_type: "redis",
  //     //       type: type,
  //     //       redisIndex: redisIndex,
  //     //     },
  //     //     function (err) {
  //     //       if (err) {
  //     //         console.error(err);
  //     //         console.log("Error processing request++++++++++++++++++++++++++");
  //     //       } else {
  //     //         console.log("Request is being processed");
  //     //       }
  //     //     }
  //     //   );
  //     // }

  //     return { success: true, message: "Data successfully", data: { stores: JSON.parse(storeB), count: get_stores_count } };

  //   } catch (error) {
  //     console.log("Error Getting All products:->", error);
  //     throw new Error("Error Getting All products:->", error)
  //   }
  },

  getAllStore: async (root, args, { user, res }) => {
    const user_pk = user?.token_type === "admin" ? args?.user_id : user?.id;
    try {
      if (user?.token_type === "admin" && !args?.user_id) {
        return { success: false, message: "User id is Mandatory." };
      }

      let { search, page = 1, limit = 10000, type } = args;
      if (limit && page) {
        var offset = (parseInt(page) - 1) * limit;
        limit = parseInt(limit);
      }
      let storesArray = [];
      let get_stores_count = 0;
      let res18 = [];
      let include = [];
      let redisIndex = "";
      let where = {};
      let searchKeyword = args?.search ? args?.search : "";

      // let count = 0;
      // count = await database.BusinessInformation.count({
      //   where: {
      //     product_count: {
      //       [Op.gt]: 0,
      //     },
      //     status: "Active",
      //   },
      // });

      const chooseDatabase = async (res18, get_stores_count, redisIndex, where) => {
        console.log("res18 === get_stores_count", res18 === get_stores_count, res18, get_stores_count);
        if (res18 === get_stores_count) {
          const startIndex = (page - 1) * limit;
          const endIndex = startIndex + limit - 1;
          let redis_list = await redisClient.lrange(redisIndex, startIndex, endIndex);
          for (let i = 0; i < redis_list?.length; i++) {
            let store = redis_list[i];
            storesArray.push(JSON.parse(store));
          }
        } else {
          let get_stores = [];
          console.log("fetching from Database >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", user_pk);
          get_stores = await database.BusinessInformation.findAndCountAll({
            where: where,
            include: include,
            order: [["name", "ASC"]],
            limit: limit,
            offset: offset,
            attributes: ["id", "name", "slug", "logo_image", "banner_image", "product_count", "createdAt"],
          });
          console.log("get_stores >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", get_stores);

          await getStoreDetails(get_stores?.rows, "database", null);
        }
      };

      const getStoreDetails = async (get_stores, database_type, redis_list_name) => {
        let stores = JSON.parse(JSON.stringify(get_stores));
        for (const store of stores) {
          let followers_count = await database.FollowStore.count({
            where: {
              store_id: Number(store.id),
            },
          });
          store.followers_count = followers_count;

          let like_count = await database.StoreLike.count({
            where: {
              store_id: store.id,
            },
          });
          store.like_count = like_count;

          // let start_date = moment().subtract(30, "days").toISOString();
          // let end_date = moment().toISOString();
          // let data = await storeActivity.getAllStoreActivityChartData({ store_id: store.id, start_date, end_date });
          // store.total_visitors = data?.current_total_user_reached_count;
          // store.past_visitors = data?.previous_total_user_reached_count_percentage;

          if (user_pk) {
            let isFollow = await database.FollowStore.findOne({
              where: {
                store_id: store.id,
                user_id: Number(user_pk),
              },
            });
            store.isFollow = isFollow ? true : false;

            let isLike = await database.StoreLike.findOne({
              where: {
                store_id: store.id,
                user_id: Number(user_pk),
              },
            });
            store.isLike = isLike ? true : false;
          } else {
            store.isLike = false;
            store.isFollow = false;
          }

          let find_product = await database.Product.findAll({
            where: {
              store_id: store.id,
            },
            limit: 5,
            attributes: ["id"],
            raw: true,
          });

          let n = find_product ? find_product?.length : 0;
          if (Boolean(find_product.length)) {
            let image = [];
            for (let i = 0; i < n; i++) {
              if (i === 5) break;
              const product = find_product[i];
              let find_product_images = await database.ProductMedia.findOne({
                where: {
                  product_id: product.id,
                },
                order: [["createdAt", "DESC"]],
                attributes: ["src"],
                raw: true,
              });
              if (find_product_images) {
                image.push(find_product_images.src);
              }
            }
            store.product_images = image;
          }
          if (database_type === "redis") {
            let add_data = await redisClient.lpush(redis_list_name, JSON.stringify(store));
            console.log("adding data in Redis >>>>>>>>>>>>>>>>>>>>", add_data);
          } else {
            storesArray.push(store);
            console.log("not adding into DB pushing for response >>>>>>>>>>>>>>>>>>>>");
          }
        }
      };

      let types = ["JOIN_STORES", "SUGGESTED_STORES", "ALL_STORE"];
      if (!types.includes(type)) {
        return { success: false, message: "Wrong type Provided.", data: { stores: storesArray } };
      }
      if (user_pk) {
        console.log("<<<<<<<<<<<<<<<<<<< Called with token >>>>>>>>>>>>>>>");

        switch (type) {
          case "JOIN_STORES":
            where = {
              product_count: {
                [Op.gt]: 0,
              },
              status: "Active",
            };
            //   where = {
            //     id: {
            //       [Op.in]: Sequelize.literal(`
            //   (SELECT DISTINCT "store_id"
            //    FROM "Products"
            //    WHERE "status" = 'Publish')
            // `),
            //     },
            //     status: "Active",
            //   };
            include = [
              {
                model: database.FollowStore,
                as: "follow_store",
                where: {
                  user_id: user_pk,
                },
              },
            ];
            get_stores_count = await database.BusinessInformation.count({
              where: where,
              include: include,
            });
            redisIndex = `USER/${user_pk}:${type}`;
            res18 = await redisClient.llen(redisIndex);
            // res18 = await redisClient.lrange(`USER/${user?.id}:${type}`, startIndex, endIndex);
            break;
          case "SUGGESTED_STORES":
            let storeJoinedIds = await database.FollowStore.findAll({
              where: {
                user_id: user_pk,
              },
              raw: true,
            });
            let only_id = storeJoinedIds.map((store) => store.store_id);
            where = {
              product_count: {
                [Op.gt]: 0,
              },
              id: { [Op.not]: only_id },
              status: "Active",
            };
            get_stores_count = await database.BusinessInformation.count({
              where: where,
            });
            redisIndex = `USER/${user_pk}:${type}`;
            res18 = await redisClient.llen(redisIndex);
            break;
          case "ALL_STORE":
            where = {
              product_count: {
                [Op.gt]: 0,
              },

              status: "Active",
            };
            where = searchKeyword
              ? {
                ...where,
                [Op.or]: [
                  {
                    name: { [Op.iLike]: `%${searchKeyword}%` },
                  },
                ],
              }
              : where;
            get_stores_count = await database.BusinessInformation.count({
              where: where,
            });
            // res18 = await redisClient.lrange(`PUBLIC:ALL_STORES`, 0, -1);
            redisIndex = `USER/${user_pk}:${type}`;
            res18 = await redisClient.llen(redisIndex);
            // res18 = await redisClient.lrange(`PUBLIC:ALL_STORES`, startIndex, endIndex);
            break;
          default:
            break;
        }

        await chooseDatabase(res18, get_stores_count, redisIndex, where);

        await handleRequest({
          user: user,
          include: include,
          database_type: "redis",
          type: type,
          redisIndex: redisIndex,
        });

        // q.push(
        //   {
        //     user: user,
        //     include: include,
        //     database_type: "redis",
        //     type: type,
        //     redisIndex: redisIndex,
        //   },
        //   function (err) {
        //     if (err) {
        //       console.error(err);
        //       console.log("Error processing request++++++++++++++++++++++++++");
        //     } else {
        //       console.log(" proRequest is beingcessed");
        //     }
        //   }
        // );
      } else {
        console.log("<<<<<<<<<<<<<<<<<<< Called Without with token >>>>>>>>>>>>>>>");
        where = {
          product_count: {
            [Op.gt]: 0,
          },
          status: "Active",
        };
        where = searchKeyword
          ? {
            ...where,
            [Op.or]: [
              {
                name: { [Op.iLike]: `%${searchKeyword}%` },
              },
            ],
          }
          : where;
        // where = {
        //   id: {
        //     [Op.in]: Sequelize.literal(`
        //     (SELECT DISTINCT "store_id"
        //      FROM "Products"
        //      WHERE "status" = 'Publish')
        //   `),
        //   },
        //   status: "Active",
        // };
        get_stores_count = await database.BusinessInformation.count({
          where: where,
        });
        redisIndex = `PUBLIC:ALL_STORE`;
        const res18 = await redisClient.llen(redisIndex);
        console.log("res18++++++++++++++++++++++++++++++++++", res18);
        await chooseDatabase(res18, get_stores_count, redisIndex, where);
        q.push(
          {
            user: user,
            include: include,
            database_type: "redis",
            type: type,
            redisIndex: redisIndex,
          },
          function (err) {
            if (err) {
              console.error(err);
              console.log("Error processing request++++++++++++++++++++++++++");
            } else {
              console.log("Request is being processed");
            }
          }
        );
      }

      console.log(storesArray)
      return { success: true, message: "Data successfully", data: { stores: storesArray, count: get_stores_count } };
    } catch (error) {
      console.log("ERRRRRRRRRR", error);
    }
  },

  getStoreFollow: async (root, args, { user }) => {
    try {
      let { store_id, page, limit, product_id } = args;
      let isExist = false;
      let isBookmark = false;
      let bookmark_id;
      let collection_id;
      if (store_id && user?.id) {
        const isFollowStore = await FollowStoreService.getById(store_id, user?.id);
        if (isFollowStore) {
          isExist = true;
        }
      }

      if (product_id && user?.id) {
        get_bookmark = await database.Bookmark.findOne({
          where: {
            product_id: Number(product_id),
            user_id: Number(user?.id),
          },
          atributes: ["id", "collection_id"],
          raw: true,
        });
        if (get_bookmark) {
          bookmark_id = get_bookmark?.id;
          collection_id = get_bookmark?.collection_id;
          isBookmark = true;
        }
      }

      return { success: true, message: "Data successfully", isFollow: isExist, isBookmark: isBookmark, bookmark_id: bookmark_id, collection_id: collection_id };
    } catch (error) {
      console.log("ERRRRRRRRRR", error);
    }
  },

  getStoreSingleLike: async (root, { store_id }, { user }) => {
    try {
      let isExist = false;
      if (store_id && user?.id) {
        const isLikeStore = await database.StoreLike.findOne({
          where: {
            store_id: Number(store_id),
            user_id: Number(user?.id),
          },
        });
        if (isLikeStore) {
          isExist = true;
        }
      } else {
        new AuthenticationError("Error in store id or user id");
      }
      return { success: true, message: "Data successfully", isLike: isExist };
    } catch (error) {
      console.log("ERRRRRRRRRR", error);
    }
  },

  getAllAdminStore: async (root, { limit, page, search, category = [], subCategory = [], status, order}, { user }) => {
    if (!user) return new AuthenticationError("Please Login");
    if (user.token_type !== "admin") return new AuthenticationError("Unauthorized");

    try {
      let offset;
      if (page && limit) {
        limit = parseInt(limit);
        offset = (parseInt(page) - 1) * parseInt(limit);
      }

      const categoryIds = category;
      const subCategoryIds = subCategory;

      let order_data = [["name", "ASC"]];
      if (order) {
        if (order === "Date Created") {
          order_data = [["createdAt", "DESC"]];
        } else if (order === "A-Z") {
          order_data = [["name", "ASC"]];
        } else if (order === "Z-A") {
          order_data = [["name", "DESC"]];
        }
      }

      let stores = await database.BusinessInformation.findAndCountAll({
        where: {
          ...(search && {
            name: {
              [Op.iLike]: `%${search}%`,
            },
          }),
          ...(status && {
            status: status,
          }),
          is_deleted: false,
        },
        attributes: [
          "id", 
          "name", 
          "logo_image",
          "createdAt",
          "status",
          "sellerType",
          ["product_count", "products_count"],
          ["state_name", "state"],
          [
            Sequelize.literal(`(
              SELECT COUNT(*) 
              FROM "FollowStores" 
              WHERE "FollowStores"."store_id" = "BusinessInformation"."id"
            )`),
            "followers_count",
          ],
          [
            Sequelize.literal(`(
              SELECT COALESCE(SUM(quantity), 0)::INTEGER 
              FROM "OrderItems" 
              WHERE "OrderItems"."store_id" = "BusinessInformation"."id" AND "order_status" = 'delivered'
            )`),
            "products_sold",
          ],
        ],
        ...(limit && { limit: limit }),
        ...(page && limit && offset && { offset: offset }),
        ...(order_data && { order: order_data }),
        ...((Boolean(categoryIds?.length) || Boolean(subCategoryIds?.length)) && {
          include: [
            {
              model: database.StoreCategories,
              as: "category",
              where: {
                [subCategoryIds?.length > 0 ? Op.and : Op.or]: [{ category_id: categoryIds }, { subCategory_id: subCategoryIds }],
              },
              attributes: ["id"],
            },
          ],
        }),
        raw: true
      });

      // Format the createdAt field using moment
      if (stores && Array.isArray(stores.rows) && stores.rows.length) {

        stores.rows = stores?.rows.map(store => {
          store.createdAt = moment(store?.createdAt).format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
          return store;
        });
      }

      return { success: true, message: "Fetched stores successfully.", data: stores?.rows, total: stores?.count };
    } catch (error) {
      console.error("An error occured while fetching stores: ", error);
      return {
        success: false,
        message: "An error occured while fetching stores!",
        data: null,
        total: null
      };
    }
  },

  getAllStoresDetail: async (root, args, { user }) => {
    if (user != null) {
      const allStores = await StoreService.getAll();

      let result = [];

      //   allStores.forEach(async (store) => {
      for (let index = 0; index < allStores.length; index++) {
        const store = allStores[index];
        store.logo = await stringToUrl(store.logo, store.id);
        store.cover_image = await stringToUrl(store.cover_image, store.id);
        result.push({
          id: store.id,
          businessInformation: store,
        });
        //   });
      }
      return result;
      // }
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getAllStoreWithProducts: async (root, args, { user }) => {
    if (user != null) {
      const allStores = await StoreService.getAll(Sequelize.literal('(SELECT COUNT(*) FROM "Products" WHERE "Products"."store_id" = "BusinessInformation"."id") > 0'));
      console.log("allStores.lengthallStores.length", allStores.length);
      console.log("allStores", JSON.parse(JSON.stringify(allStores)));
      let result = [];

      for (let index = 0; index < allStores.length; index++) {
        const store = allStores[index];

        // product images

        for (const product of store.products) {
          // Images Ids and createurl link
          let images = [];
          if (product.image !== null) {
            // convert in array
            if (product.image.includes("{") && product.image.includes("}")) {
              images = JSON.parse(product.image.replace(/{/g, "[").replace(/}/g, "]"));
              // check is array or not
              if (Array.isArray(images)) {
                if (images.length === 0) {
                  product.image = [];
                } else {
                  for (let i = 0; i < images.length; i++) {
                    images[i] = await database.Media.findOne({
                      where: { id: images[i] },
                    })
                      .then((data) => {
                        if (data.media !== null) {
                          return data.media;
                        } else {
                          return "";
                        }
                      })
                      .catch((err) => {
                        console.log(err);
                      });
                  }
                  // product image with array of url
                  product.image = images;
                }
              }
            }
          } else {
            product.image = [];
          }
        }
        store.logo = await stringToUrl(store.logo, store.id);
        store.cover_image = await stringToUrl(store.cover_image, store.id);

        // user follow store or not

        const followStores = await FollowStoreService.getById(store.id, user.id);

        store.isFollow = followStores ? true : false;

        // Store Followers
        const followStore = await FollowStoreService.getAll(store.id);
        for (const item of followStore) {
          console.log(item.user.profileAvtar);
          if (item.user.profileAvtar != null) {
            console.log(1111111111111111111111111);
          } else {
            console.log(2222222222222222222222222);
          }

          item.user.profileUrl != null
            ? (item.user.profileAvtar = await database.Media.findOne({
              where: {
                id: item.user.profileAvtar ? item.user.profileAvtar[0] : 0,
              },
            }).then((res) => res.media))
            : "";
          item.user.profileCoverImage != null
            ? (item.user.profileCoverImageUrl = await database.Media.findOne({
              where: {
                id: item.user.profileCoverImage[0],
              },
            }).then((res) => {
              return res.media;
            }))
            : "";
        }

        let followers = followStore;

        // mutual friends

        const loginUserFriends = (
          await database.Friend.findAll({
            where: {
              user_id: user.id,
            },
            raw: true,
          })
        ).map((friend) => friend.friend_id);
        const storeFollower = (
          await database.FollowStore.findAll({
            where: {
              store_id: store.id,
            },
            raw: true,
          })
        ).map((friend) => friend.user_id);
        const mutualFriends = loginUserFriends.filter((friend) => storeFollower.includes(friend));

        // mutual friends data
        const userData = await database.User.findAll({
          where: {
            id: {
              [Op.in]: mutualFriends,
            },
          },
          raw: true,
        });

        // mutual friends profile image and cover image
        for (const user of userData) {
          user.profileUrl = await database.Media.findOne({
            where: {
              id: user.profileAvtar ? user.profileAvtar[0] : 0,
            },
          }).then((res) => res.media);
          user.profileCoverImageUrl = await database.Media.findOne({
            where: {
              id: user.profileCoverImage ? user.profileCoverImage[0] : 0,
            },
          }).then((res) => res.media);
        }

        store.mutualFriends = userData;

        result.push({
          id: store.id,
          businessInformation: store,
          products: store.products,
          followers: followers,
        });
      }

      return result;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
  /* get all stores with products and posts */
  getAllStoresWithElasticSearch: async (root, args, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    let { search, page, limit } = args;
    let stores = await elasticClient.store.getAllStoresWithElasticSearch("stores", { search, page, limit, user_id: user.id });
    // console.log("stores", stores);
    if (stores && stores.success === false) {
      return { success: false, message: stores.message, data: [] };
    }
    return { success: true, message: "Data successfully", data: stores.data };
  },

  /* get  popular stores */
  getAllPopularStores: async (root, { category = [], subCategory = [], page = 1, limit = 10 }, { user }) => {
    const categoryIds = category;
    const subCategoryIds = subCategory;
    if (limit && page) {
      var offset = (parseInt(page) - 1) * limit;
      limit = parseInt(limit);
    }

    try {
      let get_stores = await database.BusinessInformation.findAll({
        where: {
          product_count: {
            [Op.gt]: 0,
          },
          status: "Active",
        },
        order: [["createdAt", "DESC"]],
        limit: limit,
        offset: offset,
        attributes: ["id", "name", "slug", "logo_image", "banner_image", "product_count", "createdAt"],
        // ...((Boolean(categoryIds?.length) || Boolean(subCategoryIds?.length)) && {
        include: [
          {
            model: database.StoreLike,
            as: "like",
            attributes: ["id"],
          },
          {
            model: database.StoreCategories,
            as: "category",
            where: {
              [subCategoryIds?.length > 0 ? database.Sequelize.Op.and : database.Sequelize.Op.or]: [{ category_id: categoryIds }, { subCategory_id: subCategoryIds }],
            },
            attributes: ["id"],
          },
        ],
        // }),
      });
      let storesArray = [];
      let stores = JSON.parse(JSON.stringify(get_stores));
      for (const store of stores) {
        let followers_count = await database.FollowStore.count({
          where: {
            store_id: Number(store.id),
          },
        });
        store.followers_count = followers_count;

        let like_count = await database.StoreLike.count({
          where: {
            store_id: store.id,
          },
        });
        store.like_count = like_count;

        // let start_date = moment().subtract(30, "days").toISOString();
        // let end_date = moment().toISOString();
        // let data = await storeActivity.getAllStoreActivityChartData({ store_id: store.id, start_date, end_date });
        // store.total_visitors = data?.current_total_user_reached_count;
        // store.past_visitors = data?.previous_total_user_reached_count_percentage;

        if (user?.id) {
          let isFollow = await database.FollowStore.findOne({
            where: {
              store_id: store.id,
              user_id: Number(user.id),
            },
          });
          store.isFollow = isFollow ? true : false;

          let isLike = await database.StoreLike.findOne({
            where: {
              store_id: store.id,
              user_id: Number(user.id),
            },
          });
          store.isLike = isLike ? true : false;
        } else {
          store.isLike = false;
          store.isFollow = false;
        }

        let find_product = await database.Product.findAll({
          where: {
            store_id: store.id,
          },
          limit: 5,
          attributes: ["id"],
          raw: true,
        });

        let n = find_product ? find_product?.length : 0;
        if (Boolean(find_product.length)) {
          let image = [];
          for (let i = 0; i < n; i++) {
            if (i === 5) break;
            const product = find_product[i];
            let find_product_images = await database.ProductMedia.findOne({
              where: {
                product_id: product.id,
              },
              order: [["createdAt", "DESC"]],
              attributes: ["src"],
              raw: true,
            });
            if (find_product_images) {
              image.push(find_product_images.src);
            }
          }
          store.product_images = image;
        }
        storesArray.push(store);
        console.log("not adding into DB pushing for response >>>>>>>>>>>>>>>>>>>>");
      }

      return { success: true, message: "Data successfully", data: { stores: storesArray } };
    } catch (error) {
      console.log("ERRRRRRRRRR", error);
    }
  },
  /* suggested stores */
  getSuggestedStores: async (root, args, { user }) => {
    // if (!user) return new AuthenticationError("Please Provide the token");
    // let { page, limit } = args;
    // var offset = (parseInt(page) - 1) * limit;
    // limit = parseInt(limit);
    // let stores = await elasticClient.store.getAllStoresWithElasticSearch("stores", { isFollow: false, page, limit, user_id: user?.id });
    // if (stores && stores.success === false) {
    //   return { success: false, message: stores.message, data: [] };
    // }
    // return { success: true, message: "Data successfully", data: stores.data };
    try {
      let { search, page, limit } = args;
      let stores = await database.BusinessInformation.findAll({ raw: true, order: [["name", "ASC"]] });
      let storesArray = [];
      for (const store of stores) {
        console.log(store.id);

        let find_product = await database.Product.findAll({
          where: {
            store_id: store.id,
          },
        });

        store.products = find_product;

        let n = store.products.length;
        if (Boolean(store.products.length)) {
          console.log("store.products+++++++++++++++++++++++++++++++++++++", store.products.length);

          let image = [];
          for (let i = 0; i < n; i++) {
            if (i === 5) break;
            console.log("i++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", i);
            const product = store.products[i];
            let find_product_images = await database.ProductMedia.findOne({
              where: {
                product_id: product.id,
              },
              order: [["createdAt", "DESC"]],
            });

            console.log("find_product_images+++++++++++++++++++++++++++++++++++++++++++++++", product.id, "=====>", JSON.parse(JSON.stringify(find_product_images)));

            if (find_product_images) {
              image.push(find_product_images.src);
            }
            // }
          }
          console.log("image+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", image);
          store.product_images = image;
        }

        // console.log(
        //   "store+++++++++++++++++++++++++++++++++++++++++++++++++++++",
        //   stores.filter((str) => str.id === 1)
        // );

        //*get followers count */  COMMENTED
        let followers_count = await database.FollowStore.count({
          where: {
            store_id: Number(store.id),
          },
        });
        store.followers_count = followers_count;

        /* get roducts count */
        let products_count = await database.Product.count({
          where: {
            store_id: store.id,
          },
        });
        store.products_count = products_count;

        //* COMMENTED
        // let find_product = await database.Product.findAll({
        //   where: {
        //     store_id: store.id,
        //   },
        // });

        // store.products = find_product;
        // // console.log("store.productsstore.productsstore.products", store.products.length);
        // let image = [];
        // let n = 5;
        // if (Boolean(store.products.length)) {
        //   for (let i = 0; i < store.products.length; i++) {
        //     if (i == n - 1) break;
        //     console.log("store.products[i]++++++++++++++++++++++++++++++++++++", store.products[i]);
        //     // const product = store.products[i];
        //     // if (Boolean(product.cropImages.length)) {
        //     //   let cropImages = await findCropImages([product.cropImages[0]]);
        //     //   if (Boolean(cropImages.length)) image.push(cropImages[0]?.croppedFile?.baseURL);
        //     // }
        //   }
        // }

        // return;

        // store.product_images = image;

        //* get store activity */   COMMENTED
        let start_date = moment().subtract(30, "days").toISOString();
        let end_date = moment().toISOString();
        let data = await storeActivity.getAllStoreActivityChartData({ store_id: store.id, start_date, end_date });
        store.total_visitors = data?.current_total_user_reached_count;
        store.past_visitors = data?.previous_total_user_reached_count_percentage;

        if (user?.id) {
          let isFollow = await database.FollowStore.findOne({
            where: {
              store_id: store.id,
              user_id: Number(user.id),
            },
          });
          store.isFollow = isFollow ? true : false;
        } else {
          store.isFollow = false;
        }

        let store_logo = await database.Media.findOne({
          where: {
            id: Number(store?.logo?.length > 0 ? store?.logo[0] : 0),
          },
        });
        if (Boolean(store?.logo?.length) && store_logo) {
          store.logo = store_logo?.media;
        } else {
          store.logo = "";
        }

        let store_cover_image = await database.Media.findOne({
          where: {
            id: Number(store?.cover_image?.length > 0 ? store?.cover_image[0] : 0),
          },
        });
        if (Boolean(store?.cover_image?.length) && store_cover_image) {
          store.cover_image = store_cover_image?.media;
        } else {
          store.cover_image = "";
        }

        let allData = false;
        if (!allData && store.products_count) storesArray.push(store);
        else if (allData) storesArray.push(store);
      }
      return { success: true, message: "Data successfully", data: { stores: storesArray } };
    } catch (error) {
      console.log("ERRRRRRRRRR", error);
    }
  },
  /* get follow stores */
  getFollowStores: async (root, args, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    let { page, limit } = args;
    // let stores = await elasticClient.store.gtAllStoresWithElasticSearch("stores", { isFollow: true, page, limit, user_id: user.id });

    try {
      let { search, page, limit } = args;
      // let stores = await elasticClient.store.getAllStoresWithElasticSearch("stores", { page, limit, user_id: user?.id, allData: false });
      let stores = await database.BusinessInformation.findAll({
        include: [
          {
            model: database.StoreLike,
            as: "like",
            attributes: ["id"],
          },
        ],
      });

      let storesArray = [];
      for (const store of stores) {
        let isFollow = await database.FollowStore.findOne({
          where: {
            store_id: store.id,
            user_id: Number(user.id),
          },
        });
        store.isFollow = isFollow ? true : false;
        if (store.isFollow) {
          /*get followers count */
          let followers_count = await database.FollowStore.count({
            where: {
              store_id: Number(store.id),
              // user_id: Number(user?.id),
            },
          });
          store.followers_count = followers_count;
          /* get roducts count */
          let products_count = await database.Product.count({
            where: {
              store_id: store.id,
            },
          });
          store.products_count = products_count;

          let find_product = await database.Product.findAll({
            where: {
              store_id: store.id,
            },
          });

          store.products = find_product;
          // console.log("store.productsstore.productsstore.products", store.products.length);
          // let image = [];
          // let n = 5;
          // if (Boolean(store.products.length)) {
          //   for (let i = 0; i < store.products.length; i++) {
          //     if (i == n - 1) break;
          //     const product = store.products[i];
          //     if (Boolean(product.cropImages.length)) {
          //       let cropImages = await findCropImages([product.cropImages[0]]);
          //       if (Boolean(cropImages.length)) image.push(cropImages[0]?.croppedFile?.baseURL);
          //       // console.log("product.cropImages", product.cropImages, cropImages);
          //       // console.log("productproduct", product.id);
          //     }
          //   }
          // }
          // store.product_images = image;

          let n = store.products.length;
          if (Boolean(store.products.length)) {
            let image = [];
            for (let i = 0; i < n; i++) {
              if (i === 5) break;
              const product = store.products[i];
              let find_product_images = await database.ProductMedia.findOne({
                where: {
                  product_id: product.id,
                },
                order: [["createdAt", "DESC"]],
              });

              if (find_product_images) {
                image.push(find_product_images.src);
              }
              // }
            }
            store.product_images = image;
          }

          /* get store activity */
          let start_date = moment().subtract(30, "days").toISOString();
          let end_date = moment().toISOString();
          let data = await storeActivity.getAllStoreActivityChartData({ store_id: store.id, start_date, end_date });
          store.total_visitors = data?.current_total_user_reached_count;
          store.past_visitors = data?.previous_total_user_reached_count_percentage;

          let store_logo = await database.Media.findOne({
            where: {
              id: Number(store?.logo?.length > 0 ? store?.logo[0] : 0),
            },
          });
          store.logo = store_logo?.media;

          let store_cover_image = await database.Media.findOne({
            where: {
              id: Number(store?.cover_image?.length > 0 ? store?.cover_image[0] : 0),
            },
          });
          store.cover_image = store_cover_image?.media;

          let allData = false;
          if (!allData && store.products_count) storesArray.push(store);
          else if (allData) storesArray.push(store);
        }
      }
      return { success: true, message: "Data successfully", data: { stores: storesArray } };
    } catch (error) {
      console.log("ERRRRRRRRRR", error);
    }

    // // console.log("stores", stores);
    // if (stores && stores.success === false) {
    //   return { success: false, message: stores.message, data: [] };
    // }
    // return { success: true, message: "Data successfully", data: stores.data };
  },

  getSingleStore: async (_, { slug }, { user }) => {
    try {
      let isExist = false;
      // if (redisClient) {
      //   const hashObject = await redisClient.hgetall(`${tableName}:${slug}`);
      //   if (hashObject?.id) {
      //     if (hashObject?.id && user?.id) {
      //       const isFollowStore = await FollowStoreService.getById(hashObject?.id, user?.id);
      //       if (isFollowStore) {
      //         isExist = true;
      //       }
      //     }
      //     let final_data = { ...hashObject, isExist: isExist };
      //     return { success: true, message: "Store Fetch successfully!", data: final_data };
      //   }
      // } else {
      const get_store = await StoreService.getByName(slug);
      if (!get_store) return new AuthenticationError("Store not found");
      let store = JSON.parse(JSON.stringify(get_store));
      let find_product_count = await database.Product.count({
        where: {
          store_id: get_store?.id,
        },
      });
      if (store?.id && user?.id) {
        const isFollowStore = await FollowStoreService.getById(store?.id, user?.id);
        if (isFollowStore) {
          isExist = true;
        }
      }
      let isFollow = false;
      if (user?.id) {
        let check_isFollow = await database.Friend.findOne({
          where: {
            user_id: Number(user?.id),
            friend_id: Number(store?.store_owner?.id),
          },
        });
        isFollow = check_isFollow ? true : false;
      }
      let final_data = { ...store, store_owner: { ...store?.store_owner, isFollow: isFollow }, isExist: isExist, product_count: find_product_count };
      return { success: true, message: "Store Fetch successfully!", data: final_data };
      // }
    } catch (error) {
      console.log("error >>>>>>>>>>", error);
    }

    // try {
    //   let tableName = "BusinessInformation";
    //   const hashObject = await redisClient.hgetall(`${tableName}:${slug}`);
    //   let isExist = false;
    //   if (hashObject?.id) {
    //     if (hashObject?.id && user?.id) {
    //       const isFollowStore = await FollowStoreService.getById(hashObject?.id, user?.id);
    //       if (isFollowStore) {
    //         isExist = true;
    //       }
    //     }
    //     let final_data = { ...hashObject, isExist: isExist };
    //     return { success: true, message: "Store Fetch successfully!", data: final_data };
    //   } else {
    //     const get_store = await StoreService.getByName(slug);
    //     if (!get_store) return new AuthenticationError("Store not found");
    //     let store = JSON.parse(JSON.stringify(get_store));
    //     let final_data = { ...store, isExist: isExist };
    //     return { success: true, message: "Store Fetch successfully!", data: final_data };
    //   }
    // } catch (error) {
    //   console.log("error >>>>>>>>>>", error);
    // }
  },

/**
 * Retrieves the followers of a store by its slug and returns detailed user information.
 * 
 * @param {Object} _ - Unused parameter placeholder.
 * @param {Object} args - The arguments object.
 * @param {string} args.slug - The slug of the store to retrieve followers for.
 * @param {Object} context - The context object containing user information.
 * @param {Object} context.user - The current authenticated user.
 * 
 * @returns {Promise<Object>} - A promise that resolves to an object containing:
 *   - success: A boolean indicating if the operation was successful.
 *   - message: A string message indicating the result of the operation.
 *   - data: An array of follower objects with detailed profile and friendship status.
 *   - totalFollowers: The total number of followers for the store.
 * 
 * @throws {Error} - If an error occurs during the process.
 */
  getStoreFollowers: async (_, { slug }, { user }) => {
    try {
      let userId = user?.id ? user?.id : null;
      const store = await StoreService.getByName(slug);
      if (!store) {
        return { success: false, message: "Store not Found!" };
      }

      const followStore = await FollowStoreService.getAll(store.id);
      console.log("🚀 ~ getStoreFollowers: ~ followStore:", followStore)
 
      async function checkStatusesForFriend(userId, friendId) {
        if (userId) {
          const friend = await database.Friend.findOne({
            where: {
              user_id: userId,
              friend_id: friendId,
            },
          });
          if (friend) {
            return {
              isActiveForFriendStatus: friend?.isActive || false,
              isFriendForFriendStatus: friend?.isFriend || false,
            };
          } else {
            return {
              isActiveForFriendStatus: false,
              isFriendForFriendStatus: false,
            };
          }
        } else {
          return {
            isActiveForFriendStatus: false,
            isFriendForFriendStatus: false,
          };
        }
      }
      for (const item of followStore) {
        item.user.profileUrl = await database.Media.findOne({
          where: {
            id: item.user.profileAvtar ? item.user.profileAvtar[0] : 0,
          },
        }).then((res) => res.media);
        item.user.profileCoverImageUrl = await database.Media.findOne({
          where: {
            id: item.user.profileCoverImage ? item.user.profileCoverImage[0] : 0,
          },
        }).then((res) => res.media);

        // Friend Status
        let { isActiveForFriendStatus, isFriendForFriendStatus } = await checkStatusesForFriend(userId, item.user.id);
        item.user.isActiveForFriendStatus = isActiveForFriendStatus;
        item.user.isFriendForFriendStatus = isFriendForFriendStatus;
      }

      let followers = followStore;
      
      return { success: true, message: "Fetch successfully!", data: followers, totalFollowers: followStore.length };
    } catch (error) { }
  },

  getStorePosts: async (_, { slug, page, limit }, { user }) => {
    if (limit && page) {
      var offset = (parseInt(page) - 1) * limit;
      limit = parseInt(limit);
    }
    try {
      const find_store = await database.BusinessInformation.findOne({
        where: {
          slug: user?.store_slug ? user?.store_slug : slug,
        },
        raw: true,
      });
      if (!find_store) {
        return { success: false, data: [], message: "Store not Found!" };
      }

      const get_store = await database.Post.findAll({
        where: {
          store_id: find_store?.id,
        },
        limit: limit,
        offset: offset,
        include: [
          {
            model: database.Comment,
            as: "comments",
            attributes: ["id"],
          },
          {
            model: database.Like,
            as: "likes",
            attributes: ["id", "user_id"],
            include: [
              {
                model: database.User,
                as: "user",
              },
            ],
          },
        ],
        order: [
          ["createdAt", "DESC"],
          [{ model: database.Comment, as: "comments" }, "createdAt", "ASC"],
          [{ model: database.Like, as: "likes" }, "createdAt", "ASC"],
        ],
      });

      let store = JSON.parse(JSON.stringify(get_store));

      console.log("store+++++++++++++++++++++++++++", store);

      let posts = [];
      for (let i = 0; i < store?.length; i++) {
        const post = store[i];
        post.comment_count = post.comments.length;

        if (Boolean(post.likes.length)) {
          post.like_count = post.likes.length || 0;
          let n = 3;
          // if (Boolean(post.likes.length)) {
          for (let i = 0; i < post.likes.length; i++) {
            if (i == n - 1) break;
            let user = post.likes[i].user;
            if (user) {
              let user_profileUrl = await database.Media.findOne({
                where: { id: Number(user?.profileAvtar[0]) },
              });
              user.profileUrl = user_profileUrl ? user_profileUrl?.media : "";
              let user_profileCoverImageUrl = await database.Media.findOne({
                where: { id: Number(user?.profileCoverImage[0]) },
              });
              user.profileCoverImageUrl = user_profileCoverImageUrl ? user_profileCoverImageUrl?.media : "";
            }
          }
          // }
        }

        if (post?.media_id?.length > 0) {
          const medias = await database.Media.findAll({
            where: {
              id: {
                [Op.in]: post?.media_id || [],
              },
            },
          });
          post.medias = medias.map((media) => {
            return { ...media.dataValues, url: media.dataValues.media };
          });
        }
        post.store = {
          id: find_store?.id,
          name: find_store?.name,
          logo: [find_store?.logo_image ? find_store?.logo_image : ""],
          cover_image: [find_store?.banner_image ? find_store?.banner_image : ""],
          slug: find_store?.slug,
        };
        posts.push(post);
      }
      return { success: true, data: posts, message: "Fetch Successfully" };
    } catch (error) {
      console.log("error", error);
    }
  },

  getStoreByName: async (_, { slug }, { user }) => {
    if (user != null) {
      const store = await StoreService.getByName(slug);
      console.log(store);
      const seller = await database.Seller.findOne({
        where: {
          id: store.seller_id,
        },
      });
      store.logo = stringToUrl(store.logo, store.id);
      store.cover_image = stringToUrl(store.cover_image, store.id);

      let products = [];
      for (let index = 0; index < store?.products?.length; index++) {
        const images = store.products[index];
        let validImage = await stringToUrl(images.image, images.id);
        images.image = validImage;
        products.push(images);
      }

      let posts = [];
      for (let i = 0; i < store?.posts?.length; i++) {
        const post = store.posts[i];
        let validImage = await stringToUrl(post.image, post.id);
        post.image = validImage;
        posts.push(post);
      }

      let result = {
        id: store.id,
        businessInformation: store,
        products: products,
        seller: seller,
        posts: posts || [],
      };
      return result;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getStorePostsMedia: async (_, { name }, { user }) => {
    if (user != null) {
      const store = await StoreService.getByName(name);
      let stores_collection = store?.posts
        ?.map((post) => {
          return { post_id: post.id, url: post?.media_id };
        })
        .filter((post) => post?.url?.length > 0);

      /* adjust data */
      for (const store_col of stores_collection) {
        store_col.url = (
          await database.Media.findAll({
            where: {
              id: {
                [Op.in]: store_col?.url || [],
              },
            },
            raw: true,
          })
        ).map((m) => m.media);
      }

      console.log("stores", stores_collection);

      return stores_collection;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getSingleAdminStore: async (root, { id }, { user }) => {
    try {
      let updated_find_store = await database.BusinessInformation.findOne({
        where: {
          id: id,
        },
        include: [
          {
            model: database.StoreCategories,
            as: "category",
            attributes: ["category_id", "subCategory_id"],
            include: [
              { model: database.Category, as: "category_data", attributes: ["name"] },
              { model: database.Subcategory, as: "sub_category_data", attributes: ["name"] },
            ],
          },
        ],
      });
      if (!updated_find_store) {
        return { success: false, message: "Store not found" };
      }

      let find_store = JSON.parse(JSON.stringify(updated_find_store));

      // let find_logo = await database.Media.findOne({
      //   where: {
      //     id: Number(find_store?.logo?.length > 0 ? find_store?.logo[0] : 0),
      //   },
      //   raw: true,
      // });

      // let find_cover = await database.Media.findOne({
      //   where: {
      //     id: Number(find_store?.cover_image?.length > 0 ? find_store?.cover_image[0] : 0),
      //   },
      //   raw: true,
      // });
      // let spread_data = {
      //   ...find_store,
      //   cover_image: {
      //     id: find_cover ? find_cover?.id : null,
      //     media: find_cover ? find_cover?.media : "",
      //   },
      //   logo: {
      //     id: find_logo ? find_logo?.id : null,
      //     media: find_logo ? find_logo?.media : "",
      //   },
      // };
      return { success: true, message: "Store Fetch Successfully", data: find_store };
    } catch (error) {
      console.error("Server started.", error);
      throw error;
    }
  },

  getAllStoreLike: async (root, { store_id }, { user }) => {
    // if (!user) return new AuthenticationError("Please Provide the token");
    // if (!user) return new AuthenticationError("Please Provide the token");
    if (!store_id) return { success: false, meesage: "store_id is Mandatory" };

    try {
      let updated_find_store = await database.BusinessInformation.findOne({
        where: {
          id: store_id,
        },
      });
      if (!updated_find_store) {
        return { success: false, message: "Store not found" };
      }
      let store_likes = await database.StoreLike.findAll({
        where: {
          store_id: store_id,
        },
        include: [
          {
            model: database.User,
            as: "storeLikeUsers",
            attributes: ["id", "firstName", "lastName", "profileAvtar", "profileCoverImage", "userName"],
          },
        ],
      });

      let store_detail = JSON.parse(JSON.stringify(store_likes));
      let store_like_users = [];

      for (let i = 0; i < store_detail.length; i++) {
        let single_user = store_detail[i];
        if (single_user) {
          let user_profileUrl = await database.Media.findOne({
            where: {
              id: single_user?.storeLikeUsers?.profileAvtar?.length > 0 ? Number(single_user.storeLikeUsers?.profileAvtar[0]) : 0,
            },
          });

          let user_profileCoverImageUrl = await database.Media.findOne({
            where: {
              id: single_user?.storeLikeUsers?.profileCoverImage?.length > 0 ? Number(single_user.storeLikeUsers?.profileCoverImage[0]) : 0,
            },
          });
          let { isActiveForFriendStatus, isFriendForFriendStatus } = await checkStatusesForFriend(user?.id, single_user?.storeLikeUsers?.id);

          let finalObject = {
            user: {
              ...single_user?.storeLikeUsers,
              profileUrl: user_profileUrl ? user_profileUrl?.media : "",
              profileCoverImage: user_profileCoverImageUrl ? user_profileCoverImageUrl?.media : "",
              isActiveForFriendStatus: user ? isActiveForFriendStatus : false,
              isFriendForFriendStatus: user ? isFriendForFriendStatus : false,
            },
          };
          console.log("finalObject++++++++++++++++++++++++++++++++++", finalObject);
          store_like_users.push(finalObject);
        }
      }

      console.log("store_like_users", store_like_users);

      return { success: true, message: "Fetch Store Likes Successfully", data: store_like_users };
    } catch (error) {
      console.error("Server started.", error);
    }
  },

  addClubsIntoElastic: async (root, { category_id, subCategory_id }, { user }) => {
    try {
      let get_stores = await database.Group.findAll({
        // order: [["createdAt", "DESC"]],
        raw: true,
      });
      for (let i = 0; i < get_stores.length; i++) {
        let store = get_stores[i];
        // let elkData = await elasticClient.user.createUser(store);
        let elkData = await elasticClient.group.addGroup(store);
        if (!elkData.success) throw new Error(elkData.message);
        if (store?.id) {
          let followers_count = await database.FollowStore.count({
            where: {
              store_id: Number(store.id),
            },
          });
          let like_count = await database.StoreLike.count({
            where: {
              store_id: Number(store.id),
            },
          });
          let find_product = await database.Product.findAll({
            where: {
              store_id: store.id,
            },
            limit: 5,
            attributes: ["id"],
            raw: true,
          });
          let n = find_product ? find_product?.length : 0;
          let image = [];
          if (Boolean(find_product.length)) {
            for (let i = 0; i < n; i++) {
              if (i === 5) break;
              const product = find_product[i];
              let find_product_images = await database.ProductMedia.findOne({
                where: {
                  product_id: product.id,
                },
                order: [["createdAt", "DESC"]],
                attributes: ["src"],
                raw: true,
              });
              if (find_product_images) {
                image.push(find_product_images.src);
              }
            }
          }
          const elasticsearch_data = {
            seller_id: store?.seller_id,
            id: store?.id,
            name: store?.name,
            companyLegalName: store?.companyLegalName,
            streetAddress: store?.streetAddress,
            state_name: store?.state_name,
            postalCode: store?.postalCode,
            websiteUrl: store?.websiteUrl,
            businessType: store?.businessType,
            title: store?.title,
            logo_image: store?.logo_image,
            product_count: store?.product_count,
            banner_image: store?.banner_image,
            followers_count: followers_count,
            like_count: like_count,
            product_images: image,
            slug: store?.slug,
            status: store?.status,
            city: "Miami",
            state: "FL",
            shortDescription: "short  Descriptions",
            longDescription: "long Descriptions",
            BusinessInformationFor: "SELLER",
            createdAt: store?.createdAt,
          };
          let add_data = await elasticClient.store.createStore(elasticsearch_data);
        }
      }
    } catch (error) {
      console.log("error  >>>>>>> ", error);
    }
  },

  addStoresIntoElastic: async (root, { category_id, subCategory_id }, { user }) => {
    // ================================================================== BULK_STORE ============================================================================
    // try {
    //   let get_stores = await database.BusinessInformation.findAll({
    //     order: [["createdAt", "DESC"]],
    //     raw: true,
    //   });
    //   for (let i = 0; i < get_stores.length; i++) {
    //     let store = get_stores[i];
    //     if (store?.id) {
    //       let followers_count = await database.FollowStore.count({
    //         where: {
    //           store_id: Number(store.id),
    //         },
    //       });
    //       let like_count = await database.StoreLike.count({
    //         where: {
    //           store_id: Number(store.id),
    //         },
    //       });
    //       let find_product = await database.Product.findAll({
    //         where: {
    //           store_id: store.id,
    //         },
    //         limit: 5,
    //         attributes: ["id"],
    //         raw: true,
    //       });
    //       let n = find_product ? find_product?.length : 0;
    //       let image = [];
    //       if (Boolean(find_product.length)) {
    //         for (let i = 0; i < n; i++) {
    //           if (i === 5) break;
    //           const product = find_product[i];
    //           let find_product_images = await database.ProductMedia.findOne({
    //             where: {
    //               product_id: product.id,
    //             },
    //             order: [["createdAt", "DESC"]],
    //             attributes: ["src"],
    //             raw: true,
    //           });
    //           if (find_product_images) {
    //             image.push(find_product_images.src);
    //           }
    //         }
    //       }
    //       const elasticsearch_data = {
    //         seller_id: store?.seller_id,
    //         id: store?.id,
    //         name: store?.name,
    //         companyLegalName: store?.companyLegalName,
    //         streetAddress: store?.streetAddress,
    //         state_name: store?.state_name,
    //         postalCode: store?.postalCode,
    //         websiteUrl: store?.websiteUrl,
    //         businessType: store?.businessType,
    //         title: store?.title,
    //         logo_image: store?.logo_image,
    //         product_count: store?.product_count,
    //         banner_image: store?.banner_image,
    //         followers_count: followers_count,
    //         like_count: like_count,
    //         product_images: image,
    //         slug: store?.slug,
    //         status: store?.status,
    //         city: "Miami",
    //         state: "FL",
    //         shortDescription: "short  Descriptions",
    //         longDescription: "long Descriptions",
    //         BusinessInformationFor: "SELLER",
    //         createdAt: store?.createdAt,
    //       };
    //       let add_data = await elasticClient.store.createStore(elasticsearch_data);
    //       console.log("add_data++++++++++++++++++++++++++", add_data);
    //     }
    //   }
    // } catch (error) {
    //   console.log("error  >>>>>>> ", error);
    // }
    // ================================================================== BULK_STORE ============================================================================

    // ================================================================== SINGLE_STORE ============================================================================
    const store_id = 319;
    try {
      let get_stores = await database.BusinessInformation.findOne({
        where: {
          id: store_id,
        },
        raw: true,
      });
      let store = get_stores;
      if (store?.id) {
        let followers_count = await database.FollowStore.count({
          where: {
            store_id: Number(store.id),
          },
        });
        let like_count = await database.StoreLike.count({
          where: {
            store_id: Number(store.id),
          },
        });
        let find_product = await database.Product.findAll({
          where: {
            store_id: store.id,
          },
          limit: 5,
          attributes: ["id"],
          raw: true,
        });
        let n = find_product ? find_product?.length : 0;
        let image = [];
        if (Boolean(find_product.length)) {
          for (let i = 0; i < n; i++) {
            if (i === 5) break;
            const product = find_product[i];
            let find_product_images = await database.ProductMedia.findOne({
              where: {
                product_id: product.id,
              },
              order: [["createdAt", "DESC"]],
              attributes: ["src"],
              raw: true,
            });
            if (find_product_images) {
              image.push(find_product_images.src);
            }
          }
        }
        const elasticsearch_data = {
          // seller_id: store?.seller_id,
          // id: store?.id,
          // name: store?.name,
          // companyLegalName: store?.companyLegalName,
          // streetAddress: store?.streetAddress,
          // state_name: store?.state_name,
          // postalCode: store?.postalCode,
          // websiteUrl: store?.websiteUrl,
          // businessType: store?.businessType,
          // title: store?.title,
          // logo_image: store?.logo_image,
          // product_count: store?.product_count,
          // banner_image: store?.banner_image,
          // followers_count: followers_count,
          // like_count: like_count,
          product_images: image,
          // slug: store?.slug,
          // status: store?.status,
          // city: "Miami",
          // state: "FL",
          // shortDescription: "short  Descriptions",
          // longDescription: "long Descriptions",
          // BusinessInformationFor: "SELLER",
          // createdAt: store?.createdAt,
        };

        let elkData = await elasticClient.store.updateStoreById("store", store?.id, elasticsearch_data);
        if (!elkData?.success) return new Error(elkData?.message || "Elasctic search error");
      }
    } catch (error) {
      console.log("error  >>>>>>> ", error);
    }
    // ================================================================== SINGLE_STORE ============================================================================
  },

  createStoreForShopify: async (root, { slug, category_id, subCategory_id }, { user }) => {
    try {
      let storedata = {
        name: "People of Leisure",
        seller_id: 152,
        logo: [62895],
        cover_image: [62896],
        logo_url: "https://bluejestic-media.storage.googleapis.com/bluejestic-stage/store/admin/Logo___SloganGrey_Sage_290x-1712137080378-981920670.webp",
        cover_url: "https://bluejestic-media.storage.googleapis.com/bluejestic-stage/store/admin/People of Leisure-bn-1712137241399-233256789.webp",
        companyLegalName: "Bluejestic",
        streetAddress: "195 NW 36th St",
        state_name: "Florida",
        postalCode: "33101",
        websiteUrl: "https://www.bluejestic.com/",
        businessType: "Part-time",
        title: "Mr",
      };

      //* STORE_CREATE_SCRIPT_START=================================================================================

      let slug = slugify(storedata?.name, { lower: true, replacement: "" });
      let final_slug;

      let is_exist = await database.BusinessInformation.findOne({
        where: {
          name: storedata?.name,
        },
      });

      if (is_exist) {
        return { success: false, message: "Store name already exist" };
      }

      let find_unique_user = await database.BusinessInformation.findOne({
        where: {
          slug: slug,
        },
        raw: true,
      });

      if (find_unique_user) {
        const otp = Math.floor(Math.random() * 900) + 100;
        final_slug = slug + otp;
      } else {
        final_slug = slug;
      }

      console.log("final_slug", final_slug);

      let create_store = await database.BusinessInformation.create({
        seller_id: storedata?.seller_id,
        slug: final_slug,
        name: storedata?.name,
        companyLegalName: storedata?.companyLegalName,
        streetAddress: storedata?.streetAddress,
        city: "Miami",
        state: "FL",
        postalCode: storedata?.postalCode,
        websiteUrl: storedata?.websiteUrl,
        logo: storedata?.logo,
        cover_image: storedata?.cover_image,
        logo_image: storedata?.logo_url,
        banner_image: storedata?.cover_url,
        businessType: storedata?.businessType,
        shortDescription: "-",
        longDescription: "-",
        country: "US",
        title: storedata?.title,
        isFollow: true,
        isLikeShare: true,
        isNotification: true,
        isMessaging: true,
        isTrends: true,
        documents: [],
        status: "Active",
        is_deleted: false,
        BusinessInformationFor: "SELLER",
        firstName: "Bluejestic",
        lastName: "Admin",
        companyEmail: "admin@bluejestic.com",
        phoneNumber: "9568235689",
        accountType: "Large Company",
        productType: "Women - Apparel",
        state_name: storedata?.state_name,
      });

      let store_id = JSON.parse(JSON.stringify(create_store));

      // let store_id = {
      //   id: 319,
      // };
      console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", store_id?.id);

      let store = await database.BusinessInformation.findOne({
        where: {
          id: store_id?.id,
        },
        raw: true,
      });

      if (store?.id) {
        let followers_count = await database.FollowStore.count({
          where: {
            store_id: Number(store.id),
          },
        });

        let like_count = await database.StoreLike.count({
          where: {
            store_id: Number(store.id),
          },
        });

        let find_product = await database.Product.findAll({
          where: {
            store_id: store.id,
          },
          limit: 5,
          attributes: ["id"],
          raw: true,
        });

        let n = find_product ? find_product?.length : 0;
        let image = [];
        if (Boolean(find_product.length)) {
          for (let i = 0; i < n; i++) {
            if (i === 5) break;
            const product = find_product[i];
            let find_product_images = await database.ProductMedia.findOne({
              where: {
                product_id: product.id,
              },
              order: [["createdAt", "DESC"]],
              attributes: ["src"],
              raw: true,
            });
            if (find_product_images) {
              image.push(find_product_images.src);
            }
          }
        }

        const elasticsearch_data = {
          seller_id: store?.seller_id,
          id: store?.id,
          name: store?.name,
          companyLegalName: store?.companyLegalName,
          streetAddress: store?.streetAddress,
          state_name: store?.state_name,
          postalCode: store?.postalCode,
          websiteUrl: store?.websiteUrl,
          businessType: store?.businessType,
          title: store?.title,
          logo_image: store?.logo_image,
          product_count: store?.product_count,
          banner_image: store?.banner_image,
          followers_count: followers_count,
          like_count: like_count,
          product_images: image,
          slug: store?.slug,
          status: store?.status,
          city: "Miami",
          state: "FL",
          shortDescription: "short  Descriptions",
          longDescription: "long Descriptions",
          BusinessInformationFor: "SELLER",
          createdAt: store?.createdAt,
        };

        let add_data = await elasticClient.store.createStore(elasticsearch_data);
        console.log("add_data++++++++++++++++++++++++++", add_data);
      }
    } catch (error) {
      console.log("error+++++++++++", error);
    }
  },

  getStoreSlugList: async (root, { slug, category_id, subCategory_id }, { user }) => {
    try {
      let find_store_slug = await database.BusinessInformation.findAll({
        attributes: ["slug"],
        raw: true,
      });
      console.log("find_store_slug", find_store_slug);
      return { success: true, message: "Fetch successfully!", data: find_store_slug };
    } catch (error) {
      console.log(error);
    }
  },

  generateLogFile: async (root, { slug, category_id, subCategory_id }, { user }) => {
    console.log("asdf dasfdasfdasfdasfasfasfassdfasdfdsafasdfds+++++++++++++++++");
    // const logData = ["2019-11-01 00:00:02 UTC,view,1004258,2053013555631882655,electronics.smartphone,apple,732.07,532647354,d2d3d2c6-631d-489e-9fb5-06f340b85be0"];

    // // Parse log data into objects
    // const parsedLogs = logData.map((log) => {
    //   const [timestamp, action, ...rest] = log.split(",");
    //   return {
    //     timestamp,
    //     action,
    //     item_id: rest[0],
    //     user_id: rest[1],
    //     category: rest[2],
    //     brand: rest[3],
    //     price: rest[4],
    //     session_id: rest[5],
    //     uuid: rest[6],
    //   };
    // });

    // // Write parsed data into a CSV file
    // const csvWriterInstance = csvWriter({
    //   path: "logs.csv",
    //   header: [
    //     { id: "timestamp", title: "Timestamp" },
    //     { id: "action", title: "Action" },
    //     { id: "item_id", title: "Item ID" },
    //     { id: "user_id", title: "User ID" },
    //     { id: "category", title: "Category" },
    //     { id: "brand", title: "Brand" },
    //     { id: "price", title: "Price" },
    //     { id: "session_id", title: "Session ID" },
    //     { id: "uuid", title: "UUID" },
    //   ],
    // });

    // csvWriterInstance
    //   .writeRecords(parsedLogs)
    //   .then(() => console.log("CSV file successfully written"))
    //   .catch((err) => console.error("Error writing CSV file:", err));

    async function getRandomProduct() {
      const count = 10095;
      const offset = Math.floor(Math.random() * count);

      const randomProduct = await database.Product.findOne({
        offset: offset,
        raw: true,
        attributes: ["id", "dis_price"],
      });

      return randomProduct;
    }

    function randomDate(start, end) {
      const startDate = moment(start);
      const endDate = moment(end);
      const diff = endDate.diff(startDate, "seconds");
      const randomSeconds = Math.floor(Math.random() * diff);
      return startDate.add(randomSeconds, "seconds");
    }

    async function getProductCategory(product_id) {
      let find_category = await database.ProductCategories.findOne({
        where: {
          product_id: product_id,
        },
        raw: true,
        attributes: ["category_id", "subCategory_id", "childSubCategory_id"],
      });
      return find_category;
    }

    async function getRandomUser() {
      const count = 15;
      const offset = Math.floor(Math.random() * count);
      const randomProduct = await database.User.findOne({
        offset: offset,
        raw: true,
        attributes: ["id"],
      });
      return randomProduct;
    }

    const rows = [];
    const startDate = moment("2022-01-01");
    const endDate = moment();

    const event_type = ["view", "cart", "remove_from_cart", "purchase"];
    for (let i = 0; i < 5000; i++) {
      if (rows?.length === 5000) break;
      let event_time = randomDate(startDate, endDate).format("YYYY-MM-DD HH:mm:ss") + " UTC";
      let randomIndex = Math.floor(Math.random() * event_type.length); // generate random index
      let randomProduct = await getRandomProduct();
      let findCategory = await getProductCategory(randomProduct?.id);
      let randomUser = await getRandomUser();

      const rowData = {
        event_time,
        event_type: event_type[randomIndex],
        product_id: randomProduct?.id,
        price: randomProduct?.dis_price,
        user_id: randomUser?.id,
        ...findCategory,
      };
      if (findCategory) {
        rows.push(rowData);
        console.log("index >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", i, rows?.length);
      }
    }

    const csvWriterInstance = csvWriter({
      path: "logs.csv",
      header: [
        { id: "event_time", title: "event_time" },
        { id: "event_type", title: "event_type" },
        { id: "product_id", title: "product_id" },
        { id: "category_id", title: "category_id" },
        { id: "subCategory_id", title: "subCategory_id" },
        { id: "childSubCategory_id", title: "childSubCategory_id" },
        { id: "price", title: "price" },
        { id: "user_id", title: "user_id" },
      ],
    });

    csvWriterInstance
      .writeRecords(rows)
      .then(() => console.log("CSV file successfully written"))
      .catch((err) => console.error("Error writing CSV file:", err));

    // console.log(JSON.stringify(rows));
  },

  getStoreDetailById: async (root, { store_id }, { user }) => {
    if (user?.token_type !== "admin") return new AuthenticationError("Unauthorized");
    try {
      const find_store = await database.BusinessInformation.findOne({
        where: {
          id: store_id
        },
        raw: true
      })

      if (!find_store) {
        return { success: false, message: "Store not Found" }
      }

      const get_store_detail = await database.StoreDetail.findOne({
        where: { store_id: find_store?.id },
        raw: true
      })

      if (get_store_detail) {
        return { success: true, message: "Store Detail fetch Successfully", data: get_store_detail }
      } else {
        return { success: true, message: "Something went wrong" }
      }
    } catch (error) {
      console.log('error', error);
    }
  }
};
