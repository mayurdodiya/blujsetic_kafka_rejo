const { AuthenticationError } = require("apollo-server-express");

const ShippingService = require("../../../database/services/shipping");

module.exports = {
  getAllShipping: async (root, args, { user }) => {
    if (user != null) {
      const allShippingDetail = await ShippingService.getAll();
      return allShippingDetail;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  //   getSingleShipping: async (_, { id }, { user }) => {
  //     if (user != null) {
  //       return ShippingService.getById(id);
  //     } else {
  //       return new AuthenticationError("Please Provide the Token");
  //     }
  //   },
};
