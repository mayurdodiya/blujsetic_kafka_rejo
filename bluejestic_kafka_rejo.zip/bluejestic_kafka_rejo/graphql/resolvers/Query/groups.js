fetch("https://stage-graph.bluejestic.com/graphql", {
  "headers": {
    "accept": "*/*",
    "accept-language": "en-US,en;q=0.9",
    "authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6NiwidHlwZSI6InVzZXIiLCJpYXQiOjE2OTU3MjEwNzF9.DL_Af2baaftkHHCcq6OghyfBcgaMtJcfWdvMuksDIRM",
    "content-type": "application/json",
    "sec-ch-ua": "\"Google Chrome\";v=\"117\", \"Not;A=Brand\";v=\"8\", \"Chromium\";v=\"117\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "cross-site",
    "Referer": "http://localhost:3000/",
    "Referrer-Policy": "strict-origin-when-cross-origin"
  },
  "body": "{\"operationName\":\"GET_GROUPS_ONBOARDING\",\"variables\":{},\"query\":\"query GET_GROUPS_ONBOARDING($subCategory_id: Int) {\\n  getAllGroups(subCategory_id: $subCategory_id) {\\n    id\\n    name\\n    description\\n    hashtags\\n    coverImage\\n    bannerImage\\n    privacy\\n    isExist\\n    total_members\\n    members {\\n      id\\n      firstName\\n      lastName\\n      profileUrl: profileAvtar\\n      profileCoverImage\\n      __typename\\n    }\\n    __typename\\n  }\\n}\\n\"}",
  "method": "POST"
});