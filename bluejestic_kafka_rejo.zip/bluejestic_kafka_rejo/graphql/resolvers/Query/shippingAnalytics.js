const { AuthenticationError } = require("apollo-server-express");
const { pendingShipmentsOfSeller, calculatePercentageChange,  } = require("../../../utils/utils");

module.exports = {
    getShippingAnalytics: async (root, { seller_id, time_zone, timeRange }, { user }) => {
        try {

            if (!user) {
                return new AuthenticationError("Please Provide the token");
            }

            seller_id = user?.seller_id;
            if (!seller_id) {
                return new AuthenticationError("Please Provide the seller_id");
            }

            const {
                previousMonthInTransist,
                previourMonthDelivered,
                previousMonthCancelledShipments,
                previousMonthReturnedShippments,
                previousMonthPendingShipments,
                inTransistShipments,
                pendingShipments,
                deliveredShipments,
                cancelledShipments,
                returnedShippments,
                delayedShippings,
                averageShipmentTime,
                changeInAverageShipmentTime
            } = await pendingShipmentsOfSeller(seller_id, time_zone, timeRange);

            const percentageChangeInPendings = calculatePercentageChange(previousMonthPendingShipments,pendingShipments);
            const percentageChangeInTransist = calculatePercentageChange(previousMonthInTransist,inTransistShipments)            
            const percentageChangeInDelivery = calculatePercentageChange(previourMonthDelivered,deliveredShipments);            
            const percentageChangeInCancelled = calculatePercentageChange(previousMonthCancelledShipments,cancelledShipments);                        
            const percentageChangeInReturned = calculatePercentageChange(previousMonthReturnedShippments,returnedShippments);
            const percentageChangeInAverageShipmentTime = calculatePercentageChange(changeInAverageShipmentTime,averageShipmentTime);

            return {
                success: true,
                message: "Seller analytics retrieved successfully",
                data: {
                    pendingShipments: pendingShipments === 0 ? 0 : pendingShipments,
                    percentageChangeInPendings,
                    inTransistShipments: inTransistShipments === 0 ? 0 : inTransistShipments,
                    percentageChangeInTransist,
                    deliveredShipments: deliveredShipments === 0 ? 0 : deliveredShipments,
                    percentageChangeInDelivery,
                    cancelledShipments: cancelledShipments === 0 ? 0 : cancelledShipments,
                    percentageChangeInCancelled,
                    returnedShippments: returnedShippments === 0 ? 0 : returnedShippments,
                    percentageChangeInReturned,
                    delayedShippings,
                    averageShipmentTime,
                    percentageChangeInAverageShipmentTime
                }
            };

        } catch (error) {
            throw new Error('Failed to fetch shipping analytics: ' + error.message);
        }
    }
};  