const { AuthenticationError } = require("apollo-server-express");
const database = require("../../../database/models");
const FriendService = require("../../../database/services/friend");
const { Op } = require("sequelize");
const redisClient = require("../../../redis/redisClient");
const async = require("async");
const Sequelize = require("sequelize");

let q = async.queue(function ({ user, include, database_type, type, redisIndex, table }, callback) {
  process.nextTick(async () => {
    let get_stores_count;
    let res18;
    let where = {};

    table = database.User;
    get_stores_count = await table.count({
      where: where,
    });
    res18 = await redisClient.llen(redisIndex);

    console.log("get_stores_count, res18 .>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>++++++++++++++", res18, get_stores_count);
    if (res18 !== get_stores_count) {
      // let redis_list_name = (user?.id && type === "ALL_STORE") || !user?.id ? "PUBLIC:ALL_STORES" : `USER/${user?.id}:${type}`;
      // console.log("redis_list_name++++++++++++++++++++++++++", redis_list_name);
      const res45 = await redisClient.del(redisIndex);
      try {
        get_stores = await table.findAll({
          where: where,
          include: include,
          order: [["createdAt", "ASC"]],
        });
        let stores = JSON.parse(JSON.stringify(get_stores));
        let storesArray = [];
        // console.log("fucntion-called++++++++++++++++++++++++++", stores);
        for (let i = 0; i < stores.length; i++) {
          let user_data = {};
          switch (type) {
            case "FOLLOWERS":
              user_data = stores[i].friend;
              break;
            case "FOLLOWING":
              user_data = stores[i].user;
              break;
            case "SUGGESTED_PEOPLE":
              user_data = stores[i];
              break;
            case "ALL_PEOPLE":
              user_data = stores[i];
              break;
            default:
              break;
          }

          if (!user_data) continue;
          let users_followers_count = await database.Friend.count({
            where: {
              user_id: Number(user_data.id),
              isFriend: true,
            },
          });
          user_data.followers_count = users_followers_count;

          if (user?.id) {
            let isFollow = await database.Friend.findOne({
              where: {
                user_id: Number(user?.id),
                friend_id: Number(user_data.id),
              },
            });
            user_data.isFollow = isFollow ? true : false;
          } else {
            user_data.isFollow = false;
          }

          if (database_type === "redis") {
            let add_data = await redisClient.lpush(redisIndex, JSON.stringify(user_data));
            console.log("adding data in Redis >>>>>>>>>>>>>>>>>>>>", add_data);
          } else {
            storesArray.push(user_data);
            console.log("not adding into DB pushing for response >>>>>>>>>>>>>>>>>>>>");
          }
        }
        return;
      } catch (e) {
        console.log("sdfasdfdsfafdasfafdasfdasf >>>>>>>>>>", e);
      }
    }
  });
}, 1);

q.drain(function () {
  console.log("All tasks have been processed");
});

const userQueues = new Map();

function handleRequest(requestData) {
  return new Promise((resolve, reject) => {
    if (!userQueues.has(requestData?.user?.id)) {
      userQueues.set(
        requestData?.user?.id,
        async.queue((taskData, callback) => {
          // Removed async keyword here
          // Process the task here
          processRequest(taskData)
            .then((result) => {
              // console.log("result+++++++++++++", result);
              callback(null, result);
            })
            .catch((error) => callback(error));
        })
      );
    }

    userQueues.get(requestData?.user?.id).push(requestData, (error, result) => {
      if (error) {
        console.log("error ======================================", error);
        reject(error);
      } else {
        resolve(result);
      }
    });
  });
}

async function processRequest({ user, include, database_type, type, redisIndex }) {
  process.nextTick(async () => {
    let get_stores_count;
    let res18;
    let where = {};

    switch (type) {
      case "FOLLOWERS":
        where = {
          friend_id: Number(user?.id),
          isFriend: true,
        };
        include = [
          {
            model: database.User,
            as: "friend",
          },
        ];
        table = database.Friend;
        get_stores_count = await table.count({
          where: where,
          // include: include,
        });
        console.log("get_stores_count", get_stores_count);
        res18 = await redisClient.llen(redisIndex);
        break;
      case "FOLLOWING":
        where = {
          user_id: Number(user?.id),
          isFriend: true,
        };
        include = [
          {
            model: database.User,
            as: "user",
          },
        ];
        table = database.Friend;
        get_stores_count = await table.count({
          where: where,
          // include: include,
        });
        res18 = await redisClient.llen(redisIndex);
        break;
      case "SUGGESTED_PEOPLE":
        const response = await database.Friend.findAll({
          where: {
            user_id: Number(user?.id),
          },
          attributes: ["friend_id"],
          raw: true,
        });
        let userIds = [...response.map((item) => item.friend_id), user?.id];
        userIds = [...new Set(userIds)];
        console.log("userIds+++++++++++++++++", userIds);
        where = {
          id: {
            [Op.notIn]: userIds,
          },
        };
        table = database.User;
        get_stores_count = await table.count({
          where: where,
          // include: include,
        });
        res18 = await redisClient.llen(redisIndex);
        break;
      case "ALL_PEOPLE":
        table = database.User;
        get_stores_count = await table.count({
          where: where,
          // include: include,
        });
        res18 = await redisClient.llen(redisIndex);
        break;
      default:
        break;
    }

    if (res18 !== get_stores_count) {
      // let redis_list_name = (user?.id && type === "ALL_STORE") || !user?.id ? "PUBLIC:ALL_STORES" : `USER/${user?.id}:${type}`;
      // console.log("redis_list_name++++++++++++++++++++++++++", redis_list_name);
      const res45 = await redisClient.del(redisIndex);
      try {
        get_stores = await table.findAll({
          where: where,
          include: include,
          order: [["createdAt", "DESC"]],
        });
        let stores = JSON.parse(JSON.stringify(get_stores));
        let storesArray = [];
        // console.log("fucntion-called++++++++++++++++++++++++++", stores);
        for (let i = 0; i < stores.length; i++) {
          let user_data = {};

          switch (type) {
            case "FOLLOWERS":
              user_data = stores[i].friend;
              break;
            case "FOLLOWING":
              user_data = stores[i].user;
              break;
            case "SUGGESTED_PEOPLE":
              user_data = stores[i];
              break;
            case "ALL_PEOPLE":
              user_data = stores[i];
              break;
            default:
              break;
          }

          if (!user_data) continue;
          let users_followers_count = await database.Friend.count({
            where: {
              user_id: Number(user_data.id),
              isFriend: true,
            },
          });
          user_data.followers_count = users_followers_count;

          if (user?.id) {
            let isFollow = await database.Friend.findOne({
              where: {
                user_id: Number(user?.id),
                friend_id: Number(user_data.id),
              },
            });
            user_data.isFollow = isFollow ? true : false;
          } else {
            user_data.isFollow = false;
          }

          if (database_type === "redis") {
            let add_data = await redisClient.lpush(redisIndex, JSON.stringify(user_data));
            console.log("adding data in Redis >>>>>>>>>>>>>>>>>>>>", add_data);
          } else {
            storesArray.push(user_data);
            console.log("not adding into DB pushing for response >>>>>>>>>>>>>>>>>>>>");
          }
        }
        return;
      } catch (e) {
        console.log("sdfasdfdsfafdasfafdasfdasf >>>>>>>>>>", e);
      }
    }
  });
}

module.exports = {
  getAllPeople: async (_, args, { user }) => {
    let { page = 1, limit = 10000, type } = args;
    const gender = args?.gender ? args?.gender : null;
    if (limit && page) {
      var offset = (parseInt(page) - 1) * limit;
      limit = parseInt(limit);
    }
    let storesArray = [];
    let get_stores_count = 0;
    let res18 = [];
    let include = [];
    let redisIndex = "";
    let where = gender
      ? {
          gender: gender,
        }
      : {};
    let table = {};
    let count = 0;
    let searchKeyword = args?.search ? args?.search : "";
    count = await database.User.count();

    const chooseDatabase = async (res18, get_stores_count, redisIndex, where, table) => {
      console.log("res18 === get_stores_count", res18 === get_stores_count, res18, get_stores_count);
      if (res18 === get_stores_count && !searchKeyword) {
        const startIndex = (page - 1) * limit;
        const endIndex = startIndex + limit - 1;
        let redis_list = await redisClient.lrange(redisIndex, startIndex, endIndex);
        for (let i = 0; i < redis_list?.length; i++) {
          let store = redis_list[i];
          storesArray.push(JSON.parse(store));
        }
      } else {
        let get_stores = [];
        console.log("fetching from Database >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", user?.id, table);

        get_stores = await table.findAll({
          where: where,
          include: include,
          order: [["createdAt", "DESC"]],
          limit: limit,
          offset: offset,
          // attributes: ["id", "name", "slug", "logo_image", "banner_image", "product_count", "createdAt"],
        });
        await getStoreDetails(get_stores, "database", null);
      }
    };

    const getStoreDetails = async (get_stores, database_type, redis_list_name) => {
      let stores = JSON.parse(JSON.stringify(get_stores));
      for (let i = 0; i < stores.length; i++) {
        let user_data = {};

        switch (type) {
          case "FOLLOWERS":
            user_data = stores[i].friend;
            break;
          case "FOLLOWING":
            user_data = stores[i].user;
            break;
          case "SUGGESTED_PEOPLE":
            user_data = stores[i];
            break;
          case "ALL_PEOPLE":
            user_data = stores[i];
            break;
          default:
            break;
        }

        if (!user_data) continue;
        let users_followers_count = await database.Friend.count({
          where: {
            user_id: Number(user_data.id),
            isFriend: true,
          },
        });
        user_data.followers_count = users_followers_count;

        if (user?.id) {
          let isFollow = await database.Friend.findOne({
            where: {
              user_id: Number(user?.id),
              friend_id: Number(user_data.id),
            },
          });
          user_data.isFollow = isFollow ? true : false;
        } else {
          user_data.isFollow = false;
        }

        if (database_type === "redis") {
          let add_data = await redisClient.lpush(redis_list_name, JSON.stringify(user_data));
          console.log("adding data in Redis >>>>>>>>>>>>>>>>>>>>", add_data);
        } else {
          storesArray.push(user_data);
          console.log("not adding into DB pushing for response >>>>>>>>>>>>>>>>>>>>");
        }
      }
    };

    let types = ["FOLLOWERS", "FOLLOWING", "SUGGESTED_PEOPLE", "ALL_PEOPLE"];
    console.log("!types.includes(type)>>>>>>>>>", !types.includes(type));
    if (!types.includes(type)) {
      return { success: false, message: "Wrong type Provided.", data: [] };
    }
    if (user?.id) {
      switch (type) {
        case "FOLLOWERS":
          where = {
            friend_id: Number(user?.id),
            isFriend: true,
          };
          include = [
            {
              model: database.User,
              as: "friend",
            },
          ];
          table = database.Friend;
          get_stores_count = await table.count({
            where: where,
            // include: include,
          });
          console.log("get_stores_count", get_stores_count);
          redisIndex = `USER/${user?.id}:${type}`;
          res18 = await redisClient.llen(redisIndex);
          break;
        case "FOLLOWING":
          where = {
            user_id: Number(user?.id),
            isFriend: true,
          };
          include = [
            {
              model: database.User,
              as: "user",
            },
          ];
          table = database.Friend;
          get_stores_count = await table.count({
            where: where,
            // include: include,
          });
          redisIndex = `USER/${user?.id}:${type}`;
          res18 = await redisClient.llen(redisIndex);
          break;
        case "SUGGESTED_PEOPLE":
          const response = await database.Friend.findAll({
            where: {
              user_id: Number(user?.id),
            },
            attributes: ["friend_id"],
            raw: true,
          });
          let userIds = [...response.map((item) => item.friend_id), user?.id];
          userIds = [...new Set(userIds)];
          console.log("userIds+++++++++++++++++", userIds);
          where = {
            id: {
              [Op.notIn]: userIds,
            },
          };
          table = database.User;
          get_stores_count = await table.count({
            where: where,
            // include: include,
          });
          redisIndex = `USER/${user?.id}:${type}`;
          res18 = await redisClient.llen(redisIndex);
          break;
        case "ALL_PEOPLE":
          table = database.User;
          where = searchKeyword
            ? {
                ...where,
                [Op.or]: [
                  {
                    firstName: { [Op.iLike]: `%${searchKeyword}%` },
                  },
                  {
                    lastName: { [Op.iLike]: `%${searchKeyword}%` },
                  },
                  {
                    [Op.and]: [
                      Sequelize.where(Sequelize.fn("concat", Sequelize.col("firstName"), " ", Sequelize.col("lastName")), {
                        [Op.iLike]: `%${searchKeyword}%`,
                      }),
                    ],
                  },
                ],
              }
            : where;
          get_stores_count = await table.count({
            where: where,
            // include: include,
          });
          redisIndex = `USER/${user?.id}:${type}`;
          res18 = await redisClient.llen(redisIndex);
          break;
        default:
          break;
      }
      await chooseDatabase(res18, get_stores_count, redisIndex, where, table);

      await handleRequest({
        user: user,
        include: include,
        database_type: "redis",
        type: type,
        redisIndex: redisIndex,
        table: table,
      });
    } else {
      table = database.User;
      get_stores_count = await table.count({
        where: where,
        // include: include,
      });
      redisIndex = `PUBLIC:ALL_PEOPLE`;
      res18 = await redisClient.llen(redisIndex);
      console.log("res18++++++++++++++++++++++++++++++++++", res18);
      await chooseDatabase(res18, get_stores_count, redisIndex, where, table);
      q.push(
        {
          user: user,
          include: include,
          database_type: "redis",
          type: type,
          redisIndex: redisIndex,
          table: table,
          search: searchKeyword,
        },
        function (err) {
          if (err) {
            console.error(err);
            console.log("Error processing request++++++++++++++++++++++++++");
          } else {
            console.log("Request is being processed");
          }
        }
      );
    }

    return { success: true, message: "Data successfully", data: storesArray, count: get_stores_count, table };
  },

  getAllAdminUser: async (_, { order, search = "", page = 1, limit = 10 }, { user }) => {
    try {
      if (user.token_type !== "admin") return new AuthenticationError("Unauthorized");

      let order_by = order ? order : "";
      let search_data = search;

      if (limit && page) {
        var offset = (parseInt(page) - 1) * limit;
        limit = parseInt(limit);
      }

      let order_data = ["createdAt", "ASC"];
      let product_data = ["firstName", "ASC"];
      if (order_by === "Date Created") {
        order_data = ["createdAt", "DESC"];
      } else if (order_by === "A-Z") {
        product_data = ["firstName", "ASC"];
      } else if (order_by === "Z-A") {
        product_data = ["firstName", "DESC"];
      }

      const find_users = await database.User.findAll({
        order: [order_data],
        limit: limit,
        offset: offset,
        where: {
          [Op.or]: [
            {
              firstName: { [Op.iLike]: `%${search_data}%` },
            },
            {
              lastName: { [Op.iLike]: `%${search_data}%` },
            },
            {
              [Op.and]: [
                Sequelize.where(Sequelize.fn("concat", Sequelize.col("firstName"), " ", Sequelize.col("lastName")), {
                  [Op.iLike]: `%${search_data}%`,
                }),
              ],
            },
          ],
        },
        include: [
          {
            model: database.OrderMaster,
            as: "order_detail",
            attributes: ["id", "totalAmount", "totalTaxAmount", "totalBasicAmount"],
          },
          {
            model: database.OrderItems,
            as: "total_purchase_item",
            attributes: ["id"],
          },
        ],
      });

      const find_user_total = await database.User.count({
        where: {
          [Op.or]: [
            {
              firstName: { [Op.iLike]: `%${search_data}%` },
            },
            {
              lastName: { [Op.iLike]: `%${search_data}%` },
            },
            {
              [Op.and]: [
                Sequelize.where(Sequelize.fn("concat", Sequelize.col("firstName"), " ", Sequelize.col("lastName")), {
                  [Op.iLike]: `%${search_data}%`,
                }),
              ],
            },
          ],
        },
      })

      const pupulated_user = await JSON.parse(JSON.stringify(find_users));

      return { success: true, message: "Fetch User Successfully!", data: pupulated_user, total: find_user_total };
    } catch (error) {
      console.log("error", error);
    }
  },

  getUserDetail: async (_, { slug }, { user }) => {
    try {
      if (user.token_type !== "admin") return new AuthenticationError("Unauthorized");

      const find_user = await database.User.findOne({
        where: {
          userName: slug,
        },
        include: [
          {
            model: database.BioDetail,
            as: "bio_detail",
          },
          {
            model: database.BillingAddresses,
            as: "shipping_address",
          },
        ],
      });

      if (!find_user) return { success: false, message: "User Not Found!" };

      const user_detail = JSON.parse(JSON.stringify(find_user));

      const user_id = user_detail?.id;

      const [post_count, followers_count, following_count, club_count, followed_stores_count, purchased_item_count, total_spent] = await Promise.all([
        database.Post.count({
          where: { user_id: user_id },
        }),
        database.Friend.count({
          where: {
            user_id: user_id,
            isFriend: true,
          },
        }),
        database.Friend.count({
          where: {
            friend_id: user_id,
            isFriend: true,
          },
        }),
        database.Group.count({
          where: { user_id: user_id },
        }),
        database.FollowStore.count({
          where: { user_id: user_id },
        }),
        database.OrderItems.count({
          where: { user_id: user_id },
        }),
        database.OrderItems.sum("totalAmount", {
          where: { user_id: user_id },
        }),
      ]);

      return {
        success: true,
        message: "User Detail Fetch Successfully",
        data: { ...user_detail, post_count, followers_count, following_count, club_count, followed_stores_count, purchased_item_count, total_spent },
      };
    } catch (error) {
      console.error("An error occcured while fetching user details: ", error);
      return {
        success: false,
        message: "An error occcured while fetching user details!",
        data: null
      }
    }
  },

  getAllFriend: async (root, args, { user }) => {
    if (user != null) {
      const allFriend = await FriendService.getAll();
      return allFriend;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getSingleFriend: async (_, { id }, { user }) => {
    if (user != null) {
      return FriendService.getById(id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getFriendRequest: async (_, { id }, { user }) => {
    console.log("getFriendRequest", id);
    if (user != null) {
      return FriendService.getFriendByUserId(id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  checkRequestStatus: async (_, { user_id, friend_id }, { user }) => {
    if (user != null) {
      return FriendService.getByUserByStatus(user_id, friend_id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  deleteFriendByUserAndFriendId: async (_, { user_id, friend_id }, { user }) => {
    if (user != null) {
      return FriendService.deleteFriendByUserAndFriendId(user_id, friend_id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getMyFriends: async (_, { user_id, friend_id }, { user }) => {
    if (user != null) {
      return FriendService.getMyFriends(user_id, friend_id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getMutualFollowing: async (_, { user_id }, { user }) => {
    if (user != null) {
      const loginUserFriends = await database.Friend.findAll({
        where: {
          [Op.or]: [{ user_id: user?.id }],
        },
        raw: true,
      }).map((friend) => friend.friend_id);

      let mutualFollowing = [];

      for (let i = 0; i < loginUserFriends.length; i++) {
        let friend_id = loginUserFriends[i];
        let founded_friend_id = await database.Friend.findOne({
          where: {
            user_id: user?.id,
            friend_id: friend_id,
          },
          attributes: ["friend_id"],
          include: [
            {
              model: database.User,
              as: "user",
              attributes: ["id", "firstName", "lastName", "logo_image"],
            },
          ],
          raw: true,
          nest: true,
        });
        if (founded_friend_id) {
          mutualFollowing.push(founded_friend_id);
        }
      }
      return { success: true, message: "fetch Successfully", data: mutualFollowing };
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getUserFollowers: async (_, { user_id }, { user }) => {
    if (user != null) {
      return FriendService.getUsesrsWithFollowers(user_id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getUserFollowings: async (_, { user_id }, { user }) => {
    if (user != null) {
      return FriendService.getUsesrsWithFollowings(user_id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getSuggestedUsers: async (_, { user_id }, { user }) => {
    // if (user != null) {
    console.log("user_idgsdiludahfudhsfuyfdbagf", user_id);
    return FriendService.getSuggestedUsers(user_id);
    // } else {
    //   return new AuthenticationError("Please Provide the token");
    // }
  },
};
