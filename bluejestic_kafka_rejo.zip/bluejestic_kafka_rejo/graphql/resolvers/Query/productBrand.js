const database = require("../../../database/models");

module.exports = {
  getBrandByProductId: async (root, args, { user }) => {
    try {
      let findProductBrand = await database.ProductBrand.findAll({
        where: {
          store_id: args.store_id,
        },
        order: [["createdAt", "DESC"]],
        attributes: ["name", "id"],
      });
      return { success: true, message: "Brand fetch successfully", data: findProductBrand };
    } catch (error) {
      console.log("error", error);
      throw error;
    }
  },
};
