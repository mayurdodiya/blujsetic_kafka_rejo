const { AuthenticationError } = require("apollo-server-express");
const moment = require("moment");
const {
  totalSellerSales,
  averageOrderValueOfSeller,
  getPreviousDate,
  totalOrdersOfSeller,
  totalRevenuOfSeller,
  totalRevenueOverviewOfSeller,
  newCustomesOfSeller,
  calculatePercentageChange,
  orderOutOfStockOfSeller,
  totalEarningsOfSeller,
  getProcessingTimeOfSeller,
  getTrafficAndEngagementData,
  getCustomerData,
  getTimeRange,
  calculateAge,
} = require("../../../utils/utils");
const database = require("../../../database/models");
const { Op, Sequelize } = require("sequelize");
const client = require("../../../services/elasticsearch/config/config");
const getRegiounOfAmerica = require("../../../utils/utils").getRegiounOfAmerica;
const getRegiounOfCountry = require("../../../utils/utils").getRegiounOfCountry;
const getProcessingTimeOfSellerForPreviousMonth =
  require("../../../utils/utils").getProcessingTimeOfSellerForPreviousMonth;
const FollowStoreService = require("../../../database/services/followstore");

module.exports = {
  /**
   * Fetches analytics data for a seller. The analytics data includes total orders, total sales, average order value, total revenue, revenue overview, total earnings and revenue, and stock report.
   * @param {string} time_zone Time zone for the analytics data
   * @param {string} startDate Start date for the analytics data
   * @param {string} endDate End date for the analytics data
   * @param {string} timeInterval Time interval for the analytics data (day, week, month)
   * @returns {object} Analytics data for the seller
   */
  getSellerAnalytics: async (
    root,
    { startDate, endDate, timeInterval = "day", time_zone },
    { user }
  ) => {
    try {
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }

      seller_id = user?.seller_id;
      if (!seller_id) {
        return new AuthenticationError("Please Provide the seller_id");
      }

      if (startDate && endDate) {
        const start = moment(startDate).startOf("day");
        const end = moment(endDate).endOf("day");

        // Check if the endDate is before the startDate
        if (end.isBefore(start)) {
          return {
            success: false,
            message: "The endDate cannot be before the startDate.",
            data: null,
          };
        }

        startDate = start.format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
        endDate = end.format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
      }

      // let startDateObj = moment(startDate);
      // console.log("🚀 ~ file: sellerAnalytics.js:54 ~ startDateObj:", startDateObj);
      // let endDateObj = moment(endDate);
      // console.log("🚀 ~ file: sellerAnalytics.js:56 ~ endDateObj:", endDateObj);

      // Calculate the difference in milliseconds
      // let diffMillis = endDateObj.diff(startDateObj);
      // if (diffMillis <= 0) {
      //   return {
      //     success: false,
      //     message: "Start Date should be less than or equal to End Date",
      //     data: null,
      //   };
      // }

      // let { previous_start_date, previous_end_date } = await getPreviousDate(
      //   startDate,
      //   endDate,
      //   timeInterval,
      //   time_zone
      // );

      // Elastic search query to calculate average order value
      const averageOrderValue = await averageOrderValueOfSeller(
        seller_id,
        time_zone,
        startDate,
        endDate,
        timeInterval
      );
      const previousMonthAOV = await averageOrderValueOfSeller(
        seller_id,
        time_zone,
        startDate,
        endDate,
        timeInterval
      );
      const percentageChangeInAOV = calculatePercentageChange(
        previousMonthAOV,
        averageOrderValue
      );

      // Elastic search Query yo count total orders
      let totalOrders = await totalOrdersOfSeller(
        seller_id,
        time_zone,
        startDate,
        endDate,
        timeInterval
      );
      const previousMonthOrders = await totalOrdersOfSeller(
        seller_id,
        time_zone,
        startDate,
        endDate,
        timeInterval
      );
      const percentageChangeInOrders = calculatePercentageChange(
        previousMonthOrders,
        totalOrders
      );

      //ELastic searhc query to get total sales
      let totalRevenue = await totalRevenuOfSeller(
        seller_id,
        time_zone,
        startDate,
        endDate,
        timeInterval
      );
      const previousMonthTotalRevenue = await totalRevenuOfSeller(
        seller_id,
        time_zone,
        startDate,
        endDate,
        timeInterval
      );
      const percentageChangeInRevenue = calculatePercentageChange(
        previousMonthTotalRevenue,
        totalRevenue
      );

      // Elastic search query to calculate revenue overview
      let revenueOverview = await totalRevenueOverviewOfSeller(
        seller_id,
        time_zone,
        startDate,
        endDate,
        timeInterval
      );
      const previousMonthRevenueOverview = await totalRevenueOverviewOfSeller(
        seller_id,
        time_zone,
        startDate,
        endDate,
        timeInterval
      );
      // const percentageChangeInRevenueOverview = calculatePercentageChange(previousMonthRevenueOverview,revenueOverview);

      // Elastic search query to calculate total sales
      let totalSales = await totalSellerSales(
        seller_id,
        time_zone,
        startDate,
        endDate,
        timeInterval
      );
      const previousMonthSales = await totalSellerSales(
        seller_id,
        time_zone,
        startDate,
        endDate,
        timeInterval
      );
      const percentageChangeInSales = calculatePercentageChange(
        previousMonthSales,
        totalSales
      );

      // Elastic search query to find product is in stock or not
      const outOfStock = await orderOutOfStockOfSeller(
        seller_id,
        time_zone,
        startDate,
        endDate,
        timeInterval
      );

      let totalEarningsAndRevenue = await totalEarningsOfSeller(
        seller_id,
        time_zone,
        startDate,
        endDate,
        timeInterval
      );
      totalEarningsAndRevenue = totalEarningsAndRevenue.map((item) => {
        return {
          total_earnings: item.total_earnings.value,
          total_revenue: item.total_revenue.value,
          date: item.key_as_string,
        };
      });

      // Elastic search api to count new customers
      let newCustomers = await newCustomesOfSeller(
        seller_id,
        time_zone,
        startDate,
        endDate,
        timeInterval
      );

      //Elastic search api to calculate processing time
      let processingTime = await getProcessingTimeOfSeller(
        seller_id,
        time_zone,
        startDate,
        endDate,
        timeInterval
      );
      const totalProcessingTimeInDays = processingTime.reduce((acc, hit) => {
        const { updatedAt, createdAt } = hit._source; // Access `_source` from each `hit`
        const processingTimeInMs = new Date(updatedAt) - new Date(createdAt); // Difference in milliseconds
        const processingTimeInDays = processingTimeInMs / 86400000; // Convert ms to days
        return acc + processingTimeInDays; // Accumulate the total
      }, 0);

      let processingTimeOfPreviousMonth =
        await getProcessingTimeOfSellerForPreviousMonth(
          seller_id,
          time_zone,
          startDate,
          endDate,
          timeInterval
        );

      const previousMonthTotalProcessingTimeInDays =
        processingTimeOfPreviousMonth.reduce((acc, hit) => {
          // Ensure _source is defined and contains 'updatedAt' and 'createdAt' before destructuring
          const { updatedAt, createdAt } = hit._source || {}; // Fallback to empty object if _source is undefined

          // Check if either createdAt or updatedAt is undefined or invalid
          if (
            !createdAt ||
            !updatedAt ||
            isNaN(new Date(updatedAt)) ||
            isNaN(new Date(createdAt))
          ) {
            return acc; // Just return the accumulator unchanged
          }
          // Calculate the processing time in milliseconds
          const processingTimeInMs = new Date(updatedAt) - new Date(createdAt);
          const processingTimeInDays = processingTimeInMs / 86400000; // Convert ms to days
          return acc + processingTimeInDays;
        }, 0);

      const percentageChangeInProcessingTime = calculatePercentageChange(
        previousMonthTotalProcessingTimeInDays,
        totalProcessingTimeInDays
      );

      const currentStock = await database.OrderItems.findAll({
        where: {
          store_id: user?.store_id,
        },
        attributes: ["quantity"],
        include: [
          {
            model: database.Product,
            as: "product",
            attributes: ["id", "title"], // Include product ID for matching
          },
        ],
      });

      // Query for previous stock
      const previousStock = await database.OrderItems.findAll({
        where: {
          store_id: user?.store_id,
          createdAt: {
            [Op.between]: [startDate, endDate],
          },
        },
        attributes: ["quantity"],
        include: [
          {
            model: database.Product,
            as: "product",
            attributes: ["id"], // Include product ID for matching
          },
        ],
      });

      // Map previous stock quantities by product ID
      const previousStockMap = previousStock.reduce((acc, item) => {
        acc[item.product.id] = item.quantity || 0;
        return acc;
      }, {});

      const stockReportData = [];

      currentStock.map((item) => {
        const stockReport = {};
        const currentQuantity = item.quantity;
        const previousQuantity = previousStockMap[item.product.id] || 0;

        // Calculate percentage change
        const percentageChange =
          previousQuantity === 0 || previousQuantity === currentQuantity
            ? 0
            : ((currentQuantity - previousQuantity) / previousQuantity) * 100;

        // Determine stock status
        if (currentQuantity === 0) {
          stockReport["status"] = "Out of Stock";
        } else if (currentQuantity >= 1 && currentQuantity <= 20) {
          stockReport["status"] = "Low Stock";
        } else if (currentQuantity >= 21 && currentQuantity <= 40) {
          stockReport["status"] = "Optimal Stock";
        } else if (currentQuantity > 40) {
          stockReport["status"] = "Excess Stock";
        }

        stockReport["product"] = item.product.title;
        stockReport["units"] = currentQuantity;
        stockReport["percentageChange"] = parseFloat(
          percentageChange.toFixed(2)
        );

        stockReportData.push(stockReport);
      });

      // Calculate the status count
      const statusCount = stockReportData.reduce((acc, item) => {
        acc[item.status] = (acc[item.status] || 0) + 1;
        return acc;
      }, {});

      // Create the final report object
      const finalReport = {
        stock: statusCount,
        data: stockReportData,
      };

      return {
        success: true,
        message: "Seller analytics retrieved successfully",
        data: {
          totalOrders,
          percentageChangeInOrders,
          totalSales,
          newCustomers,
          averageOrderValue,
          totalRevenue,
          percentageChangeInSales,
          percentageChangeInAOV,
          percentageChangeInRevenue,
          processingTime: totalProcessingTimeInDays,
          outOfStock: outOfStock === null ? 0 : outOfStock,
          revenueOverview: {
            monthlyRevenue:
              revenueOverview.aggregations.monthly_stats.buckets.map(
                (bucket) => ({
                  date: bucket.key_as_string,
                  revenue: bucket.revenue.value,
                  orders: bucket.orders.value,
                })
              ),
          },
          totalEarningsAndRevenue:
            totalEarningsAndRevenue === null ? [] : totalEarningsAndRevenue,
          stockReport: finalReport,
          percentageChangeInProcessingTime,
        },
      };
    } catch (error) {
      console.error("Elasticsearch error:", error);
      throw new Error("Failed to fetch seller analytics: " + error.message);
    }
  },

  /**
   * This function fetches the traffic and engagement data of a seller.
   * It queries the elasticsearch database to fetch the product views, likes, shares, saves and gender ratio of the users.
   * It also fetches the regionwise sales data and the total number of visitors.
   * @param {string} store_id - The id of the store.
   * @returns {Object} An object containing the traffic and engagement data of the seller.
   */
  getSellerTrafficAndEngagement: async (root, args, { user }) => {
    try {
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }

      store_id = user?.store_id;
      if (!store_id) {
        return new AuthenticationError("Please Provide the Sotre Id");
      }

      const {
        productViews,
        productLikes,
        productShared,
        productSaved,
        genderRatio,
        regionWiseSalesRatio,
        totalVisitors,
      } = await getTrafficAndEngagementData(store_id);

      let regionData = [
        { value: 0, region: "America" },
        { value: 0, region: "Asia" },
        { value: 0, region: "Europe" },
        { value: 0, region: "Pacific" },
        { value: 0, region: "Middle East" },
        { value: 0, region: "Africa" },
      ];

      regionWiseSalesRatio.forEach((region) => {
        const existingRegion = regionData.find(
          (item) => item.region === region
        );
        if (existingRegion) {
          existingRegion.value++; // Increment the value if the region exists
        }
      });

      const { male, female } = genderRatio.reduce(
        (acc, user) => {
          if (user.total_purchase_item.gender === "Male") {
            acc.male += 1;
          } else if (user.total_purchase_item.gender === "Female") {
            acc.female += 1;
          }
          return acc;
        },
        { male: 0, female: 0 }
      );

      return {
        success: true,
        message: "Seller Traffic and Engagement data retrieved successfully",
        data: {
          productViews,
          productLikes,
          productShared,
          productSaved,
          genderRatio: {
            male: male + female > 0 ? (male / male + female) * 100 : 0,
            female: male + female > 0 ? (female / male + female) * 100 : 0,
          },
          regionWiseSales: regionData,
          totalVisitors,
        },
      };
    } catch (error) {
      throw new Error("Failed to fetch seller traffic and engagement analytics: " + error.message);
    }
  },

  /**
   * Retrieves customer details for the authenticated user's store.
   *
   * This function checks if the user is authenticated and has a valid store ID.
   * It then fetches the number of store followers, total customers, and new customers
   * using the `getCustomerData` function. Additionally, it calculates the age distribution
   * of customers by fetching order items data and associating it with user data.
   * The age distribution is categorized into age ranges and expressed as percentages.
   *
   * @param {Object} root - The root object for the GraphQL operation.
   * @param {Object} args - The arguments provided to the GraphQL operation.
   * @param {Object} context - The context containing the authenticated user.
   * @returns {Object} An object containing success status, a message, and data with store followers,
   *                   total customers, new customers, and age ratio distribution.
   * @throws {AuthenticationError} If the user is not authenticated or the store ID is missing.
   * @throws {Error} If there is an error fetching the customer details.
   */
  getCustomersDetails: async (root, args, { user }) => {
    try {
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }

      store_id = user?.store_id;
      if (!store_id) {
        return new AuthenticationError("Please Provide the Sotre Id");
      }

      const { storeFollowers, totalCustomers, newCustomers } =
        await getCustomerData(store_id);

      const ageDistribution = await database.OrderItems.findAll({
        where: {
          store_id: store_id,
        },
        include: [
          {
            model: database.User,
            as: "customer",
          },
        ],
      });

      const ageCounts = { "18-24": 0, "25-34": 0, "35-44": 0, "45+": 0 };

      for (const item of ageDistribution) {
        const birthDate = item.customer?.bday;
        if (!birthDate) continue;

        const age = await calculateAge(birthDate);
        if (age >= 18 && age <= 24) {
          ageCounts["18-24"]++;
        } else if (age >= 25 && age <= 34) {
          ageCounts["25-34"]++;
        } else if (age >= 35 && age <= 44) {
          ageCounts["35-44"]++;
        } else if (age >= 45) {
          ageCounts["45+"]++;
        }
      }

      // Calculate the total to get percentages
      const total = Object.values(ageCounts).reduce(
        (sum, count) => sum + count,
        0
      );
      const ageRatio = Object.keys(ageCounts).map((key) => ({
        name: key,
        value: total > 0 ? Math.round((ageCounts[key] / total) * 100) : 0,
      }));

      return {
        success: true,
        message: "Customer details retrieved successfully",
        data: {
          storeFollowers,
          totalCustomers,
          newCustomers,
          ageRatio,
        },
      };
    } catch (error) {
      throw new Error("Failed to fetch customer details: " + error.message);
    }
  },

  /**
   * Fetches sales data for a given seller, including:
   *  1. Cart abandonment rate
   *  2. Sales by region
   *  3. Sales by category
   *  4. Conversion rates
   *  5. Delivered shipments
   * @param {object} root - The root of the GraphQL query
   * @param {object} args - The arguments of the GraphQL query
   * @param {object} context - The context of the GraphQL query
   * @param {object} info - The info of the GraphQL query
   * @returns {object} - The result of the GraphQL query
   */
  getSellerSalesData: async (root, { timeRange = "Last_7_Days" }, { user }) => {
    try {
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }

      store_id = user?.store_id;

      if (!store_id) {
        return new AuthenticationError("Please Provide the Sotre Id");
      }

      timeRange = getTimeRange(timeRange);

      const cartProducts = await database.Cart.findAll({
        where: {
          createdAt: {
            [Op.between]: [timeRange.startDate, timeRange.endDate],
          },
        },
        attributes: ["parent_id"],
      });

      const cartIdExist = await database.OrderItems.findAll({
        where: {
          seller_id: store_id,
          createdAt: {
            [Op.between]: [timeRange.startDate, timeRange.endDate],
          },
          product_id: cartProducts.map((item) => item.parent_id),
        },
        raw: true,
      });

      // Find sales by region
      const sales = await database.OrderItems.findAll({
        where: {
          store_id: store_id,
          createdAt: {
            [Op.between]: [timeRange.startDate, timeRange.endDate],
          },
        },
        include: [
          {
            model: database.User,
            as: "customer",
          },
        ],
      });

      let regions = await Promise.all(
        sales.map(async (item) => {
          try {
            const state = item.customer.state;

            // Assuming getRegiounOfCountry is async, you should await the result
            const region = await getRegiounOfAmerica(state); // Wait for the region details

            const value = item.sellerFinalAmount;

            return {
              name: region, // Use the resolved region name
              value: value,
            };
          } catch (error) {
            console.error("Error getting region for customer", error);
            // Handle the error, for example, by returning a fallback value
            return {
              name: "Unknown Region",
              value: item.sellerFinalAmount,
            };
          }
        })
      );

      let totalSales = 0;
      const salesByRegion = regions.map((region) => {
        totalSales += region.value;
        return region;
      });

      const cartAbandunce =
        cartProducts.length === 0
          ? 0
          : ((cartProducts.length - cartIdExist.length) / cartProducts.length) *
          100;

      const totalSalesResult = await database.OrderItems.sum("totalAmount", {
        where: { store_id },
      });

      // Get sales grouped by category
      const categorySales = await database.OrderItems.findAll({
        where: { store_id },
        include: [
          {
            model: database.Product,
            as: "product",
            attributes: ["id"],
            include: [
              {
                model: database.ProductCategories,
                as: "categories",
                attributes: [
                  "category_id",
                  "subCategory_id",
                  "childSubCategory_id",
                ],
                include: [
                  {
                    model: database.Category,
                    as: "category",
                    attributes: ["name"],
                  },
                ],
              },
            ],
          },
        ],
      });

      let categoryCounts = {};

      categorySales.forEach((item) => {
        const categories = item.product?.categories || [];
        categories.forEach((category) => {
          const categoryName = category.category?.name;
          categoryCounts[categoryName] =
            (categoryCounts[categoryName] || 0) + 1;
        });
      });

      const totalItems = Object.entries(categoryCounts).reduce(
        (sum, [, count]) => sum + count,
        0
      );

      let categoryPercentages = [];

      for (const [category, count] of Object.entries(categoryCounts)) {
        const percentage = ((count / totalItems) * 100).toFixed(2);
        categoryPercentages.push({
          name: category,
          value: percentage,
        });
      }

      const allRegions = ["East", "West", "North", "South"];
      const salesByRegionGrouped = salesByRegion.reduce((acc, sale) => {
        if (!acc[sale.name]) {
          acc[sale.name] = 0;
        }
        acc[sale.name] += sale.value;
        return acc;
      }, {});


      allRegions.forEach(region => {
        if (!salesByRegionGrouped[region]) {
          salesByRegionGrouped[region] = 0;
        }
      });

      totalSales = Object.values(salesByRegionGrouped).reduce((sum, value) => sum + value, 0);

      // Step 4: Calculate the percentage for each region
      const salesWithPercentages = Object.entries(salesByRegionGrouped).map(([region, value]) => ({
        name: region,
        value: totalSales === 0 ? 0 : (value / totalSales) * 100
      }));


      // Calculate conersion rates
      const searchParams = {
        index: "store-activities",
        query: {
          bool: {
            must: [
              {
                match: {
                  store_id: store_id,
                },
              },
              {
                range: {
                  createdAt: {
                    gte: timeRange.startDate,
                    lte: timeRange.endDate,
                  },
                },
              },
            ],
          },
        },
        size: 0,
        body: {
          aggs: {
            total_user_reached_count: {
              cardinality: {
                field: "id",
              },
            },
          },
        },
      };

      const result = await client.search(searchParams);
      const totalVisitors = result.aggregations.total_user_reached_count.value;
      const totalOrdersDelivered = await database.OrderItems.count({
        where: {
          store_id: store_id,
          order_status: "Delivered",
        },
      });

      const deliveredShipments = await client.count({
        index: "order_items",
        body: {
          query: {
            bool: {
              must: [
                { match: { order_status: "delivered" } },
                { match: { seller_id: user.seller_id } },
                {
                  range: {
                    createdAt: {
                      gte: timeRange.startDate,
                      lte: timeRange.endDate,
                    },
                  },
                },
              ],
            },
          },
        },
      });

      return {
        success: true,
        message: "Customer details retrieved successfully",
        data: {
          cartAbandunce,
          salesByRegion: salesWithPercentages,
          categoryPercentages,
          conversionRate:
            totalVisitors === 0
              ? 0
              : (totalOrdersDelivered / totalVisitors) * 100,
          deliveredShipments: deliveredShipments.count,
        },
      };
    } catch (error) {
      throw new Error("Failed to fetch customer details: " + error.message);
    }
  },

  /**
   * Get the social activity details of a seller. This includes the total followers, change in followers, engagement rate, change in engagement rate, average order value, and change in average order value.
   * @param {string} timeRange The time range for which to fetch the social activity details. Defaults to "Previous_Month".
   * @return {object} An object containing the social activity details.
   */
  getSellerSocialActivity: async (
    root,
    { timeRange = "Previous_Month" },
    { user }
  ) => {
    try {
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }

      store_id = user?.store_id;

      if (!store_id) {
        return new AuthenticationError("Please Provide the Sotre Id");
      }

      timeRange = getTimeRange(timeRange);

      let previousMonthVipCount = 0;
      const previousMonthvipCustomers = await database.FollowStore.findAll({
        where: {
          store_id: Number(store_id),
          createdAt: {
            [Op.between]: [timeRange.startDate, timeRange.endDate],
          },
        },
        include: [
          {
            model: database.User,
            as: "user",
          },
        ],
      });

      const previousUserGroups = previousMonthvipCustomers.reduce(
        (acc, customer) => {
          const { user_id } = customer;
          if (!acc[user_id]) {
            acc[user_id] = customer;
          }
          return acc;
        },
        {}
      );

      for (const user_id in previousUserGroups) {
        const totalOrdersDelivered = await database.OrderItems.findAll({
          attributes: [
            [Sequelize.fn("SUM", Sequelize.col("basicAmount")), "sales"],
          ],
          where: {
            user_id: user_id,
            order_status: "confirmed",
          },
        });

        const sales = parseFloat(
          totalOrdersDelivered[0]?.dataValues.sales || 0
        ); // Handle null or undefined and parse to number

        // Step 3: Check if sales exceed $2500
        if (sales >= 2500) {
          previousMonthVipCount++;
        }
      }

      const vipCustomers = await FollowStoreService.getAll(store_id);

      // Step 1: Group vipCustomers by user_id (only once)
      const userGroups = vipCustomers.reduce((acc, customer) => {
        const { user_id } = customer;
        if (!acc[user_id]) {
          acc[user_id] = customer;
        }
        return acc;
      }, {});

      // Step 2: Iterate over grouped users and calculate sales
      let vipCount = 0;

      for (const user_id in userGroups) {
        const totalOrdersDelivered = await database.OrderItems.findAll({
          attributes: [
            [Sequelize.fn("SUM", Sequelize.col("basicAmount")), "sales"],
          ],
          where: {
            user_id: user_id,
            order_status: "confirmed",
          },
        });

        const sales = parseFloat(
          totalOrdersDelivered[0]?.dataValues.sales || 0
        ); // Handle null or undefined and parse to number

        // Step 3: Check if sales exceed $2500
        if (sales >= 2500) {
          vipCount++;
        }
      }

      const [
        totalFollowers,
        previousMonthFollowers,
        engagementRate,
        previousMonthEngagementRate,
        averageOrderValue,
        previousMonthAverageOrderValue,
      ] = await Promise.all([
        FollowStoreService.getAll(store_id),
        database.FollowStore.findAll({
          where: {
            store_id: Number(store_id),
            createdAt: {
              // Assuming 'createdAt' is the date field you want to filter on
              [Op.between]: [timeRange.startDate, timeRange.endDate],
            },
          },
          include: [
            {
              model: database.User,
              as: "user",
            },
          ],
        }),
        client.search({
          index: "store-activities",
          query: {
            bool: {
              must: [
                {
                  match: {
                    store_id: store_id,
                  },
                },
              ],
            },
          },
          size: 0,
          body: {
            aggs: {
              total_user_reached_count: {
                cardinality: {
                  field: "id",
                },
              },
            },
          },
        }),
        client.search({
          index: "store-activities",
          query: {
            bool: {
              must: [
                {
                  match: {
                    store_id: store_id,
                  },
                },
                {
                  range: {
                    createdAt: {
                      gte: timeRange.startDate,
                      lte: timeRange.endDate,
                    },
                  },
                },
              ],
            },
          },
          size: 0,
          body: {
            aggs: {
              total_user_reached_count: {
                cardinality: {
                  field: "id",
                },
              },
            },
          },
        }),
        client.search({
          index: "order_items",
          body: {
            query: {
              bool: {
                must: [{ match: { store_id: user?.store_id } }],
              },
            },
            aggs: {
              avg_order: {
                avg: { field: "totalAmount" },
              },
            },
          },
        }),
        client.search({
          index: "order_items",
          body: {
            query: {
              bool: {
                must: [
                  {
                    match: {
                      store_id: store_id,
                    },
                  },
                  {
                    range: {
                      createdAt: {
                        gte: timeRange.startDate,
                        lte: timeRange.endDate,
                      },
                    },
                  },
                ],
              },
            },
            aggs: {
              avg_order: {
                avg: { field: "totalAmount" },
              },
            },
          },
        }),
      ]);



      // Query to find VIP customers
      let totalVisitors =
        engagementRate.aggregations.total_user_reached_count.value;

      const totalOrdersDelivered = await database.OrderItems.count({
        where: {
          store_id: store_id,
          order_status: "Delivered",
        },
      });

      const percentageChangeInFollowers = calculatePercentageChange(
        previousMonthFollowers.length,
        totalFollowers.length
      );
      const percentageChangeInAverageOrderValue = calculatePercentageChange(
        previousMonthAverageOrderValue.aggregations.avg_order.value ?? 0,
        averageOrderValue.aggregations.avg_order.value ?? 0
      );
      const percentageChangeInEngagementRange = calculatePercentageChange(
        previousMonthEngagementRate.aggregations.total_user_reached_count.value,
        totalVisitors
      );
      const percentageChangeInVipUsers = calculatePercentageChange(
        previousMonthVipCount,
        vipCount
      );

      return {
        success: true,
        message: "Social Activity details retrieved successfully",
        data: {
          totalFollowers: totalFollowers.length,
          percentageChangeInFollowers: percentageChangeInFollowers,
          engagementRate:
            totalVisitors === 0
              ? 0
              : (totalOrdersDelivered / totalVisitors) * 100,
          percentageChangeInEngagementRange,
          averageOrderValue: averageOrderValue.aggregations.avg_order.value ?? 0,
          percentageChangeInAverageOrderValue:
            percentageChangeInAverageOrderValue ?? 0,
          vipCount,
          percentageChangeInVipUsers,
        },
      };
    } catch (error) {
      console.log(error);
      throw new Error(
        "Failed to fetch social activity of seller:-> " + error.message
      );
    }
  },

  /**
   * Retrieves followers of the authenticated user's store along with their order details.
   *
   * This function checks if the user is authenticated and has a valid store ID.
   * It fetches the list of followers for the user's store and retrieves details
   * such as the user's name, profile image, the number of orders placed,
   * and the total amount spent.
   *
   * @param {Object} root - The root object for the GraphQL operation.
   * @param {Object} args - The arguments provided to the GraphQL operation.
   * @param {Object} context - The context containing the authenticated user.
   * @returns {Object} An object containing success status, a message, and data
   *                   with store followers' order details.
   * @throws {AuthenticationError} If the user is not authenticated or the store ID is missing.
   * @throws {Error} If there is an error fetching the store followers.
   */
  getSellerStoreFollowers: async (root, args, { user }) => {
    try {
      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }

      const { search } = args;

      let store_id = user?.store_id;
      if (!store_id) {
        return new AuthenticationError("Please Provide the Sotre Id");
      }

      // Define search condition for firstName and lastName
      const searchCondition = search
        ? {
          [Sequelize.Op.or]: [
            { firstName: { [Sequelize.Op.iLike]: `%${search}%` } },
            { lastName: { [Sequelize.Op.iLike]: `%${search}%` } },
          ],
        }
        : {};

      let find_store = await database.FollowStore.findAll({
        where: { store_id: Number(store_id) },
        include: [
          {
            model: database.User,
            as: "user",
            attributes: ["id", "firstName", "lastName", "logo_image"],
            where: searchCondition, // Add search condition here
            include: [
              {
                model: database.OrderItems,
                as: "total_purchase_item",
                attributes: ["totalAmount", "id"],
              },
            ],
          },
        ],
        attributes: {
          include: [
            [
              Sequelize.literal(
                `(SELECT COALESCE(SUM("totalAmount"), 0) FROM "OrderItems" WHERE "OrderItems"."user_id" = "user"."id")`
              ),
              "totalAmountSum",
            ],
            [
              Sequelize.literal(
                `(SELECT COUNT(*) FROM "OrderItems" WHERE "OrderItems"."user_id" = "user"."id")`
              ),
              "totalPurchaseCount",
            ],
          ],
        },
      });

      return {
        success: true,
        message: "Store followers retrieved successfully",
        data: JSON.parse(JSON.stringify(find_store)),
      };
    } catch (error) {
      throw new Error("Failed to fetch store followers:-> " + error.message);
    }
  },

  /**
   * Retrieves the financial information for the authenticated user's store.
   *
   * The financial information includes the total revenue, pending payment,
   * withdrawable amount, and total funds. The information is retrieved
   * for the current and previous month.
   *
   * @param {Object} root - The root object for the GraphQL operation.
   * @param {Object} args - The arguments provided to the GraphQL operation.
   * @param {Object} context - The context containing the authenticated user.
   * @returns {Object} An object containing success status, a message, and data
   *                   with the financial information.
   * @throws {AuthenticationError} If the user is not authenticated or the store ID is missing.
   * @throws {Error} If there is an error fetching the financial information.
   */
  getSellerFinances: async (
    root,
    { timeRange = "Previous_Month" },
    { user }
  ) => {
    try {

      if (!user) {
        return new AuthenticationError("Please Provide the token");
      }

      const { email } = user;

      const store_id = user?.store_id;
      if (!store_id) {
        return new AuthenticationError("Please Provide the stored");
      }

      const find_seller = await database.Seller.findOne({
        where: {
          email,
        },
      });

      const seller = JSON.parse(JSON.stringify(find_seller));

      if (!seller) {
        return {
          success: false,
          message: "Seller not found!"
        }
      }

      timeRange = getTimeRange(timeRange);
      const currentMonthTimeRange = getTimeRange('This_Month');


      const [
        availableFunds,
        previousMonthAvailableFunds,
        totalRevenue,
        previousMonthRevenue,
        monthlyWithdrawableAmount,
        previousMonthWithdrawableAmount,
        pendingPayment,
        previousMonthPendingPayments,
      ] = await Promise.all([
        database.OrderItems.findAll({
          attributes: [
            [Sequelize.fn("sum", Sequelize.col("sellerFinalAmount")), "sellerFinalAmount"]
          ],
          where: {
            seller_id: seller?.id,
            order_status: "delivered",
          }
        }),
        database.OrderItems.findAll({
          attributes: [
            [Sequelize.fn("sum", Sequelize.col("sellerFinalAmount")), "sellerFinalAmount"]
          ],
          where: {
            seller_id: seller?.id,
            order_status: "delivered",
            createdAt: {
              [Op.between]: [timeRange.startDate, timeRange.endDate]
            }
          },
        }),
        client.search({
          index: "order_items",
          body: {
            size: 0, // Exclude document hits from the response
            query: {
              bool: {
                must: [{ match: { store_id: store_id } }],
              },
            },
            aggs: {
              sellers: {
                terms: {
                  field: "store_id",
                  size: 1000,
                },
                aggs: {
                  total_sellerFinalAmount: {
                    sum: { field: "sellerFinalAmount" },
                  },
                },
              },
              overall_total: {
                sum_bucket: {
                  buckets_path: "sellers>total_sellerFinalAmount",
                },
              },
            },
          },
        }),
        client.search({
          index: "order_items",
          body: {
            size: 0,
            query: {
              bool: {
                must: [
                  { match: { store_id: store_id } },
                  {
                    range: {
                      createdAt: {
                        gte: timeRange.startDate,
                        lte: timeRange.endDate,
                      },
                    },
                  },
                ],
              },
            },
            aggs: {
              sellers: {
                terms: {
                  field: "store_id", // Group by seller_id
                  size: 1000, // Adjust bucket size as needed
                },
                aggs: {
                  total_sellerFinalAmount: {
                    sum: { field: "sellerFinalAmount" }, // Sum totalAmount for each seller
                  },
                },
              },
              overall_total: {
                sum_bucket: {
                  buckets_path: "sellers>total_sellerFinalAmount", // Sum all bucket values
                },
              },
            },
          },
        }),
        database.SellerPayoutHistory.findAll({
          where: {
            seller_id: user?.seller_id,
          },
          createdAt: {
            [Op.between]: [currentMonthTimeRange.startDate, currentMonthTimeRange.endDate]
          },
          attributes: [[Sequelize.fn("sum", Sequelize.col("amount")), "amount"]]
        }),
        database.SellerPayoutHistory.findAll({
          where: {
            seller_id: user?.seller_id,
            createdAt: {
              [Op.between]: [timeRange.startDate, timeRange.endDate]
            }
          },
          attributes: [[Sequelize.fn("sum", Sequelize.col("amount")), "amount"]]
        }),
        client.count({
          index: "order_items",
          body: {
            query: {
              bool: {
                must: [
                  { term: { store_id: store_id } },
                  { term: { payment_status: "pending" } },
                ],
              },
            },
          },
        }),
        client.count({
          index: "order_items",
          body: {
            query: {
              bool: {
                must: [
                  { term: { store_id: store_id } }, // Exact match for store_id
                  { term: { payment_status: "pending" } }, // Exact match for payment_status
                  {
                    range: {
                      createdAt: {
                        gte: timeRange.startDate,
                        lt: timeRange.endDate,
                      },
                    },
                  },
                ],
              },
            },
          },
        }),
      ]);

      const percentageChangeInRevenue = calculatePercentageChange(
        totalRevenue.aggregations.overall_total.value,
        previousMonthRevenue.aggregations.overall_total.value
      );

      const percentageChangeInPendingPayments = calculatePercentageChange(
        pendingPayment.count,
        previousMonthPendingPayments.count
      );

      const sellerFinalAmountFromDB = JSON.parse(JSON.stringify(availableFunds))[0].sellerFinalAmount;
      const prevsellerFinalAmountFromDB = JSON.parse(JSON.stringify(previousMonthAvailableFunds))[0].sellerFinalAmount;

      const percentageChangeInAvailableFunds = calculatePercentageChange(
        sellerFinalAmountFromDB && typeof sellerFinalAmountFromDB === "number" ? sellerFinalAmountFromDB : 0,
        prevsellerFinalAmountFromDB && typeof prevsellerFinalAmountFromDB === "number" ? prevsellerFinalAmountFromDB : 0
      )

      const percentageChangeInMonthlyWithdrawedAmount = calculatePercentageChange(
        monthlyWithdrawableAmount[0].amount === null ? 0 : monthlyWithdrawableAmount[0].amount,
        previousMonthWithdrawableAmount[0].amount === null ? 0 : previousMonthWithdrawableAmount[0].amount
      )


      return {
        success: true,
        message: "Finance stats retrieved successfully.",
        data: {
          availableFunds: sellerFinalAmountFromDB && typeof sellerFinalAmountFromDB === "number" ? sellerFinalAmountFromDB : 0,
          percentageChangeInAvailableFunds,
          totalRevenue: totalRevenue.aggregations.overall_total.value,
          percentageChangeInRevenue,
          monthlyWithdrawedAmount: monthlyWithdrawableAmount[0].amount === null ? 0 : monthlyWithdrawableAmount[0].amount,
          percentageChangeInMonthlyWithdrawedAmount,
          pendingPayment: pendingPayment.count || 0,
          percentageChangeInPendingPayments,
        },
      };
    } catch (error) {
      console.error("An error occured while fetchin=g finance stats: ", error);
      throw new Error("Error fetching seller finances!");
    }
  },

  // getOrdersAnalysis: async (root, { input }, { user }) => {
  //   if (!user) return new AuthenticationError("Please Provide the token");
  //   try {

  //     let startDate, endDate;
  //     if (input && input?.startDate && input?.endDate) {
  //       startDate = moment(input?.startDate).startOf("day").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
  //       endDate = moment(input?.endDate).endOf("day").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
  //     }

  //     const result = await database.OrderItems.findAll({
  //       attributes: [
  //         [Sequelize.fn('TO_CHAR', Sequelize.fn('DATE_TRUNC', 'week', Sequelize.col('createdAt')), 'YYYY-MM-DD'), 'date'],
  //         [Sequelize.fn('COUNT', Sequelize.col('id')), 'orders'],
  //       ],
  //       where: {
  //         ...(startDate && endDate && {
  //           createdAt: {
  //             [Op.between]: [startDate, endDate],
  //           },
  //         }),
  //         user_id: user?.id,
  //       },
  //       group: [Sequelize.fn('DATE_TRUNC', 'week', Sequelize.col('createdAt'))],
  //       order: [Sequelize.fn('DATE_TRUNC', 'week', Sequelize.col('createdAt'))],
  //     });
  //     return {
  //       success: true,
  //       message: "Fetched User's order analysis for summary successfully.",
  //       data: JSON.parse(JSON.stringify(result))
  //     }
  //   } catch (error) {
  //     console.error("Error while fetching user's order analysis for summary: ", error);
  //     return {
  //       success: false,
  //       message: "Error while fetching user's order analysis for summary!",
  //       data: []
  //     }
  //   }
  // }

  getOrdersAnalysis: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    try {

      let startDate, endDate;
      if (input && input?.startDate && input?.endDate) {
        startDate = moment(input?.startDate).startOf("day");
        endDate = moment(input?.endDate).endOf("day");


        // Generate the date range
        const dateRange = [];
        let currentDate = startDate.clone();
        while (currentDate.isSameOrBefore(endDate)) {
          dateRange.push(currentDate.format("YYYY-MM-DD"));
          currentDate.add(1, "day");
        }


        const formattedStartDate = startDate.format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
        const formattedEndDate = endDate.format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");

        const orders = await database.OrderItems.findAll({
          where: {
            ...(startDate && endDate && {
              createdAt: {
                [Op.between]: [formattedStartDate, formattedEndDate],
              },
            }),
            user_id: user?.id,
          },
          attributes: [
            [Sequelize.fn("DATE", Sequelize.col("createdAt")), "date"], // Extract date
            [Sequelize.fn("COUNT", Sequelize.col("id")), "orderCount"], // Count orders
            [Sequelize.fn("SUM", Sequelize.col("totalAmount")), "totalAmount"], // Sum totalAmount
          ],
          group: [Sequelize.fn('DATE', Sequelize.col('createdAt'))],
        });


        const sanitizedOrders = JSON.parse(JSON.stringify(orders));

        // Convert orders into a map for quick lookup
        const orderMap = {};
        sanitizedOrders.forEach(order => {
          orderMap[order.date] = {
            orderCount: parseInt(order.orderCount, 10),
            totalAmount: parseFloat(order.totalAmount),
          };
        });

        // Build the final result by combining dateRange with orders
        const result = dateRange.map(date => ({
          date,
          orderCount: orderMap[date]?.orderCount || 0,
          totalAmount: orderMap[date]?.totalAmount || 0,
        }));

        return {
          success: true,
          message: "Fetched Seller's order analysis for summary successfully.",
          data: result
        }
      } else {
        return {
          success: false,
          message: "Start date and end date are required!",
          data: []
        }
      }
    } catch (error) {
      console.error("Error while fetching user's order analysis for summary: ", error);
      return {
        success: false,
        message: "Error while fetching user's order analysis for summary!",
        data: []
      }
    }
  },

  getSellerSalesDataInsights: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");  
    try {

      const seller_id = user?.seller_id;
      const store_id = user?.store_id;

      if (!seller_id) {
        return {
          success: false,
          message: "Seller not found!",
          data: {}
        }
      }

      if (!store_id) {
        return {
          success: false,
          message: "Seller's store not found!",
          data: {}
        }
      }

      let startDate, endDate;
      if (input && input?.startDate && input?.endDate) {
        startDate = moment(input?.startDate).startOf("day");
        endDate = moment(input?.endDate).endOf("day");

        if (endDate.isBefore(startDate)) {
          return {
            success: false,
            message: "End date cannot be before start date!",
            data: {}
          }
        }

        startDate = moment(startDate).format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
        endDate = moment(endDate).format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
      }

      const [
        totalShippedOrders,
        totalVisitorsOfSellerStore,
        totalCreatedCart,
        abandonedCart
      ] = await Promise.all([
        //* total shipped orders
        database.OrderItems.count({
          where: {
            store_id: store_id,
            order_status: "delivered",
            ...(startDate && endDate && {
              createdAt: {
                [Op.between]: [startDate, endDate]
              }
            })
          }
        }),

        //* total store visitors 
        database.StoreActivity.findAll({
          where: {
            store_id: store_id,
            ...(startDate && endDate && {
              createdAt: {
                [Op.between]: [startDate, endDate]
              }
            })
          },
          attributes: [[Sequelize.fn("COUNT", Sequelize.fn("DISTINCT", Sequelize.col("user_id"))), "distinctUsers"]]
        }),

        //* total created cart
        database.Cart.findAll({
          where: {
            store_id: store_id,
            ...(startDate && endDate && {
              createdAt: {
                [Op.between]: [startDate, endDate]
              }
            })
          },
          attributes: [[Sequelize.fn("COUNT", Sequelize.fn("DISTINCT", Sequelize.col("user_id"))), "distinctUsers"]]
        }),

        //* total abandoned cart
        database.Cart.findAll({
          where: {
            store_id: store_id,
            ...(startDate && endDate && {
              createdAt: {
                [Op.between]: [startDate, endDate]
              }
            }),
            status: "cart_abandoned"
          },
          attributes: [[Sequelize.fn("COUNT", Sequelize.fn("DISTINCT", Sequelize.col("user_id"))), "distinctUsers"]]
        }),

      ]);

      const totalDistinctVisitors = parseInt(totalVisitorsOfSellerStore[0]?.dataValues?.distinctUsers) ?? 0;
      const totalDistinctCartAddedUsers = parseInt(totalCreatedCart[0]?.dataValues?.distinctUsers) ?? 0;
      const totalDistinctCartAbandonedUsers = parseInt(abandonedCart[0]?.dataValues?.distinctUsers) ?? 0;

      const conversionRateInPercentage = totalDistinctVisitors ? (totalShippedOrders / totalDistinctVisitors) * 100 : 0.00;
      const cartAbandonmentInPercentage = totalDistinctCartAddedUsers ? (totalDistinctCartAbandonedUsers / totalDistinctCartAddedUsers) * 100 : 0.00;


      return {
        success: true,
        message: "Fetched sales data insights for seller successfully.",
        data: {
          productShipped: totalShippedOrders,
          conversionRateInPercentage: conversionRateInPercentage,
          cartAbandonmentInPercentage: cartAbandonmentInPercentage
        }
      }
    } catch (error) {
      console.error("Error while fetching sales data insights for seller: ", error);
      return {
        success: false,
        message: error?.message ?? "Error while fetching sales data insights for seller",
        data: {}
      }
    }
  }




};
