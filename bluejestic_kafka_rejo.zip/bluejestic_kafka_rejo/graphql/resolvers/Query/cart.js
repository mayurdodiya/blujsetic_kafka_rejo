const { AuthenticationError } = require("apollo-server-express");

const CartService = require("../../../database/services/cart");
const database = require("../../../database/models/index");
const { stringToUrl } = require("../../../middlewares/utils");
const { findCropImages } = require("../../../utils/utils");
const { Op, where } = require("sequelize");

module.exports = {
  getAllCart: async (root, args, { user }) => {
    if (user != null) {
      const allCart_to = await database.Cart.findAll({
        where: { 
          user_id: user?.id,
          status: {
            [Op.in]: ["cart_created", "cart_updated", "checkout_initiated", "cart_abandoned"]
          }
         },
        attributes: ["id", "parent_id", "quantity", "variant_id"],
        raw: true,
        order: [["createdAt", "ASC"]],
        // include: [
        //   {
        //     model: database.Product,
        //     as: "product",
        //     include: [
        //       {
        //         model: database.ProductItem,
        //         as: "variant",
        //         attributes: ["id", "title", "price", "listPrice", "inventory_quantity", "old_inventory_quantity"],
        //         include: [
        //           {
        //             model: database.ProductConfiguration,
        //             as: "total_variant",
        //             attributes: ["id", "variant_option_id"],
        //             include: [
        //               {
        //                 model: database.VariationOption,
        //                 as: "variant_option",
        //                 attributes: ["value", "variation_id", "colorCode"],
        //                 include: [{ model: database.Variation, as: "data", attributes: ["name"] }],
        //               },
        //             ],
        //           },
        //           {
          //             model: database.Media,
        //             as: "image",
        //             attributes: ["media"],
        //           },
        //         ],
        //       },
        //       {
        //         model: database.Variation,
        //         as: "options",
        //         attributes: ["name"],
        //         include: [{ model: database.VariationOption, as: "data", attributes: ["value", "colorCode"] }],
        //       },
        //       { model: database.ProductShippingDetails, as: "shipping" },
        //       {
          //         model: database.ProductMedia,
        //         as: "images",
        //         attributes: ["src", "media_id"],
        //       },
        //       {
          //         model: database.ProductInventory,
        //         as: "inventoryPrice",
        //         attributes: ["price", "listPrice", "quantity", "sku"],
        //       },
        //       {
          //         model: database.BusinessInformation,
          //         as: "store",
          //         attributes: ["id", "name", "logo"],
        //       },
        //     ],
        //   },
        // ],
      });
      let blankArray = [];
      for (let i = 0; i < allCart_to?.length; i++) {
        let cart = allCart_to[i];
        let get_allProduct = await database.Product.findOne({
          where: {
            id: cart?.parent_id,
          },
          include: [
            {
              model: database.ProductItem,
              as: "variant",
              attributes: ["id", "title", "price", "listPrice", "inventory_quantity", "old_inventory_quantity", "image_id"],
              ...(cart?.variant_id && {
                where: {
                  id: cart?.variant_id,
                  product_id: cart?.parent_id,
                },
              }),
              include: [
                {
                  model: database.ProductConfiguration,
                  as: "total_variant",
                  attributes: ["id", "variant_option_id"],
                  include: [
                    {
                      model: database.VariationOption,
                      as: "variant_option",
                      attributes: ["value", "variation_id", "colorCode"],
                      include: [{ model: database.Variation, as: "data", attributes: ["name"] }],
                    },
                  ],
                },
                {
                  model: database.Media,
                  as: "image",
                  attributes: ["media"],
                },
              ],
            },
            // {
            //   model: database.Variation,
            //   as: "options",
            //   attributes: ["name"],
            //   include: [{ model: database.VariationOption, as: "data", attributes: ["value", "colorCode"] }],
            // },
            { model: database.ProductShippingDetails, as: "shipping" },
            {
              model: database.ProductMedia,
              as: "images",
              attributes: ["src", "media_id"],
            },
            {
              model: database.ProductInventory,
              as: "inventoryPrice",
              attributes: ["price", "listPrice", "quantity", "sku"],
            },
            {
              model: database.BusinessInformation,
              as: "store",
              attributes: ["id", "name", "logo"],
            },
          ],
          order: [
            [
              {
                model: database.ProductMedia,
                as: "images",
              },
              "position",
              "ASC",
            ],
          ],
        });
        blankArray.push({ ...cart, product: JSON.parse(JSON.stringify(get_allProduct)) });
      }

      function unique(array, propertyName) {
        return array.filter((e, i) => array.findIndex((a) => a[propertyName] === e[propertyName]) === i);
      }

      let store = unique(
        blankArray.map((i) => i?.product?.store),
        "id"
      );

      function arrayOfCartItem(store, array) {
        let arr = [];
        store.forEach((s) => {
          let product = array.filter((i) => i?.product?.store?.id === s.id);

          product && product.length && product.forEach(p => {
            p.product.cart_item_id = p?.id
          });

          arr.push({ storeDetail: s, product: product });
        });
        return arr;
      }
      let final = [];
      for (const { storeDetail, product } of arrayOfCartItem(store, blankArray)) {
        let store_logo = await database.Media.findOne({
          where: { id: storeDetail?.logo[0] },
        });
        await final.push({
          storeDetail: { ...storeDetail, logo_url: store_logo?.dataValues?.media },
          product,
        });
      }

      return [{ success: true, message: "Fetched cart successfully.", carts: final, count: blankArray.length }];
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getCartCount: async (root, args, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    try {
      
      const allCart_to = await database.Cart.count({
        where: { 
          user_id: user?.id,
          status: {
            [Op.in]: ["cart_created", "cart_updated", "checkout_initiated", "cart_abandoned"]
          }
        },
      });
      return { success: true, message: "Fetched cart items count successfully.", count: allCart_to || 0 };
    } catch (error) {
      console.error("An error occured while fetching cart items count", error);
      return {
        success: false,
        message: "An error occured while fetching cart items count",
        count: 0
      };
    }
    },

  getSingleCart: async (_, { id }, { user }) => {
    if (user != null) {
      return CartService.getById(id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getSelectedCartItems: async (_, { input }, { user }) => {
    if (!user) {
      return {
        success: false,
        message: "Please Provide Token",
        data: [],
      };
    }
    let userId = user.id;
    const selectedProducts = await database.SelectedCartItems.findAll({ user_id: userId });
    let productIds = selectedProducts.map((i) => i.product_id);
    if (productIds.length <= 0) {
      return { success: false, message: "Store's Product Not Found", carts: [], count: 0 };
    }
    let quantity = selectedProducts.map((i) => i.quantity);
    const products = await database.Product.findAll({
      where: {
        id: productIds,
        is_deleted: false,
      },
      include: [
        {
          model: database.BusinessInformation,
          as: "store",
        },
      ],
    });
    let result = [];
    for (let i = 0; i < products.length; i++) {
      const product = products[i];
      let images = product?.image !== undefined && (await stringToUrl(product?.image, product?.id));
      let payload = {
        product: {
          id: product?.id,
          title: product?.title,
          description: product?.description,
          price: product?.price,
          image: images || [],
          store: product.store,
          quantity: quantity[i],
        },
      };
      result.push(payload);
    }

    function unique(array, propertyName) {
      return array.filter((e, i) => array.findIndex((a) => a[propertyName] === e[propertyName]) === i);
    }
    let store = unique(
      result.map((i) => i.product.store),
      "id"
    );

    function arrayOfCartItem(store, array) {
      let arr = [];
      store.forEach((s) => {
        let product = array
          .filter((i) => i.product.store.id === s.id)
          .map((p) => {
            let obj = {
              title: p.product.title,
              description: p.product.description,
              price: p.product.price,
              image: p.product.image,
              productId: p.product.id,
              quantity: p.product.quantity,
            };
            return obj;
          });
        arr.push({ storeDetail: s, product: product });
      });
      return arr;
    }
    let final = [];
    for (const { storeDetail, product } of arrayOfCartItem(store, result)) {
      final.push({
        storeDetail: storeDetail,
        product: product,
      });
    }
    return { sucess: true, message: "Selected cart items get successfully", carts: final, count: products.length };
  },
};
