const { AuthenticationError } = require("apollo-server-express");
const client = require("../../../services/elasticsearch/config/config");
const moment = require("moment");
const database = require("../../../database/models/");
const { Op, Sequelize } = require("sequelize");
const { raw } = require("express");

module.exports = self = {
    /**
     * getDashboardAnalytics: Returns the analytics data for the admin dashboard.
     * @param {Object} root - The root object of the GraphQL query.
     * @param {Object} args - The arguments passed to the GraphQL query.
     * @param {Object} context - The context object of the GraphQL query.
     * @returns {Object} - The analytics data for the admin dashboard.
     */
    getDashboardAnalytics: async (root, args, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        if (user.role !== "admin") return new AuthenticationError("Unauthorized");

        try {
            //* start date and end date of last month
            const startDateOfLastMonth = moment().utc().subtract(1, "months").startOf("month").toISOString();
            const endDateOfLastMonth = moment().utc().subtract(1, "months").endOf("month").toISOString();

            const [
                totalUsers,
                UsersAddedLastMonth,
                totalActiveStores,
                activeStoresAddedLastMonth,
                totalProducts,
                productsAddedLastMonth,
                totalRevenueData,
                revenueGeneratedLastMonthData
            ] = await Promise.all([
                //* total users
                client.count({
                    index: "user"
                }),

                client.count({
                    index: "user",
                    body: {
                        query: {
                            range: {
                                createdAt: {
                                    gte: startDateOfLastMonth,
                                    lte: endDateOfLastMonth
                                }
                            },
                        },
                    },
                }),


                //* total active stores
                client.count({
                    index: 'store',
                    body: {
                        query: {
                            term: {
                                status: {
                                    value: "Active"
                                }
                            }
                        },
                    }
                }),

                client.count({
                    index: "store",
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        range: {
                                            createdAt: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    },
                                    {
                                        term: {
                                            status: {
                                                value: "Active"
                                            }
                                        }
                                    }
                                ],
                            },
                        },
                    },
                }),


                //* total products
                client.count({
                    index: 'products',
                }),

                client.count({
                    index: "products",
                    body: {
                        query: {
                            range: {
                                createdAt: {
                                    gte: startDateOfLastMonth,
                                    lte: endDateOfLastMonth
                                }
                            },
                        },
                    },
                }),


                //* total revenue
                client.search({
                    index: 'order_items',
                    body: {
                        query: {
                            term: {
                                order_status: {
                                    value: 'delivered'
                                }
                            }
                        },
                        aggs: {
                            totalRevenue: {
                                sum: {
                                    field: 'totalAmount'
                                },
                            },
                        },
                        size: 0,
                    }
                }),


                client.search({
                    index: 'order_items',
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        range: {
                                            createdAt: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    },
                                    {
                                        term: {
                                            order_status: {
                                                value: 'delivered'
                                            }
                                        }
                                    }
                                ],
                            },
                        },
                        aggs: {
                            totalRevenue: {
                                sum: {
                                    field: 'totalAmount'
                                },
                            },
                        },
                        size: 0,
                    },
                })
            ]);


            //* Total revenue and last month revenue
            const totalRevenue = totalRevenueData?.aggregations?.totalRevenue?.value;
            const revenueGeneratedLastMonth = revenueGeneratedLastMonthData?.aggregations?.totalRevenue?.value;


            const myData = {
                totalUsers: {
                    total: totalUsers.count,
                    lastMonthPercentage: self.calculatePercentage(UsersAddedLastMonth.count, totalUsers.count),
                },
                activeStores: {
                    total: totalActiveStores.count,
                    lastMonthPercentage: self.calculatePercentage(activeStoresAddedLastMonth.count, totalActiveStores.count),
                },
                totalProducts: {
                    total: totalProducts.count,
                    lastMonthPercentage: self.calculatePercentage(productsAddedLastMonth.count, totalProducts.count),
                },
                totalRevenue: {
                    total: totalRevenue,
                    lastMonthPercentage: self.calculatePercentage(revenueGeneratedLastMonth, totalRevenue),
                }
            };

            return { success: true, message: "Dashbaord analytics data fetched successfully.", data: myData };

        } catch (error) {
            console.error("Error fetching dashboard analytics:", error);
            throw new Error("An error occurred while fetching dashboard analytics data.");
        }
    },


    /**
     * Fetches dashboard data for admin panel, including category distribution.
     * @memberof Resolvers.Query
     * @requires Authentication as admin
     * @returns {Object} - { success: Boolean, message: String, data: Object }
     * @throws {Error} - If an error occurs while fetching the data
     */
    getAdminDashboardData: async (root, args, { user }) => {
        if (!user) return new AuthenticationError("Please Login");
        if (user.role !== "admin") return new AuthenticationError("Unauthorized");
        try {

            const [categoryDistribution] = await Promise.all([
                database.ProductCategories.findAll({
                    attributes: [
                        'category_id',
                        [Sequelize.fn('COUNT', Sequelize.col('ProductCategories.product_id')), 'product_count'], // Count of products in each category
                        [
                            Sequelize.literal(
                                `(COUNT("ProductCategories"."product_id") * 100.0 / (SELECT COUNT(*) FROM "ProductCategories"))`
                            ),
                            'percentage',
                        ],
                    ],
                    include: [
                        {
                            model: database.Category,
                            as: 'category',
                            attributes: ['name'],
                        },
                    ],
                    group: ['ProductCategories.category_id', 'category.id', 'category.name'],
                    raw: true,
                }),
            ]);


            categoryDistribution.map((item) => {
                item["value"] = item.percentage;
                item["name"] = item['category.name'] === null ? "Others" : item['category.name'];
            })

            return {
                success: true, message: "Dashboard data fetched successfully.", data: {
                    categoryDistribution
                }
            };

        } catch (error) {
            console.log("Error in gettingAdmin Dashboard ========>", error);
            throw new Error("Error Getting Dashboard Data:->", error);
        }
    },

    //getSalesAnalytics: async (root, { dateRange }, { user }) => {
    //         if (!user) return new AuthenticationError("Please Provide the token");
    //         if (user.role !== "admin") return new AuthenticationError("Unauthorized");
    //         const { start_date, end_date, time_interval, time_zone } = dateRange;
    //         console.log("🚀 ~ getSalesAnalytics: ~ end_date:", end_date)
    //         console.log("🚀 ~ getSalesAnalytics: ~ start_date:", start_date)

    //         try {
    //             // const formattedStartDate = moment(start_date).utc().format("YYYY-MM-DD");
    //             // const formattedEndDate = moment(end_date).utc().format("YYYY-MM-DD");

    //             // const userResponse = await client.search({


    //             //     index: 'user',
    //             //     body: {
    //             //         query: {
    //             //             range: {
    //             //                 createdAt: {
    //             //                     gte: start_date,
    //             //                     lte: end_date
    //             //                 }
    //             //             }
    //             //         },
    //             //         aggs: {
    //             //             users_over_time: {  // key name in aggregation in response
    //             //                 date_histogram: {  //  group documents by date intervals (day, week, month) and send data in buckets
    //             //                     field: 'createdAt',
    //             //                     calendar_interval: time_interval ?? 'day',
    //             //                     // format: 'yyyy-MM-dd',
    //             //                     min_doc_count: 0, // Ignores lower count data
    //             //                     // "missing": "2024-01-01", // default value for createdAt when it is's missing 
    //             //                     time_zone: time_zone ?? "Asia/Kolkata", // If results needed in a specific time zone(if not set default is utc)
    //             //                     extended_bounds: {     // returns data with 0 even when no doc count on that perticular date(if not apply then date with empty document is ignored)  
    //             //                         min: formattedStartDate, // only execpts as per above formatted date otherwise throws error
    //             //                         max: formattedEndDate
    //             //                     }
    //             //                 }
    //             //             }
    //             //         },
    //             //         size: 0 // Exclude actual document hits from the response
    //             //     }
    //             // });

    //             // const salesResponse = await client.search({
    //             //     index: 'order_items',
    //             //     body: {
    //             //         query: {
    //             //             bool: {
    //             //                 must: [
    //             //                     {
    //             //                         range: {
    //             //                             createdAt: {
    //             //                                 gte: start_date,
    //             //                                 lte: end_date
    //             //                             }
    //             //                         }
    //             //                     },
    //             //                     {
    //             //                         term: {
    //             //                             order_status: "delivered"
    //             //                         }
    //             //                     }
    //             //                 ]
    //             //             }
    //             //         },
    //             //         aggs: {
    //             //             sales_over_time: {
    //             //                 date_histogram: {
    //             //                     field: 'createdAt',
    //             //                     calendar_interval: time_interval ?? 'day',
    //             //                     // format: 'yyyy-MM-dd',
    //             //                     time_zone: time_zone ?? "Asia/Kolkata",
    //             //                     extended_bounds: {
    //             //                         min: formattedStartDate,
    //             //                         max: formattedEndDate
    //             //                     }
    //             //                 },
    //             //                 aggs: {
    //             //                     total_sales: {
    //             //                         sum: {
    //             //                             field: 'totalAmount'
    //             //                         }
    //             //                     }
    //             //                 }
    //             //             }
    //             //         },
    //             //         size: 0
    //             //     }
    //             // });

    //             // const userBuckets = userResponse?.aggregations?.users_over_time?.buckets;
    //             // const salesBuckets = salesResponse?.aggregations?.sales_over_time?.buckets;

    //             // Create a map of users by date
    //             // const userMap = userBuckets.reduce((acc, bucket) => {
    //             //     acc[bucket.key_as_string] = bucket.doc_count;
    //             //     return acc;
    //             // }, {});

    //             // Combine with sales data
    //             // const salesUserData = salesBuckets.map(bucket => ({
    //             //     date: bucket.key_as_string,
    //             //     totalSales: bucket.total_sales.value || 0,
    //             //     totalUsers: userMap[bucket.key_as_string] || 0
    //             // }));

    //             // const users = await database.User.findAll({
    //             //     attributes: [
    //             //         [Sequelize.fn("DATE", Sequelize.col("User.createdAt")), "date"],
    //             //         // "createdAt",
    //             //         [Sequelize.fn("COUNT", Sequelize.col("User.id")), "count"]
    //             //     ],
    //             //     where: {
    //             //         [Op.and]: [
    //             //             {
    //             //                 createdAt: {
    //             //                     [Op.between]: [start_date, end_date]
    //             //                 }
    //             //             },
    //             //             {
    //             //                 '$userLoginActivities.createdAt$': {
    //             //                     [Op.between]: [start_date, end_date]
    //             //                 }
    //             //             }
    //             //         ]
    //             //     },
    //             //     include: [
    //             //         {
    //             //             model: database.UserLoginActivity,
    //             //             as: "userLoginActivities",
    //             //             attributes: [],
    //             //             required: false,
    //             //             // where: {
    //             //             //     createdAt: {
    //             //             //         [Op.between]: [start_date, end_date]
    //             //             //     }
    //             //             // }
    //             //         }
    //             //     ],
    //             //     group: [
    //             //         // "User.createdAt",
    //             //         "User.id",
    //             //         Sequelize.fn("DATE", Sequelize.col("User.createdAt")),
    //             //         // Sequelize.col("userLoginActivities.loginTime")
    //             //     ],
    //             //     having: Sequelize.literal(`COUNT("userLoginActivities"."id") != '0'`), // Filter where count is 0
    //             //     order: [
    //             //         [Sequelize.fn("DATE", Sequelize.col("User.createdAt")), "ASC"]
    //             //     ]

    //             // });
    //             const users = await database.sequelize.query(
    //                 `
    //                 WITH date_series AS (
    //                     SELECT generate_series(
    //                         :startDate::date,
    //                         :endDate::date,
    //                         '1 day'::interval
    //                     )::date AS date
    //                 )
    //                 SELECT 
    //                     ds.date,
    //                     COUNT(DISTINCT u.id) AS count
    //                 FROM 
    //                     date_series ds
    //                 LEFT JOIN 
    //                     "Users" u ON DATE(u."createdAt") = ds.date
    //                 LEFT JOIN
    //                     "UserLoginActivities" ula ON ula."user_id" = u.id
    //                     AND DATE(ula."createdAt") = ds.date
    //                 WHERE 
    //                     u."createdAt" BETWEEN :startDate AND :endDate
    //                     OR ula."createdAt" BETWEEN :startDate AND :endDate
    //                     OR u."createdAt" IS NULL
    //                 GROUP BY 
    //                     ds.date
    //                 ORDER BY 
    //                     ds.date ASC
    //                 `,
    //                 {
    //                     replacements: {
    //                         startDate: start_date,
    //                         endDate: end_date,
    //                     },
    //                     type: Sequelize.QueryTypes.SELECT,
    //                 }
    //             );

    //              // const users = await database.User.findAll({
    //             //     attributes: [
    //             //         [Sequelize.fn("DATE", Sequelize.col("User.createdAt")), "date"], // Group by distinct date
    //             //         [Sequelize.fn("COUNT", Sequelize.col("User.id")), "count"]      // Count users per date
    //             //     ],
    //             //     where: {
    //             //         createdAt: {
    //             //             [Op.between]: [start_date, end_date] // Filter by date range
    //             //         }
    //             //     },
    //             //     include: [
    //             //         {
    //             //             model: database.UserLoginActivity,
    //             //             as: "userLoginActivities",
    //             //             attributes: [],
    //             //             required: false,
    //             //             where: {
    //             //                 createdAt: {
    //             //                     [Op.between]: [start_date, end_date] // Filter by login activity date range
    //             //                 }
    //             //             }
    //             //         }
    //             //     ],
    //             //     group: [
    //             //         "User.id",
    //             //         Sequelize.fn("DATE", Sequelize.col("User.createdAt")) // Group by distinct date
    //             //     ],
    //             //     order: [
    //             //         [Sequelize.fn("DATE", Sequelize.col("User.createdAt")), "ASC"] // Order by date
    //             //     ]
    //             // });

    // //             const users = await database.sequelize.query(`
    // //                     WITH date_sequence AS (
    // //     -- Generate a sequence of dates within the specified range
    // //     SELECT generate_series(
    // //       '${start_date}'::date, 
    // //       '${end_date}'::date, 
    // //       '1 day'::interval
    // //     )::date AS date
    // //   )
    // //   SELECT
    // //     ds.date,
    // //     COALESCE(COUNT(DISTINCT u.id), 0) AS count
    // //   FROM
    // //     date_sequence ds
    // //   LEFT JOIN
    // //     "Users" u
    // //       ON DATE(u.createdAt) = ds.date
    // //       ds.date
    // //       ORDER BY
    // //       ds.date;
    // //       `)
    //     //   LEFT JOIN
    //     //     "UserLoginActivities" ula
    //     //       ON DATE(ula.loginTime) = ds.date AND ula.user_id = u.id
    //     //   GROUP BY

    // //             const users = await database.sequelize.query(`
    // //                WITH UserCounts AS (
    // //     SELECT
    // //         DATE_TRUNC('day', u.created_at) AS date,
    // //         COUNT(*) AS new_users
    // //     FROM
    // //         users u
    // //     WHERE
    // //         u.created_at BETWEEN '2024-12-01' AND '2024-12-19'
    // //     GROUP BY
    // //         DATE_TRUNC('day', u.created_at)
    // // ),
    // // ActiveUserCounts AS (
    // //     SELECT
    // //         DATE_TRUNC('day', ula.login_time) AS date,
    // //         COUNT(DISTINCT ula.user_id) AS active_users
    // //     FROM
    // //         UserLoginActivity ula
    // //     WHERE
    // //         ula.login_time BETWEEN '2024-12-01' AND '2024-12-19'
    // //     GROUP BY
    // //         DATE_TRUNC('day', ula.login_time)
    // // ),
    // // DeliveredOrderCounts AS (
    // //     SELECT
    // //         DATE_TRUNC('day', oi.created_at) AS date,
    // //         COUNT(*) AS delivered_orders
    // //     FROM
    // //         order_items oi
    // //     WHERE
    // //         oi.order_status = 'delivered'
    // //         AND oi.created_at BETWEEN '2024-12-01' AND '2024-12-19'
    // //     GROUP BY
    // //         DATE_TRUNC('day', oi.created_at)
    // // )
    // // SELECT
    // //     uc.date,
    // //     uc.new_users + ac.active_users AS total_active_users,
    // //     doc.delivered_orders AS total_sales
    // // FROM
    // //     UserCounts uc
    // // FULL OUTER JOIN ActiveUserCounts ac ON uc.date = ac.date
    // // FULL OUTER JOIN DeliveredOrderCounts doc ON uc.date = doc.date
    // // ORDER BY
    // //     uc.date ASC;
    // //               `, {
    // //                 type: database.Sequelize.QueryTypes.SELECT,
    // //             });
    //             console.log("🚀 ~ getSalesAnalytics: ~ users:", JSON.parse(JSON.stringify(users)))
    //             // const sales = await database.OrderItems.findAll({});
    //             return {
    //                 success: true,
    //                 message: "Sales usersanalytics data fetched successfully.",
    //                 // data: salesUserData
    //             }

    //         } catch (error) {
    //             console.error("Error while fetching sales analytics data:", error);
    //             throw new Error("An error occured while fetching sales analytics data.");
    //         }
    //     },

    getSalesAnalytics: async (root, { dateRange }, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        if (user.role !== "admin") return new AuthenticationError("Unauthorized");
        const { start_date, end_date, time_interval, time_zone } = dateRange;

        try {
            // const analytics = await database.sequelize.query(
            //     `
            // WITH date_series AS (
            //     SELECT generate_series(
            //         :startDate::date,
            //         :endDate::date,
            //         '1 day'::interval
            //     )::date AS date
            // ),
            // user_analytics AS (
            //     SELECT 
            //         ds.date,
            //         COUNT(DISTINCT 
            //             CASE WHEN 
            //                 DATE(u."createdAt") = ds.date 
            //                 OR DATE(ula."createdAt") = ds.date 
            //             THEN u.id END
            //         ) AS active_users
            //     FROM 
            //         date_series ds
            //     LEFT JOIN 
            //         "Users" u ON (
            //             DATE(u."createdAt") = ds.date 
            //             OR (
            //                 u."createdAt" <= :endDate 
            //                 AND u."createdAt" >= :startDate
            //             )
            //         )
            //     LEFT JOIN 
            //         "UserLoginActivities" ula ON (
            //             ula."user_id" = u.id 
            //             AND DATE(ula."createdAt") = ds.date
            //         )
            //     GROUP BY 
            //         ds.date
            // ),
            // sales_analytics AS (
            //     SELECT 
            //         ds.date,
            //         COUNT(DISTINCT oi.id) AS total_sales
            //     FROM 
            //         date_series ds
            //     LEFT JOIN 
            //         "OrderItems" oi ON (
            //             DATE(oi."createdAt") = ds.date 
            //             AND oi.order_status = 'delivered'
            //         )
            //     GROUP BY 
            //         ds.date
            // )
            // SELECT 
            //     ds.date,
            //     COALESCE(ua.active_users, 0) AS active_users,
            //     COALESCE(sa.total_sales, 0) AS total_sales
            // FROM 
            //     date_series ds
            // LEFT JOIN 
            //     user_analytics ua ON ua.date = ds.date
            // LEFT JOIN 
            //     sales_analytics sa ON sa.date = ds.date
            // ORDER BY 
            //     ds.date ASC
            // `,
            //     {
            //         replacements: {
            //             startDate: start_date,
            //             endDate: end_date,
            //         },
            //         type: Sequelize.QueryTypes.SELECT,
            //     }
            // );



            const results = await database.User.findAll({
                attributes: [
                    [Sequelize.fn('DATE', Sequelize.literal(`
                    COALESCE("User"."createdAt", "userLoginActivities"."createdAt")
                  `)), 'date'],
                    [Sequelize.fn('COUNT', Sequelize.fn('DISTINCT', Sequelize.col('User.id'))), 'userCount'],
                ],
                include: [
                    {
                        model: database.UserLoginActivity,
                        as: "userLoginActivities",
                        attributes: [],
                        required: false, // Left join to include users who may not have login activity
                    },
                ],
                where: {
                    [Sequelize.Op.or]: [
                        { createdAt: { [Sequelize.Op.between]: [start_date, end_date] } },
                        { '$userLoginActivities.createdAt$': { [Sequelize.Op.between]: [start_date, end_date] } },
                    ],
                },
                group: [
                    "User.id",
                    Sequelize.fn('DATE', Sequelize.literal(`
                  COALESCE("User"."createdAt", "userLoginActivities"."createdAt")
                `))],
                order: [[Sequelize.literal('date'), 'ASC']],
            });

            // Transform the results into a simple date-count map
            const dataMap = {};
            results.forEach((entry) => {
                const date = entry.getDataValue('date');
                const count = parseInt(entry.getDataValue('userCount'), 10);
                dataMap[date] = count;
            });

            // Step 2: Generate the full range of dates and fill in zeros where needed
            const start = moment(start_date);
            const end = moment(end_date);
            const dateRange = [];

            while (start <= end) {
                const dateStr = start.format('YYYY-MM-DD');
                dateRange.push({ date: dateStr, userCount: dataMap[dateStr] || 0 });
                start.add(1, 'day');
            }

            console.log("dateRange: ", dateRange);

            //   return dateRange;

            // console.log("🚀 ~ getSalesAnalytics: ~ analytics:", JSON.parse(JSON.stringify(analytics)));

            // const data = analytics.map(item => ({
            //     date: moment(item.date).format('YYYY-MM-DD'),
            //     active_users: parseInt(item.active_users),
            //     total_sales: parseInt(item.total_sales)
            // }));
            // console.log("🚀 ~ data ~ data:", data)

            // return {
            //     success: true,
            //     message: "Sales users analytics data fetched successfully.",
            //     data
            // }

        } catch (error) {
            console.error("An Error occured while fetching users sales analytics data:", error);
            throw new Error("An Error occured while fetching users sales analytics data:");
        }
    },

    getCategoryDistribution: async (root, { args }, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        if (user.role !== "admin") return new AuthenticationError("Unauthorized");

        try {

            const abc = await database.OrderItems.findAll({
                attributes: ["id"],
                include: [
                    {
                        model: database.Product,
                        as: "product",
                        attributes: ["id"],
                        include: [
                            {
                                model: database.ProductCategories,
                                as: "categories",
                                attributes: ["id"],
                                where: {
                                    id: {
                                        [Op.not]: null
                                    }
                                },
                                include: [
                                    {
                                        model: database.Category,
                                        as: "category",
                                        attributes: ["id"]
                                    }
                                ]
                            }
                        ]
                    }
                ]
            });
            console.log("🚀 ~ getCategoryDistribution: ~ abc:", JSON.parse(JSON.stringify(abc)));


            return {
                success: true,
                message: "Category distribution analytics data fetched successfully.",
            }

        } catch (error) {
            console.error("Error while fetching category destribution analytics data:", error);
            throw new Error("An error occured while fetching category destribution analytics data.");
        }
    },

    getCustomersAnalytics: async () => {
        try {

            //* start date and end date of last month
            const startDateOfLastMonth = moment().utc().subtract(1, "months").startOf("month").toISOString();
            const endDateOfLastMonth = moment().utc().subtract(1, "months").endOf("month").toISOString();

            const [
                totalCustomers,
                customersAddedLastMonth,
                totalActiveCustomers,
                activeCustomersAddedLastMonth,
                totalOrders,
                ordersReceivedLastMonth,
                totalRevenueData,
                revenueGeneratedLastMonthData
            ] = await Promise.all([
                //* total customers
                client.count({
                    index: "user"
                }),

                client.count({
                    index: "user",
                    body: {
                        query: {
                            range: {
                                createdAt: {
                                    gte: startDateOfLastMonth,
                                    lte: endDateOfLastMonth
                                }
                            },
                        },
                    },
                }),


                //* total active customers
                client.count({
                    index: 'user',
                    body: {
                        query: {
                            term: {
                                status: {
                                    value: "active"
                                }
                            }
                        },
                    }
                }),

                client.count({
                    index: "user",
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        range: {
                                            createdAt: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    },
                                    {
                                        term: {
                                            status: {
                                                value: "active"
                                            }
                                        }
                                    }
                                ],
                            },
                        },
                    },
                }),


                //* total orders
                client.count({
                    index: 'order_master',
                }),

                client.count({
                    index: "order_master",
                    body: {
                        query: {
                            range: {
                                createdAt: {
                                    gte: startDateOfLastMonth,
                                    lte: endDateOfLastMonth
                                }
                            },
                        },
                    },
                }),


                //* total revenue
                client.search({
                    index: 'order_items',
                    body: {
                        query: {
                            term: {
                                order_status: {
                                    value: 'delivered'
                                }
                            }
                        },
                        aggs: {
                            totalRevenue: {
                                sum: {
                                    field: 'totalAmount'
                                },
                            },
                        },
                        size: 0,
                    }
                }),


                client.search({
                    index: 'order_items',
                    body: {
                        query: {
                            term: {
                                order_status: {
                                    value: 'delivered'
                                }
                            }
                        },
                        aggs: {
                            totalRevenue: {
                                sum: {
                                    field: 'totalAmount'
                                },
                            },
                        },
                        size: 0,
                    },
                })
            ]);


            //* Total revenue and last month revenue
            const totalRevenue = totalRevenueData?.aggregations?.totalRevenue?.value;
            const revenueGeneratedLastMonth = revenueGeneratedLastMonthData?.aggregations?.totalRevenue?.value;


            const myData = {
                totalCustomers: {
                    total: totalCustomers.count,
                    lastMonthPercentage: self.calculatePercentage(customersAddedLastMonth.count, totalCustomers.count),
                },
                activeCustomers: {
                    total: totalActiveCustomers.count,
                    lastMonthPercentage: self.calculatePercentage(activeCustomersAddedLastMonth.count, totalActiveCustomers.count),
                },
                totalOrders: {
                    total: totalOrders.count,
                    lastMonthPercentage: self.calculatePercentage(ordersReceivedLastMonth.count, totalOrders.count),
                },
                totalRevenue: {
                    total: totalRevenue,
                    lastMonthPercentage: self.calculatePercentage(revenueGeneratedLastMonth, totalRevenue),
                }
            };

            return { success: true, message: "Customers analytics data fetched successfully.", data: myData };

        } catch (error) {
            console.error("Error fetching customers analytics:", error);
            throw new Error("An error occurred while fetching customers analytics data.");
        }
    },

    getUserAnalyticsBySlug: async (root, { slug }, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        if (user.role !== "admin") return new AuthenticationError("Unauthorized");
        if (!slug) return {
            success: false,
            message: "Please provide a slug!",
            data: null
        }
        try {
            console.log(slug);


            let find_user = await database.User.findOne({
                where: {
                    userName: slug
                }
            })

            find_user = JSON.parse(JSON.stringify(find_user));

            //* start date and end date of last month
            const startDateOfLastMonth = moment().utc().subtract(1, "months").startOf("month").toISOString();
            const endDateOfLastMonth = moment().utc().subtract(1, "months").endOf("month").toISOString();

            let [
                totalOrders,
                ordersReceivedLastMonth,
                totalSpent,
                spentLastMonth,
                followers,
                followersLastMonth,
                following,
                followingLastMonth
            ] = await Promise.all([
                //* total orders
                client.count({
                    index: "order_items",
                    body: {
                        query: {
                            term: {
                                user_id: find_user?.id
                            }
                        }
                    }
                }),

                //* ordersReceivedLastMonth
                client.count({
                    index: "order_items",
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        term: {
                                            user_id: {
                                                value: find_user?.id
                                            }
                                        }
                                    },
                                    {
                                        range: {
                                            createdAt: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    },
                                ],
                            },
                        },
                    }
                }),

                //* totalSpent
                client.search({
                    index: "order_items",
                    body: {
                        query: {
                            term: {
                                user_id: {
                                    value: find_user?.id
                                }
                            }
                        },
                        aggs: {
                            totalSpent: {
                                sum: {
                                    field: "totalAmount"
                                }
                            }
                        },
                        size: 0
                    }
                }),

                //* spentLastMonth
                client.search({
                    index: "order_items",
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        term: {
                                            user_id: {
                                                value: find_user?.id
                                            }
                                        }
                                    },
                                    {
                                        range: {
                                            createdAt: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    },
                                ],
                            },
                        },
                        aggs: {
                            spentLastMonth: {
                                sum: {
                                    field: "totalAmount"
                                }
                            }
                        },
                        size: 0,
                    }
                }),

                //* followers
                database.Friend.count({
                    where: {
                        user_id: find_user?.id,
                        isFriend: true,
                    },
                }),

                //* followersLastMonth
                database.Friend.count({
                    where: {
                        user_id: find_user?.id,
                        isFriend: true,
                        createdAt: {
                            [Op.between]: [startDateOfLastMonth, endDateOfLastMonth]
                        }
                    },
                }),

                //* following
                database.Friend.count({
                    where: {
                        friend_id: find_user?.id,
                        isFriend: true,
                    },
                }),

                //* followingLastMonth
                database.Friend.count({
                    where: {
                        friend_id: find_user?.id,
                        isFriend: true,
                        createdAt: {
                            [Op.between]: [startDateOfLastMonth, endDateOfLastMonth]
                        }
                    },
                }),
            ]);


            totalOrders = totalOrders?.count ?? 0;
            ordersReceivedLastMonth = ordersReceivedLastMonth?.count ?? 0;
            totalSpent = totalSpent?.aggregations?.totalSpent?.value ?? 0;
            spentLastMonth = spentLastMonth?.aggregations?.spentLastMonth?.value ?? 0;

            const lastMonthPercentageTotalOrders = totalOrders ? (ordersReceivedLastMonth / totalOrders) * 100 : 0;
            const lastMonthPercentageTotalSpent = totalSpent ? (spentLastMonth / totalSpent) * 100 : 0;
            const lastMonthPercentageFollowers = followers ? (followersLastMonth / followers) * 100 : 0;
            const lastMonthPercentageFollowing = following ? (followingLastMonth / following) * 100 : 0;



            return {
                success: true,
                message: "Fetched user analytics successfully.",
                data: {
                    totalOrders,
                    lastMonthPercentageTotalOrders,
                    totalSpent,
                    lastMonthPercentageTotalSpent,
                    followers,
                    lastMonthPercentageFollowers,
                    following,
                    lastMonthPercentageFollowing
                }
            }

        } catch (error) {
            console.error("An error occured while fetching user analytics: ", error);
            return {
                success: false,
                message: "An error occured while fetching user analytics!",
                data: null
            }
        }
    },

    getStoresAnalytics: async (root, args, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        if (user.role !== "admin") return new AuthenticationError("Unauthorized");

        try {

            //* start date and end date of last month
            const startDateOfLastMonth = moment().utc().subtract(1, "months").startOf("month").toISOString();
            const endDateOfLastMonth = moment().utc().subtract(1, "months").endOf("month").toISOString();

            const [
                totalStores,
                storesAddedLastMonth,
                totalActiveStores,
                activeStoresAddedLastMonth,
                totalProducts,
                productsAddedLastMonth,
                totalSalesData,
                salesGeneratedLastMonthData
            ] = await Promise.all([
                //* total stores
                client.count({
                    index: 'store'
                }),

                client.count({
                    index: "store",
                    body: {
                        query: {
                            range: {
                                createdAt: {
                                    gte: startDateOfLastMonth,
                                    lte: endDateOfLastMonth
                                }
                            },
                        },
                    },
                }),


                //* total active stores
                client.count({
                    index: 'store',
                    body: {
                        query: {
                            term: {
                                status: {
                                    value: "Active"
                                }
                            }
                        },
                    }
                }),

                client.count({
                    index: "store",
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        range: {
                                            createdAt: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    },
                                    {
                                        term: {
                                            status: {
                                                value: "Active"
                                            }
                                        }
                                    }
                                ],
                            },
                        },
                    },
                }),


                //* total products
                client.count({
                    index: 'products',
                }),

                client.count({
                    index: "products",
                    body: {
                        query: {
                            range: {
                                createdAt: {
                                    gte: startDateOfLastMonth,
                                    lte: endDateOfLastMonth
                                }
                            },
                        },
                    },
                }),


                //* total revenue
                client.search({
                    index: 'order_items',
                    body: {
                        query: {
                            term: {
                                order_status: {
                                    value: 'delivered'
                                }
                            }
                        },
                        aggs: {
                            totalSales: {
                                sum: {
                                    field: 'totalAmount'
                                },
                            },
                        },
                        size: 0,
                    }
                }),

                client.search({
                    index: 'order_items',
                    body: {
                        query: {
                            term: {
                                order_status: {
                                    value: 'delivered'
                                }
                            }
                        },
                        aggs: {
                            totalSales: {
                                sum: {
                                    field: 'totalAmount'
                                },
                            },
                        },
                        size: 0,
                    },
                })
            ]);


            //* Total revenue and last month revenue
            const totalSales = totalSalesData?.aggregations?.totalSales?.value;
            const salesGeneratedLastMonth = salesGeneratedLastMonthData?.aggregations?.totalSales?.value;


            const myData = {
                totalStores: {
                    total: totalStores.count,
                    lastMonthPercentage: self.calculatePercentage(storesAddedLastMonth.count, totalStores.count),
                },
                activeStores: {
                    total: totalActiveStores.count,
                    lastMonthPercentage: self.calculatePercentage(activeStoresAddedLastMonth.count, totalActiveStores.count),
                },
                totalProducts: {
                    total: totalProducts.count,
                    lastMonthPercentage: self.calculatePercentage(productsAddedLastMonth.count, totalProducts.count),
                },
                totalSales: {
                    total: totalSales,
                    lastMonthPercentage: self.calculatePercentage(salesGeneratedLastMonth, totalSales),
                }
            };

            return { success: true, message: "Store analytics data fetched successfully.", data: myData };

        } catch (error) {
            console.error("Error fetching stores analytics:", error);
            throw new Error("An error occurred while fetching stores analytics data.");
        }
    },

    getStoresAnalyticsBySlug: async (root, { slug }, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        if (user.role !== "admin") return new AuthenticationError("Unauthorized");

        try {

            //* start date and end date of last month
            const startDateOfLastMonth = moment().utc().subtract(1, "months").startOf("month").toISOString();
            const endDateOfLastMonth = moment().utc().subtract(1, "months").endOf("month").toISOString();

            let find_store = await database.BusinessInformation.findOne({
                where: {
                    slug: slug
                }
            });

            find_store = JSON.parse(JSON.stringify(find_store));

            if (!find_store) {
                return {
                    success: false,
                    message: "Store not found!",
                    data: null
                }
            }



            const [
                totalProducts,
                productsAddedLastMonth,
                productsSold,
                productSoldLastMonth,
                totalFollowers,
                totalFollowersAddedLastMonth,
                totalRevenue,
                revenueGeneratedLastMonthData
            ] = await Promise.all([
                //* total products
                client.count({
                    index: 'products',
                    body: {
                        query: {
                            term: {
                                store_id: find_store?.id
                            }
                        }
                    }
                }),

                client.count({
                    index: "products",
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        match: {
                                            store_id: find_store?.id
                                        }
                                    },
                                    {
                                        range: {
                                            createdAt: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    }
                                ]
                            }
                        },
                    },
                }),

                //* products sold
                client.search({
                    index: 'order_items',
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        match: {
                                            store_id: find_store?.id
                                        }
                                    },
                                    {
                                        match: {
                                            order_status: "delivered"
                                        },
                                    }
                                ]
                            }
                        },
                        aggs: {
                            totalProductSold: {
                                sum: {
                                    field: "quantity"
                                }
                            }
                        },
                        size: 0
                    }
                }),

                client.search({
                    index: "order_items",
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        match: {
                                            store_id: find_store?.id
                                        }
                                    },
                                    {
                                        match: {
                                            order_status: "delivered"
                                        },
                                    },
                                    {
                                        range: {
                                            createdAt: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    }
                                ]
                            }
                        },
                        aggs: {
                            totalProductSoldLastMonth: {
                                sum: {
                                    field: "quantity"
                                }
                            }
                        },
                        size: 0
                    },
                }),



                //* total followers
                database.FollowStore.count({
                    where: {
                        store_id: find_store?.id
                    }
                }),

                database.FollowStore.count({
                    where: {
                        store_id: find_store?.id,
                        createdAt: {
                            [Op.between]: [startDateOfLastMonth, endDateOfLastMonth]
                        }
                    }
                }),


                //* total revenue
                client.search({
                    index: 'order_items',
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        match: {
                                            store_id: find_store?.id
                                        }
                                    },
                                    {
                                        match: {
                                            order_status: "delivered"
                                        },
                                    },
                                    {
                                        range: {
                                            createdAt: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    }
                                ]
                            }
                        },
                        aggs: {
                            totalSales: {
                                sum: {
                                    field: 'totalAmount'
                                },
                            },
                        },
                        size: 0,
                    }
                }),

                client.search({
                    index: 'order_items',
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        match: {
                                            store_id: find_store?.id
                                        }
                                    },
                                    {
                                        match: {
                                            order_status: "delivered"
                                        },
                                    },
                                    {
                                        range: {
                                            createdAt: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    }
                                ]
                            }
                        },
                        aggs: {
                            totalSales: {
                                sum: {
                                    field: 'totalAmount'
                                },
                            },
                        },
                        size: 0,
                    },
                })
            ]);


            console.log("totalProducts, \
                productsAddedLastMonth, \
                productsSold, \
                productSoldLastMonth, \
                totalFollowers, \
                totalFollowersAddedLastMonth, \
                totalRevenue, \
                revenueGeneratedLastMonthData",
                totalProducts,
                productsAddedLastMonth,
                productsSold,
                productSoldLastMonth,
                totalFollowers,
                totalFollowersAddedLastMonth,
                totalRevenue,
                revenueGeneratedLastMonthData);


            // //* Total revenue and last month revenue
            // const totalSales = totalSalesData?.aggregations?.totalSales?.value;
            // const salesGeneratedLastMonth = salesGeneratedLastMonthData?.aggregations?.totalSales?.value;


            const myData = {
                totalProducts: {
                    total: 0,
                    lastMonthPercentage: 0,
                },
                ProductsSold: {
                    total: 0,
                    lastMonthPercentage: 0,
                },
                followers: {
                    total: 0,
                    lastMonthPercentage: 0,
                },
                totalRevenure: {
                    total: 0,
                    lastMonthPercentage: 0,
                }
            };

            return { success: true, message: "Store's analytics data fetched successfully.", data: myData };

        } catch (error) {
            console.error("Error fetching store's analytics data:", error);
            throw new Error("An error occurred while fetching store's analytics data.");
        }
    },

    getNewStoresApplicationsAnalytics: async (root, args, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        if (user.role !== "admin") return new AuthenticationError("Unauthorized");

        try {

            //* start date and end date of last month
            const startDateOfLastMonth = moment().utc().subtract(1, "months").startOf("month").toISOString();
            const endDateOfLastMonth = moment().utc().subtract(1, "months").endOf("month").toISOString();

            //* start date and current dateTime of current month
            const startDateOfCurrentMonth = moment().utc().startOf("month").toISOString();
            const currentDateTime = moment().utc().toISOString();

            //* start date of current week and currentDataTime is above
            const startDateOfCurrentWeek = moment().utc().startOf("week").toISOString();

            const [
                pendingApplications,
                pendingApplicationsAddedCurrentWeek,
                totalApprovedApplications,
                approvedThisMonth,
                approvedLastMonth,
                totalApplications,
                totalApplicationsAddedLastMonth,
                totalAverageProcessingTimeData,
                averageProcessingTimeLastMonthData,
            ] = await Promise.all([
                //* pending applications
                client.count({
                    index: "sellers",
                    body: {
                        query: {
                            term: {
                                sellerApprovedStatusNew: {
                                    value: "Pending"
                                }
                            },
                        },
                    },
                }),

                client.count({
                    index: 'sellers',
                    body: {
                        query: {
                            bool: {
                                filter: [
                                    {
                                        term: {
                                            sellerApprovedStatusNew: {
                                                value: "Pending"
                                            }
                                        }
                                    },
                                    {
                                        range: {
                                            details5OnboardingCompletedAtNew: {
                                                gte: startDateOfCurrentWeek, // it starts from sunday as per moment library
                                                lte: currentDateTime
                                            }
                                        }
                                    }
                                ]
                            }
                        },
                    }
                }),


                //* approved this month
                client.count({
                    index: 'sellers',
                    body: {
                        query: {
                            term: { sellerApprovedStatusNew: "approved" }
                        },
                    }
                }),

                client.count({
                    index: 'sellers',
                    body: {
                        query: {
                            bool: {
                                filter: [
                                    { term: { sellerApprovedStatusNew: "approved" } },
                                    {
                                        range: {
                                            status_updated_at_new: {
                                                gte: startDateOfCurrentMonth,
                                                lte: currentDateTime
                                            }
                                        }
                                    }
                                ]
                            }
                        },
                    }
                }),

                client.count({
                    index: "sellers",
                    body: {
                        query: {
                            bool: {
                                must: [
                                    { term: { sellerApprovedStatusNew: "approved" } },
                                    {
                                        range: {
                                            status_updated_at_new: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    },
                                ],
                            },
                        },
                    },
                }),


                //* total applications
                client.count({
                    index: 'sellers',
                }),

                client.count({
                    index: "sellers",
                    body: {
                        query: {
                            range: {
                                createdAt: {
                                    gte: startDateOfLastMonth,
                                    lte: endDateOfLastMonth
                                }
                            },
                        },
                    },
                }),


                //* average processing time
                client.search({
                    index: 'sellers',
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        exists: { field: "details5OnboardingCompletedAtNew" }
                                    },
                                    {
                                        exists: { field: "status_updated_at_new" }
                                    }
                                ]
                            }
                        },
                        aggs: {
                            avgProcessingTime: {
                                avg: {
                                    script: {
                                        source: "if (doc['status_updated_at_new'].size() != 0 && doc['details5OnboardingCompletedAtNew'].size() != 0) { return (doc['status_updated_at_new'].value - doc['details5OnboardingCompletedAtNew'].value) / 1000 / 60 / 60 } else { return 0 }",
                                        lang: "painless"
                                    }
                                }
                            }
                        },
                        size: 0,
                    }
                }),

                client.search({
                    index: 'sellers',
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        exists: { field: "details5OnboardingCompletedAtNew" }
                                    },
                                    {
                                        exists: { field: "status_updated_at_new" }
                                    }
                                ],
                                filter: {
                                    range: {
                                        status_updated_at_new: {
                                            gte: startDateOfLastMonth,
                                            lte: endDateOfLastMonth
                                        }
                                    }
                                }
                            }
                        },
                        aggs: {
                            avgProcessingTimeLastMonth: {
                                avg: {
                                    script: {
                                        source: "if (doc['status_updated_at_new'].size() != 0 && doc['details5OnboardingCompletedAtNew'].size() != 0) { return (doc['status_updated_at_new'].value - doc['details5OnboardingCompletedAtNew'].value) / 1000 / 60 / 60 } else { return 0 }",
                                        lang: "painless"
                                    }
                                }
                            }
                        },
                        size: 0,
                    }
                }),
            ]);

            //* average processing time for total and for last month
            const totalAverageProcessingTime = totalAverageProcessingTimeData?.aggregations?.avgProcessingTime?.value;
            const averageProcessingTimeLastMonth = averageProcessingTimeLastMonthData?.aggregations?.avgProcessingTimeLastMonth?.value;


            const myData = {
                pendingApplications: {
                    total: pendingApplications.count,
                    lastMonthPercentage: pendingApplicationsAddedCurrentWeek.count,
                },
                approvedThisMonth: {
                    total: approvedThisMonth.count,
                    lastMonthPercentage: self.calculatePercentage(approvedLastMonth.count, totalApprovedApplications.count),
                },
                totalApplications: {
                    total: totalApplications.count,
                    lastMonthPercentage: self.calculatePercentage(totalApplicationsAddedLastMonth.count, totalApplications.count),
                },
                averageProcessingTime: {
                    total: totalAverageProcessingTime ?? 0,
                    lastMonthPercentage: averageProcessingTimeLastMonth ?? 0
                }
            };

            return { success: true, message: "New store applications analytics data fetched successfully.", data: myData };

        } catch (error) {
            console.error("Error fetching new store applications analytics:", error);
            throw new Error("An error occurred while fetching new store applications analytics data.");
        }
    },

    getProductsAnalytics: async (root, args, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        if (user.role !== "admin") return new AuthenticationError("Unauthorized");

        try {

            //* start date and end date of last month
            const startDateOfLastMonth = moment().utc().subtract(1, "months").startOf("month").toISOString();
            const endDateOfLastMonth = moment().utc().subtract(1, "months").endOf("month").toISOString();

            const [
                totalProducts,
                productsAddedLastMonth,
                totalActiveProducts,
                activeProductsAddedLastMonth,
                draftProducts,
                draftproductsAddedLastMonth,
                totalRevenueData,
                revenueGeneratedLastMonthData
            ] = await Promise.all([
                //* total products
                client.count({
                    index: 'products'
                }),

                client.count({
                    index: "products",
                    body: {
                        query: {
                            range: {
                                createdAt: {
                                    gte: startDateOfLastMonth,
                                    lte: endDateOfLastMonth
                                }
                            },
                        },
                    },
                }),


                //* total active products
                client.count({
                    index: 'products',
                    body: {
                        query: {
                            term: {
                                status: {
                                    value: "Active"
                                }
                            }
                        },
                    }
                }),

                client.count({
                    index: "products",
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        range: {
                                            createdAt: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    },
                                    {
                                        term: {
                                            status: {
                                                value: "Active"
                                            }
                                        }
                                    }
                                ],
                            },
                        },
                    },
                }),


                //* total drafts products
                client.count({
                    index: 'products',
                    body: {
                        query: {
                            term: {
                                status: {
                                    value: "Draft"
                                }
                            }
                        },
                    }
                }),

                client.count({
                    index: "products",
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        range: {
                                            createdAt: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    },
                                    {
                                        term: {
                                            status: {
                                                value: "Draft"
                                            }
                                        }
                                    }
                                ],
                            },
                        },
                    },
                }),


                //* total revenue
                client.search({
                    index: 'order_items',
                    body: {
                        query: {
                            term: {
                                order_status: {
                                    value: 'delivered'
                                }
                            }
                        },
                        aggs: {
                            totalRevenue: {
                                sum: {
                                    field: 'totalAmount'
                                },
                            },
                        },
                        size: 0,
                    }
                }),


                client.search({
                    index: 'order_items',
                    body: {
                        query: {
                            term: {
                                order_status: {
                                    value: 'delivered'
                                }
                            }
                        },
                        aggs: {
                            totalRevenue: {
                                sum: {
                                    field: 'totalAmount'
                                },
                            },
                        },
                        size: 0,
                    },
                })
            ]);


            //* Total revenue and last month revenue
            const totalRevenue = totalRevenueData?.aggregations?.totalRevenue?.value;
            const revenueGeneratedLastMonth = revenueGeneratedLastMonthData?.aggregations?.totalRevenue?.value;


            const myData = {
                totalProducts: {
                    total: totalProducts.count,
                    lastMonthPercentage: self.calculatePercentage(productsAddedLastMonth.count, totalProducts.count),
                },
                activeProducts: {
                    total: totalActiveProducts.count,
                    lastMonthPercentage: self.calculatePercentage(activeProductsAddedLastMonth.count, totalActiveProducts.count),
                },
                draftProducts: {
                    total: draftProducts.count,
                    lastMonthPercentage: self.calculatePercentage(draftproductsAddedLastMonth.count, draftProducts.count),
                },
                totalRevenue: {
                    total: totalRevenue,
                    lastMonthPercentage: self.calculatePercentage(revenueGeneratedLastMonth, totalRevenue),
                }
            };

            return { success: true, message: "Products analytics data fetched successfully.", data: myData };

        } catch (error) {
            console.error("Error fetching products analytics:", error);
            throw new Error("An error occurred while fetching products analytics data.");
        }
    },

    getOrdersAnalytics: async (root, args, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        if (user.role !== "admin") return new AuthenticationError("Unauthorized");

        try {

            //* start date and end date of last month
            const startDateOfLastMonth = moment().utc().subtract(1, "months").startOf("month").toISOString();
            const endDateOfLastMonth = moment().utc().subtract(1, "months").endOf("month").toISOString();

            const [
                totalOrders,
                ordersAddedLastMonth,
                totalRevenueData,
                revenueGeneratedLastMonthData,
                pendingOrders,
                pendingOrdersAddedLastMonth,
                deliveredOrders,
                deliveredOrdersAddedLastMonth
            ] = await Promise.all([
                //* total orders
                client.count({
                    index: 'order_master'
                }),

                client.count({
                    index: "order_master",
                    body: {
                        query: {
                            range: {
                                createdAt: {
                                    gte: startDateOfLastMonth,
                                    lte: endDateOfLastMonth
                                }
                            },
                        },
                    },
                }),


                //* total revenue
                client.search({
                    index: 'order_items',
                    body: {
                        query: {
                            term: {
                                order_status: {
                                    value: 'delivered'
                                }
                            }
                        },
                        aggs: {
                            totalRevenue: {
                                sum: {
                                    field: 'totalAmount'
                                },
                            },
                        },
                        size: 0,
                    }
                }),

                client.search({
                    index: 'order_items',
                    body: {
                        query: {
                            term: {
                                order_status: {
                                    value: 'delivered'
                                }
                            }
                        },
                        aggs: {
                            totalRevenue: {
                                sum: {
                                    field: 'totalAmount'
                                },
                            },
                        },
                        size: 0,
                    },
                }),


                //* pending orders
                client.count({
                    index: 'order_master',
                    body: {
                        query: {
                            term: {
                                order_status: {
                                    value: "pending"
                                }
                            }
                        },
                    }
                }),

                client.count({
                    index: "order_master",
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        range: {
                                            createdAt: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    },
                                    {
                                        term: {
                                            order_status: {
                                                value: "pending"
                                            }
                                        }
                                    }
                                ],
                            },
                        },
                    },
                }),


                //* delivered orders
                client.count({
                    index: 'order_master',
                    body: {
                        query: {
                            term: {
                                order_status: {
                                    value: "delivered"
                                }
                            }
                        },
                    }
                }),

                client.count({
                    index: "order_master",
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        range: {
                                            createdAt: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    },
                                    {
                                        term: {
                                            order_status: {
                                                value: "delivered"
                                            }
                                        }
                                    }
                                ],
                            },
                        },
                    },
                }),
            ]);


            //* Total revenue and last month revenue
            const totalRevenue = totalRevenueData?.aggregations?.totalRevenue?.value;
            const revenueGeneratedLastMonth = revenueGeneratedLastMonthData?.aggregations?.totalRevenue?.value;


            const myData = {
                totalOrders: {
                    total: totalOrders.count,
                    lastMonthPercentage: self.calculatePercentage(ordersAddedLastMonth.count, totalOrders.count),
                },
                totalRevenue: {
                    total: totalRevenue,
                    lastMonthPercentage: self.calculatePercentage(revenueGeneratedLastMonth, totalRevenue),
                },
                pendingOrders: {
                    total: pendingOrders.count,
                    lastMonthPercentage: self.calculatePercentage(pendingOrdersAddedLastMonth.count, pendingOrders.count),
                },
                deliveredOrders: {
                    total: deliveredOrders.count,
                    lastMonthPercentage: self.calculatePercentage(deliveredOrdersAddedLastMonth.count, deliveredOrders.count),
                }
            };

            return { success: true, message: "Orders analytics data fetched successfully.", data: myData };

        } catch (error) {
            console.error("Error fetching orders analytics:", error);
            throw new Error("An error occurred while fetching orders analytics data.");
        }
    },

    getCategoriesAnalytics: async (root, args, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        if (user.role !== "admin") return new AuthenticationError("Unauthorized");

        try {

            //* start date and end date of last month
            const startDateOfLastMonth = moment().utc().subtract(1, "months").startOf("month").toISOString();
            const endDateOfLastMonth = moment().utc().subtract(1, "months").endOf("month").toISOString();

            const [
                categories,
                categoriesAddedLastMonth,
                subCategories,
                subCategoriesAddedLastMonth,
                childSubCategories,
                childSubCategoriesAddedLastMonth,
                nestedChildSubCategories,
                nestedChildSubCategoriesAddedLastMonth,
            ] = await Promise.all([
                //* total categories
                database.Category.count(),

                database.Category.count({
                    where: {
                        createdAt: {
                            [Op.between]: [startDateOfLastMonth, endDateOfLastMonth]
                        }
                    }
                }),


                //* sub categories
                database.Subcategory.count(),

                database.Subcategory.count({
                    where: {
                        createdAt: {
                            [Op.between]: [startDateOfLastMonth, endDateOfLastMonth]
                        }
                    }
                }),


                //* child sub categories
                database.Childsubcategory.count(),

                database.Childsubcategory.count({
                    where: {
                        createdAt: {
                            [Op.between]: [startDateOfLastMonth, endDateOfLastMonth]
                        }
                    }
                }),


                //* nested child sub categories
                database.NestedChildSubcategory.count(),

                database.NestedChildSubcategory.count({
                    where: {
                        createdAt: {
                            [Op.between]: [startDateOfLastMonth, endDateOfLastMonth]
                        }
                    }
                }),
            ]);


            const myData = {
                categories: {
                    total: categories,
                    lastMonthPercentage: categoriesAddedLastMonth,
                },
                subCategories: {
                    total: subCategories,
                    lastMonthPercentage: subCategoriesAddedLastMonth,
                },
                childSubCategories: {
                    total: childSubCategories,
                    lastMonthPercentage: childSubCategoriesAddedLastMonth,
                },
                nestedChildSubCategories: {
                    total: nestedChildSubCategories,
                    lastMonthPercentage: nestedChildSubCategoriesAddedLastMonth,
                }
            };

            return { success: true, message: "Categories analytics data fetched successfully.", data: myData };
        } catch (error) {
            console.error("Error fetching categories analytics:", error);
            throw new Error("An error occurred while fetching categories analytics data.");
        }
    },

    getClubsAnalytics: async (root, args, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        if (user.role !== "admin") return new AuthenticationError("Unauthorized");
        try {

            //* start date and end date of last month
            const startDateOfLastMonth = moment().utc().subtract(1, "months").startOf("month").toISOString();
            const endDateOfLastMonth = moment().utc().subtract(1, "months").endOf("month").toISOString();

            const [
                totalClubs,
                clubsAddedLastMonth,
                activeClubs,
                activeClubsAddedLastMonth,
                totalMembers,
                totalMembersAddedLastMonth,
                //  deliveredOrders,
                //  deliveredOrdersAddedLastMonth
            ] = await Promise.all([
                //* total clubs
                client.count({
                    index: 'group'
                }),

                client.count({
                    index: "group",
                    body: {
                        query: {
                            range: {
                                createdAt: {
                                    gte: startDateOfLastMonth,
                                    lte: endDateOfLastMonth
                                }
                            },
                        },
                    },
                }),


                //* active clubs
                client.count({
                    index: 'group',
                    body: {
                        query: {
                            term: {
                                isActive: {
                                    value: true
                                }
                            }
                        },
                    }
                }),

                client.count({
                    index: 'group',
                    body: {
                        query: {
                            bool: {
                                must: [
                                    {
                                        range: {
                                            createdAt: {
                                                gte: startDateOfLastMonth,
                                                lte: endDateOfLastMonth
                                            }
                                        },
                                    },
                                    {
                                        term: {
                                            isActive: {
                                                value: true
                                            }
                                        }

                                    },
                                ]
                            }
                        },
                    },
                }),


                //* total members
                client.count({
                    index: 'join-group',
                }),

                client.count({
                    index: "join-group",
                    body: {
                        query: {
                            range: {
                                createdAt: {
                                    gte: startDateOfLastMonth,
                                    lte: endDateOfLastMonth
                                }
                            },
                        },
                    },
                }),


                //  //* average engagement time in percentage
                //  client.count({
                //      index: 'order_master',
                //      body: {
                //          query: {
                //              term: {
                //                  order_status: {
                //                      value: "delivered"
                //                  }
                //              }
                //          },
                //      }
                //  }),

                //  client.count({
                //      index: "order_master",
                //      body: {
                //          query: {
                //              bool: {
                //                  must: [
                //                      {
                //                          range: {
                //                              createdAt: {
                //                                  gte: startDateOfLastMonth,
                //                                  lte: endDateOfLastMonth
                //                              }
                //                          },
                //                      },
                //                      {
                //                          term: {
                //                              order_status: {
                //                                  value: "delivered"
                //                              }
                //                          }
                //                      }
                //                  ],
                //              },
                //          },
                //      },
                //  }),
            ]);



            const myData = {
                totalClubs: {
                    total: totalClubs.count,
                    lastMonthPercentage: clubsAddedLastMonth.count,
                },
                activeClubs: {
                    total: activeClubs.count,
                    lastMonthPercentage: self.calculatePercentage(activeClubsAddedLastMonth.count, activeClubs.count),
                },
                totalMembers: {
                    total: totalMembers.count,
                    lastMonthPercentage: totalMembersAddedLastMonth.count,
                },
                averageEngagement: {
                    total: 0,
                    lastMonthPercentage: 0,
                    // total: averageEngagement ?? 0,
                    // lastMonthPercentage: averageEngagementDIfferenceLastMonth ?? 0,
                }
            };

            return { success: true, message: "Clubs analytics data fetched successfully.", data: myData };

        } catch (error) {
            console.error("Error fetching clubs analytics data:", error);
            throw new Error("An error occurred while fetching clubs analytics data.");

        }
    },

    getClubAnalyticsBySlug: async (root, { slug }, { user }) => {
        if (!user) return new AuthenticationError("Please Provide the token");
        if (user.role !== "admin") return new AuthenticationError("Unauthorized");

        try {
            // start date of current month and today's date
            const startDateOfCurrentMonth = moment().utc().startOf("month").toISOString();
            const today = moment().utc().toISOString();


            //* start date and end date of last month
            const startDateOfLastMonth = moment().utc().subtract(1, "months").startOf("month").toISOString();
            const endDateOfLastMonth = moment().utc().subtract(1, "months").endOf("month").toISOString();

            const groupId = await client.search({
                index: "group",
                query: {
                    term: {
                        slug: {
                            value: slug
                        }
                    }
                }
            });

            if (!groupId?.hits?.hits.length) {
                return {
                    success: false,
                    message: "Club not found."
                }
            }

            const group_id = groupId?.hits?.hits[0]?._source?.id;

            const [posts, members] = await Promise.all([
                // for average posts
                client.search({
                    index: "post",
                    size: 0,
                    body: {
                        query: {
                            term: {
                                group_id: {
                                    value: group_id
                                }
                            },
                        },
                        aggs: {
                            current_month: {
                                filter: {
                                    range: {
                                        createdAt: {
                                            gte: startDateOfCurrentMonth,
                                            lte: today
                                        },
                                    },
                                },
                                aggs: {
                                    daily_posts: {
                                        date_histogram: {
                                            field: 'createdAt',
                                            calendar_interval: 'day',
                                        },
                                    },
                                    average_posts: {
                                        avg_bucket: {
                                            buckets_path: 'daily_posts._count',
                                        },
                                    },
                                },
                            },
                            previous_month: {
                                filter: {
                                    range: {
                                        createdAt: {
                                            gte: startDateOfLastMonth,
                                            lte: endDateOfLastMonth
                                        },
                                    },
                                },
                                aggs: {
                                    daily_posts: {
                                        date_histogram: {
                                            field: 'createdAt',
                                            calendar_interval: 'day',
                                        },
                                    },
                                    average_posts: {
                                        avg_bucket: {
                                            buckets_path: 'daily_posts._count',
                                        },
                                    },
                                },
                            },
                        },
                    },
                }),

                // for member growth
                client.search({
                    index: "join-group",
                    size: 0,
                    body: {
                        query: {
                            term: {
                                group_id: {
                                    value: group_id
                                }
                            },
                        },
                        aggs: {
                            current_month: {
                                filter: {
                                    range: {
                                        createdAt: {
                                            gte: startDateOfCurrentMonth,
                                            lte: today,
                                        },
                                    },
                                },
                                aggs: {
                                    daily_joins: {
                                        date_histogram: {
                                            field: 'createdAt',
                                            calendar_interval: 'day',
                                        },
                                    },
                                    average_joins: {
                                        avg_bucket: {
                                            buckets_path: 'daily_joins._count',
                                        },
                                    },
                                },
                            },
                            previous_month: {
                                filter: {
                                    range: {
                                        createdAt: {
                                            gte: startDateOfLastMonth,
                                            lte: endDateOfLastMonth,
                                        },
                                    },
                                },
                                aggs: {
                                    daily_joins: {
                                        date_histogram: {
                                            field: 'createdAt',
                                            calendar_interval: 'day',
                                        },
                                    },
                                    average_joins: {
                                        avg_bucket: {
                                            buckets_path: 'daily_joins._count',
                                        },
                                    },
                                },
                            },
                        },
                    },
                })


            ]);

            const currentAveragePosts = posts?.aggregations?.current_month?.average_posts?.value ?? 0;
            const previousAveragePosts = posts?.aggregations?.previous_month?.average_posts?.value ?? 0;

            const currentAverageMembers = members?.aggregations?.current_month?.daily_joins?.value ?? 0;
            const previousAverageMembers = members?.aggregations?.previous_month?.daily_joins?.value ?? 0;

            const percentageChangeForPosts = previousAveragePosts
                ? ((currentAveragePosts - previousAveragePosts) / previousAveragePosts) * 100
                : 0;

            const percentageChangeForMembers = previousAverageMembers
                ? ((currentAverageMembers - previousAverageMembers) / previousAverageMembers) * 100
                : 0;

            const myData = {
                avgPosts: {
                    total: Number(currentAveragePosts.toFixed(2)),
                    lastMonthPercentage: Number(percentageChangeForPosts.toFixed(2)),
                },
                memberGrowth: {
                    total: Math.round(currentAverageMembers ?? 0),
                    lastMonthPercentage: Math.round(percentageChangeForMembers ?? 0)
                },
                engagementRate: {
                    total: 0,
                    lastMonthPercentage: 0
                }
            }

            return {
                success: true,
                message: "The club analytics by slug fetched successfully.",
                data: myData

            }
        } catch (error) {
            console.error("Error fetching the club analytics by slug:", error);
            throw new Error("An error occurred while fetching the club analytics by slug.");

        }
    },

    calculatePercentage: (partial, total) => {
        return total > 0 ? Math.round((partial / total) * 100) : 0;
    }

};