
const database = require("../../../database/models");
module.exports = {
    getAllUserLocationHistory: async (root, args, { user }) => {
        if (user != null) {
            const userLocationActivity = await database.UserLocationActivity.findAll({ where: { user_id: user.id } });
            return { success: true, message: "fetched all user location activities", data: userLocationActivity };
        } else {
            return { success: false, message: "Please Provide Token" }
        }
    },
};