const { AuthenticationError } = require("apollo-server-express");

const BillingAddressService = require("../../../database/services/billingAddress");
module.exports = {
  getAllBillingAddress: async (root, args, { user }) => {
    if (user != null) {
      const allMedia = await BillingAddressService.getAll(user.id);
      return allMedia;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
  getSingleBillingAddress: async (_, { id }, { user }) => {
    if (user != null) {
      return BillingAddressService.getById(id, user.id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
};
