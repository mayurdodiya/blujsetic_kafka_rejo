const { AuthenticationError } = require("apollo-server-express");
const { orderAnalyticsOfSeller, calculatePercentageChange, order_number_generator } = require("../../../utils/utils");
const DB = require("../../../database/models");
const { Op } = require("sequelize");
const moment = require("moment");
const client = require("../../../services/elasticsearch/config/config");





module.exports = {
    getOrderAnalyticsForSeller: async (root, {}, { user }) => {
        try {
            if (!user) {
                return new AuthenticationError("Please Provide the token");
            }

            const seller_id = user?.seller_id;
            if (!seller_id) {
                return new AuthenticationError("Please Provide the seller_id");
            }

             //* start date and end date of last month
             const startDateOfLastMonth = moment().subtract(1, "months").startOf("month").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
             const endDateOfLastMonth = moment().subtract(1, "months").endOf("month").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");

            //* start date and current dateTime of current month
            const startDateOfCurrentMonth = moment().startOf("month").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");
            const endDateOfCurrentMonth = moment().endOf("month").format("YYYY-MM-DD[T]HH:mm:ss.SSS[Z]");

            const [
                totalOrders,
                totalOrdersOfThisMonth,
                totalOrdersOfLastMonth,
                totalPendingOrders,
                pendingOrdersThisMonth,
                pendingOrdersOfLastMonth,
                totalCompletedOrders,
                completedOrdersThisMonth,
                completedOrdersOfLastMonth,
                totalCancelledOrders,
                cancelledOrdersThisMonth,
                cancelledOrdersOfLastMonth,
             ] = await Promise.all([
                //* total orders
                client.count({
                    index: "order_items",
                    body: {
                      query: {
                        bool: {
                          must: [
                            { term: { seller_id: seller_id } },
                          ],
                        }
                      }
                    }
                  }),

                  //* orders received this month
                client.count({
                    index: "order_items",
                    body: {
                      query: {
                        bool: {
                          must: [
                            { term: { seller_id: seller_id } },
                            { 
                                range: {
                                    createdAt: {
                                        gte: startDateOfCurrentMonth,
                                        lte: endDateOfCurrentMonth
                                    }
                                }
                            }
                          ],
                        }
                      }
                    }
                  }),

                  //* orders received last month
                client.count({
                    index: "order_items",
                    body: {
                      query: {
                        bool: {
                          must: [
                            { term: { seller_id: seller_id } },
                            { 
                                range: {
                                    createdAt: {
                                        gte: startDateOfLastMonth,
                                        lte: endDateOfLastMonth
                                    }
                                }
                            }
                          ],
                        }
                      }
                    }
                  }),


                //* total pending orders
                client.count({
                    index: "order_items",
                    body: {
                      query: {
                        bool: {
                          must: [
                            { term: { seller_id: seller_id } },
                            { term: { order_status: "pending" } },
                        ],
                    }
                      }
                    }
                  }),

                  //* orders pending this month
                client.count({
                    index: "order_items",
                    body: {
                      query: {
                        bool: {
                            must: [
                            { term: { seller_id: seller_id } },
                              { term: { order_status: "pending" } },
                              { 
                                  range: {
                                    createdAt: {
                                        gte: startDateOfCurrentMonth,
                                        lte: endDateOfCurrentMonth
                                    }
                                }
                            }
                          ],
                        }
                      }
                    }
                  }),

                  //* orders pending last month
                client.count({
                    index: "order_items",
                    body: {
                      query: {
                        bool: {
                          must: [
                            { term: { seller_id: seller_id } },
                                    { term: { order_status: "pending" } },
                            { 
                                range: {
                                    createdAt: {
                                        gte: startDateOfLastMonth,
                                        lte: endDateOfLastMonth
                                    }
                                }
                            }
                          ],
                        }
                      }
                    }
                  }),


                //* total completed orders
                client.count({
                    index: "order_items",
                    body: {
                      query: {
                        bool: {
                          must: [
                            { term: { seller_id: seller_id } },
                            { term: { order_status: "delivered" } },
                        ],
                    }
                      }
                    }
                  }),

                  //* orders completed this month
                client.count({
                    index: "order_items",
                    body: {
                      query: {
                        bool: {
                            must: [
                            { term: { seller_id: seller_id } },
                              { term: { order_status: "delivered" } },
                              { 
                                  range: {
                                    createdAt: {
                                        gte: startDateOfCurrentMonth,
                                        lte: endDateOfCurrentMonth
                                    }
                                }
                            }
                          ],
                        }
                      }
                    }
                  }),

                  //* orders completed last month
                client.count({
                    index: "order_items",
                    body: {
                      query: {
                        bool: {
                          must: [
                            { term: { seller_id: seller_id } },
                                    { term: { order_status: "delivered" } },
                            { 
                                range: {
                                    createdAt: {
                                        gte: startDateOfLastMonth,
                                        lte: endDateOfLastMonth
                                    }
                                }
                            }
                          ],
                        }
                      }
                    }
                  }),


                //* total cancelled orders
                client.count({
                    index: "order_items",
                    body: {
                      query: {
                        bool: {
                          must: [
                            { term: { seller_id: seller_id } },
                            { term: { order_status: "cancelled" } },
                        ],
                    }
                      }
                    }
                  }),

                  //* orders cancelled this month
                client.count({
                    index: "order_items",
                    body: {
                      query: {
                        bool: {
                            must: [
                            { term: { seller_id: seller_id } },
                              { term: { order_status: "cancelled" } },
                              { 
                                  range: {
                                    createdAt: {
                                        gte: startDateOfCurrentMonth,
                                        lte: endDateOfCurrentMonth
                                    }
                                }
                            }
                          ],
                        }
                      }
                    }
                  }),

                  //* orders cancelled last month
                client.count({
                    index: "order_items",
                    body: {
                      query: {
                        bool: {
                          must: [
                            { term: { seller_id: seller_id } },
                            { term: { order_status: "cancelled" } },
                            { 
                                range: {
                                    createdAt: {
                                        gte: startDateOfLastMonth,
                                        lte: endDateOfLastMonth
                                    }
                                }
                            }
                          ],
                        }
                      }
                    }
                  }),
            ]);



            const percentageChangeInTotalOrders = calculatePercentageChange(totalOrdersOfThisMonth.count, totalOrdersOfLastMonth.count);
            const percentageChangeInPendingOrders = calculatePercentageChange(pendingOrdersThisMonth.count, pendingOrdersOfLastMonth.count);
            const percentageChangeInCompletedOrders = calculatePercentageChange(completedOrdersThisMonth.count, completedOrdersOfLastMonth.count);
            const percentageChangeInCancelledOrders = calculatePercentageChange(cancelledOrdersThisMonth.count, cancelledOrdersOfLastMonth.count);

            return {
                message: "Order Analytics for seller fetched successfully",
                success: true,
                data: {
                    totalOrders: totalOrders.count,
                    percentageChangeInTotalOrders: percentageChangeInTotalOrders,
                    pendingOrders: totalPendingOrders.count,
                    percentageChangeInPendingOrders: percentageChangeInPendingOrders,
                    completedOrders: totalCompletedOrders.count,
                    percentageChangeInCompletedOrders: percentageChangeInCompletedOrders,
                    cancelledOrders: totalCancelledOrders.count,
                    percentageChangeInCancelledOrders: percentageChangeInCancelledOrders,
                }
            }


        } catch (error) {
            console.error("An error occured while fetching order analytics for seller: ", error);
            return {
                success: false,
                message: "An error occured while fetching order analytics for seller: "
            }
        }

    },

    getOrdersOfSeller: async (root, args, { user }) => {
        try {

            if (!user) {
                return new AuthenticationError("Please Provide the token");
            }

            const seller_id = user?.seller_id;
            if (!seller_id) {
                return new AuthenticationError("Please Provide the seller_id");
            }

            let page, offset;
            if (args?.page && args?.limit) {
              page = parseInt(args?.page) || 1;
              limit = parseInt(args?.limit) || 10;
              offset = (page - 1) * limit;
              
            }


            let search = args?.search;
            // let where = { seller_id: seller_id }

            const orders = await DB.OrderItems.findAndCountAll({
                where: {
                    seller_id,
                    ...(args?.order_status && { order_status: args?.order_status }),
                    ...(search && {
                      [Op.or]: [
                        { order_status: { [Op.iLike]: `%${search}%` } },
                        {
                          '$customer.firstName$': { [Op.iLike]: `%${search}%` }
                        },
                        {
                          '$customer.lastName$': { [Op.iLike]: `%${search}%` }
                        },
                      ],
                    })
                },
                ...(offset && { offset }),
                ...(limit && { limit }),
                attributes: ["id", "order_status", "totalAmount", "createdAt", "quantity", "product_price"],
                include: [
                    {
                        model: DB.User,
                        as: "customer",
                        attributes: ["id", "firstName", "lastName"],
                    },
                    {
                        model: DB.Product,
                        as: "product",
                        attributes: ["id", "store_id", "title", "dis_listPrice", "dis_price", "slug"],
                    },
                    {
                        model: DB.OrderMaster,
                        as: "orderMaster",
                        include: [
                            {
                                model: DB.BillingAddresses,
                                as: "shipping_detail",
                                attributes: ["streetAddress", "city", "state", "country", "zipcode", "buildingName"],
                            },
                        ],
                    },
                ],
            });

            const data = JSON.parse(JSON.stringify(orders));

            return {
              success: true,
              message: "Fetched orders of seller successfully",
              data
            }

        } catch (error) {
          console.error("An error occured while fetching orders of seller!", error);
          return {
            success: false,
            message: error?.message || "An error occured while fetching orders of seller!",
          }
        }

    },
}