const { AuthenticationError } = require("apollo-server-express");

const CardAndAddressService = require("../../../database/services/cardandbillingaddress");
module.exports = {
  getAllCardAndAddress: async (root, args, { user }) => {
    if (user != null) {
      const allMedia = await CardAndAddressService.getAll(user.id);
      return allMedia;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
  getSingleCardAndAddress: async (_, { id }, { user }) => {
    if (user != null) {
      return CardAndAddressService.getById(id, user.id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },
};
