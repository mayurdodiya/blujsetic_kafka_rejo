const { AuthenticationError } = require("apollo-server-express");

const UserService = require("../../../database/services/user");
const { Media } = require("../../../database/models");
const database = require("../../../database/models");
const Sequelize = require("sequelize");
const Op = Sequelize.Op;
const utils = require("../../../middlewares/utils");
const FriendService = require("../../../database/services/friend");
const { checkStatusesForFriend } = require("../../../utils/utils");
const jwt = require("jsonwebtoken");
const elasticClient = require("../../../services/elasticsearch");
// const logger = require("../../../utils/logger");
module.exports = {
  getAllUsersData: async (root, { id, slug }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide Token");
    const userData = await UserService.getAll(id);
    return userData;
  },

  users: async (root, args, context) => {
    const userData = await UserService.skipUsers(args.id_nin);
    return userData;
  },

  getUserbyName: async (root, args, { user }) => {
    // if (!user) {
    //   throw new AuthenticationError("Unauthenticated");
    // }

    // logger.debug(`GET EXTERNAL USER PAYMENT CONFIGURATION:`, { email: find_user_slug.email, additionalField: '1' }, { name: "jainam" });
    // logger.debug("This is a debug log", { email: "jdaisdnasdk", name: ";dasdasd" });

    let find_user_slug = await database.User.findOne({
      where: {
        userName: args?.slug,
      },
      raw: true,
    });

    try {
      if (!find_user_slug?.id) {
        return new AuthenticationError("Please Provide Valid Slug");
      }
      const userData = await UserService.getUserbyName(find_user_slug?.id, user?.id);
      // user Followers

      userData.followers = await FriendService.getMyFriends(find_user_slug.id);

      for (const res of userData.followers) {
        if (res && res.user != null) {
          //  user followers count
          let userFollowers = await FriendService.getMyFollowing(res.user.id);
          res.user.follower_count = userFollowers.length;

          //  user following  count
          let userFollowings = await FriendService.getMyFriends(res.user.id);
          res.user.following_count = userFollowings.length;

          // mutual friends

          const loginUserFriends = (
            await database.Friend.findAll({
              where: {
                user_id: find_user_slug.id,
                isFriend: true,
              },
              raw: true,
            })
          ).map((friend) => friend.friend_id);
          const memberFriends = (
            await database.Friend.findAll({
              where: {
                user_id: res.user.id,
                isFriend: true,
              },
              raw: true,
            })
          ).map((friend) => friend.friend_id);
          const mutualFriends = loginUserFriends.filter((friend) => memberFriends.includes(friend));

          // mutual friends data
          const mutualUserData = await database.User.findAll({
            where: {
              id: {
                [Op.in]: mutualFriends,
              },
            },
            raw: true,
          });

          // mutual friends profile image and cover image
          // for (const user of mutualUserData) {
          //   user.profileUrl = await database.Media.findOne({
          //     where: {
          //       id: user.profileAvtar ? user.profileAvtar[0] : 0,
          //     },
          //   }).then((res) => res.media);
          //   user.profileCoverImageUrl = await database.Media.findOne({
          //     where: {
          //       id: user.profileCoverImage ? user.profileCoverImage[0] : 0,
          //     },
          //   }).then((res) => res.media);
          // }

          res.user.mutualFriends = mutualUserData;

          // Friend Status
          res.user.isActiveForFriendStatus = await (await checkStatusesForFriend(user?.id, res.user.id)).isActiveForFriendStatus;
          res.user.isFriendForFriendStatus = await (await checkStatusesForFriend(user?.id, res.user.id)).isFriendForFriendStatus;
        } else {
          new Error("User not found");
        }
      }

      // user Following

      userData.followings = await FriendService.getMyFollowing(find_user_slug.id);

      for (const res of userData.followings) {
        if (res && res.friend != null) {
          //  user followers count
          let userFollowers = await FriendService.getMyFollowing(res.friend.id);
          res.friend.follower_count = userFollowers.length;

          //  user following  count
          let userFollowings = await FriendService.getMyFriends(res.friend.id);
          res.friend.following_count = userFollowings.length;
          // mutual friends

          const loginUserFriends = (
            await database.Friend.findAll({
              where: {
                user_id: find_user_slug.id,
                isFriend: true,
              },
              raw: true,
            })
          ).map((friend) => friend.friend_id);

          const memberFriends = (
            await database.Friend.findAll({
              where: {
                user_id: res.friend.id,
                isFriend: true,
              },
              raw: true,
            })
          ).map((friend) => friend.friend_id);

          const mutualFriends = loginUserFriends.filter((friend) => memberFriends.includes(friend));
          // mutual friends data
          const mutualUserData = await database.User.findAll({
            where: {
              id: {
                [Op.in]: mutualFriends,
              },
            },
            raw: true,
          });

          // mutual friends profile image and cover image
          // for (const user of mutualUserData) {
          //   if (user.profileAvtar && user.profileAvtar.length) {
          //     user.profileUrl = await database.Media.findOne({
          //       where: {
          //         id: user.profileAvtar ? user.profileAvtar[0] : 0,
          //       },
          //     }).then((res) => res?.media || "");
          //   }
          //   if (user.profileCoverImageUrl && user.profileCoverImageUrl.length) {
          //     user.profileCoverImageUrl = await database.Media.findOne({
          //       where: {
          //         id: user.profileCoverImage ? user.profileCoverImage[0] : 0,
          //       },
          //     }).then((res) => res?.media || "");
          //   }
          // }

          res.friend.mutualFriends = mutualUserData;

          // Friend Status
          res.friend.isActiveForFriendStatus = await (await checkStatusesForFriend(user?.id, res.friend.id)).isActiveForFriendStatus;
          res.friend.isFriendForFriendStatus = await (await checkStatusesForFriend(user?.id, res.friend.id)).isFriendForFriendStatus;
        } else {
          new Error("User not found");
        }
      }

      // user medias

      let userPost = await database.Post.findAll({
        where: {
          user_id: find_user_slug.id,
          post_for: "USER",
        },
        raw: true,
      })
        .filter((post) => post.media_id != null)
        .map((post) => post.media_id);

      // flatten array
      function flatten(arr) {
        return arr.reduce(function (flat, toFlatten) {
          return flat.concat(Array.isArray(toFlatten) ? flatten(toFlatten) : toFlatten);
        }, []);
      }

      let userMedias = flatten(userPost);
      userData.medias = await Media.findAll({
        where: {
          id: { [Op.in]: userMedias },
        },
      })
        .then((img) => img)
        .map((media) => {
          return { ...media.dataValues, url: media.dataValues.media };
        });
      return userData;
    } catch (error) {
      console.log("error++++++++++++++++++++++++++++++++++++++++++++++", error);
    }
  },

  currentUser: async (_, { input }, { user }) => {
    try {
      if (!user || user === null || user === undefined) return new AuthenticationError("Please Provide the token");

      if (user?.token_type === "seller") {
        const userData = await database.Seller.findOne({
          where: {
            id: user?.id,
          },
          include: [
            {
              model: database.User,
              as: "user",
              include: [
                {
                  model: database.BioDetail,
                  as: "bio_detail",
                },
              ],
            },
            {
              model: database.SellerBusinessDetail,
              as: "seller_business_detail",
            },
            {
              model: database.BusinessInformation,
              as: "seller_detail",
            }
          ],
        });

        // return {
        //   seller: JSON.parse(JSON.stringify(userData)),
        // };
        const seller = JSON.parse(JSON.stringify(userData));
        // console.log('seller=================',seller);

        // return 

        // let store = await database.BusinessInformation.findOne({
        //   where: {
        //     seller_id: userData?.id,
        //   },
        //   raw: true,
        // });
        // if (store) {
        //   // let sellerToken = jwt.sign({ id: seller.id, type: "seller" }, process.env.JWT_SECRET);
        //   // let storeDetail = {
        //   //   id: store?.id,
        //   //   name: store?.name,
        //   //   logo: store?.logo,
        //   //   logo_id: store?.logo_id,
        //   //   logo_image: store?.logo_image,
        //   //   banner_image: store?.banner_image,
        //   //   slug: store?.slug,
        //   //   seller_token: sellerToken,
        //   //   createdAt: store?.createdAt,
        //   //   companyLegalName: store?.companyLegalName,
        //   // };
        //   seller.user = {
        //     ...(seller?.user && { ...seller?.user }),
        //     store: seller?.seller_detail,
        //   };
        //   // userData.user.store = storeDetail;
        // }

        return {
          seller: seller,
        };
      } else {
        const userData = await database.User.findOne({
          where: {
            id: Number(user.id),
          },
          include: [
            {
              model: database.Seller,
              as: "seller",
              include: [
                {
                  model: database.SellerBusinessDetail,
                  as: "seller_business_detail",
                },
                {
                  model: database.BusinessInformation,
                  as: "seller_detail",
                }]
            },
            {
              model: database.BioDetail,
              as: "bio_detail",
            },
          ],
        });

        console.log(('userDatav==========', JSON.parse(JSON.stringify(userData))));
        if (userData.firstName != null && userData.lastName != null && userData.gender != null) {
          userData.isFirstTime = false;
        } else {
          userData.isFirstTime = true;
        }

        // get store and seller data
        let seller = await database.Seller.findOne({
          where: {
            email: userData.email,
            sellerApprovedStatusNew: "approved",
          },
          raw: true,
        });

        if (seller) {
          let store = await database.BusinessInformation.findOne({
            where: {
              seller_id: seller?.id,
            },
            raw: true,
          });
          if (store) {
            let sellerToken = jwt.sign({ id: seller.id, type: "seller" }, process.env.JWT_SECRET);
            let storeDetail = {
              ...store
            };
            userData.store = storeDetail;
          }
        }
        return { user: userData };
      }
    } catch (error) {
      console.log("Error Catch ", error);
      throw error;
    }
  },

  userAnalytics: async (_, { input }, { user }) => {
    if (!user) {
      return {
        success: false,
        message: "unauthorized",
        data: null,
      };
    }

    const userData = await UserService.getById(user?.id);
    // user Followers
    console.log("user", JSON.parse(JSON.stringify(userData)));

    let followers = await FriendService.getMyFriends(user?.id);
    console.log("followers", followers.length);
    // user Following

    let followings = await FriendService.getMyFollowing(user?.id);
    console.log("followings", followings.length);
    return {
      success: true,
      message: "User Analytics",
      data: {
        followers: followers.length,
        followings: followings.length,
        savedStore: 0,
        joinGroups: userData.joingroups.length,
        savePosts: userData.save_posts.length,
      },
    };
  },

  searchUsersWithElasticSearch: async (root, args, { user }) => {
    // if (!user) return new AuthenticationError("Please Provide the token");
    let { search, page, limit, isFollow } = args;
    let users = await elasticClient.user.searchUsersWithElasticSearch("users", { search, isFollow, page, limit, user_id: user?.id });
    if (users && users.success === false) {
      return { success: false, message: users.message, data: [] };
    }
    return { success: true, message: "Data successfully", data: users.data };
  },

  getUserSlugList: async (root, { slug, category_id, subCategory_id }, { user }) => {
    try {
      let find_user_slug = await database.User.findAll({
        attributes: ["userName"],
        raw: true,
      });
      console.log("find_user_slug", find_user_slug);
      return { success: true, message: "Fetch successfully!", data: find_user_slug };
    } catch (error) {
      console.log(error);
    }
  },

  userSignupVerification: async (root, { token }, context) => {
    // const token = jwt.sign({ id: 226, type: "user" }, process.env.JWT_SECRET, { expiresIn: "1m" });
    // console.log("token++++++++++++++++++++++++++++++++++++++", token);
    // return;

    try {
      const tokenData = await jwt.verify(token, process.env.JWT_SECRET);
      if (!tokenData || tokenData?.type === "seller") return { success: false, message: "Invalid user found" };
      let userData = await database.User.findOne({
        where: {
          id: tokenData?.id,
        },
        raw: true,
      });
      if (!userData) return { success: false, message: "User not found", isVerified: false };
      // if (userData?.isRegisterVerified) return { success: true, message: "User already Registered", isAlreadyRegistered: true, isVerified: true };
      if (userData?.isRegisterVerified) return { success: false, message: "Verification link expired", isVerified: false };
      let updateData = await database.User.update({ isRegisterVerified: true }, { where: { id: userData?.id } });
      return { success: true, message: "User Verified", isVerified: true };
    } catch (error) {
      console.log(error);
      let err = JSON.parse(JSON.stringify(error));
      if (err?.message === "jwt expired") {
        return { success: false, message: "Verification link expired", isVerified: false };
      } else {
        return { success: false, message: err?.message, isVerified: false };
      }
    }
  },

  sellerSignupVerification: async (root, { token }, context) => {
    try {
      const tokenData = await jwt.verify(token, process.env.JWT_SECRET);
      if (!tokenData || tokenData?.type !== "seller") return { success: false, message: "Invalid Seller found" };
      let userData = await database.User.findOne({
        where: {
          id: tokenData?.id,
          isSeller: true,
        },
        raw: true,
      });
      if (!userData) return { success: false, message: "Seller not found", isVerified: false };
      // if (userData?.isRegisterVerified) return { success: true, message: "User already Registered", isAlreadyRegistered: true, isVerified: true };
      if (userData?.isRegisterVerified) return { success: false, message: "Verification link expired", isVerified: false };
      let updateData = await database.User.update({ isRegisterVerified: true }, { where: { id: userData?.id } });
      return { success: true, message: "Seller Verified", isVerified: true };
    } catch (error) {
      console.log("error >>>>>>>>> \n", error);
    }
  },
};
