
const { AuthenticationError } = require("apollo-server-express");

const AboutService = require("../../../database/services/about");
module.exports = {
   getAllAbout:async(root, args, {user})=> {
    if(user != null){
    const allMedia = await AboutService.getAll();
    return allMedia;
    }else{
        return new AuthenticationError('Please Provide the token')
    }
  },
  getSingleAbout :async (_, { id }, {user}) =>  {
    if(user != null){
        return AboutService.getById(id)
    }else{
        return new AuthenticationError('Please Provide the token')
    }
},
};