
const { AuthenticationError } = require("apollo-server-express");

const FollowService = require("../../../database/services/follow");

module.exports = {
    getAllFollowDetails:async(root, args, {user})=> {
    if(user != null){
    const allFollowDetail = await FollowService.getAll();
    return allFollowDetail;
    }else{
        return new AuthenticationError('Please Provide the token')
    }
  },
  getSingleFollowDetail :async (_, { id }, {user}) =>  {
    if(user != null){
        return FollowService.getById(id)
    }else{
        return new AuthenticationError('Please Provide the token')
    }
},
};