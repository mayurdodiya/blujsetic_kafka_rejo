const { AuthenticationError } = require("apollo-server-express");

const LegalDetailsService = require("../../../database/services/LegalDetails");

module.exports = {
  getAllLegalDetails: async (root, args, { user }) => {
    if (user != null) {
      const allLegalDetailsDetail = await LegalDetailsService.getAll();
      return allLegalDetailsDetail;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getSingleLegalDetails: async (_, { id }, { user }) => {
    if (user != null) {
      return LegalDetailsService.getById(id);
    } else {
      return new AuthenticationError("Please Provide the Token");
    }
  },
};
