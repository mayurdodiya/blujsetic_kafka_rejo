const { Comment } = require("../../../database/models");
const database = require("../../../database/models");

const { AuthenticationError, ApolloError } = require("apollo-server-express");
const FriendService = require("../../../database/services/friend");
const { checkStatusesForFriend } = require("../../../utils/utils");
const elasticClient = require("../../../services/elasticsearch");
const { raw } = require("express");
module.exports = {
  getAllComments: async (root, args, context) => {
    return Comment.findAll({
      include: [
        {
          model: database.Like,
          as: "likes",
        },
      ],
    });
  },

  getCommentById: async (root, { id, comment_for }, { user }) => {
    console.log("userd++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++", user);
    if (!user) {
      return new AuthenticationError("Please Provide the token");
    }
    let where = {};
    comment_for = comment_for.toUpperCase();
    if (comment_for === "POST") {
      const post = await database.Post.findOne({ where: { id: id } });
      if (!post) return { success: false, message: "Post not found", data: null };
      where = { post_id: id };
    } else if (comment_for === "SHAREPOST") {
      const sharePost = await database.SharePost.findOne({ where: { id: id }, include: [{ model: database.Product, as: "products" }], raw: true, nest: true });
      if (!sharePost) return { success: false, message: "Share Post not found", data: null };
      where = { product_id: sharePost.products.id };
    } else if (comment_for === "PRODUCT") {
      const product = await database.Product.findOne({ where: { id: id, is_deleted: false } });
      if (!product) return { success: false, message: "Product not found", data: null };
      where = { product_id: id };
    } else {
      return { success: false, message: "Invalid comment type", data: null };
    }
    let comments = await Comment.findAll({
      where: where,
      order: [
        [{ model: database.CommentReply, as: "commentReply" }, "createdAt", "ASC"],
        [{ model: database.CommentReply, as: "commentReply" }, { model: database.Like, as: "commentReplyLike" }, "createdAt", "ASC"],
        ["createdAt", "ASC"],
      ],
      include: [
        {
          model: database.User,
          as: "user",
        },
        {
          model: database.CommentReply,
          as: "commentReply",
          include: [
            {
              model: database.User,
              as: "user",
            },
            {
              model: database.Like,
              as: "commentReplyLike",
              include: [
                {
                  model: database.User,
                  as: "user",
                },
              ],
            },
          ],
        },
        {
          model: database.Like,
          as: "likes",
          include: [
            {
              model: database.User,
              as: "user",
            },
          ],
        },
      ],
    });
    if (comments.length > 0) {
      for (const comment of comments) {
        // console.log("comment", JSON.parse(JSON.stringify(comment)));
        let user = comment.user;

        //  comment reply
        if (comment.commentReply)
          for (const reply of comment.commentReply) {
            let user = reply.user;
            // let profileAvtar = await database.Media.findOne({
            //   where: { id: user.profileAvtar },
            // });
            // let profileCoverImage = await database.Media.findOne({
            //   where: { id: user.profileCoverImage },
            // });
            reply.user = {
              id: user.id,
              firstName: user.firstName,
              lastName: user.lastName,
              logo_image: user?.logo_image,
              banner_image: user?.banner_image,
              // profileUrl: profileAvtar ? profileAvtar?.dataValues?.media : profileAvtar,
              // profileCoverImageUrl: profileCoverImage ? profileCoverImage?.dataValues?.media : profileCoverImage,
              userName: user?.userName,
            };
          }

        if (user) {
          // comment user follower

          const commentUserFollowers = await FriendService.getMyFriends(user.id);

          user.followers = commentUserFollowers;
          // comment user following
          const commentUserFollowing = await FriendService.getMyFollowing(user.id);
          user.followings = commentUserFollowing;
          // User friend status
          let { isActiveForFriendStatus, isFriendForFriendStatus } = await checkStatusesForFriend(user.id, user.id);

          user.isActiveForFriendStatus = isActiveForFriendStatus;
          user.isFriendForFriendStatus = isFriendForFriendStatus;

          // user.profileUrl = await database.Media.findOne({
          //   where: { id: Number(user?.profileAvtar[0]) },
          // }).then((res) => {
          //   return res.media;
          // });
          // user.profileCoverImageUrl = await database.Media.findOne({
          //   where: { id: Number(user?.profileCoverImage[0]) },
          // }).then((res) => {
          //   return res.media;
          // });
        }
        // user.profileAvtar = ["123"];
      }
    }
    return { success: true, message: "Comments found", data: comments, count: comments.length };
  },

  getCommentCount: async (root, { id, comment_for }, { user }) => {
    try {
      let where = {};
      comment_for = comment_for.toUpperCase();
      if (comment_for === "POST") {
        const post = await database.Post.findOne({
          where: { id: id },
          raw: true,
          attributes: ["id"],
        });
        if (!post) return { success: false, message: "Post not found", data: null };
        where = { post_id: id };
      } else if (comment_for === "SHAREPOST") {
        const sharePost = await database.SharePost.findOne({ where: { id: id }, include: [{ model: database.Product, as: "products" }], raw: true, nest: true });
        if (!sharePost) return { success: false, message: "Share Post not found", data: null };
        where = { product_id: sharePost.products.id };
      } else if (comment_for === "PRODUCT") {
        const product = await database.Product.findOne({ where: { id: id, is_deleted: false } });
        if (!product) return { success: false, message: "Product not found", data: null };
        where = { product_id: id };
      } else {
        return { success: false, message: "Invalid comment type", data: null };
      }
      let comments = await Comment.count({
        where: where,
      });
      return { count: comments };
    } catch (error) {
      console.log(error);
    }
  },

  getAllStoreCommentsChartData: async (root, args, { user }) => {
    try {
      let { comment_for, start_date, end_date, time_interval, time_zone } = args;
      if (!user || !user?.store_id  ) {
        return new AuthenticationError("Please Provide the token");
      }
      let data = await elasticClient.storeComments.getAllStoreCommentsChartData({ store_id: user?.store_id, comment_for, start_date, end_date, time_interval, time_zone });
      // console.log("data", 111111111111, data);
      return { success: true, message: "Data successfully", data };
    } catch (error) {
      console.log(error.message);
      console.log("error", error.stack);
    }
  },
};
