const { AuthenticationError } = require("apollo-server-express");
const database = require("../../../database/models/index");
const CategoryService = require("../../../database/services/category");
const { findMediaUrlFromId } = require("../../../utils/utils");
const sequelize = require("sequelize");
const redisClient = require("../../../redis/redisClient");
const async = require("async");

let q = async.queue(function ({ user, include, database_type, type, redisIndex }, callback) {
  process.nextTick(async () => {
    let get_stores_count;
    let res18;
    let where = {};
    where = {
      product_count: {
        [Op.gt]: 0,
      },
      status: "Active",
    };

    get_stores_count = await database.BusinessInformation.count({
      where: where,
    });

    res18 = await redisClient.llen(redisIndex);

    console.log("get_stores_count, res18 .>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>++++++++++++++", res18, get_stores_count);
    if (res18 !== get_stores_count) {
      // let redis_list_name = (user?.id && type === "ALL_STORE") || !user?.id ? "PUBLIC:ALL_STORES" : `USER/${user?.id}:${type}`;
      // console.log("redis_list_name++++++++++++++++++++++++++", redis_list_name);
      const res45 = await redisClient.del(redisIndex);
      try {
        let get_stores = await database.BusinessInformation.findAll({
          where: where,
          attributes: ["id", "name", "slug", "logo_image", "banner_image", "product_count", "createdAt"],
          include: include,
          order: [["createdAt", "ASC"]],
          // raw: true,
        });

        let stores = JSON.parse(JSON.stringify(get_stores));
        let storesArray = [];
        // console.log("fucntion-called++++++++++++++++++++++++++", stores);
        for (const store of stores) {
          let followers_count = await database.FollowStore.count({
            where: {
              store_id: Number(store.id),
            },
          });
          store.followers_count = followers_count;

          let like_count = await database.StoreLike.count({
            where: {
              store_id: store.id,
            },
          });
          store.like_count = like_count;

          // let start_date = moment().subtract(30, "days").toISOString();
          // let end_date = moment().toISOString();
          // let data = await storeActivity.getAllStoreActivityChartData({ store_id: store.id, start_date, end_date });
          // store.total_visitors = data?.current_total_user_reached_count;
          // store.past_visitors = data?.previous_total_user_reached_count_percentage;

          if (user?.id) {
            let isFollow = await database.FollowStore.findOne({
              where: {
                store_id: store.id,
                user_id: Number(user.id),
              },
            });
            store.isFollow = isFollow ? true : false;

            let isLike = await database.StoreLike.findOne({
              where: {
                store_id: store.id,
                user_id: Number(user.id),
              },
            });
            store.isLike = isLike ? true : false;
          } else {
            store.isLike = false;
            store.isFollow = false;
          }

          let find_product = await database.Product.findAll({
            where: {
              store_id: store.id,
            },
            limit: 5,
            attributes: ["id"],
            raw: true,
          });

          let n = find_product ? find_product?.length : 0;
          if (Boolean(find_product.length)) {
            let image = [];
            for (let i = 0; i < n; i++) {
              if (i === 5) break;
              const product = find_product[i];
              let find_product_images = await database.ProductMedia.findOne({
                where: {
                  product_id: product.id,
                },
                order: [["createdAt", "DESC"]],
                attributes: ["src"],
                raw: true,
              });
              if (find_product_images) {
                image.push(find_product_images.src);
              }
            }
            store.product_images = image;
          }
          if (database_type === "redis") {
            let add_data = await redisClient.lpush(redisIndex, JSON.stringify(store));
            console.log("adding data in Redis >>>>>>>>>>>>>>>>>>>>", add_data);
          } else {
            storesArray.push(store);
            console.log("not adding into DB pushing for response >>>>>>>>>>>>>>>>>>>>");
          }
        }
        callback();
        // await getStoreDetails(get_stores, "redis", redis_list_name, user);
      } catch (e) {
        console.log("sdfasdfdsfafdasfafdasfdasf >>>>>>>>>>", e);
      }
    }
  });
}, 1);

module.exports = {
  getAllCategoryDetail: async (root, args, { user }) => {
    try {
      const allCategoryDetail = await database.Category.findAll({
        where: {
          is_deleted: false,
        },
        attributes: ["id", "name", "description", "createdAt", "media", "banner_media", "position", "slug"],
        include: [
          {
            model: database.Subcategory,
            as: "subCategory",
            attributes: ["id", "name", "description", "createdAt", "media", "banner_media", "position", "slug"],
            include: [
              {
                model: database.Childsubcategory,
                as: "childSubCategory",
                attributes: ["id", "name", "description", "createdAt", "media", "banner_media", "position", "slug"],
                include: [
                  {
                    model: database.NestedChildSubcategory,
                    as: "nestedChildSubCategory",
                    attributes: ["id", "name", "description", "createdAt", "media", "banner_media", "position", "slug"],
                  },
                ],
              },
            ],
          },
        ],
        order: [
          ["position", "ASC"],
          [
            {
              model: database.Subcategory,
              as: "subCategory",
            },
            "position",
            "ASC",
          ],
          [
            {
              model: database.Subcategory,
              as: "subCategory",
            },
            {
              model: database.Childsubcategory,
              as: "childSubCategory",
            },
            "position",
            "ASC",
          ],
          [
            {
              model: database.Subcategory,
              as: "subCategory",
            },
            {
              model: database.Childsubcategory,
              as: "childSubCategory",
            },
            {
              model: database.NestedChildSubcategory,
              as: "nestedChildSubCategory",
            },
            "position",
            "ASC",
          ],
        ],
      });
      // console.log("getAllCategoryDetail-callled +++++++++++++++++++++++++++++++++++", JSON.stringify(allCategoryDetail));
      // console.log(JSON.parse(JSON.stringify(allCategoryDetail)));
      // for await (const cat of allCategoryDetail) {
      //   // category image
      //   cat.image = findMediaUrlFromId(cat.image);
      //   cat.bannerImage = findMediaUrlFromId(cat.bannerImage);

      //   // subcategory image
      //   for await (const sub_cat of cat.subCategory) {
      //     sub_cat.image = findMediaUrlFromId(sub_cat.image);
      //     sub_cat.bannerImage = findMediaUrlFromId(sub_cat.bannerImage);

      //     // childsubcategory image
      //     for await (const child_cat of sub_cat.childSubCategory) {
      //       child_cat.image = findMediaUrlFromId(child_cat.image);
      //       child_cat.bannerImage = findMediaUrlFromId(child_cat.bannerImage);
      //     }
      //   }
      // }
      // console.log("allCategoryDetail++++++++++++++++++", allCategoryDetail);
      return allCategoryDetail;
    } catch (error) {
      console.log(error);
    }
  },

  getSingleCategoryDetail: async (_, { id }, { user }) => {
    if (user != null) {
      return CategoryService.getById(id);
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getSingleCategory: async (_, { type, category_name, subcategory_slug, childsub_slug, nested_slug }, { user }) => {
    try {
      if (!type) {
        return new AuthenticationError("Please Provide Type");
      }
      let allCategoryDetail = [];
      let find_main_category;
      let find_sub_category;
      let find_child_category;
      let redisIndex = "";
      let category_count;
      // let res18;

      switch (type) {
        case "CATEGORY":
          allCategoryDetail = await database.Category.findAll({
            attributes: ["id", "name", "description", "createdAt", "media", "banner_media", "position", "slug"],
            order: [["position", "ASC"]],
          });
          category_count = await database.Category.count({});
          redisIndex = `CATEGORY`;
          break;
        case "SUB_CATEGORY":
          if (!category_name) {
            return { success: false, message: "Please Provide Category name" };
          }
          find_main_category = await database.Category.findOne({
            where: {
              name: category_name,
            },
            raw: true,
          });
          if (!find_main_category) {
            return { success: false, message: "Provide Valid Category" };
          }
          redisIndex = `SUB_CATEGORY/${find_main_category?.id}`;
          allCategoryDetail = await database.Subcategory.findAll({
            where: {
              category_id: find_main_category?.id,
            },
            attributes: ["id", "name", "description", "createdAt", "media", "banner_media", "position", "slug"],
            order: [["position", "ASC"]],
          });
          break;
        case "CHILD_SUB_CATEGORY":
          console.log("category_name", category_name, subcategory_slug);
          if (!category_name || !subcategory_slug) {
            return { success: false, message: "Please Provide Mandatory Fields" };
          }
          find_main_category = await database.Category.findOne({
            where: {
              name: category_name,
            },
            raw: true,
          });
          if (!find_main_category) {
            return { success: false, message: "Provide Valid Category!" };
          }
          find_sub_category = await database.Subcategory.findOne({
            where: {
              slug: subcategory_slug,
              category_id: find_main_category?.id,
            },
            raw: true,
          });
          if (!find_sub_category) {
            return { success: false, message: "Provide Valid Subcategory!" };
          }
          redisIndex = `SUB_CATEGORY/${find_main_category?.id}/${find_sub_category?.id}`;
          allCategoryDetail = await database.Childsubcategory.findAll({
            where: {
              sub_category_id: find_sub_category?.id,
              category_id: find_main_category?.id,
            },
            attributes: ["id", "name", "description", "createdAt", "media", "banner_media", "position", "slug"],
            order: [["position", "ASC"]],
          });
          break;
        case "NESTED_CHILD_CATEGORY":
          if (!category_name || !subcategory_slug || !childsub_slug) {
            return { success: false, message: "Please Provide Mandatory Fields" };
          }
          find_main_category = await database.Category.findOne({
            where: {
              name: category_name,
            },
            raw: true,
          });
          if (!find_main_category) {
            return { success: false, message: "Provide Valid Category!" };
          }
          find_sub_category = await database.Subcategory.findOne({
            where: {
              slug: subcategory_slug,
              category_id: find_main_category?.id,
            },
            raw: true,
          });
          if (!find_sub_category) {
            return { success: false, message: "Provide Valid Subcategory!" };
          }
          find_child_category = await database.Childsubcategory.findOne({
            where: {
              category_id: find_main_category?.id,
              sub_category_id: find_sub_category?.id,
              slug: childsub_slug,
            },
            raw: true,
          });
          if (!find_child_category) {
            return { success: false, message: "Provide Valid ChildSub Category!" };
          }
          redisIndex = `SUB_CATEGORY/${find_main_category?.id}/${find_sub_category?.id}/${find_child_category?.id}`;
          allCategoryDetail = await database.NestedChildSubcategory.findAll({
            where: {
              category_id: find_main_category?.id,
              sub_category_id: find_sub_category?.id,
              child_sub_category_id: find_child_category?.id,
            },
            attributes: ["id", "name", "description", "createdAt", "media", "banner_media", "position", "slug"],
            order: [["position", "ASC"]],
          });
          break;
        default:
          break;
      }
      redisIndex = `PUBLIC:ALL_CLUB`;
      let find_list = await redisClient.exists(redisIndex);
      res18 = await redisClient.llen(redisIndex);

      console.log("find_list+++++++++++++++++++++++++++++++", find_list, res18, category_count, res18 === category_count, Boolean(find_list) && res18 === category_count);

      if (Boolean(find_list) && res18 === category_count) {
        let redis_list = await redisClient.lrange(`PUBLIC:${redisIndex}`);
        for (let i = 0; i < redis_list?.length; i++) {
          let category = redis_list[i];
          storesArray.push(JSON.parse(category));
        }
        console.log("redis_list", redis_list);
      }

      console.log("find_list++++++", find_list);
      res18 = await redisClient.llen(redisIndex);
      console.log("redisIndex+++++++++++", redisIndex);

      return { success: true, message: "Fetch Successfully", data: allCategoryDetail };

      // return allCategoryDetail;
    } catch (error) {
      console.log(error);
    }
  },
};
