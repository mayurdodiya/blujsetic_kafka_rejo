const { Message, Conversation, User, Media } = require("../../../database/models");
const { Op } = require("sequelize");
const { UserInputError } = require("apollo-server");
const authChecker = require("../../../utils/authCheker");

module.exports = {
    // getAllConversationUsers: async (_, __, { user }) => {

    //     try {
    //         if (!user) throw new UserInputError('User not authenticated');
    //         console.log("USER ", JSON.parse(JSON.stringify(user)));
    //         let users = await User.findAll({
    //             where: { id: { [Op.ne]: user.id } },
    //         });
    //         const privateMessages = await Message.findAll({
    //             include: [
    //                 {
    //                     model: Conversation,
    //                     as: 'conversation',
    //                     where: {
    //                         [Op.and]: [
    //                             { type: 'private' },
    //                             {
    //                                 participants: { [Op.contains]: [user.id] },
    //                             },
    //                         ],
    //                     },
    //                     attributes: ['participants'],
    //                 },
    //                 {
    //                     model: User,
    //                     as: 'user',
    //                     attributes: ['firstName', 'id'],
    //                 }
    //             ],
    //             order: [['createdAt', 'DESC']],
    //         });
    //         console.log("privateMessages ", JSON.parse(JSON.stringify(privateMessages)));

    //         users = users.map((user) => {
    //             const latestMessage = privateMessages.find((p) => {
    //                 console.log("p.conversation.participants", p.conversation.participants, user.id);
    //                 return p.conversation.participants.includes(user.id)
    //             }
    //             );
    //             user.latestMessage = latestMessage;
    //             return user;
    //         });

    //         return users;
    //     } catch (err) {
    //         throw new UserInputError(err);
    //     }
    // },

    getAllConversationUsers: async (_, __, { user }) => {
        try {
            if (!user) throw new UserInputError('User not authenticated');
            const privateMessages = await Conversation.findAll({
                where: {
                    [Op.and]: [
                        { type: 'private' },
                        {
                            participants: { [Op.contains]: [user.id] },
                        },
                    ],
                },
                order: [['createdAt', 'DESC']],
            });

            let userIds = privateMessages.map((p) => {
                return p.participants.includes(user.id) && p.participants.filter((p) => p !== user.id)[0]
            }
            );
            let users = await User.findAll({
                where: { id: { [Op.in]: userIds } },
            });
            users = JSON.parse(JSON.stringify(users)).map((user) => {
                const getImages = async (ids) => {
                    const medias = await Media.findAll({
                        where: {
                            [Op.and]: [
                                { id: { [Op.in]: ids } },
                            ]
                        }
                    })
                    return medias.map((m) => m.media);
                }
                user.profileAvtar = user.profileAvtar && user.profileAvtar.length > 0 ? getImages(user.profileAvtar) : []
                return user;
            })
            return users;
        } catch (err) {
            throw new UserInputError(err);
        }
    },
    getPrivateMessages: async (_, args, { user }) => {
        const { userId } = args;

        try {
            const existUser = await User.findOne({ where: { id: userId } });

            if (!existUser) {
                throw new UserInputError(
                    `User with id: ${userId} does not exist in DB.`
                );
            }

            let messages = await Message.findAll({
                include: [
                    {
                        model: Conversation,
                        as: "conversation",
                        where: {
                            [Op.and]: [
                                { type: "private" },
                                {
                                    participants: { [Op.contains]: [user.id, userId] },
                                },
                            ],
                        },
                        attributes: [],
                    },
                    {
                        model: User,
                        as: "user",
                        attributes: ["firstName", "id", "userName"],
                    },
                ],
                order: [["createdAt", "ASC"]],
            });
            messages = JSON.parse(JSON.stringify(messages)).map((message) => {
                return { ...message, user: { id: message.user.id, username: message.user.firstName } }
            })
            console.log(messages);
            return messages;
        } catch (err) {
            console.log(err);
            throw new UserInputError(err);
        }
    },
    getGlobalMessages: async () => {
        try {
            const globalConversation = await Conversation.findOne({
                where: { type: "public" },
            });

            if (!globalConversation) {
                throw new UserInputError(`Global Chat group does not exist.`);
            }

            const messages = await Message.findAll({
                include: [
                    {
                        model: Conversation,
                        as: "conversation",
                        where: {
                            type: "public",
                        },
                        attributes: [],
                    },
                    {
                        model: User,
                        as: "user",
                        attributes: ["username", "id"],
                    },
                ],
                order: [["createdAt", "ASC"]],
            });

            return messages;
        } catch (err) {
            throw new UserInputError(err);
        }
    },
};
