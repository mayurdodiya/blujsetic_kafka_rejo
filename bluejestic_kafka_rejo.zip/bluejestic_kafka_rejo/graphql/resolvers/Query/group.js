const { AuthenticationError } = require("apollo-server-express");

const GroupService = require("../../../database/services/group");
const { Media, JoinGroup, User, Friend } = require("../../../database/models");
const { stringToUrl } = require("../../../middlewares/utils");
const { checkStatusesForFriend } = require("../../../utils/utils");
const FriendService = require("../../../database/services/friend");
const database = require("../../../database/models");
const elasticClient = require("../../../services/elasticsearch");
const { Op, where } = require("sequelize");
const redisClient = require("../../../redis/redisClient");
const async = require("async");
const client = require("../../../services/elasticsearch/config/config");
const moment = require("moment");

let q = async.queue(function ({ user, database_type, type, redisIndex }, callback) {
  process.nextTick(async () => {
    let get_stores_count;
    let res18;
    let where = {};
    // switch (type) {
    //   case "JOIN_CLUBS":
    //     groupJoinedIds = await database.JoinGroup.findAll({
    //       where: {
    //         user_id: user?.id,
    //       },
    //       attributes: ["group_id"],
    //       raw: true,
    //     });
    //     only_id = groupJoinedIds.map((group) => group.group_id);
    //     where = { id: { [Op.in]: only_id } };
    //     get_stores_count = await database.Group.count({
    //       where: where,
    //     });
    //     redisIndex = `USER/${user?.id}:${type}`;
    //     res18 = await redisClient.llen(redisIndex);
    //     break;
    //   case "CLUBS_YOU_MANAGE":
    //     groupJoinedIds = await database.JoinGroup.findAll({
    //       where: {
    //         user_id: user?.id,
    //         [Op.or]: [{ isAdmin: true }, { isOwner: true }],
    //       },
    //       attributes: ["group_id"],
    //       raw: true,
    //     });
    //     only_id = groupJoinedIds.map((group) => group.group_id);
    //     where = {
    //       id: { [Op.in]: only_id },
    //     };
    //     get_stores_count = await database.Group.count({
    //       where: where,
    //     });
    //     redisIndex = `USER/${user?.id}:${type}`;
    //     res18 = await redisClient.llen(redisIndex);
    //     break;
    //   case "SUGGESTED_CLUBS":
    //     groupJoinedIds = await database.JoinGroup.findAll({
    //       where: {
    //         user_id: user?.id,
    //       },
    //       raw: true,
    //       attributes: ["group_id"],
    //     });
    //     only_id = groupJoinedIds.map((group) => group.group_id);
    //     where = {
    //       id: { [Op.not]: only_id },
    //     };
    //     get_stores_count = await database.Group.count({
    //       where: where,
    //     });
    //     redisIndex = `USER/${user?.id}:${type}`;
    //     res18 = await redisClient.llen(redisIndex);
    //     break;
    //   case "ALL_CLUB":
    //     get_stores_count = await database.Group.count({
    //       where: where,
    //     });
    //     redisIndex = `PUBLIC:ALL_CLUB`;
    //     res18 = await redisClient.llen(redisIndex);
    //     break;
    //   default:
    //     break;
    // }

    get_stores_count = await database.Group.count({
      where: where,
    });
    res18 = await redisClient.llen(redisIndex);

    if (res18 !== get_stores_count) {
      // let redis_list_name = (user?.id && type === "ALL_STORE") || !user?.id ? "PUBLIC:ALL_STORES" : `USER/${user?.id}:${type}`;
      // console.log("redis_list_name++++++++++++++++++++++++++", redis_list_name);
      const res45 = await redisClient.del(redisIndex);
      try {
        // let get_stores = await database.BusinessInformation.findAll({
        //   where: where,
        //   attributes: ["id", "name", "slug", "logo_image", "banner_image", "product_count"],
        //   include: include,
        //   order: [["createdAt", "ASC"]],
        //   // raw: true,
        // });

        let get_stores = await database.Group.findAll({
          where: where,
          order: [["createdAt", "desc"]],
          attributes: ["id", "name", "slug", "privacy", "logo_image", "banner_image"],
        });

        let getAllGroups = JSON.parse(JSON.stringify(get_stores));
        for (let i = 0; i < getAllGroups.length; i++) {
          let group = getAllGroups[i];

          const total_members = await database.JoinGroup.count({
            where: {
              group_id: group.id,
            },
          });
          group.total_members = total_members;

          let groupUser;
          if (user?.id) {
            groupUser = await database.JoinGroup.findOne({
              where: {
                user_id: user?.id,
                group_id: group.id,
              },
              attributes: ["id"],
            });
            group.isExist = groupUser ? true : false;
          } else {
            group.isExist = false;
          }

          let group_data = await JoinGroup.findAll({
            order: [["createdAt", "desc"]],
            where: {
              group_id: group.id,
            },
            limit: 3,
            raw: true,
          });
          let group_member_array = [];
          for (const group_member of group_data) {
            const limitedMembers = await database.User.findOne({
              where: {
                id: group_member?.user_id,
              },
              attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "userName"],
              raw: true,
            });
            group_member_array.push({ ...limitedMembers });
          }
          group.members = group_member_array;

          if (database_type === "redis") {
            let add_data = await redisClient.lpush(redisIndex, JSON.stringify(group));
            console.log("adding data in Redis >>>>>>>>>>>>>>>>>>>>", add_data);
          } else {
            storesArray.push(group);
            console.log("not adding into DB pushing for response >>>>>>>>>>>>>>>>>>>>");
          }
        }
        callback();
        // return;
      } catch (e) {
        console.log("sdfasdfdsfafdasfafdasfdasf >>>>>>>>>>", e);
      }
    }
  });
}, 1);

q.drain(function () {
  console.log("All tasks have been processed");
});

const userQueues = new Map();

function handleRequest(requestData) {
  return new Promise((resolve, reject) => {
    if (!userQueues.has(requestData?.user?.id)) {
      userQueues.set(
        requestData?.user?.id,
        async.queue((taskData, callback) => {
          // Removed async keyword here
          // Process the task here
          processRequest(taskData)
            .then((result) => {
              // console.log("result+++++++++++++", result);
              callback(null, result);
            })
            .catch((error) => callback(error));
        })
      );
    }

    userQueues.get(requestData?.user?.id).push(requestData, (error, result) => {
      if (error) {
        console.log("error ======================================", error);
        reject(error);
      } else {
        resolve(result);
      }
    });
  });
}

async function processRequest({ user, database_type, type, redisIndex }) {
  // JOIN_CLUBS
  // CLUBS_YOU_MANAGE
  // SUGGESTED_CLUBS
  // ALL_CLUB
  process.nextTick(async () => {
    let get_stores_count;
    let res18;
    let where = {};
    switch (type) {
      case "JOIN_CLUBS":
        groupJoinedIds = await database.JoinGroup.findAll({
          where: {
            user_id: user?.id,
          },
          attributes: ["group_id"],
          raw: true,
        });
        only_id = groupJoinedIds.map((group) => group.group_id);
        where = { id: { [Op.in]: only_id } };
        get_stores_count = await database.Group.count({
          where: where,
        });
        redisIndex = `USER/${user?.id}:${type}`;
        res18 = await redisClient.llen(redisIndex);
        break;
      case "CLUBS_YOU_MANAGE":
        groupJoinedIds = await database.JoinGroup.findAll({
          where: {
            user_id: user?.id,
            [Op.or]: [{ isAdmin: true }, { isOwner: true }],
          },
          attributes: ["group_id"],
          raw: true,
        });
        only_id = groupJoinedIds.map((group) => group.group_id);
        where = {
          id: { [Op.in]: only_id },
        };
        get_stores_count = await database.Group.count({
          where: where,
        });
        redisIndex = `USER/${user?.id}:${type}`;
        res18 = await redisClient.llen(redisIndex);
        break;
      case "SUGGESTED_CLUBS":
        groupJoinedIds = await database.JoinGroup.findAll({
          where: {
            user_id: user?.id,
          },
          raw: true,
          attributes: ["group_id"],
        });
        only_id = groupJoinedIds.map((group) => group.group_id);
        where = {
          id: { [Op.not]: only_id },
        };
        get_stores_count = await database.Group.count({
          where: where,
        });
        redisIndex = `USER/${user?.id}:${type}`;
        res18 = await redisClient.llen(redisIndex);
        break;
      case "ALL_CLUB":
        get_stores_count = await database.Group.count({
          where: where,
        });
        redisIndex = `USER/${user?.id}:${type}`;
        res18 = await redisClient.llen(redisIndex);
        break;
      default:
        break;
    }

    if (res18 !== get_stores_count) {
      // let redis_list_name = (user?.id && type === "ALL_STORE") || !user?.id ? "PUBLIC:ALL_STORES" : `USER/${user?.id}:${type}`;
      // console.log("redis_list_name++++++++++++++++++++++++++", redis_list_name);
      const res45 = await redisClient.del(redisIndex);
      try {
        // let get_stores = await database.BusinessInformation.findAll({
        //   where: where,
        //   attributes: ["id", "name", "slug", "logo_image", "banner_image", "product_count"],
        //   include: include,
        //   order: [["createdAt", "ASC"]],
        //   // raw: true,
        // });

        let get_stores = await database.Group.findAll({
          where: where,
          order: [["createdAt", "desc"]],
          attributes: ["id", "name", "slug", "privacy", "logo_image", "banner_image"],
          // limit: limit,
          // offset: offset,
        });

        let getAllGroups = JSON.parse(JSON.stringify(get_stores));
        for (let i = 0; i < getAllGroups.length; i++) {
          let group = getAllGroups[i];

          const total_members = await database.JoinGroup.count({
            where: {
              group_id: group.id,
            },
          });
          group.total_members = total_members;

          let groupUser;
          if (user?.id) {
            groupUser = await database.JoinGroup.findOne({
              where: {
                user_id: user?.id,
                group_id: group.id,
              },
              attributes: ["id"],
            });
            group.isExist = groupUser ? true : false;
          } else {
            group.isExist = false;
          }

          let group_data = await JoinGroup.findAll({
            order: [["createdAt", "desc"]],
            where: {
              group_id: group.id,
            },
            limit: 3,
            raw: true,
          });
          let group_member_array = [];
          for (const group_member of group_data) {
            const limitedMembers = await database.User.findOne({
              where: {
                id: group_member?.user_id,
              },
              attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "userName"],
              raw: true,
            });
            group_member_array.push({ ...limitedMembers });
          }
          group.members = group_member_array;

          if (database_type === "redis") {
            let add_data = await redisClient.lpush(redisIndex, JSON.stringify(group));
            console.log("adding data in Redis >>>>>>>>>>>>>>>>>>>>", add_data);
          } else {
            storesArray.push(group);
            console.log("not adding into DB pushing for response >>>>>>>>>>>>>>>>>>>>");
          }
        }
        return;
      } catch (e) {
        console.log("sdfasdfdsfafdasfafdasfdasf >>>>>>>>>>", e);
      }
    }
  });
}

module.exports = {
  group: async (root, args, { user }) => {
    const getIndividualGroup = await GroupService.getById(args.slug);
    let groupUser;
    if (user?.id) {
      groupUser = await JoinGroup.findOne({
        where: {
          user_id: user.id,
          group_id: getIndividualGroup.id,
        },
        attributes: ["id"],
      });
      getIndividualGroup.isExist = groupUser ? true : false;
    } else {
      getIndividualGroup.isExist = false;
    }
    return getIndividualGroup;
  },

  getGroupMember: async (root, args, { user }) => {
    try {
      const getIndividualGroup = await GroupService.getById(args?.slug);
      if (!getIndividualGroup) {
        return { success: false, message: "Club not Found!" };
      }

      async function checkStatusesForFriend(userId, friendId) {
        const friend = await Friend.findOne({
          where: {
            // user_id: userId,
            friend_id: friendId,
          },
        });
        if (friend) {
          return {
            isActiveForFriendStatus: friend?.isActive || false,
            isFriendForFriendStatus: friend?.isFriend || false,
          };
        } else {
          return {
            isActiveForFriendStatus: false,
            isFriendForFriendStatus: false,
          };
        }
      }

      const groupMembers = await JoinGroup.findAll({
        where: {
          group_id: getIndividualGroup.id,
        },
        include: [
          {
            model: User,
            as: "members",
          },
        ],
      });

      let membersPayload = [];
      for (let i = 0; i < groupMembers.length; i++) {
        const admin = groupMembers[i];
        let loginUserFriends = [];
        let memberFriends = [];

        // set the friends status of Admins

        let { isActiveForFriendStatus, isFriendForFriendStatus } = await checkStatusesForFriend(user?.id, admin.members.id);

        admin.members.isActiveForFriendStatus = user?.id ? isActiveForFriendStatus : false;
        admin.members.isFriendForFriendStatus = user?.id ? isFriendForFriendStatus : false;

        // set the profile image of members of group
        // admin.members.profileAvtar =
        //   admin?.members?.profileAvtar != null
        //     ? await Media.findOne({
        //         where: { id: Number(admin?.members?.profileAvtar[0]) },
        //       }).then((res) => res?.media || "")
        //     : "";

        // set the cover image of members of group
        // admin.members.profileCoverImage =
        //   admin?.members?.profileCoverImage[0] != null
        //     ? await Media.findOne({
        //         where: { id: Number(admin?.members?.profileCoverImage[0]) },
        //       }).then((res) => res?.media || "")
        //     : "";
        admin.members.isAdmin = admin?.isAdmin;
        admin.members.joinedAt = moment(admin?.createdAt).utc().toISOString();
        membersPayload.push(admin.members);
        // mutual friends
        if (user?.id) {
          loginUserFriends = (
            await Friend.findAll({
              where: {
                user_id: user.id,
                isFriend: true,
              },
              raw: true,
            })
          ).map((friend) => friend.friend_id);
          memberFriends = (
            await Friend.findAll({
              where: {
                user_id: admin.members.id,
                isFriend: true,
              },
              raw: true,
            })
          ).map((friend) => friend.friend_id);
        } else {
          loginUserFriends = (
            await Friend.findAll({
              where: {
                isFriend: true,
              },
              raw: true,
            })
          ).map((friend) => friend.friend_id);
          memberFriends = (
            await Friend.findAll({
              where: {
                user_id: admin.members.id,
                isFriend: true,
              },
              raw: true,
            })
          ).map((friend) => friend.friend_id);
        }
        const mutualFriends = loginUserFriends.filter((friend) => memberFriends.includes(friend));
        admin.members.mutualFriends = mutualFriends;
        
        // Followers and Following
        const memberFollowers = await FriendService.getMyFriends(admin.members.id, user?.id);
        
        // comment user following
        const memberFollowing = await FriendService.getMyFollowing(admin.members.id, user?.id);
        admin.members.followers = memberFollowers;
        admin.members.followings = memberFollowing;
      }
      return { success: true, message: "Fetch successfully", data: membersPayload };
    } catch (error) {
      console.log("error >>>>>>>>>", error);
    }
  },

  getAllClubs: async (root, { type, page = 1, limit = 10000, isAdmin = true, user_id }, { user }) => {
    // try {
    //   if (limit && page) {
    //     var offset = (parseInt(page) - 1) * limit;
    //     limit = parseInt(limit);
    //   }
    //   let criteria = {};
    //   switch (type) {
    //     case "JOIN_CLUBS":
    //       if (user?.id) {
    //         let groupJoinedIds = await database.JoinGroup.findAll({
    //           where: {
    //             user_id: user?.id,
    //           },
    //           raw: true,
    //         });
    //         let only_id = groupJoinedIds.map((group) => group.group_id);
    //         criteria = {
    //           where: { id: { [Op.in]: only_id } },
    //         };
    //       }
    //       break;
    //     case "CLUBS_YOU_MANAGE":
    //       if (user?.id) {
    //         let groupJoinedIds = await database.JoinGroup.findAll({
    //           where: {
    //             user_id: user?.id,
    //             [Op.or]: [{ isAdmin: true }, { isOwner: true }],
    //           },
    //           raw: true,
    //         });
    //         let only_id = groupJoinedIds.map((group) => group.group_id);
    //         criteria = {
    //           where: {
    //             id: { [Op.in]: only_id },
    //           },
    //         };
    //       }
    //       break;
    //     case "SUGGESTED_CLUBS":
    //       if (user?.id) {
    //         let groupJoinedIds = await database.JoinGroup.findAll({
    //           where: {
    //             user_id: user?.id,
    //           },
    //           raw: true,
    //         });
    //         let only_id = groupJoinedIds.map((group) => group.group_id);
    //         criteria = {
    //           where: {
    //             id: { [Op.not]: only_id },
    //           },
    //         };
    //       }
    //       break;
    //     default:
    //       break;
    //   }
    //   let getAllGroups = await database.Group.findAll({ ...criteria, order: [["createdAt", "desc"]], attributes: ["id", "name", "slug", "privacy", "logo_image", "banner_image"], limit: limit, offset: offset, raw: true, nest: true });
    //   for (let i = 0; i < getAllGroups.length; i++) {
    //     let group = getAllGroups[i];

    //     const total_members = await database.JoinGroup.count({
    //       where: {
    //         group_id: group.id,
    //       },
    //     });
    //     group.total_members = total_members;

    //     let groupUser;
    //     if (user?.id) {
    //       groupUser = await database.JoinGroup.findOne({
    //         where: {
    //           user_id: user?.id,
    //           group_id: group.id,
    //         },
    //         attributes: ["id"],
    //       });
    //       group.isExist = groupUser ? true : false;
    //     }

    //     let group_data = await JoinGroup.findAll({
    //       order: [["createdAt", "desc"]],
    //       where: {
    //         group_id: group.id,
    //       },
    //       limit: 3,
    //       raw: true,
    //     });
    //     let group_member_array = [];
    //     for (const group_member of group_data) {
    //       const limitedMembers = await database.User.findOne({
    //         where: {
    //           id: group_member?.user_id,
    //         },
    //         attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "userName"],
    //         raw: true,
    //       });
    //       group_member_array.push({ ...limitedMembers });
    //     }
    //     group.members = group_member_array;
    //   }
    //   return { success: true, message: "Clubs Fetch Successfully", data: getAllGroups };
    // } catch (error) {
    //   console.error("An error occurred:", error);
    //   throw error;
    // }
    const user_pk = user?.token_type === "admin" ? user_id : user?.id;
    if (user?.token_type === "admin" && !user_id) {
      return { success: false, message: "User id is Mandatory." };
    }

    if (limit && page) {
      var offset = (parseInt(page) - 1) * limit;
      limit = parseInt(limit);
    }

    let storesArray = [];
    let get_stores_count = 0;
    let res18 = [];
    let include = [];
    let redisIndex = "";
    let where = {};
    let groupJoinedIds;
    let only_id = [];

    const chooseDatabase = async (res18, get_stores_count, redisIndex, where) => {
      console.log("res18 === get_stores_count", res18 === get_stores_count, res18, get_stores_count);
      if (res18 === get_stores_count) {
        const startIndex = (page - 1) * limit;
        const endIndex = startIndex + limit - 1;
        let redis_list = await redisClient.lrange(redisIndex, startIndex, endIndex);
        for (let i = 0; i < redis_list?.length; i++) {
          let store = redis_list[i];
          storesArray.push(JSON.parse(store));
        }
      } else {
        let get_stores = [];
        console.log("fetching from Database >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>", user?.id);

        get_stores = await database.Group.findAll({
          where: where,
          order: [["createdAt", "desc"]],
          attributes: ["id", "name", "slug", "privacy", "logo_image", "banner_image"],
          limit: limit,
          offset: offset,
          // raw: true,
          // nest: true,
        });

        await getStoreDetails(get_stores, "database", null);
      }
    };

    const getStoreDetails = async (get_stores, database_type, redis_list_name) => {
      let getAllGroups = JSON.parse(JSON.stringify(get_stores));
      for (let i = 0; i < getAllGroups.length; i++) {
        let group = getAllGroups[i];

        const total_members = await database.JoinGroup.count({
          where: {
            group_id: group.id,
          },
        });
        group.total_members = total_members;

        let groupUser;
        if (user_pk) {
          groupUser = await database.JoinGroup.findOne({
            where: {
              user_id: user_pk,
              group_id: group.id,
            },
            attributes: ["id"],
          });
          group.isExist = groupUser ? true : false;
        } else {
          group.isExist = false;
        }

        let group_data = await database.JoinGroup.findAll({
          order: [["createdAt", "desc"]],
          where: {
            group_id: group.id,
          },
          limit: 3,
          raw: true,
        });
        let group_member_array = [];
        for (const group_member of group_data) {
          const limitedMembers = await database.User.findOne({
            where: {
              id: group_member?.user_id,
            },
            attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "userName"],
            raw: true,
          });
          group_member_array.push({ ...limitedMembers });
        }
        group.members = group_member_array;

        if (database_type === "redis") {
          let add_data = await redisClient.lpush(redis_list_name, JSON.stringify(group));
          console.log("adding data in Redis >>>>>>>>>>>>>>>>>>>>", add_data);
        } else {
          storesArray.push(group);
          console.log("not adding into DB pushing for response >>>>>>>>>>>>>>>>>>>>");
        }
      }
    };
    let types = ["JOIN_CLUBS", "CLUBS_YOU_MANAGE", "SUGGESTED_CLUBS", "ALL_CLUB"];
    if (!types.includes(type)) {
      return { success: false, message: "Wrong type Provided.", data: storesArray };
    }

    if (user?.id) {
      switch (type) {
        case "JOIN_CLUBS":
          groupJoinedIds = await database.JoinGroup.findAll({
            where: {
              user_id: user_pk,
            },
            attributes: ["group_id"],
            raw: true,
          });
          only_id = groupJoinedIds.map((group) => group.group_id);
          where = { id: { [Op.in]: only_id } };
          get_stores_count = await database.Group.count({
            where: where,
          });
          redisIndex = `USER/${user_pk}:${type}`;
          res18 = await redisClient.llen(redisIndex);
          break;
        case "CLUBS_YOU_MANAGE":
          groupJoinedIds = await database.JoinGroup.findAll({
            where: {
              user_id: user_pk,
              [Op.or]: [{ isAdmin: isAdmin }, { isOwner: true }],
            },
            attributes: ["group_id"],
            raw: true,
          });
          only_id = groupJoinedIds.map((group) => group.group_id);
          where = isAdmin
            ? {
                id: { [Op.in]: only_id },
              }
            : { user_id: user_pk };
          get_stores_count = await database.Group.count({
            where: where,
          });
          console.log("get_stores_count+++++++++++++++++++++++++++++++++++++++++", get_stores_count, isAdmin, user_pk);

          redisIndex = `USER/${user_pk}:${type}`;
          res18 = await redisClient.llen(redisIndex);
          break;
        case "SUGGESTED_CLUBS":
          groupJoinedIds = await database.JoinGroup.findAll({
            where: {
              user_id: user_pk,
            },
            raw: true,
            attributes: ["group_id"],
          });
          only_id = groupJoinedIds.map((group) => group.group_id);
          where = {
            id: { [Op.not]: only_id },
          };
          get_stores_count = await database.Group.count({
            where: where,
          });
          redisIndex = `USER/${user_pk}:${type}`;
          res18 = await redisClient.llen(redisIndex);
          break;
        case "ALL_CLUB":
          get_stores_count = await database.Group.count({
            where: where,
          });
          redisIndex = `USER/${user_pk}:${type}`;
          res18 = await redisClient.llen(redisIndex);
          break;
        default:
          break;
      }
      console.log("++++++++++++++++++++++++++++++", res18, get_stores_count, redisIndex, where);
      await chooseDatabase(res18, get_stores_count, redisIndex, where);

      await handleRequest({
        user: user,
        database_type: "redis",
        type: type,
        redisIndex: redisIndex,
      });
    } else {
      console.log("<<<<<<<<<<<<<<<<<<< Called Without token >>>>>>>>>>>>>>>");
      where = {};
      get_stores_count = await database.Group.count({
        where: where,
      });
      redisIndex = `PUBLIC:ALL_CLUB`;
      const res18 = await redisClient.llen(redisIndex);
      console.log("res18++++++++++++++++++++++++++++++++++", res18);
      await chooseDatabase(res18, get_stores_count, redisIndex, where);
      q.push(
        {
          user: user,
          database_type: "redis",
          type: type,
          redisIndex: redisIndex,
        },
        function (err) {
          if (err) {
            console.error(err);
            console.log("Error processing request++++++++++++++++++++++++++");
          } else {
            console.log("Request is being processed");
          }
        }
      );
    }

    // return { success: true, message: "Data successfully", data: { stores: storesArray } };
    return { success: true, message: "Clubs Fetch Successfully", data: storesArray, count: get_stores_count };
  },

  groups: async (root, { type, limit, page }, { user }) => {
    // try {
    //   if (limit && page) {
    //     var offset = (parseInt(page) - 1) * limit;
    //     limit = parseInt(limit);
    //   }
    //   let criteria = {};
    //   switch (type) {
    //     case "JOIN_CLUBS":
    //       if (user?.id) {
    //         let groupJoinedIds = await database.JoinGroup.findAll({
    //           where: {
    //             user_id: user?.id,
    //           },
    //           raw: true,
    //         });
    //         let only_id = groupJoinedIds.map((group) => group.group_id);
    //         criteria = {
    //           where: { id: { [Op.in]: only_id } },
    //         };
    //       }
    //       break;
    //     case "CLUBS_YOU_MANAGE":
    //       if (user?.id) {
    //         let groupJoinedIds = await database.JoinGroup.findAll({
    //           where: {
    //             user_id: user?.id,
    //             [Op.or]: [{ isAdmin: true }, { isOwner: true }],
    //           },
    //           raw: true,
    //         });
    //         let only_id = groupJoinedIds.map((group) => group.group_id);
    //         criteria = {
    //           where: {
    //             id: { [Op.in]: only_id },
    //           },
    //         };
    //       }
    //       break;
    //     case "SUGGESTED_CLUBS":
    //       if (user?.id) {
    //         let groupJoinedIds = await database.JoinGroup.findAll({
    //           where: {
    //             user_id: user?.id,
    //           },
    //           raw: true,
    //         });
    //         let only_id = groupJoinedIds.map((group) => group.group_id);
    //         criteria = {
    //           where: {
    //             id: { [Op.not]: only_id },
    //           },
    //         };
    //       }
    //       break;
    //     default:
    //       break;
    //   }
    //   let getAllGroups = await database.Group.findAll({ ...criteria, order: [["createdAt", "desc"]], attributes: ["id", "name", "slug", "privacy", "logo_image", "banner_image"], limit: limit, offset: offset, raw: true, nest: true });
    //   for (let i = 0; i < getAllGroups.length; i++) {
    //     let group = getAllGroups[i];

    //     const total_members = await database.JoinGroup.count({
    //       where: {
    //         group_id: group.id,
    //       },
    //     });
    //     group.total_members = total_members;

    //     let groupUser;
    //     if (user?.id) {
    //       groupUser = await database.JoinGroup.findOne({
    //         where: {
    //           user_id: user?.id,
    //           group_id: group.id,
    //         },
    //         attributes: ["id"],
    //       });
    //       group.isExist = groupUser ? true : false;
    //     }

    //     let group_data = await JoinGroup.findAll({
    //       order: [["createdAt", "desc"]],
    //       where: {
    //         group_id: group.id,
    //       },
    //       limit: 3,
    //       raw: true,
    //     });
    //     let group_member_array = [];
    //     for (const group_member of group_data) {
    //       const limitedMembers = await database.User.findOne({
    //         where: {
    //           id: group_member?.user_id,
    //         },
    //         attributes: ["id", "firstName", "lastName", "logo_image", "banner_image", "userName"],
    //         raw: true,
    //       });
    //       group_member_array.push({ ...limitedMembers });
    //     }
    //     group.members = group_member_array;
    //   }
    //   return { success: true, message: "Clubs Fetch Successfully", data: getAllGroups };
    // } catch (error) {
    //   console.error("An error occurred:", error);
    //   throw error;
    // }
    return;
  },

  getSuggestedGroups: async (root, { isJoined, isMyGroups }, { user }) => {
    if (user != null) {
      const allGroupDetail = await GroupService.getSuggestedGroups(user.id);
      // console.log("allGroupDetail", allGroupDetail);
      let groupIds = [];
      for (let i = 0; i < allGroupDetail.length; i++) {
        const group = allGroupDetail[i];
        // console.log("group.bannerImage", group.bannerImage);
        // console.log("group.coverImage", group.coverImage);
        group.bannerImage = await Media.findOne({
          where: { id: Number(group.bannerImage) },
        }).then((res) => res?.media || "");
        group.coverImage = await Media.findOne({
          where: { id: Number(group.coverImage) },
        }).then((res) => res?.media || "");

        // console.log("group.id", group.id);
        const followGroups = await GroupService.followGroup(group.id, user.id);
        groupIds.push({ group_id: group.id, user_id: user.id });
        group.isFollow = followGroups ? true : false;

        // Find Group Members
        const groupMembers = await database.JoinGroup.findAll({
          where: {
            group_id: group.id,
          },
          include: [
            {
              model: database.User,
              as: "members",
            },
          ],
        });
        let membersPayload = [];
        for (let i = 0; i < groupMembers.length; i++) {
          const admin = groupMembers[i];
          // set the profile image of members of group
          admin.members.profileAvtar =
            admin?.members?.profileAvtar != null
              ? await database.Media.findOne({
                  where: { id: Number(admin?.members?.profileAvtar[0]) },
                }).then((res) => res?.media || "")
              : "";
          // // set the cover image of members of group
          membersPayload.push(admin.members);
        }
        group.members = membersPayload;
      }
      return allGroupDetail;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getJoinedGroups: async (root, { isJoined, isMyGroups }, { user }) => {
    if (user != null) {
      const allGroupDetail = await GroupService.getJoinedGroups(user.id);
      // console.log("allGroupDetail", allGroupDetail);
      let groupIds = [];
      for (let i = 0; i < allGroupDetail.length; i++) {
        const group = allGroupDetail[i];
        // console.log("group.bannerImage", group.bannerImage);
        // console.log("group.coverImage", group.coverImage);
        group.bannerImage = await Media.findOne({
          where: { id: Number(group.bannerImage) },
        }).then((res) => res?.media || "");
        group.coverImage = await Media.findOne({
          where: { id: Number(group.coverImage) },
        }).then((res) => res?.media || "");

        // console.log("group.id", group.id);
        const followGroups = await GroupService.followGroup(group.id, user.id);
        groupIds.push({ group_id: group.id, user_id: user.id });
        group.isFollow = followGroups ? true : false;

        // Find Group Members
        const groupMembers = await database.JoinGroup.findAll({
          where: {
            group_id: group.id,
          },
          include: [
            {
              model: database.User,
              as: "members",
            },
          ],
        });
        let membersPayload = [];
        for (let i = 0; i < groupMembers.length; i++) {
          const admin = groupMembers[i];
          // set the profile image of members of group
          admin.members.profileAvtar =
            admin?.members?.profileAvtar != null
              ? await database.Media.findOne({
                  where: { id: Number(admin?.members?.profileAvtar[0]) },
                }).then((res) => res?.media || "")
              : "";
          // // set the cover image of members of group
          membersPayload.push(admin.members);
        }
        group.members = membersPayload;
      }
      console.log("allGroupDetail", JSON.stringify(allGroupDetail));

      return allGroupDetail;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getMyGroups: async (root, { isJoined, isMyGroups }, { user }) => {
    // if (user != null) {
    console.log("getMyGroups-callled +++++++++++++++++++++++++++++++++++");
    const allGroupDetail = await GroupService.getMyGroups(user?.id);
    let groupIds = [];
    for (let i = 0; i < allGroupDetail.length; i++) {
      const group = allGroupDetail[i];
      group.bannerImage = await Media.findOne({
        where: { id: Number(group.bannerImage) },
      }).then((res) => res?.media || "");
      group.coverImage = await Media.findOne({
        where: { id: Number(group.coverImage) },
      }).then((res) => res?.media || "");

      const followGroups = await GroupService.followGroup(group.id, user?.id);
      groupIds.push({ group_id: group.id, user_id: user?.id });
      group.isFollow = user?.id ? (followGroups ? true : false) : false;

      // Find Group Members
      const groupMembers = await database.JoinGroup.findAll({
        where: {
          group_id: group.id,
        },
        include: [
          {
            model: database.User,
            as: "members",
          },
        ],
      });
      let membersPayload = [];
      for (let i = 0; i < groupMembers.length; i++) {
        const admin = groupMembers[i];
        // set the profile image of members of group
        admin.members.profileAvtar =
          admin?.members?.profileAvtar != null
            ? await database.Media.findOne({
                where: { id: Number(admin?.members?.profileAvtar[0]) },
              }).then((res) => res?.media || "")
            : "";
        // // set the cover image of members of group
        membersPayload.push(admin.members);
      }
      group.members = membersPayload;
    }

    return allGroupDetail;
  },

  groupsRequested: async (root, args, { user }) => {
    if (user != null) {
      console.log("user", user.id);
      const allGroupDetail = await GroupService.getAllGroupsRequested(user.id);
      for (let i = 0; i < allGroupDetail.length; i++) {
        const imgs = allGroupDetail[i];
        imgs.bannerImage = await Media.findOne({
          where: { id: Number(imgs.bannerImage) },
        }).then((res) => res?.media || "");
        imgs.coverImage = await Media.findOne({
          where: { id: Number(imgs.coverImage) },
        }).then((res) => res?.media || "");
      }
      return allGroupDetail;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  groupMedia: async (root, { groupId }, { user }) => {
    if (user != null) {
      const media = await GroupService.getGroupMedia(groupId);
      return media;
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  searchGroupsWithElasticSearch: async (root, args, { user }) => {
    console.log("searchGroupsWithElasticSearch-callled +++++++++++++++++++++++++++++++++++");
    let { search, page, limit } = args;
    let groups = await elasticClient.group.searchGroupsWithElasticSearch("groups", { search, page, limit, user_id: user?.id });
    if (groups && groups.success === false) {
      return { success: false, message: groups.message, data: [] };
    }
    return { success: true, message: "Data successfully", data: groups.data };
  },

  getCacheClub: async (root, args, { user }) => {
    // try {
    //   let find_group = await database.User.findAll({
    //     raw: true,
    //   });
    //   for (let i = 0; i < find_group.length; i++) {
    //     let element = find_group[i];
    //     let find_logo;
    //     let find_coverImage;
    //     if (element?.profileAvtar?.length > 0) {
    //       find_logo = await database.Media.findOne({
    //         where: {
    //           id: Number(element?.profileAvtar[0]),
    //         },
    //       });
    //     }
    //     if (element?.profileCoverImage?.length > 0) {
    //       find_coverImage = await database.Media.findOne({
    //         where: {
    //           id: Number(element?.profileCoverImage[0]),
    //         },
    //       });
    //     }
    //     let uddateStore = await database.User.update(
    //       {
    //         logo_image: find_logo ? find_logo?.media : "",
    //         banner_image: find_coverImage ? find_coverImage?.media : "",
    //       },
    //       {
    //         where: {
    //           id: element?.id,
    //         },
    //       }
    //     );
    //     console.log("uddateStore+++++++++++++++++++++++++", uddateStore);
    //   }
    // } catch (error) {
    //   console.log("error >>>>>>>>>>>>", error);
    // }
    return;
  },

  getClubSlugList: async (root, { slug, category_id, subCategory_id }, { user }) => {
    try {
      let find_club_slug = await database.Group.findAll({
        attributes: ["slug"],
        raw: true,
      });
      console.log("find_club_slug", find_club_slug);
      return { success: true, message: "Fetch successfully!", data: find_club_slug };
    } catch (error) {
      console.log(error);
    }
  },

  checkMemberStatus: async (root, { group_id }, { user }) => {
    if (user != null) {
      try {
        const find_group = await database.Group.findOne({ where: { id: group_id }, attributes: ["id"] });
        if (!find_group) {
          return {
            success: false,
            message: "Club not Found, Refresh your page",
            data: null,
          };
        }

        const isJoined = await database.JoinGroup.findOne({ where: { group_id: group_id, user_id: user?.id }, attributes: ["isAdmin", "isOwner"] });
        if (!isJoined) {
          return {
            success: false,
            message: "You are not in this Group",
            data: null,
          };
        }
        return {
          success: true,
          message: "Status Fetch Successfully",
          data: {
            isAdmin: isJoined?.isAdmin,
            isOwner: isJoined?.isOwner,
          },
        };
      } catch (error) {
        console.log("<<< error >>>", error);
      }
    } else {
      return new AuthenticationError("Please Provide the token");
    }
  },

  getClubsForAdmin: async (root, { input }, { user }) => {
    if (!user) return new AuthenticationError("Please Provide the token");
    if (user.role !== "admin") return new AuthenticationError("Unauthorized!");

    try {
      let findClub;
      if (input?.slug) {
        findClub = await database.Group.findOne({
          where: {
            slug: input?.slug,
            is_deleted: false
          },
          raw: true
        });
        if (!findClub) {
          return {
            success: false,
            message: "The Club has not been found.",
            data: []
          }
        }
      }


      const allClubs = await database.Group.findAll({
        where: {
          is_deleted: false,
          ...(input?.slug && {
            slug: input?.slug
          }),
          ...(input?.search && {
              [Op.or]: [
                {
                  name: {
                    [Op.iLike]: `%${input?.search}%`
                  }
                }
              ]
            } 
          ),
          ...(input?.category_id && {
            category_id: input?.category_id
          }),
          ...((input?.status === true || input?.status === false) && { isActive: input?.status })
        },
        attributes: {
          include: [
            [database.Sequelize.literal(`(SELECT COALESCE(CAST(COUNT(*) AS INTEGER), 0) FROM "JoinGroups" WHERE "JoinGroups"."group_id" = "Group"."id")`), "totalMembers"],
            [database.Sequelize.literal(`(SELECT COALESCE(CAST(COUNT(*) AS INTEGER), 0) FROM "Posts" WHERE "Posts"."group_id" = "Group"."id")`), "totalPosts"],
          ]
        },
        include: [
          {
            model: database.Category,
            as: "categoryDetails",
          },
          // {
          //   model: database.JoinGroup,
          //   as: "groups",
          //   include: [
          //     {
          //       model: database.User,
          //       as: "members"
          //     }
          //   ]
          // },
          // {
          //   model: database.Post,
          //   as: "posts",
          //   attributes: {
          //     include: [
          //       [database.Sequelize.literal(`(SELECT COALESCE(CAST(COUNT(*) AS INTEGER), 0) FROM "Likes" WHERE "Likes"."post_id" = "posts"."id")`), "totalLikes"],
          //       [database.Sequelize.literal(`(SELECT COALESCE(CAST(COUNT(*) AS INTEGER), 0) FROM "Comments" WHERE "Comments"."post_id" = "posts"."id")`), "totalComments"],
          //       [database.Sequelize.literal(`(SELECT COALESCE(CAST(COUNT(*) AS INTEGER), 0) FROM "SharePosts" WHERE "SharePosts"."post_id" = "posts"."id")`), "totalPostShares"]
          //     ]
          //   },
          //   include: [
          //     {
          //       model: database.User,
          //       as: "user"
          //     },
          //     // {
          //     //   model: database.Like,
          //     //   as: "likes"
          //     // },
          //     // {
          //     //   model: database.Comment,
          //     //   as: "comments"
          //     // }
          //   ]
          // }
        ]
      });
      
      const allClubsData = JSON.parse(JSON.stringify(allClubs));

      if (input?.slug) {

        const startDateOfLastMonth = moment().utc().subtract(1, "months").startOf("month").format("YYYY-MM-DD");
        const endDateOfLastMonth = moment().utc().subtract(1, "months").endOf("month").format("YYYY-MM-DD");

        const startOfDay = moment().utc().startOf("day").format("YYYY-MM-DD HH:mm:ss");
        const endOfDay = moment().utc().endOf("day").format("YYYY-MM-DD HH:mm:ss");


        const [
          totalMembers,
          // activeMembersToday,
          membersAddedLastMonth,
          totalPosts,
          newPostsToday,
          postsAddedLastMonth,
          // totalEngagement,
          // interactionsToday,
          // engagedLastMonth
        ] = await Promise.all([
          database.JoinGroup.count({
            where: {
              group_id: findClub?.id
            }
          }),

          database.JoinGroup.count({
            where: {
              group_id: findClub?.id,
              createdAt: {
                [Op.between]: [startDateOfLastMonth, endDateOfLastMonth]
              }
            }
          }),

          database.Post.count({
            where: {
              group_id: findClub?.id
            }
          }),

          database.Post.count({
            where: {
              group_id: findClub?.id,
              createdAt: {
                [Op.between]: [startOfDay, endOfDay]
              }
            }
          }),

          database.Post.count({
            where: {
              group_id: findClub?.id,
              createdAt: {
                [Op.between]: [startDateOfLastMonth, endDateOfLastMonth]
              }
            }
          }),
        ]);

        allClubsData[0].totalMembers = totalMembers;
        allClubsData[0].activeMembersToday = 0;
        allClubsData[0].membersAddedLastMonthPercentage = Math.round((membersAddedLastMonth / totalMembers) * 100);
        allClubsData[0].totalPosts = totalPosts;
        allClubsData[0].newPostsToday = newPostsToday;
        allClubsData[0].postsAddedLastMonthPercentage = Math.round((postsAddedLastMonth / totalPosts) * 100);
        allClubsData[0].totalEngagement = 0;
        allClubsData[0].interactionsToday = 0;
        allClubsData[0].engagedLastMonth = 0;
      }

      return {
        success: true,
        message: `The club/s fetched successfully`,
        data: allClubsData,
      }

    } catch (error) {
      console.error("An error occured while fetching The club/s for admin", error);
      throw new Error("An error occured while fetching The club/s for admin");
    }
  },
};
