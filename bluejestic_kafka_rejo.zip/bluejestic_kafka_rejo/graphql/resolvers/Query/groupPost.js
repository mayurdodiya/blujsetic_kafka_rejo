const { AuthenticationError } = require("apollo-server-express");

const GroupService = require("../../../database/services/groupPost");
const { Media, JoinGroup, User, Friend } = require("../../../database/models");
const { stringToUrl } = require("../../../middlewares/utils");

const Sequelize = require("sequelize");
const PostService = require("../../../database/services/post");
const FriendService = require("../../../database/services/friend");
const Op = Sequelize.Op;
module.exports = {
  getAllGroupPost: async (root, { group_id }, { user }) => {
    if (user !== null) {
      const group = await PostService.getAllGroupPost(group_id);
      async function checkStatusesForFriend(userId, friendId) {
        const friend = await Friend.findOne({
          where: {
            user_id: userId,
            friend_id: friendId,
          },
        });
        if (friend) {
          return {
            isActiveForFriendStatus: friend?.isActive || false,
            isFriendForFriendStatus: friend?.isFriend || false,
          };
        } else {
          return {
            isActiveForFriendStatus: false,
            isFriendForFriendStatus: false,
          };
        }
      }
      for (const res of group) {
        // user information
        if (res && res.user) {
          // user Followers

          res.user.followers = await FriendService.getMyFriends(user.id);

          // user Following

          res.user.followings = await FriendService.getMyFollowing(user.id);

          if (res.user.profileAvtar) {
            res.user.profileUrl = await Media.findOne({
              where: {
                id: res.user.profileAvtar ? res.user.profileAvtar[0] : 0,
              },
            }).then((res) => res.media);
          }
          if (res.user.profileCoverImage) {
            res.user.profileCoverImageUrl = await Media.findOne({
              where: {
                id: res.user.profileCoverImage
                  ? res.user.profileCoverImage[0]
                  : 0,
              },
            }).then((res) => res.media);
          }

          // user friend status

          let { isActiveForFriendStatus, isFriendForFriendStatus } =
            await checkStatusesForFriend(user.id, res.user.id);
          res.user.isActiveForFriendStatus = isActiveForFriendStatus;
          res.user.isFriendForFriendStatus = isFriendForFriendStatus;
        }

        // Comments user
        for (const comment of res.comments) {
          // set images of user
          if (comment.user.profileAvtar) {
            comment.user.profileUrl = await Media.findOne({
              where: {
                id: comment.user.profileAvtar
                  ? comment.user.profileAvtar[0]
                  : 0,
              },
            }).then((res) => res.media);
          }
          if (comment.user.profileCoverImage) {
            comment.user.profileCoverImageUrl = await Media.findOne({
              where: {
                id: comment.user.profileCoverImage
                  ? comment.user.profileCoverImage[0]
                  : 0,
              },
            }).then((res) => res.media);
          }
          // set friend status
          let { isActiveForFriendStatus, isFriendForFriendStatus } =
            await checkStatusesForFriend(user.id, comment.user.id);
          comment.user.isActiveForFriendStatus = isActiveForFriendStatus;
          comment.user.isFriendForFriendStatus = isFriendForFriendStatus;

          // comment user follower

          comment.user.followers = await FriendService.getMyFriends(comment.user.id);

          // comment user following
          comment.user.followings = await FriendService.getMyFollowing(comment.user.id);
        }
        // set medias
        if (res.media_id) {
          const media = await Media.findAll({
            where: {
              id: { [Op.in]: res.media_id ? res.media_id : [] },
            },
          }).then((img) => img);
          res.medias = media;
        } else {
          res.medias = [];
        }
      }
      return group;
    } else {
      return new AuthenticationError("Please Provide Token");
    }
  },
};
