const jwt = require("jsonwebtoken");
// const messages = require("../json/messages.json");
// Required Config
const JWT_SECRET = process.env.JWT_SECRET;
module.exports = async (req, res, next) => {
  // const token = req.headers.authorization.split(" ")[1]
  let token;
  if (req.headers.authorization !== undefined || null) {
    token = req.headers.authorization.split(" ")[1];
  } else {
    token = req.headers.token;
  }

  // Check for token
  if (!token) {
    return res.status(401).json({ success: false, message: "INVALID_TOKEN" });
  }
  try {
    // Verify token
    jwt.verify(token, JWT_SECRET, function (err, decoded) {
      if (err) {
        // console.log("err", err);
        return res.status(400).json({ success: false, message: err.message });
      }
      req.user = decoded;
      next();
    });
    // Add user from payload
  } catch (error) {
    console.error("An Error occured while authorizing the user: ", error);
    return res
      .status(500)
      .json({ success: false, message: "INTERNAL_SERVER_ERROR" });
  }
};
