
const multer = require("multer");
const multerGoogleStorage = require("multer-google-storage");
const uploadHandler = multer({
    storage: multerGoogleStorage.storageEngine({
        autoRetry: true,
        bucket: process.env.GCP_BUCKET_NAME,
        projectId: process.env.GCP_PROJECT_ID,
        keyFilename: process.env.GCP_CREDENTIALS_FILE_PATH,
        filename: (req, file, cb) => {
            let url;
            const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
            url = req.query.type + "/" + file.originalname.split(".")[0] +
                "-" +
                uniqueSuffix +
                "." +
                file.originalname.split(".")[file.originalname.split(".").length - 1]
            cb(null, url);
        }
    })
});

module.exports = { uploadHandler };