const database = require("../database/models");
module.exports = {
  stringToUrl: async (productImage, productId) => {
    let images = [];
    if (productImage !== null) {
      // convert in array
      // if (productImage.includes("{") && productImage.includes("}")) {
      //   images = JSON.parse(productImage.replace(/{/g, "[").replace(/}/g, "]"));
      // check is array or not
      images = productImage;
      if (Array.isArray(images)) {
        if (images.length === 0) {
          productImage = [];
        } else {
          for (let i = 0; i < images.length; i++) {
            let mediaData = await database.Media.findOne({
              where: { id: images[i] },
            }).then((data) => data);

            // let update = await database.Media.update(
            //   {
            //     parent_id: productId,
            //   },
            //   {
            //     where: { id: images[i] },
            //   }
            // )
            // .then((data) => console.log("DATA", data))
            // .catch((err) => console.log("ERR", err));
            images[i] = mediaData.media;
          }
          // product image with array of url
          productImage = images;
          return productImage;
        }
      }
      // }
    } else {
      return [];
    }
  },
  stringToUrlWithId: async (productImage, productId) => {
    let images = [];
    let result = [];
    if (productImage !== null) {
      // convert in array
      // if (productImage.includes("{") && productImage.includes("}")) {
      //   images = JSON.parse(productImage.replace(/{/g, "[").replace(/}/g, "]"));
      // check is array or not
      // productImage =
      if (Array.isArray(images)) {
        if (images.length === 0) {
          productImage = [];
        } else {
          for (let i = 0; i < images.length; i++) {
            let mediaData = await database.Media.findOne({
              where: { id: images[i] },
            }).then((data) => data);

            let update = await database.Media.update(
              {
                parent_id: productId,
              },
              {
                where: { id: images[i] },
              }
            )
              // .then((data) => console.log("DATA", data))
              .catch((err) => console.log("ERR", err));
            let objectForImageAndId = {
              id: mediaData.id,
              url: mediaData.media,
            };
            result.push(objectForImageAndId);
          }
          // product image with array of url
          productImage = result;
          return productImage;
        }
      }
      // }
    } else {
      return [];
    }
  },

  mediaWithUrlAndnId: async (images, productId) => {
    let result = [];
    if (images !== null) {
      if (Array.isArray(images)) {
        for (let i = 0; i < images.length; i++) {
          let mediaData = await database.Media.findOne({
            where: { id: images[i] },
          }).then((data) => data);

          let update = await database.Media.update(
            {
              parent_id: productId,
            },
            {
              where: { id: images[i] },
            }
          )
            .catch((err) => console.log("ERR", err));
          let objectForImageAndId = {
            id: mediaData.id,
            url: mediaData.media,
          };
          result.push(objectForImageAndId);
        }
        // product image with array of url
        images = result;
        return images;
      }
      // }
    } else {
      return [];
    }
  },
};
