const AWS = require("aws-sdk");
// store each image in it's own unique folder to avoid name duplicates
const { uuid } = require("uuidv4");
var fs = require("fs");
const path = require("path");
// const fs = require("fs");
// load config data from .env file
require("dotenv").config();
// update AWS config env data
AWS.config.update({
  accessKeyId: process.env.AWS_ACCESS_ID,
  secretAccessKey: process.env.AWS_SECRET_KEY,
  region: process.env.AWS_REGION,
});
const s3 = new AWS.S3({ region: process.env.AWS_REGION });

// my default params for s3 upload
// I have a max upload size of 1 MB
const s3DefaultParams = {
  ACL: "public-read",
  Bucket: process.env.S3_BUCKET_NAME,
  Conditions: [{ acl: "public-read" }],
};

// the actual upload happens here
const handleFileUpload = async (file) => {
  const { createReadStream, filename, mimetype, resolve, reject } = await file;
  // const stream = createReadStream();

  // console.log("stream", resolve);
  const stream = createReadStream();

  const out = require("fs").createWriteStream("local-file-output.txt");
  stream.pipe(out);
  await streamPromise(out);

  // const capacitor = new WriteStream();
  // console.log("stream", capacitor);
  // stream.pipe(capacitor);
  // capacitor.createReadStream();
  // let stream;
  // var readStream = createReadStream(filename);
  // stream
  //   .then((stream) => {
  //     console.log("streamQQQQQQQQQQQQ", stream);
  //   })
  //   .catch((err) => {
  //     console.log("errQQQQQQQQQQQQ", err);
  //   });

  // const pathname = path.join(__dirname, "../../images");
  // await stream.pipe(fs.createReadStream(pathname));

  // fs.createReadStream(__dirname + "/1.txt", {  encoding: "base64" }).pipe(
  //   concat(function (data) {
  //     console.log("got data", data);
  //   })
  // );

  const key = uuid();

  // console.log("key@@@@@@@@@@@", key);
  // function stream2buffer(stream) {
  //   console.log("===========");
  //   return new Promise((resolve, reject) => {
  //     const _buf = [];

  //     stream.on("data", (chunk) => _buf.push(chunk));
  //     stream.on("end", () => {
  //       console.log("Buffer.concat(_buf)", Buffer.concat(_buf));
  //       return resolve(Buffer.concat(_buf));
  //     });
  //     stream.on("error", (err) => reject(err));
  //   });
  // }
  // console.log(":::::::::::::");
  // console.log(
  //   "stream2buffer(createReadStream)",
  //   stream2buffer(createReadStream())
  // );
  return new Promise((resolve, reject) => {
    s3.upload(
      {
        ...s3DefaultParams,
        Body: encoding,
        ACL: "public-read",
        Key: `${filename}`,
      },
      (err, data) => {
        if (err) {
          console.log("error uploading...", err);
          reject(err);
        } else {
          console.log("successfully uploaded file...", data);
          resolve(data);
        }
      }
    );
  });
};

module.exports = {
  handleFileUpload,
};
