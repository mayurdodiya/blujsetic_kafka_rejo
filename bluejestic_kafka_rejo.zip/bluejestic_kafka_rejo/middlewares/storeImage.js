const enums = require("../json/enum.json");
const messages = require("../json/message.json");
// const roleMaster = require("../../models/roleMaster/roleMasterSchema");
const aws = require("aws-sdk");
const multer = require("multer");
const multerS3 = require("multer-s3");
require("dotenv").config();
aws.config.update({
    accessKeyId: process.env.AWS_ACCESS_ID,
    secretAccessKey: process.env.AWS_SECRET_KEY,
    region: process.env.AWS_REGION,
});
const s3 = new aws.S3();
const upload = multer({
    // fileFilter,
    storage: multerS3({
        s3,
        bucket: process.env.S3_BUCKET_NAME,
        // acl: "public-read",
        metadata: function (req, file, cb) {
            console.log("req.body EC222222222222222222222222", req.query);
            cb(null, { fieldName: file.fieldname });
        },
        key: async function (req, file, cb) {
            // console.log("req.body EC222222222222222222222222", req.body);
            let url;
            const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
            url = req.query.type + "/" + file.originalname.split(".")[0] +
                "-" +
                uniqueSuffix +
                "." +
                file.originalname.split(".")[file.originalname.split(".").length - 1]

            cb(
                null,
                url
            );
        },
    }),
    limits: {
        fileSize: 1024 * 1024 * 1000, // we are allowing only 2 MB files
    },
});
let deleteFileFromS3 = async (key) => {
    console.log("key", key);
    if(!key)     return { success: true, message: "Image not found" }

    let url = key.split(".com/")[1];
    let params = {
        Bucket: process.env.S3_BUCKET_NAME,
        Key: url,
    };
    console.log("params", params);
    const util = require('util');

    const getObject = util.promisify(s3.getObject.bind(s3));
    const deleteObject = util.promisify(s3.deleteObject.bind(s3));

    try {
        const existsImage = await getObject(params);

        if (existsImage) {
            await deleteObject(params);
            console.log("File deleted from S3 bucket successfully");
        } else {
            console.log("File does not exist in the S3 bucket");
        }
    } catch (err) {
        console.log("Errrrr - > ", err.message);
        return { success: false, message: err.message }
    }
    return { success: true, message: "File deleted from S3 bucket successfully" }
}
module.exports = { upload, deleteFileFromS3 };
