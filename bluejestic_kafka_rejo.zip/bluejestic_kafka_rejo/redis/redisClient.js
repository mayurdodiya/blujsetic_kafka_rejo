const { Redis } = require("ioredis");

const MEMORY_THRESHOLD = 2 * 1024 * 1024 * 1024;
const CHECK_INTERVAL = 60000; // Check every 60 seconds
const redisClient = new Redis({
  host: process.env.REDIS_HOST,
  password: process.env.REDIS_PASSWORD,
  port: process.env.REDIS_PORT,
  user: process.env.REDIS_USER,
  retryStrategy: function (times) {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
  reconnectOnError: function (err) {
    const targetError = "READONLY";
    if (err.message.includes(targetError)) {
      // Only reconnect when the error contains "READONLY"
      return true;
    }
    return false;
  },
});

const monitorAndFlush = async () => {
  try {
    const memoryInfo = await redisClient.info("memory");
    const usedMemoryMatch = memoryInfo.match(/used_memory:(\d+)/);
    const usedMemory = usedMemoryMatch ? parseInt(usedMemoryMatch[1], 10) : 0;
        
    if (usedMemory > MEMORY_THRESHOLD) {
      console.log('Memory usage exceeded threshold. Flushing database...');
      await redisClient.flushdb();
      console.log('Database flushed successfully.');
    }

  } catch (error) {
    console.error('An error occurred while monitoring Redis memory:', error);
  }
}

setInterval(() => {
  monitorAndFlush();
}, CHECK_INTERVAL);

redisClient.on("connect", () => {
  console.log("[Redis] Successfully connected to Redis server.");
});

redisClient.on("error", (err) => {
  console.error("[Redis] Error connecting to redisClient", err);
});

module.exports = redisClient;
